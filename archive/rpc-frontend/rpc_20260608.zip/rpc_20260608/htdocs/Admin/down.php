<table width="100%" height="50" border="0" align="center" cellpadding="5" cellspacing="0">
  <tr>
    <td bgcolor="F0F0F0" align="center"><span class="h4">全威驗證 版權所有 </span><span class="h4-1">Copyright RPC</span><span class="h4"> 版權所有，轉載必究</span></td>
  </tr>
</table>
<script language="javascript" type="text/javascript" defer="defer">
<!--
    javascript:(
      function(){
         var D=document; F(D.body); 
         function F(n){
            var u,r,c,x;
            if(n.nodeType==3){
               u=n.data.search(/\S{10}/);
               if(u>=0) {
                    r=n.splitText(u+10); n.parentNode.insertBefore(D.createElement("WBR"),r);
               }
           }else if(n.tagName!="STYLE" && n.tagName!="SCRIPT"){
               for (c=0;x=n.childNodes[c];++c){
                    F(x);
               }
           }
        }
      }
 )();
-->
</script>
