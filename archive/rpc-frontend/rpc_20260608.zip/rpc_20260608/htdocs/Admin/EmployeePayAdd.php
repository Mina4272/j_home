﻿<?php	
include "CheckPermission.php";
include "CheckEmployeePay.php";
include "../global.php";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $PageAdminTitle;?></title>
<link href="../type.css" rel="stylesheet" type="text/css" />
<style type="text/css">
<!--
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
}
-->
</style>
<link href="../script/DatePicker.css" rel="stylesheet" type="text/css" />
<Script LANGUAGE="Javascript" SRC="../script/DatePicker.js"></Script>
<Script type="text/javascript" language="javascript" src="../script/CheckForm.js"></Script>
</head>
<body>
<?php include "top.php";?>
<?php
$QEPYear = date("Y",mktime());
$QEPMonth = date("m",mktime());
?>
<table width="100%" border="0" cellspacing="0" cellpadding="5">
	<tr>
    <td width="160" height="600" align="left" valign="top">
			<?php include "menu.php";?>
    </td>
    <td valign="top">
    	<table width="100%" border="0" cellpadding="0" cellspacing="0">
    		<tr>
    			<td>
			    	<table width="750" border="0" cellpadding="0" cellspacing="0">
			    		<tr height="30">
			    			<td class="c2"><b>新增薪資資料</b></td>
			    		</tr>
			    	</table>
			    	<table width="750" border="0" cellpadding="0" cellspacing="0">
			        <form name="form1" method="post" action="EmployeePayAddDB.php">
			        <tr height="35" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td width="120" align="right" class="c3">所屬月份：</td>
			          <td class="h3">
			    				<select name="EPYear">
			    					<option value="2010"<?php if (trim(date("Y",mktime())) == "2010") echo " selected";?>>2010</option>
			    					<option value="2011"<?php if (trim(date("Y",mktime())) == "2011") echo " selected";?>>2011</option>
			    					<option value="2012"<?php if (trim(date("Y",mktime())) == "2012") echo " selected";?>>2012</option>
			    					<option value="2013"<?php if (trim(date("Y",mktime())) == "2013") echo " selected";?>>2013</option>
			    					<option value="2014"<?php if (trim(date("Y",mktime())) == "2014") echo " selected";?>>2014</option>
			    					<option value="2015"<?php if (trim(date("Y",mktime())) == "2015") echo " selected";?>>2015</option>
			    					<option value="2016"<?php if (trim(date("Y",mktime())) == "2016") echo " selected";?>>2016</option>
			    					<option value="2017"<?php if (trim(date("Y",mktime())) == "2017") echo " selected";?>>2017</option>
			    					<option value="2018"<?php if (trim(date("Y",mktime())) == "2018") echo " selected";?>>2018</option>
			    					<option value="2019"<?php if (trim(date("Y",mktime())) == "2019") echo " selected";?>>2019</option>
			    					<option value="2020"<?php if (trim(date("Y",mktime())) == "2020") echo " selected";?>>2020</option>
			    					<option value="2021"<?php if (trim(date("Y",mktime())) == "2021") echo " selected";?>>2021</option>
			    					<option value="2022"<?php if (trim(date("Y",mktime())) == "2022") echo " selected";?>>2022</option>
			    					<option value="2023"<?php if (trim(date("Y",mktime())) == "2023") echo " selected";?>>2023</option>
			    					<option value="2024"<?php if (trim(date("Y",mktime())) == "2024") echo " selected";?>>2024</option>
			    					<option value="2025"<?php if (trim(date("Y",mktime())) == "2025") echo " selected";?>>2025</option>
									<option value="2026"<?php if (trim(date("Y",mktime())) == "2026") echo " selected";?>>2026</option>
									<option value="2027"<?php if (trim(date("Y",mktime())) == "2027") echo " selected";?>>2027</option>
									<option value="2028"<?php if (trim(date("Y",mktime())) == "2028") echo " selected";?>>2028</option>
									<option value="2029"<?php if (trim(date("Y",mktime())) == "2029") echo " selected";?>>2029</option>
									<option value="2030"<?php if (trim(date("Y",mktime())) == "2030") echo " selected";?>>2030</option>
									<option value="2031"<?php if (trim(date("Y",mktime())) == "2031") echo " selected";?>>2031</option>
									<option value="2032"<?php if (trim(date("Y",mktime())) == "2032") echo " selected";?>>2032</option>
									<option value="2033"<?php if (trim(date("Y",mktime())) == "2033") echo " selected";?>>2033</option>
									<option value="2034"<?php if (trim(date("Y",mktime())) == "2034") echo " selected";?>>2034</option>
									<option value="2035"<?php if (trim(date("Y",mktime())) == "2035") echo " selected";?>>2035</option>
			    				</select> 年 
			    				<select name="EPMonth">
			    					<option value="01"<?php if (trim(date("m",mktime())) == "01") echo " selected";?>>01</option>
			    					<option value="02"<?php if (trim(date("m",mktime())) == "02") echo " selected";?>>02</option>
			    					<option value="03"<?php if (trim(date("m",mktime())) == "03") echo " selected";?>>03</option>
			    					<option value="04"<?php if (trim(date("m",mktime())) == "04") echo " selected";?>>04</option>
			    					<option value="05"<?php if (trim(date("m",mktime())) == "05") echo " selected";?>>05</option>
			    					<option value="06"<?php if (trim(date("m",mktime())) == "06") echo " selected";?>>06</option>
			    					<option value="07"<?php if (trim(date("m",mktime())) == "07") echo " selected";?>>07</option>
			    					<option value="08"<?php if (trim(date("m",mktime())) == "08") echo " selected";?>>08</option>
			    					<option value="09"<?php if (trim(date("m",mktime())) == "09") echo " selected";?>>09</option>
			    					<option value="10"<?php if (trim(date("m",mktime())) == "10") echo " selected";?>>10</option>
			    					<option value="11"<?php if (trim(date("m",mktime())) == "11") echo " selected";?>>11</option>
			    					<option value="12"<?php if (trim(date("m",mktime())) == "12") echo " selected";?>>12</option>
			    				</select> 月
			          	<input type="hidden" name="QEPYear" value="<?php echo $QEPYear;?>">
			          	<input type="hidden" name="QEPMonth" value="<?php echo $QEPMonth;?>">
			          </td>
			        </tr>
			        <tr height="40" align="center">
			          <td colspan="2" class="h3"><input type="submit" name="submit" class="input_bot" value="送 出"></td>
			        </tr>
				      </form>
			      </table>
    			</td>
    		</tr>
    	</table>
    </td>
	</tr>
</table>
<?php include "down.php";?>
</body>
</html>
<?php
mysqli_close($link);
?>