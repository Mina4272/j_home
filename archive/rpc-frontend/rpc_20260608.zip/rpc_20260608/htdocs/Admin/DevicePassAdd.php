<?php	
include "CheckPermission.php";
//include "CheckAgendum.php";
include "../global.php";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $PageAdminTitle;?></title>
<link href="../type.css" rel="stylesheet" type="text/css" />
<style type="text/css">
<!--
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
}
-->
</style>
<link href="../script/DatePicker.css" rel="stylesheet" type="text/css" />
<Script LANGUAGE="Javascript" SRC="../script/DatePicker.js"></Script>
<Script type="text/javascript" language="javascript" src="../script/CheckForm.js"></Script>
<script type="text/JavaScript">
<!--
function jsCheck() 
		{
		if (ChkImp('DP_place',document.form1.DP_place.value,'地點') == false) return false;
		if (ChkDate('DSYear',document.form1.DSYear.value,document.form1.DSMonth.value,document.form1.DSDay.value,'攜出日期') == false) return false;
		if (ChkDate('DTYear',document.form1.DTYear.value,document.form1.DTMonth.value,document.form1.DTDay.value,'歸還日期') == false) return false;
		if (ChkImp('DP_status',document.form1.DP_status.value,'儀器查核') == false) return false;
		}
//-->
</script>
</head>
<body>
<?php
$device_no = $_GET['device_no'];
if (trim($device_no) == "")
		{
		mysqli_close($link);
		?>
		<script type="text/JavaScript">
			<!--
			alert ("查無資料，請冾網站管理人員！");
			self.close();
			//-->
		</script>
		<?php
		exit;
		}
?>
<table width="100%" border="0" cellpadding="0" cellspacing="0">
	<tr>
		<td>
    	<table width="100%" border="0" cellpadding="0" cellspacing="0">
    		<tr height="30">
					<td width="15" background="../images/table_bg.gif"></td>
    			<td class="c3" background="../images/table_bg.gif"><b>新增儀器進出管制</b></td>
    		</tr>
    	</table>
    	<table width="100%" border="0" cellpadding="0" cellspacing="0">
        <form name="form1" method="post" action="DevicePassAddDB.php" onSubmit="return jsCheck();">
		<?php
							$SQL_Manager="select MUID,MName,MEName from Manager where Deltag='N' and IsLeft='N';";
							$result_Manager=mysqli_query($link,$SQL_Manager) or die ("無法執行查詢");
			        ?>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td width="150" align="right" class="c3">攜出人員</td>
			          <td class="h3">
			          	<select id="DP_people" name="DP_people" >
			          		<?php while(list($MUID,$MName,$MEName)=mysqli_fetch_row($result_Manager)){?>
			          		<option value="<?php echo $MName;?>"><?php echo $MEName.$MName;?></option>
			          		<?php }?>
			          	</select>
			          </td>
			        </tr>
			        <?php mysqli_free_result($result_Manager);?>
		<tr  onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
		  <td width="auto" class="c3">地點:</td>
		  <td class="h3"><input type="text" id="DP_place" name="DP_place" size="60"></td>
        </tr>
        <tr  onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td width="70" class="c3">攜出<br/>日期:</td>
			          <td class="h3">
		              <input id="DSYear" name="DSYear" type="text" size="4" /> 年 
		              <input id="DSMonth" name="DSMonth" type="text" size="2" /> 月 
		              <input id="DSDay" name="DSDay" type="text" size="2" /> 日 
		              <img src="../images/icon.gif" width="16" height="18" style="cursor: hand" onclick="javascript:displayDatePicker('DSYear','DSMonth','DSDay');"/>
			          </td>
			        </tr>
		<tr  onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td width="auto" class="c3">歸還<br/>日期:</td>
			          <td class="h3">
		              <input id="DTYear" name="DTYear" type="text" size="4" /> 年 
		              <input id="DTMonth" name="DTMonth" type="text" size="2" /> 月 
		              <input id="DTDay" name="DTDay" type="text" size="2" /> 日 
		              <img src="../images/icon.gif" width="16" height="18" style="cursor: hand" onclick="javascript:displayDatePicker('DTYear','DTMonth','DTDay');"/>
			          </td>
			        </tr>
		<tr  onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
		  <td width="auto" class="c3">儀器<br/>查核:</td>
		  <td class="h3"><input type="text" id="DP_status" name="DP_status" size="60"></td>
        </tr>
        <tr height="40" align="center">
			<td width="15"><input name="device_no" type="hidden" id="device_no" value="<?php echo $device_no;?>" /></td>
          <td class="h3"><input type="submit" name="submit" class="input_bot" value="送 出"></td>
        </tr>
	      </form>
      </table>
		</td>
	</tr>
</table>
</body>
</html>
<?php
mysqli_close($link);
?>