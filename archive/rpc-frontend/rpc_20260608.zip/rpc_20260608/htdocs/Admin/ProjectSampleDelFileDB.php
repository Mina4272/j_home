﻿<?php
include "CheckPermission.php";
include "CheckProject.php";
include "../global.php";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $PageAdminTitle;?></title>
</head>
<body>
<?php
$PID = $_GET['PID'];
$PSID = $_GET['PSID'];
$page = $_GET['page'];
if (trim($PID) == "" || trim($PSID) == "")
		{
		mysqli_close($link);
		?>
		<script type="text/JavaScript">
			<!--
			alert ("您輸入的資料不足，請重新輸入！");
			history.go(-1);
			//-->
		</script>
		<?php
		exit;
		}
$SQL_ProjectSample="select PSType,PSDate,date_format(PSDate,'%Y'),date_format(PSDate,'%m'),date_format(PSDate,'%d'),PSCount,PSMode,PSPersonnel,PSNote,AddUser,AddDate,ProcUser,ProcDate from ProjectSample where Deltag='N' and PID = '".$PID."' and PSID = '".$PSID."';";
$result_ProjectSample=mysqli_query($link,$SQL_ProjectSample) or die ("無法執行查詢");
if (mysqli_num_rows($result_ProjectSample) == 0)
		{
		mysqli_free_result($result_ProjectSample);
		mysqli_close($link);
		?>
		<SCRIPT language=javascript>
		<!--
		alert ("查無資料，請冾網站管理人員！"); 
		history.go(-1);
		//-->
		</SCRIPT>
		<?php 	
		exit;
		}
mysqli_free_result($result_ProjectSample);

$now_time = date("Y-m-d H:i:s",mktime());

$sql_insert = "INSERT INTO ProjectSampleHistory(PSID,PID,PSType,PSDate,PSCount,PSMode,PSPersonnel,SPlace,IPlace,PSend,PSNote,PSFile,AddUser,AddDate,AddIP,Deltag,ProcUser,ProcDate,ProcIP,UpdateUser,UpdateDate,UpdateIP) SELECT PSID,PID,PSType,PSDate,PSCount,PSMode,PSPersonnel,SPlace,IPlace,PSend,PSNote,PSFile,AddUser,AddDate,AddIP,Deltag,ProcUser,ProcDate,ProcIP,'".$_SESSION["reg_MUID"]."','".$now_time."','".$_SERVER["REMOTE_ADDR"]."' FROM ProjectSample where Deltag='N' and PID = '".$PID."' and PSID = '".$PSID."';";
$result_insert=mysqli_query($link,$sql_insert) or die ("無法執行新增");
$sql_update = "update ProjectSample set PSFile = '',ProcUser = '".$_SESSION["reg_MUID"]."',ProcDate = '".$now_time."',ProcIP = '".$_SERVER["REMOTE_ADDR"]."' where Deltag='N' and PID = '".$PID."' and PSID = '".$PSID."';";
$result_update=mysqli_query($link,$sql_update) or die ("無法執行修改");

mysqli_close($link);
?>
<script type="text/JavaScript">
	<!--
	alert ("刪除成功！");
	location.href="ProjectSampleEdit.php?PID=<?php echo $PID;?>&PSID=<?php echo $PSID;?>&page=<?php echo $page;?>";
	//-->
</script>

</body>
</html>
