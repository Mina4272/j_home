﻿<?php
include "CheckPermission.php";
include "CheckMVac.php";
include "../global.php";
require_once 'PHPExcel.php';

$MVYear = $_POST['MVYear'];
$MVMonth = $_POST['MVMonth'];
$MVDay = date("t",strtotime($MVYear."-".$MVMonth."-01"));

$SQL_Manager="select MUID,MName from Manager where Deltag='N' and IsLeft='N' order by MID;";
$result_Manager=mysqli_query($link,$SQL_Manager) or die ("無法執行查詢");

while(list($MUID,$MName)=mysqli_fetch_row($result_Manager)){
		
	$SQL_Vac="select MUID,Hourage,MVSDate,MVEDate as MVEDate from managervac where Deltag='N' and MVCheck='Y' and MUID='".$MUID."' and left(MVSDate,7)='".$MVYear."-".$MVMonth."'";
	//echo $SQL_Vac;
	$result_Vac=mysqli_query($link,$SQL_Vac) or die ("無法執行查詢");
	
	while(list($MUID1,$Hourage,$MVSDate,$MVEDate)=mysqli_fetch_row($result_Vac)){
		
			//echo "123";
			//$Count = ceil($Hourage/8);
		
		$days= round((strtotime($MVEDate)-strtotime($MVSDate))/3600/24);
		//echo $days;
		//echo '<br>';
		if($days != 0){
				
			for($i=0;$i <= $days;$i++){
					
				
					
				$Date = date("Y-m-d",strtotime("+".$i." day",strtotime($MVSDate)));
								
				if($i==0){
					$start = date("Y-m-d H:i:s",strtotime("+".$i." day",strtotime($MVSDate)));
				}else{
					$start = date("Y-m-d H:i:s",strtotime("+".$i." day",strtotime(substr($MVSDate,0,10)." 08:30:00")));
				}	
				
					
				//echo $i;
				//echo '<br>';
				//echo $days;
				//echo '<br>';
				if($i != $days){
					//echo '1';
					$end = date("Y-m-d H:i:s",strtotime("+".$i." day",strtotime(substr($MVSDate,0,10)." 17:30:00")));
				}else{
					//echo '2';
					$end = date("Y-m-d H:i:s",strtotime($MVEDate));
				}
								
								//$end = date("Y-m-d",strtotime("+".$j." day",strtotime(substr($item[$stime],0,10)." 18:00:00")));
				$hours = round((strtotime($end)-strtotime($start))/3600);
				//echo $start;
				//echo $end ;
				//echo "<br>";
				$h = 0;
				if(abs($hours) == 9){
					$h = abs($hours) -1;
				}else{
					$h = abs($hours);
				}
				$Vac[$MUID1][$Date] = $h;
					
			}
				
		}else{
			$Vac[$MUID1][$MVSDate] = $Hourage;
		}
		
		
	
	
	}
	mysqli_free_result($result_Vac);
	
	
	
	//$Manager[$MUID]=$MName;
}
mysqli_free_result($result_Manager);

//echo "<pre>";
//var_dump($Vac);
//exit;

foreach($Vac as $k => $v){
	foreach($v as $ky => $va){
		$INSERT="INSERT INTO mvac (MUID, MVSDate,Hourage) VALUES ('".$k."', '".$ky."', '".$va."')";
		//echo $INSERT;
		mysqli_query($link,$INSERT);
	}
}

//exit;

$objPHPExcel = new PHPExcel();
$objPHPExcel->setActiveSheetIndex(0);

$objPHPExcel->getActiveSheet()->setCellValue('A1', '請假時數');

$tmp=66;

$SQL_Manager="select MUID,MName from Manager where Deltag='N' and IsLeft='N' order by MID;";
$result_Manager=mysqli_query($link,$SQL_Manager) or die ("無法執行查詢");
while(list($MUID,$MName)=mysqli_fetch_row($result_Manager)){
	
	$objPHPExcel->getActiveSheet()->setCellValue(chr($tmp).'1',$MName);
	$tmp++;
}
mysqli_free_result($result_Manager);
$Ecount=2;
for($day=1;$day<=$MVDay;$day++){
	$objPHPExcel->getActiveSheet()->setCellValue('A'.$Ecount,$MVYear."-".$MVMonth."-".$day);
	$SQL_Manager="select MUID,ifnull((select sum(Hourage) from mvac where MUID=Manager.MUID and date(MVSDate)='".$MVYear."-".$MVMonth."-".$day."'),0) Quantity from Manager where Deltag='N' and IsLeft='N' order by MID;";
	//echo $SQL_Manager;
	//echo '<br/>';
	$result_Manager=mysqli_query($link,$SQL_Manager) or die ("無法執行查詢");
	$tmp=66;
	while(list($MUID,$Quantity)=mysqli_fetch_row($result_Manager)){
		
		$objPHPExcel->getActiveSheet()->setCellValue(chr($tmp).''.$Ecount,$Quantity);
		$QuantitySum[$MUID]=$QuantitySum[$MUID]+$Quantity;
			$tmp++;
	}
	mysqli_free_result($result_Manager);
	$Ecount++;
}
//exit;
$objPHPExcel->getActiveSheet()->setCellValue('A'.$Ecount,"總計");

$tmp=66;
//$SQL_Manager="select MUID,MName from Manager where Deltag='N' order by MID;";
$SQL_Manager="select MUID,MName from Manager where Deltag='N' and IsLeft='N' order by MID;";
$result_Manager=mysqli_query($link,$SQL_Manager) or die ("無法執行查詢");
while(list($MUID,$MName)=mysqli_fetch_row($result_Manager)){
	
	$objPHPExcel->getActiveSheet()->setCellValue(chr($tmp).''.$Ecount,$QuantitySum[$MUID]);
	$tmp++;
}
mysqli_free_result($result_Manager);

$Ecount++;
$Ecount++;
$leavetext;
for($leave='A';$leave<='I';$leave++){
	switch ($leave) {
		case 'A':
			$leavetext="事假";
		break;
		case 'B':
			$leavetext="病假";
		break;
		case 'C':
			$leavetext="公假";
		break;
		case 'D':
			$leavetext="喪假";
		break;
		case 'E':
			$leavetext="婚假";
		break;
		case 'F':
			$leavetext="產假";
		break;
		case 'G':
			$leavetext="特休";
		break;
		case 'I':
			$leavetext="生理假";
		break;
		case 'H':
			$leavetext="其他";
		break;
		
	}
	$objPHPExcel->getActiveSheet()->setCellValue('A'.$Ecount,$leavetext);
	$SQL_Manager="select MUID,ifnull((select sum(Hourage) from managervac where Deltag='N' and MVCheck='Y' and MUID=Manager.MUID and MVType ='".$leave."' and left(MVSDate,7)='".$MVYear."-".$MVMonth."'),0) Quantity from Manager where Deltag='N' and IsLeft='N' order by MID;";
	//echo $SQL_Manager;
	$result_Manager=mysqli_query($link,$SQL_Manager) or die ("無法執行查詢");
	$tmp=66;
	while(list($MUID,$Quantity)=mysqli_fetch_row($result_Manager)){
		
		$objPHPExcel->getActiveSheet()->setCellValue(chr($tmp).''.$Ecount,$Quantity);
		$QuantitySum[$MUID]=$QuantitySum[$MUID]+$Quantity;
			$tmp++;
	}
	mysqli_free_result($result_Manager);
	$Ecount++;
}


$Del="DELETE FROM mvac";
mysqli_query($link,$Del);






		
$objPHPExcel->getActiveSheet()->setTitle('MVacExportSummaryDB');

ob_end_clean();

header('Content-Type: application/vnd.ms-excel');
header('Content-Disposition: attachment;filename="MVacExportSummaryDB.xls"');
header('Cache-Control: max-age=0');
$objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel5');
$objWriter->save('php://output');
exit;

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $PageAdminTitle;?></title>
<link href="style.css" rel="stylesheet" type="text/css" />
<body>
<table winth="1000" border="0">
	<tr>
		<td colspan="2"><font color=blue>若您無法正常觀看此報表！請下載此 <a href="owc11.zip" target="_File"><font color=red><b>元件</b></font></a> <font color=blue>安裝至您的電腦。</font></td>
	</tr>
</table>
<object id=ProjectAccounting classid=CLSID:0002E559-0000-0000-C000-000000000046 style="width:100%;height:90%"></object>
<script language=vbscript>
	Sub Window_OnLoad()
	Set chConstants = ProjectAccounting.Constants
	ProjectAccounting.ActiveSheet.Cells.Clear
	ProjectAccounting.Worksheets(1).Select
	ProjectAccounting.ActiveSheet.Name ="ProjectAccounting"

	ProjectAccounting.ActiveSheet.Cells(1,1).Value ="<?php echo $MFTypeTxt;?>"
	<?php
	$tmp=2;
	//$SQL_Manager="select MUID,MName from Manager where Deltag='N' order by MID;";
	$SQL_Manager="select MUID,MName from Manager where Deltag='N' and IsLeft='N' order by MID;";
	$result_Manager=mysqli_query($link,$SQL_Manager) or die ("無法執行查詢");
	while(list($MUID,$MName)=mysqli_fetch_row($result_Manager)){
		?>
		ProjectAccounting.ActiveSheet.Cells(1,<?php echo $tmp?>).Value ="<?php echo $MName;?>"
		<?php
		$tmp++;
		}
	mysqli_free_result($result_Manager);
	$ECount=2;
	for($day=1;$day<=$MFDay;$day++){
		?>
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,1).Value ="'<?php echo $MFYear."-".$MFMonth."-".$day;?>"
		<?php
		//$SQL_Manager="select MUID,ifnull((select sum(Quantity) from ManagerFees where Deltag='N' and MFCheck='Y' and MFType='".$MFType."' and MUID=Manager.MUID and MFDate='".$MFYear."-".$MFMonth."-".$day."'),0) Quantity from Manager where Deltag='N' order by MID;";
		$SQL_Manager="select MUID,ifnull((select sum(Quantity) from ManagerFees where Deltag='N' and IsLeft='N' and MFCheck='Y' and MFType='".$MFType."' and MUID=Manager.MUID and MFDate='".$MFYear."-".$MFMonth."-".$day."'),0) Quantity from Manager where Deltag='N' and IsLeft='N' order by MID;";
		$result_Manager=mysqli_query($link,$SQL_Manager) or die ("無法執行查詢");
		$tmp=2;
		while(list($MUID,$Quantity)=mysqli_fetch_row($result_Manager)){
			?>
			ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,<?php echo $tmp;?>).Value ="<?php echo $Quantity;?>"
			<?php
			$QuantitySum[$MUID]=$QuantitySum[$MUID]+$Quantity;
			$tmp++;
			}
		mysqli_free_result($result_Manager);
			?>
		<?php 
		$ECount++;
		}
	?>
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,1).Value ="總計"
		<?php
		$tmp=2;
		//$SQL_Manager="select MUID,MName from Manager where Deltag='N' order by MID;";
		$SQL_Manager="select MUID,MName from Manager where Deltag='N' and IsLeft='N' order by MID;";
		$result_Manager=mysqli_query($link,$SQL_Manager) or die ("無法執行查詢");
		while(list($MUID,$MName)=mysqli_fetch_row($result_Manager)){
			?>
			ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,<?php echo $tmp?>).Value ="<?php echo $QuantitySum[$MUID];?>"
			<?php
			$tmp++;
			}
		mysqli_free_result($result_Manager);
		?>
		ProjectAccounting.ActiveSheet.Range("A1:ZZ<?php echo $ECount;?>").Font.Color="blue"
		ProjectAccounting.ActiveSheet.Range("A1:ZZ<?php echo $ECount;?>").Font.Name="Courier New"
		ProjectAccounting.ActiveSheet.Range("A1:ZZ<?php echo $ECount;?>").Font.Size="11"
		ProjectAccounting.ActiveSheet.Range("A1:ZZ<?php echo $ECount;?>").Columns.AutoFit
		ProjectAccounting.ActiveSheet.Range("A1:ZZ<?php echo $ECount;?>").NumberFormat ="General"

		ProjectAccounting.ActiveSheet.Range("A1:ZZ1").Font.Bold=true
		ProjectAccounting.ActiveSheet.Range("A1:ZZ1").Font.Color="#000000"
		ProjectAccounting.ActiveSheet.Range("A1:ZZ1").Font.Bold=true
		ProjectAccounting.ActiveSheet.Range("A1:ZZ1").Font.Bold=true
		ProjectAccounting.ActiveSheet.Range("A1:ZZ1").Font.Bold=true

	End Sub
	</script>
</body>
</html>