﻿<?php
include "CheckPermission.php";
include "CheckProject.php";
include "../global.php";
include "include/page_function.php";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $PageAdminTitle;?></title>
<link href="../type.css" rel="stylesheet" type="text/css" />
<style type="text/css">
<!--
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
}
-->
</style></head>

<body>
<table width="100%" border="0" cellpadding="0" cellspacing="0">
	<tr>
		<td>
    	<table width="100%" border="0" cellpadding="0" cellspacing="0">
    		<tr height="30">
    			<td class="c2" background="../images/table_bg.gif">已刪除案件資料列表</td>
    		</tr>
    	</table>
    	<table width="750" border="0" cellpadding="0" cellspacing="0">
    		<form name="form1" action="ProjectDelHistory.php" method="post">
    		<tr>
    			<td width="200" align="left" class="h3">關鍵字：<input type="text" name="KeyWord" size="15" value="<?php echo empty($_POST['KeyWord'])?"":$_POST['KeyWord'];?>"></td>
    			<td align="left" class="h3">狀態：
    				<select name="QPStatus">
    					<option value="">不限</option>
    					<option value="A"<?php if (trim(empty($_POST['QPStatus'])?"":$_POST['QPStatus']) == "A") echo " selected";?>>新開案</option>
    					<option value="B"<?php if (trim(empty($_POST['QPStatus'])?"":$_POST['QPStatus']) == "B") echo " selected";?>>報價中</option>
    					<option value="C"<?php if (trim(empty($_POST['QPStatus'])?"":$_POST['QPStatus']) == "C") echo " selected";?>>案件處理中</option>
    					<option value="D"<?php if (trim(empty($_POST['QPStatus'])?"":$_POST['QPStatus']) == "D") echo " selected";?>>審查中</option>
    					<option value="E"<?php if (trim(empty($_POST['QPStatus'])?"":$_POST['QPStatus']) == "E") echo " selected";?>>補件中</option>
    					<option value="F"<?php if (trim(empty($_POST['QPStatus'])?"":$_POST['QPStatus']) == "F") echo " selected";?>>待印證</option>
    					<option value="G"<?php if (trim(empty($_POST['QPStatus'])?"":$_POST['QPStatus']) == "G") echo " selected";?>>案件取消</option>
    					<option value="H"<?php if (trim(empty($_POST['QPStatus'])?"":$_POST['QPStatus']) == "H") echo " selected";?>>已結案</option>
    				</select>
    			</td>
    			<?php
					$SQL_Manager="select MUID,MName,MEName from Manager where Deltag='N' and ISEngineer = 'Y' and IsLeft='N';";
					$result_Manager=mysqli_query($link,$SQL_Manager) or die ("無法執行查詢");
    			?>
    			<td align="left" class="h3">工程師：
    				<select name="QPE">
    					<option value="">不限</option>
          		<?php while(list($MUID,$MName,$MEName)=mysqli_fetch_row($result_Manager)){?>
          		<option value="<?php echo $MUID;?>"<?php if (trim($MUID) == trim(empty($_POST['QPE'])?"":$_POST['QPE'])) echo " selected";?>><?php echo $MEName.$MName;?></option>
          		<?php }?>
    				</select>　<input type="submit" class="input_bot" name="search" value="查詢">　<input type="button" name="button" class="input_bot" value="全部列出" onclick="javascript:location.href='ProjectList.php';">
    			</td>
	        <?php mysqli_free_result($result_Manager);?>
    		</tr>
    		</form>
    	</table>
			<?php
		$SqlPID = "";
		$PID="";
		$SqlTxt="";
    	$KeyWord = empty($_POST['KeyWord'])?"":$_POST['KeyWord'];
    	if (trim($KeyWord) == "") $KeyWord = empty($_GET['KeyWord'])?"":$_GET['KeyWord'];
    	$QPStatus = empty($_POST['QPStatus'])?"":$_POST['QPStatus'];
    	if (trim($QPStatus) == "") $QPStatus = empty($_GET['QPStatus'])?"":$_GET['QPStatus'];
    	$QPE = empty($_POST['QPE'])?"":$_POST['QPE'];
    	if (trim($QPE) == "") $QPE = empty($_GET['QPE'])?"":$_GET['QPE'];
			
			if (trim($KeyWord) != "") {
					$SQL_ProjectCertificate="select PID from ProjectCertificate where Deltag='N' and PCNo like '%".$KeyWord."%' group by PID order by PID;";
					$result_ProjectCertificate=mysqli_query($link,$SQL_ProjectCertificate) or die ("無法執行查詢");
					
					while(list($PC_PID)=mysqli_fetch_row($result_ProjectCertificate)){
							//if (trim($SqlPID) == "") $SqlPID = "PID='".$PC_PID."'";
							//else $SqlPID = $SqlPID." or PID='".$PC_PID."'";
							if (trim($SqlPID) == "") $SqlPID = $PC_PID;
							else $SqlPID = $SqlPID.",".$PC_PID;
							}
					mysqli_free_result($result_ProjectCertificate);
					}
			if (trim($SqlPID) != "") $SqlPID = " PID in (".$SqlPID.")";
    	if (trim($KeyWord) != "") {
    			if (trim($SqlPID) == "") $SqlTxt = $SqlTxt." and (PUID like '%".$KeyWord."%' or CName like '%".$KeyWord."%' or CTel like '%".$KeyWord."%' or CFax like '%".$KeyWord."%' or Contact like '%".$KeyWord."%' or CMobile like '%".$KeyWord."%' or CEMail like '%".$KeyWord."%' or CAddress like '%".$KeyWord."%' or PName like '%".$KeyWord."%' or ModelName like '%".$KeyWord."%' or SeriesModel like '%".$KeyWord."%' or PE like '%".$KeyWord."%' or PNote like '%".$KeyWord."%')";
    			else $SqlTxt = $SqlTxt." and (PUID like '%".$KeyWord."%' or CName like '%".$KeyWord."%' or CTel like '%".$KeyWord."%' or CFax like '%".$KeyWord."%' or Contact like '%".$KeyWord."%' or CMobile like '%".$KeyWord."%' or CEMail like '%".$KeyWord."%' or CAddress like '%".$KeyWord."%' or PName like '%".$KeyWord."%' or ModelName like '%".$KeyWord."%' or SeriesModel like '%".$KeyWord."%' or PE like '%".$KeyWord."%' or PNote like '%".$KeyWord."%' or ApplyItem like '%".$KeyWord."%' or ".$SqlPID.")";
    			
    			}
    	if (trim($QPStatus) != "") $SqlTxt = $SqlTxt." and PStatus='".$QPStatus."' ";
    	if (trim($QPE) != "") $SqlTxt = $SqlTxt." and PE='".$QPE."' ";

			$page = empty($_GET['page'])?"":$_GET['page'];
			if (trim($page) == "") $page = 1;
			$page_rows=15;  //每頁筆數
			$php_Self = "ProjectDelHistory.php";  //分頁web檔名

			$button_css = "h4";
			$limit_txt =" limit ".(($page-1) * $page_rows).",".$page_rows;
			$url_str = "&PID=".$PID."&QPStatus=".$QPStatus."&QPE=".$QPE."&KeyWord=".urlencode($KeyWord);
			$Sql_str="select PID from Project where Deltag='Y' ".$SqlTxt." order by PID desc;";
			$SQL_Project="select PID,PUID,CID,CName,CTel,CFax,CAddress,Contact,CMobile,CEMail,PStatus,PName,ModelName,SeriesModel,PE,Quote,ApplyItem,Canon,SNote,PlanDate,date_format(PlanDate,'%Y'),date_format(PlanDate,'%m'),date_format(PlanDate,'%d'),CloseDate,date_format(CloseDate,'%Y'),date_format(CloseDate,'%m'),date_format(CloseDate,'%d'),PNote,PNote1,QuoteDate,ReturnDate,AddUser,AddDate,ProcUser,ProcDate from Project where Deltag='Y' ".$SqlTxt." order by PID desc ".$limit_txt.";";
			$result_Project=mysqli_query($link,$SQL_Project) or die ("無法執行查詢");
			?>
    	<table width="100%" border="0" cellpadding="5" cellspacing="2" class="s2">
        <tr align="center">
          <td background="../images/table_bg.gif" class="t21">案件編號</td>
          <td background="../images/table_bg.gif" class="t21">產品名稱</td>
          <td background="../images/table_bg.gif" class="t21">客戶名稱</td>
          <td background="../images/table_bg.gif" class="t21">狀態</td>
          <td background="../images/table_bg.gif" class="t21">詳細</td>
          <td background="../images/table_bg.gif" class="t21">重新開案</td>
          <td width="150" background="../images/table_bg.gif" class="t21">最後更新</td>
        </tr>
        <?php
        $tmp = 1;
        while(list($PID,$PUID,$CID,$CName,$CTel,$CFax,$CAddress,$Contact,$CMobile,$CEMail,$PStatus,$PName,$ModelName,$SeriesModel,$PE,$Quote,$ApplyItem,$Canon,$SNote,$PlanDate,$PlanYear,$PlanMonth,$PlanDay,$CloseDate,$CloseYear,$CloseMonth,$CloseDay,$PNote,$PNote1,$QuoteDate,$ReturnDate,$AddUser,$AddDate,$ProcUser,$ProcDate)=mysqli_fetch_row($result_Project)){
      	?>
      	<tr<?php if ($tmp%2 == 0) echo " bgcolor=\"#F6F6F6\"";?>>
          <td align="center" class="h3"><?php echo $PUID;?></td>
          <td class="h3"><?php echo $PName;?></td>
          <td class="h3"><?php echo $CName;?></td>
          <td align="center" class="h3">
          	<?php
          	if (trim($PStatus) == "A") echo "新開案";
          	else if (trim($PStatus) == "B") echo "報價中";
          	else if (trim($PStatus) == "C") echo "案件處理中";
          	else if (trim($PStatus) == "D") echo "審查中";
          	else if (trim($PStatus) == "E") echo "補件中";
          	else if (trim($PStatus) == "F") echo "待印證";
          	else if (trim($PStatus) == "G") echo "案件取消";
          	else if (trim($PStatus) == "H") echo "已結案";
          	?>
          </td>
          <td align="center" class="h3"><input type="button" name="detail" value="詳細" class="input_bot" onclick="javascript:location.href='ProjectDelHistoryDetail.php?PID=<?php echo $PID;?>&page=<?php echo $page;?>';"></td>
          <td align="center" class="h3"><input type="button" name="PCopy" value="重新開案" class="input_bot" onclick="javascript:if (confirm('您是否確定要重新開案？')) window.open ('ProjectDelCopyDB.php?PID=<?php echo $PID;?>','ProjectDelCopy','height=10,width=10,top=200,left=200,scrollbars=no,status=no');"></td>
          <td align="center" class="h3">
          	<?php
          	if (trim($ProcUser) == "") echo $AddUser."<br>".$AddDate;
          	else echo $ProcUser."<br>".$ProcDate;
          	?>
          </td>
        </tr>
        <?php
      			$tmp++;
      			}
      	mysqli_free_result($result_Project);
        ?>
      </table>
      <table width="100%" border="0" cellpadding="5" cellspacing="2" class="s2">
        <tr align="center">
          <td bgcolor="#E8F0C2" class="h4"><?php Page_show($Sql_str,$page_rows,$php_Self,$link,$page,$url_str,$button_css);?></td>
        </tr>
      </table>
		</td>
	</tr>
</table>
</body>
</html>
<?php
mysqli_close($link);
?>