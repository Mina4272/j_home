﻿<?php
include "CheckPermission.php";
include "../global.php";
include "include/page_function.php";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $PageAdminTitle;?></title>
<link href="../type.css" rel="stylesheet" type="text/css" />
<Script type="text/javascript" language="javascript" src="../script/CheckForm.js"></Script>
<script type="text/JavaScript">
<!--
function SelManager(MID) {
		document.Selform.MID.value=MID;
		document.Selform.submit();
		}
//-->
</script>
</head>

<body>
	<?php
		$SqlTxt="";
    	$EVType = empty($_GET['EVType'])?"":$_GET['EVType'];
    	if (trim($EVType) == "") $EVType = empty($_POST['EVType'])?"":$_POST['EVType'];
    	$KeyWord = empty($_POST['KeyWord'])?"":$_POST['KeyWord'];
    	if (trim($KeyWord) == "") $KeyWord = empty($_GET['KeyWord'])?"":$_GET['KeyWord'];
    	if (trim($KeyWord) != "") $SqlTxt = $SqlTxt." and (MUID like '%".$KeyWord."%' or MName like '%".$KeyWord."%' or MEName like '%".$KeyWord."%' or EmployeeNo like '%".$KeyWord."%' or MPID like '%".$KeyWord."%' or EMail like '%".$KeyWord."%' or MIntro like '%".$KeyWord."%' or Address like '%".$KeyWord."%' or RAddress like '%".$KeyWord."%' or Tel like '%".$KeyWord."%' or Mobile like '%".$KeyWord."%')";

			$page = empty($_GET['page'])?"":$_GET['page'];
			if (trim($page) == "") $page = 1;
			$page_rows=15;  //每頁筆數
			$php_Self = "SelManager.php";  //分頁web檔名

			$button_css = "h4";
			$limit_txt =" limit ".(($page-1) * $page_rows).",".$page_rows;
			$url_str = "&KeyWord=".urlencode($KeyWord);
			$Sql_str="select MID,MUID,MName,MEName from Manager where Deltag='N' and IsLeft='N' ".$SqlTxt." order by MID desc;";
			$SQL_Manager="select MID,MUID,MName,MEName from Manager where Deltag='N' and IsLeft ='N' ".$SqlTxt." order by MID desc ".$limit_txt.";";
			$result_Manager=mysqli_query($link,$SQL_Manager) or die ("無法執行查詢");
			?>
<table width="520" border="0" align="center" cellpadding="2" cellspacing="0">
  <tr>
    <td align="left"><span class="c2"><b>選擇員工</b></span>
    </td>
  </tr>
  <tr>
    <td align="left">
    	<table width="100%" border="0" cellpadding="0" cellspacing="0">
    		<form name="form1" action="SelManager.php" method="post">
    		<tr>
    			<td align="left" class="h3">
    				關鍵字：<input type="text" name="KeyWord" size="20"> <input type="submit" name="search" value="查詢">
          	<input type="hidden" name="EVType" value="<?php echo $EVType;?>">
    			</td>
    		</tr>
    		</form>
    	</table>
		
    	<table width="100%" border="0" cellpadding="2" cellspacing="2" class="s2">
        <tr align="center">
          <td width="100" background="../images/table_bg.gif" class="t21">帳號</td>
          <td background="../images/table_bg.gif" class="t21">姓名</td>
        </tr>
        <?php
        $tmp = 1;
        while(list($MID,$MUID,$MName,$MEName)=mysqli_fetch_row($result_Manager)){
      	?>
    	  <form name="CForm<?php echo $MID;?>" method="post">
	    	<tr<?php if ($tmp%2 == 0) echo " bgcolor=\"#F6F6F6\"";?>>
          <td align="center" class="h3"><?php echo $MUID;?></td>
          <td align="center" class="h3"><?php echo $MEName.$MName;?>
          	<input type="button" name="button" class="input_bot" value="選擇" onclick="javascript:SelManager(<?php echo $MID;?>);">
          </td>
        </tr>
    		</form>
        <?php
      			$tmp++;
      			}
      	mysqli_free_result($result_Manager);
        ?>
      </table>
      <table width="100%" border="0" cellpadding="2" cellspacing="2" class="s2">
        <tr align="center">
          <td bgcolor="#E8F0C2" class="h4"><?php Page_show($Sql_str,$page_rows,$php_Self,$link,$page,$url_str,$button_css);?></td>
        </tr>
      </table>

    </td>
  </tr>
</table>
<form name="Selform" action="SelManagerDB.php" method="post">
	<input type="hidden" name="MID">
	<input type="hidden" name="EVType" value="<?php echo $EVType;?>">
</form>
</body>
</html>
<?php
mysqli_close($link);
?>