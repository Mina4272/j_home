﻿<?php
include "CheckPermission.php";
include "CheckProject.php";
include "../global.php";
require_once("../include/chinese_party.class.php");
require("class.phpmailer.php");
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $PageAdminTitle;?></title>
</head>
<body>
<?php
$PID = $_GET['PID'];

if (trim($PID) == "")
		{
		mysqli_close($link);
		?>
		<script type="text/JavaScript">
			<!--
			alert ("您輸入的資料不足，請重新輸入！");
			self.close();
			//-->
		</script>
		<?php
		exit;
		}
$SQL_Project="select CID,CName,CTel,CFax,Contact,CMobile,CEMail,CAddress,PStatus,PName,ModelName,SeriesModel,PE,PENotify,PENotifyMUID,Quote,ApplyItem,Canon,CCCCode,SNote,PlanDate,CloseDate,PNote,PNoteDate,EMC,POther,PADate,PNote1,QuoteDate,QRecord,QRecordDate,QRecordIP,ReturnDate,RRecord,RRecordDate,RRecordIP,IFlorin,OFlorin,InvoiceCUID,InvoiceTitle,InvoiceAddress,Leadtime,Trademark,PTax,IDate,INo,InvoiceDate,IRecord,IRecordDate,IRecordIP from Project where Deltag='Y' and PID = '".$PID."';";
$result_Project=mysqli_query($link,$SQL_Project) or die ("無法執行查詢");

if (mysqli_num_rows($result_Project) == 0)
		{
		mysqli_free_result($result_Project);
		mysqli_close($link);
		?>
		<SCRIPT language=javascript>
		<!--
		alert ("查無資料，請冾網站管理人員！"); 
		self.close();
		//-->
		</SCRIPT>
		<?php 	
		exit;
		}
list($CID,$CName,$CTel,$CFax,$Contact,$CMobile,$CEMail,$CAddress,$PStatus,$PName,$ModelName,$SeriesModel,$PE,$PENotify,$PENotifyMUID,$Quote,$ApplyItem,$Canon,$CCCCode,$SNote,$PlanDate,$CloseDate,$PNote,$PNoteDate,$EMC,$POther,$PADate,$PNote1,$QuoteDate,$QRecord,$QRecordDate,$QRecordIP,$ReturnDate,$RRecord,$RRecordDate,$RRecordIP,$IFlorin,$OFlorin,$InvoiceCUID,$InvoiceTitle,$InvoiceAddress,$Leadtime,$Trademark,$PTax,$IDate,$INo,$InvoiceDate,$IRecord,$IRecordDate,$IRecordIP)=mysqli_fetch_row($result_Project);
mysqli_free_result($result_Project);

$PCDate = date("ymd");
$now_time = date("Y-m-d H:i:s",mktime());
$SQL_select="select PCount from ProjectCount where PCDate = '".$PCDate."';";
$result_select=mysqli_query($link,$SQL_select) or die ("無法執行查詢");

if (mysqli_num_rows($result_select) == 0)
		{
		$sql_insert = "insert into ProjectCount (PCDate,PCount) values ('".$PCDate."','2');";
		$result_insert=mysqli_query($link,$sql_insert) or die ("無法執行新增");
		$PCount = "1";
		}
else
		{
		$sql_update = "update ProjectCount set PCount = PCount + 1 where PCDate = '".$PCDate."';";
		$result_update=mysqli_query($link,$sql_update) or die ("無法執行新增");
		list($PCount)=mysqli_fetch_row($result_select);
		}
mysqli_free_result($result_select);

if (strlen($PCount) < 2)
	{
	for ($i=1;$i=2-strlen($PCount);$i++)
		{
		$PCount = "0" . $PCount;
		}
	}
$PUID = "B".$PCDate.$PCount;

$now_time = date("Y-m-d H:i:s",mktime());
if (trim($CloseDate)=="") $CloseDate = "NULL";
else $CloseDate = "'$CloseDate'";
if (trim($PlanDate)=="") $PlanDate = "NULL";
else $PlanDate = "'$PlanDate'";
if (trim($PADate)=="") $PADate = "NULL";
else $PADate = "'$PADate'";
if (trim($PNoteDate)=="") $PNoteDate = "NULL";
else $PNoteDate = "'$PNoteDate'";

echo $CName = str_replace("'","\'",$CName);
echo $Contact = str_replace("'","\'",$Contact);
echo $CAddress = str_replace("'","\'",$CAddress);
echo $PName = str_replace("'","\'",$PName);
echo $ModelName = str_replace("'","\'",$ModelName);
echo $ApplyItem = str_replace("'","\'",$ApplyItem);
echo $SNote = str_replace("'","\'",$SNote);
echo $PNote = str_replace("'","\'",$PNote);




$sql_insert = "insert into Project (PUID,CID,CName,CTel,CFax,Contact,CMobile,CEMail,CAddress,PName,ModelName,SeriesModel,PE,PENotify,PENotifyMUID,Quote,ApplyItem,Canon,CCCCode,SNote,PlanDate,CloseDate,PNote,PNoteDate,EMC,POther,PADate,PNote1,IFlorin,OFlorin,InvoiceCUID,InvoiceTitle,InvoiceAddress,Leadtime,Trademark,PTax,AddUser,AddDate,AddIP) values ('".$PUID."','".$CID."','".$CName."','".$CTel."','".$CFax."','".$Contact."','".$CMobile."','".$CEMail."','".$CAddress."','".$PName."','".$ModelName."','".$SeriesModel."','".$PE."','".$PENotify."','".$PENotifyMUID."','".$Quote."','".$ApplyItem."','".$Canon."','".$CCCCode."','".$SNote."',".$PlanDate.",".$CloseDate.",'".$PNote."',".$PNoteDate.",'".$EMC."','".$POther."',".$PADate.",'".$PNote1."','".$IFlorin."','".$OFlorin."','".$InvoiceCUID."','".$InvoiceTitle."','".$InvoiceAddress."','".$Leadtime."','".$Trademark."','".$PTax."','".$_SESSION["reg_MUID"]."','".$now_time."','".$_SERVER["REMOTE_ADDR"]."');";



$result_insert=mysqli_query($link,$sql_insert) or die ("無法執行新增");



$NPID = mysqli_insert_id($link);

$SQL_ProjectAccounting="select PAMode,PAItem,Charges,Rate,ChargesOther,PAPDate,CID,CName,CTel,CFax,CAddress,InvoiceDate,Invoice,PANote from ProjectAccounting where Deltag='N' and PID = '".$PID."' order by PAID;";
$result_ProjectAccounting=mysqli_query($link,$SQL_ProjectAccounting) or die ("無法執行查詢");
while(list($PAMode,$PAItem,$Charges,$Rate,$ChargesOther,$PAPDate,$CID,$CName,$CTel,$CFax,$CAddress,$InvoiceDate,$Invoice,$PANote)=mysqli_fetch_row($result_ProjectAccounting)){
		if (trim($CID) == "") $CID="NULL";
		//if (trim($PAPDate)=="") $PAPDate = "NULL";
		//else $PAPDate = "'$PAPDate'";
		$PAPDate = "NULL";
		$sql_insert = "insert into ProjectAccounting (PID,PAMode,PAItem,Charges,Rate,ChargesOther,PAPDate,CID,CName,CTel,CFax,CAddress,PANote,AddUser,AddDate,AddIP) values ('".$NPID."','".$PAMode."','".$PAItem."','".$Charges."','".$Rate."','".$ChargesOther."',".$PAPDate.",".$CID.",'".$CName."','".$CTel."','".$CFax."','".$CAddress."','".$PANote."','".$_SESSION["reg_MUID"]."','".$now_time."','".$_SERVER["REMOTE_ADDR"]."');";
		$result_insert=mysqli_query($link,$sql_insert) or die ("無法執行新增");
		}
mysqli_free_result($result_ProjectAccounting);

$SQL_Manager="select MName from Manager where Deltag='N' and ISEngineer = 'Y' and MUID='".$PE."';";
$result_Manager=mysqli_query($link,$SQL_Manager) or die ("無法執行查詢");
list($MName)=mysqli_fetch_row($result_Manager);
mysqli_free_result($result_Manager);

$EMAILFN = "notify.htm";
$subject="全威驗證案件新增通知 ！！";
$fp=fopen($EMAILFN,"r");
$content="";
while($line=fgets($fp,512)){
	$content.=$line;
	}
fclose($fp);

$content = str_replace("{PUID}",$PUID,$content);
$content = str_replace("{PName}",$PName,$content);
$content = str_replace("{ModelName}",$ModelName,$content);
$content = str_replace("{CName}",$CName,$content);
$content = str_replace("{PE}",$MName,$content);

$cconv = new chinese_party();
$content = $cconv->u82tchi($content);
$subject = $cconv->u82tchi($subject);

$mail = new PHPMailer();
$mail->IsSMTP();
$mail->Host     = "127.0.0.1";
$mail->SMTPAuth = true;
$mail->From     = "Benson@rpclab.com";
$mail->FromName = $subject;
$mail->WordWrap = 50;
$mail->IsHTML(true);                               // send as HTML
$mail->CharSet = "big5";
$mail->Subject  = $subject;
$mail->Body     =  $content;
$mail->AddAddress("Benson@rpclab.com","");
$mail->AddReplyTo("Benson@rpclab.com");
if(!$mail->Send())
		{
    //echo "There has been a mail error sending to " . $SendEMail . "<br>";
    //echo "Mailer Error: " . $mail->ErrorInfo . "<br>";
  	}
else
		{
		//echo $SendEMail . " sending !!<br>";
		}
		
$mail->ClearAddresses();
$mail->ClearReplyTos();
$mail->SmtpClose();

mysqli_close($link);
?>
<script type="text/JavaScript">
	<!--
	alert ("重新開案新增成功！");
	self.close();
	//-->
</script>

</body>
</html>
