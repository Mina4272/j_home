﻿<?php
include "../global.php";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $PageTitle;?></title>
<link href="type.css" rel="stylesheet" type="text/css" />
<style type="text/css">
<!--
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
}
-->
</style></head>

<body>
<table width="100%" border="0" cellpadding="0" cellspacing="0">
  <tr>
    <td>
    	<table width="100%" border="0" cellpadding="0" cellspacing="0">
    		<tr>
    			<td width="10"></td>
    			<td class="c2"><img src="../images/logo.jpg" border="0" /></td>
    			<td width="200" class="c3" valign="bottom"><?php echo date("Y");?> 年 <?php echo date("m");?> 月 <?php echo date("d");?> 日</td>
    		</tr>
    	</table>
    </td>
  </tr>
  <tr>
    <td height="11" valign="bottom"><img src="../images/line.jpg" width="100%" height="11" /></td>
  </tr>
</table>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
	<tr>
    <td height="30" valign="top" background="../images/table_bg.gif"></td>
	</tr>
</table>
</body>
</html>
<?php
mysqli_close($link);
?>