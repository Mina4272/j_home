﻿<?php
include "CheckPermission.php";
include "CheckMFees.php";
include "../global.php";
require_once("../include/chinese_party.class.php");
require("class.phpmailer.php");
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $PageAdminTitle;?></title>
</head>
<body>
<?php
$MFCheckAns = $_POST['MFCheckAns'];
$MFCNote = $_POST['MFCNote'];
$MFID = $_POST['MFID'];

if (trim($MFID) == "" || trim($MFCheckAns) == "")
		{
		mysqli_close($link);
		?>
		<script type="text/JavaScript">
			<!--
			alert ("您輸入的資料不足，請重新輸入！");
			history.go(-1);
			//-->
		</script>
		<?php
		exit;
		}

$SQL_ManagerFees="select MUID,MFType,MFDate,MFCause,MFComment,Quantity,MFNote,MFSend,MFCheck,MFCheckID,(select MName from Manager where deltag = 'N' and MUID=ManagerFees.MFCheckID) MFCMName,MFCheckDate,MFCheckIP,AddDate,(select MName from Manager where deltag = 'N' and MUID=ManagerFees.MUID) MName from ManagerFees where Deltag='N' and MFID=".$MFID.";";
$result_ManagerFees=mysqli_query($link,$SQL_ManagerFees) or die ("無法執行查詢");
if (mysqli_num_rows($result_ManagerFees) == 0)
		{
		mysqli_free_result($result_ManagerFees);
		mysqli_close($link);
		?>
		<SCRIPT language=javascript>
		<!--
		alert ("查無資料，請冾網站管理人員！"); 
		self.close();
		//-->
		</SCRIPT>
		<?php 	
		exit;
		}
list($MUID,$MFType,$MFDate,$MFCause,$MFComment,$Quantity,$MFNote,$MFSend,$MFCheck,$MFCheckID,$MFCMName,$MFCheckDate,$MFCheckIP,$AddDate,$MName)=mysqli_fetch_row($result_ManagerFees);
mysqli_free_result($result_ManagerFees);

if (trim($MFCheck) != "W")
		{
		mysqli_close($link);
		?>
		<script type="text/JavaScript">
			<!--
			alert ("此申請單已簽核，不需再作簽核！");
			self.close();
			//-->
		</script>
		<?php
		exit;
		}
date_default_timezone_set("Asia/Taipei");
$now_time = date("Y-m-d H:i:s",mktime());
$sql_insert = "INSERT INTO ManagerFeesHistory(MFID,MUID,MFType,MFDate,MFCause,MFComment,Quantity,MFNote,MFSend,MFCheck,MFCNote,MFCheckID,MFCheckDate,MFCheckIP,AddUser,AddDate,AddIP,Deltag,ProcUser,ProcDate,ProcIP,UpdateUser,UpdateDate,UpdateIP) SELECT MFID,MUID,MFType,MFDate,MFCause,MFComment,Quantity,MFNote,MFSend,MFCheck,MFCNote,MFCheckID,MFCheckDate,MFCheckIP,AddUser,AddDate,AddIP,Deltag,ProcUser,ProcDate,ProcIP,'".$_SESSION["reg_MUID"]."','".$now_time."','".$_SERVER["REMOTE_ADDR"]."' from ManagerFees where Deltag='N' and MFID=".$MFID.";";
$result_insert=mysqli_query($link,$sql_insert) or die ("無法執行新增");
$sql_update = "update ManagerFees set MFCheck = '".$MFCheckAns."',MFCNote = '".$MFCNote."',MFCheckID = '".$_SESSION["reg_MUID"]."',MFCheckDate = '".$now_time."',MFCheckIP = '".$_SERVER["REMOTE_ADDR"]."',ProcUser = '".$_SESSION["reg_MUID"]."',ProcDate = '".$now_time."',ProcIP = '".$_SERVER["REMOTE_ADDR"]."' where Deltag='N' and MFID=".$MFID.";";
$result_update=mysqli_query($link,$sql_update) or die ("無法執行修改");

if (trim($MFType) == "A") $MFType="加班費";
else if (trim($MFType) == "B") $MFType="交通費-公里";
else if (trim($MFType) == "C") $MFType="交通費-實報實銷";

if (trim($MFCheckAns) == "Y") $MFCheckAns="同意";
else if (trim($MFCheckAns) == "N") $MFCheckAns="不同意";

$SQL_Manager="select MName,EMail from Manager where MUID='".$MUID."'and Deltag='N';";
$result_Manager=mysqli_query($link,$SQL_Manager) or die ("無法執行查詢");
list($MName,$EMail)=mysqli_fetch_row($result_Manager);
mysqli_free_result($result_Manager);

$EMAILFN = "MFeesAudit.htm";
$subject="費用申請審核通知 ！！";
$fp=fopen($EMAILFN,"r");
$content="";
while($line=fgets($fp,512)){
	$content.=$line;
	}
fclose($fp);

$content = str_replace("{MName}",$MName.$MUID,$content);
$content = str_replace("{MFType}",$MFType,$content);
$content = str_replace("{MFDate}",$MFDate,$content);
$content = str_replace("{MFCause}",$MFCause,$content);
$content = str_replace("{MFComment}",$MFComment,$content);
$content = str_replace("{Quantity}",$Quantity,$content);
$content = str_replace("{MFNote}",$MFNote,$content);

$content = str_replace("{MFCheck}",$MFCheckAns,$content);
$content = str_replace("{MFCheckID}",$_SESSION["reg_MName"],$content);
$content = str_replace("{MFCheckDate}",$now_time,$content);
$content = str_replace("{MFCNote}",$MFCNote,$content);

//$cconv =& new chinese_party();
//$content = $cconv->u82tchi($content);
//$subject = $cconv->u82tchi($subject);

$mail = new PHPMailer();
$mail->IsSMTP();
$mail->SMTPAuth = true; //設定SMTP需要驗證
$mail->SMTPSecure = "ssl"; // Gmail的SMTP主機需要使用SSL連線
$mail->Host = "smtp.gmail.com"; //Gamil的SMTP主機
$mail->Port = 465; //Gamil的SMTP主機的埠號(Gmail為465)。
$mail->CharSet = "utf-8"; //郵件編碼
$mail->Username = "Benson@rpclab.com"; //Gamil帳號
$mail->Password = "76197619"; //Gmail密碼
$mail->From     = "Benson@rpclab.com";
$mail->FromName = $subject;
$mail->WordWrap = 50;
$mail->IsHTML(true);                               // send as HTML
//$mail->CharSet = "big5";
$mail->Subject  = $subject;
$mail->Body     =  $content;
$mail->AddAddress($EMail,"");
$mail->AddReplyTo("Benson@rpclab.com");
if(!$mail->Send())
		{
    //echo "There has been a mail error sending to " . $SendEMail . "<br>";
    //echo "Mailer Error: " . $mail->ErrorInfo . "<br>";
  	}
else
		{
		//echo $SendEMail . " sending !!<br>";
		}
		
$mail->ClearAddresses();
$mail->ClearReplyTos();
$mail->SmtpClose();
mysqli_close($link);
?>
<script type="text/JavaScript">
	<!--
	alert ("簽核完成！");
	opener.location.reload();
	self.close();
	//-->
</script>

</body>
</html>
