﻿<?php	
include "CheckPermission.php";
include "CheckCommonAccounting.php";
include "../global.php";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $PageAdminTitle;?></title>
<link href="../type.css" rel="stylesheet" type="text/css" />
<style type="text/css">
<!--
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
}
-->
</style>
<link href="../script/DatePicker.css" rel="stylesheet" type="text/css" />
<Script LANGUAGE="Javascript" SRC="../script/DatePicker.js"></Script>
<Script type="text/javascript" language="javascript" src="../script/CheckForm.js"></Script>
<script type="text/JavaScript">
<!--
function jsCheck() 
		{
		if (ChkImp('CAItem',document.form1.CAItem.value,'項目') == false) return false;
		if (ChkNaN('Amount',document.form1.Amount.value,'金額','') == false) return false;
		if (jsTrim(document.form1.InvoiceYear.value) != "" || jsTrim(document.form1.InvoiceYear.value) != "" || jsTrim(document.form1.InvoiceYear.value) != "") if (ChkDate('InvoiceYear',document.form1.InvoiceYear.value,document.form1.InvoiceMonth.value,document.form1.InvoiceDay.value,'發票日期') == false) return false;
		if (document.form1.CAStatus.value == "S") {
				if (ChkDate('PayYear',document.form1.PayYear.value,document.form1.PayMonth.value,document.form1.PayDay.value,'付款日') == false) return false;
				}
		else {
				if (jsTrim(document.form1.PayYear.value) != "" || jsTrim(document.form1.PayYear.value) != "" || jsTrim(document.form1.PayYear.value) != "") if (ChkDate('PayYear',document.form1.PayYear.value,document.form1.PayMonth.value,document.form1.PayDay.value,'付款日') == false) return false;
				}
		}
//-->
</script>
</head>
<body>
<?php include "top.php";?>
<?php
$QCAYear = date("Y",mktime());
$QCAMonth = date("m",mktime());
?>
<table width="100%" border="0" cellspacing="0" cellpadding="5">
	<tr>
    <td width="160" height="600" align="left" valign="top">
			<?php include "menu.php";?>
    </td>
    <td valign="top">
    	<table width="100%" border="0" cellpadding="0" cellspacing="0">
    		<tr>
    			<td>
			    	<table width="750" border="0" cellpadding="0" cellspacing="0">
			    		<tr height="30">
			    			<td class="c2"><a href="CommonAccounting.php">一般帳務管理</a> &gt; 新增項目</td>
			    		</tr>
			    	</table>
			    	<table width="750" border="0" cellpadding="0" cellspacing="0">
			        <form name="form1" method="post" action="CommonAccountingAddDB.php" enctype="multipart/form-data" onSubmit="return jsCheck();">
			        <tr height="35" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td width="120" align="right" class="c3">所屬月份：</td>
			          <td class="h3">
			    				<select name="CAYear">
			    					<option value="2008"<?php if (trim(date("Y",mktime())) == "2008") echo " selected";?>>2008</option>
			    					<option value="2009"<?php if (trim(date("Y",mktime())) == "2009") echo " selected";?>>2009</option>
			    					<option value="2010"<?php if (trim(date("Y",mktime())) == "2010") echo " selected";?>>2010</option>
			    					<option value="2011"<?php if (trim(date("Y",mktime())) == "2011") echo " selected";?>>2011</option>
			    					<option value="2012"<?php if (trim(date("Y",mktime())) == "2012") echo " selected";?>>2012</option>
			    					<option value="2013"<?php if (trim(date("Y",mktime())) == "2013") echo " selected";?>>2013</option>
			    					<option value="2014"<?php if (trim(date("Y",mktime())) == "2014") echo " selected";?>>2014</option>
			    					<option value="2015"<?php if (trim(date("Y",mktime())) == "2015") echo " selected";?>>2015</option>
			    					<option value="2016"<?php if (trim(date("Y",mktime())) == "2016") echo " selected";?>>2016</option>
			    					<option value="2017"<?php if (trim(date("Y",mktime())) == "2017") echo " selected";?>>2017</option>
			    					<option value="2018"<?php if (trim(date("Y",mktime())) == "2018") echo " selected";?>>2018</option>
			    					<option value="2019"<?php if (trim(date("Y",mktime())) == "2019") echo " selected";?>>2019</option>
			    					<option value="2020"<?php if (trim(date("Y",mktime())) == "2020") echo " selected";?>>2020</option>
			    					<option value="2021"<?php if (trim(date("Y",mktime())) == "2021") echo " selected";?>>2021</option>
			    					<option value="2022"<?php if (trim(date("Y",mktime())) == "2022") echo " selected";?>>2022</option>
			    					<option value="2023"<?php if (trim(date("Y",mktime())) == "2023") echo " selected";?>>2023</option>
			    					<option value="2024"<?php if (trim(date("Y",mktime())) == "2024") echo " selected";?>>2024</option>
			    					<option value="2025"<?php if (trim(date("Y",mktime())) == "2025") echo " selected";?>>2025</option>
									<option value="2026"<?php if (trim(date("Y",mktime())) == "2026") echo " selected";?>>2026</option>
									<option value="2027"<?php if (trim(date("Y",mktime())) == "2027") echo " selected";?>>2027</option>
									<option value="2028"<?php if (trim(date("Y",mktime())) == "2028") echo " selected";?>>2028</option>
									<option value="2029"<?php if (trim(date("Y",mktime())) == "2029") echo " selected";?>>2029</option>
									<option value="2030"<?php if (trim(date("Y",mktime())) == "2030") echo " selected";?>>2030</option>
			    				</select> 年 
			    				<select name="CAMonth">
			    					<option value="01"<?php if (trim(date("m",mktime())) == "01") echo " selected";?>>01</option>
			    					<option value="02"<?php if (trim(date("m",mktime())) == "02") echo " selected";?>>02</option>
			    					<option value="03"<?php if (trim(date("m",mktime())) == "03") echo " selected";?>>03</option>
			    					<option value="04"<?php if (trim(date("m",mktime())) == "04") echo " selected";?>>04</option>
			    					<option value="05"<?php if (trim(date("m",mktime())) == "05") echo " selected";?>>05</option>
			    					<option value="06"<?php if (trim(date("m",mktime())) == "06") echo " selected";?>>06</option>
			    					<option value="07"<?php if (trim(date("m",mktime())) == "07") echo " selected";?>>07</option>
			    					<option value="08"<?php if (trim(date("m",mktime())) == "08") echo " selected";?>>08</option>
			    					<option value="09"<?php if (trim(date("m",mktime())) == "09") echo " selected";?>>09</option>
			    					<option value="10"<?php if (trim(date("m",mktime())) == "10") echo " selected";?>>10</option>
			    					<option value="11"<?php if (trim(date("m",mktime())) == "11") echo " selected";?>>11</option>
			    					<option value="12"<?php if (trim(date("m",mktime())) == "12") echo " selected";?>>12</option>
			    				</select> 月
			          </td>
			        </tr>
			        <tr height="35" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">項 目：</td>
			          <td class="h3">
			          	<input type="text" name="CAItem" size="60">
			          </td>
			        </tr>
			        <tr height="35" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">類 別：</td>
			          <td class="h3">
			          	<select name="CAType">
			          		<option value="C">公司</option>
			          		<option value="P">個人</option>
			          	</select>
			          </td>
			        </tr>
			        <tr height="35" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">金 額：</td>
			          <td class="h3"><input type="text" name="Amount" size="20">
			          </td>
			        </tr>
			        <tr height="35" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">發票號碼：</td>
			          <td class="h3">
			          	<input type="text" name="Invoice" size="20">
			          </td>
			        </tr>
			        <tr height="35" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">發票日期：</td>
			          <td class="h3">
		              <input name="InvoiceYear" type="text" size="4" /> 年 
		              <input name="InvoiceMonth" type="text" size="2" /> 月 
		              <input name="InvoiceDay" type="text" size="2" /> 日 
		              <img src="../images/icon.gif" width="16" height="18" style="cursor: hand" onclick="javascript:displayDatePicker('InvoiceYear','InvoiceMonth','InvoiceDay');"/>
			          </td>
			        </tr>
			        <tr height="35" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">狀 況：</td>
			          <td class="h3">
			          	<select name="CAStatus">
			          		<option value="W"<?php if (trim(empty($_POST['CAStatus'])?"":$_POST['CAStatus']) == "W") echo " selected";?>>未付</option>
			          		<option value="S"<?php if (trim(empty($_POST['CAStatus'])?"":$_POST['CAStatus']) == "S") echo " selected";?>>結清</option>
			          		<option value="C"<?php if (trim(empty($_POST['CAStatus'])?"":$_POST['CAStatus']) == "C") echo " selected";?>>取消</option>
			          	</select>　
			          	<span class="c3">付款日：</span>
		              <input name="PayYear" type="text" size="4" /> 年 
		              <input name="PayMonth" type="text" size="2" /> 月 
		              <input name="PayDay" type="text" size="2" /> 日 
		              <img src="../images/icon.gif" width="16" height="18" style="cursor: hand" onclick="javascript:displayDatePicker('PayYear','PayMonth','PayDay');"/>
			          </td>
			        </tr>
			        <tr height="35" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">備 註：</td>
			          <td class="h3">
			          	<input type="text" name="CANote" size="80">
			          	<input type="hidden" name="QCAYear" value="<?php echo $QCAYear;?>">
			          	<input type="hidden" name="QCAMonth" value="<?php echo $QCAMonth;?>">
			          </td>
			        </tr>
					<tr height="40" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td width="120" align="right" class="c3">檔案上傳:</td>
			          <td class="h3"><input type="file" name="CAFile" size="60"></td>
			        </tr>
			        <tr height="40" align="center">
			          <td colspan="2" class="h3"><input type="submit" name="submit" class="input_bot" value="送 出"></td>
			        </tr>
				      </form>
			      </table>
    			</td>
    		</tr>
    	</table>
    </td>
	</tr>
</table>
<?php include "down.php";?>
</body>
</html>
<?php
mysqli_close($link);
?>