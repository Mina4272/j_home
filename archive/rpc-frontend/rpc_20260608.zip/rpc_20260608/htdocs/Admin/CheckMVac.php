<?php
if (trim(strstr($_SESSION["reg_MPer"],'J')) == "") exit;
?>