﻿<?php	
include "CheckPermission.php";
include "../global.php";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $PageAdminTitle;?></title>
<link href="../type.css" rel="stylesheet" type="text/css" />
<style type="text/css">
<!--
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
}
-->
</style>
<link href="../script/DatePicker.css" rel="stylesheet" type="text/css" />
<Script LANGUAGE="Javascript" SRC="../script/DatePicker.js"></Script>
<Script type="text/javascript" language="javascript" src="../script/CheckForm.js"></Script>
<script type="text/JavaScript">
<!--
function jsCheck() 
		{
		if (ChkDate('MFYear',document.form1.MFYear.value,document.form1.MFMonth.value,document.form1.MFDay.value,'申請起始時間') == false) return false;
		if (ChkImp('MFCause',document.form1.MFCause.value,'申請事由','') == false) return false;
		if (ChkImp('MFComment',document.form1.MFComment.value,'申請說明','') == false) return false;
		if (ChkNaN('Quantity',document.form1.Quantity.value,'申請數量','') == false) return false;
		}
//-->
</script>
</head>
<body>
<?php include "top.php";?>
<?php
$MFID = $_GET['MFID'];
$page = $_GET['page'];
$QMFSDate = $_GET['QMFSDate'];
$QMFEDate = $_GET['QMFEDate'];
$QMFType = $_GET['QMFType'];
$QMUID = $_GET['QMUID'];
$KeyWord = $_GET['KeyWord'];
$QMFCheck = $_GET['QMFCheck'];

if (trim($MFID) == "")
		{
		mysqli_close($link);
		?>
		<script type="text/JavaScript">
			<!--
			alert ("查無資料，請冾網站管理人員！");
			history.go(-1);
			//-->
		</script>
		<?php
		exit;
		}
$SQL_ManagerFees="select MUID,MFType,MFDate,date_format(MFDate,'%Y'),date_format(MFDate,'%m'),date_format(MFDate,'%d'),MFCause,MFComment,Quantity,MFNote,MFSend,MFCheck,(select MName from Manager where MUID=ManagerFees.MUID) MName,(select MEName from Manager where MUID=ManagerFees.MUID) MEName from ManagerFees where Deltag='N' and MFID=".$MFID.";";
$result_ManagerFees=mysqli_query($link,$SQL_ManagerFees) or die ("無法執行查詢");
if (mysqli_num_rows($result_ManagerFees) == 0)
		{
		mysqli_free_result($result_Manager);
		mysqli_close($link);
		?>
		<SCRIPT language=javascript>
		<!--
		alert ("查無資料，請冾網站管理人員！"); 
		history.go(-1);
		//-->
		</SCRIPT>
		<?php 	
		exit;
		}
list($MUID,$MFType,$MFDate,$MFYear,$MFMonth,$MFDay,$MFCause,$MFComment,$Quantity,$MFNote,$MFSend,$MFCheck,$MName,$MEName)=mysqli_fetch_row($result_ManagerFees);
mysqli_free_result($result_ManagerFees);

if (trim($MFCheck) != "W")
		{
		mysqli_close($link);
		?>
		<script type="text/JavaScript">
			<!--
			alert ("此申請單已簽核，不得修改！");
			history.go(-1);
			//-->
		</script>
		<?php
		exit;
		}

if (trim($MUID) != trim($_SESSION["reg_MUID"]))
		{
		mysqli_close($link);
		?>
		<script type="text/JavaScript">
			<!--
			alert ("此申請單非本人，不得修改！");
			history.go(-1);
			//-->
		</script>
		<?php
		exit;
		}
?>
<table width="100%" border="0" cellspacing="0" cellpadding="5">
	<tr>
    <td width="160" height="600" align="left" valign="top">
			<?php include "menu.php";?>
    </td>
    <td valign="top">
    	<table width="100%" border="0" cellpadding="0" cellspacing="0">
    		<tr>
    			<td>
			    	<table width="750" border="0" cellpadding="0" cellspacing="0">
			    		<tr height="30">
			    			<td class="c2"><b>修改申請資料</b></td>
			    		</tr>
			    	</table>
			    	<table width="750" border="0" cellpadding="0" cellspacing="0">
			        <form name="form1" method="post" action="MFeesEditDB.php" onSubmit="return jsCheck();">
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td width="160" align="right" class="c3">申請人：</td>
			          <td class="h3"><?php echo $MEName.$MName;?>
			          	<input type="hidden" name="MFID" value="<?php echo $MFID;?>">
			          	<input type="hidden" name="page" value="<?php echo $page;?>">
			          	<input type="hidden" name="QMFSDate" value="<?php echo $QMFSDate;?>">
			          	<input type="hidden" name="QMFEDate" value="<?php echo $QMFEDate;?>">
			          	<input type="hidden" name="QMFType" value="<?php echo $QMFType;?>">
			          	<input type="hidden" name="QMUID" value="<?php echo $QMUID;?>">
			          	<input type="hidden" name="KeyWord" value="<?php echo $KeyWord;?>">
			          	<input type="hidden" name="QMFCheck" value="<?php echo $QMFCheck;?>">
			          </td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">申請項目：</td>
			          <td class="h3">
			          	<select id="MFType" name="MFType">
			          		<option value="A"<?php if (trim($MFType) == "A") echo " selected";?>>加班費</option>
			          		<option value="B"<?php if (trim($MFType) == "B") echo " selected";?>>交通費-公里</option>
			          		<option value="C"<?php if (trim($MFType) == "C") echo " selected";?>>交通費-實報實銷</option>
			          	</select>
			          </td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">申請日期：</td>
			          <td class="h3">
			            <input id="MFYear" name="MFYear" type="text" size="4" value="<?php echo $MFYear;?>" />年
			            <input id="MFMonth" name="MFMonth" type="text" size="2" value="<?php echo $MFMonth;?>" />月
			            <input id="MFDay" name="MFDay" type="text" size="2" value="<?php echo $MFDay;?>" />日
			            <img src="../images/icon.gif" width="16" height="18" style="cursor: hand" onclick="javascript:displayDatePicker('MFYear','MFMonth','MFDay');"/>
			          </td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">申請事由：</td>
			          <td class="h3"><input type="text" id="MFCause" name="MFCause" size="40" value="<?php echo $MFCause;?>"></td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">申請說明：</td>
			          <td class="h3"><input type="text" id="MFComment" name="MFComment" size="40" value="<?php echo $MFComment;?>"><br><font color=blue>( 請註明申請加班起迄時間或交通費起迄地點 )</font></td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">申請數量/金額：</td>
			          <td class="h3"><input type="text" id="Quantity" name="Quantity" size="10" value="<?php echo $Quantity;?>"> <font color=blue>( 加班時數/公里數/金額 )</font></td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">備註：</td>
			          <td class="h3"><input type="text" id="MFNote" name="MFNote" size="60" value="<?php echo $MFNote;?>"></td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">是否送審：</td>
			          <td class="h3">
			          	<input type="radio" id="MFSend" name="MFSend" value="N"<?php if (trim($MFSend) == "N") echo " checked";?>> 否 
			          	<input type="radio" id="MFSend" name="MFSend" value="Y"<?php if (trim($MFSend) == "Y") echo " checked";?>> 是
			          </td>
			        </tr>
			        <tr height="40" align="center">
			          <td colspan="2" class="h3">
			          	<?php if (trim($MFSend) == "Y") {?>
				          	<input type="button" name="button" class="input_bot" value="回列表" onclick="javascript:location.href='MFeesList.php?page=<?php echo $page;?>&QMFSDate=<?php echo $QMFSDate;?>&QMFEDate=<?php echo $QMFEDate;?>&QMFType=<?php echo $QMFType;?>&QMUID=<?php echo $QMUID;?>&QMFCheck=<?php echo $QMFCheck;?>&KeyWord=<?php echo urlencode($KeyWord);?>';";> <font color=blue>已送審不得再修改</font>
			          	<?php } else {?>
				          	<input type="submit" name="submit" class="input_bot" value="送 出">
			          	<?php }?>
			          </td>
			        </tr>
				      </form>
			      </table>
    			</td>
    		</tr>
    	</table>
    </td>
	</tr>
</table>
<?php include "down.php";?>
</body>
</html>
<?php
mysqli_close($link);
?>