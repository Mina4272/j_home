﻿<?php
include "CheckPermission.php";
include "CheckProjectAccounting.php";
include "../global.php";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $PageAdminTitle;?></title>
</head>
<body>
<?php
$SqlTxt = "";
$SqlTxt2 = "";
$PAPDate="";
$PAMode = $_POST['PAMode'];
$PID = $_POST['PID'];
$PAID = $_POST['PAID'];
$spage = $_POST['spage'];
$KeyWord = $_POST['KeyWord'];
$QPStatus = $_POST['QPStatus'];
$QAcc = $_POST['QAcc'];

$PANo = $_POST['PANo'];
$PAItem = $_POST['PAItem'];
//echo $PAItem;
//exit;
$Charges = $_POST['Charges'];
$ChargesOther = $_POST['ChargesOther'];
$Rate = $_POST['Rate'];
if (trim($Rate) == "") $Rate = "0";
if (trim($Rate) == "0") $ChargesOther = "0";
$PAStatus = $_POST['PAStatus'];

$PAPYear = $_POST['PAPYear'];
$PAPMonth = $_POST['PAPMonth'];
$PAPDay = $_POST['PAPDay'];
if (trim($PAPYear) != "" || trim($PAPMonth) != "" || trim($PAPDay) != "") if (checkdate($PAPMonth,$PAPDay ,$PAPYear)) $PAPDate = $PAPYear."-".$PAPMonth."-".$PAPDay;

$PAYear = $_POST['PAYear'];
$PAMonth = $_POST['PAMonth'];
$PADay = $_POST['PADay'];
if (trim($PAYear) != "" || trim($PAMonth) != "" || trim($PADay) != "") if (checkdate($PAMonth,$PADay ,$PAYear)) $PADate = $PAYear."-".$PAMonth."-".$PADay;
if (trim($PAStatus) != "S") $PADate = "";
$PANote = $_POST['PANote'];
$PANote = str_replace("\r\n","<br>",$PANote);
$CID = $_POST['CID'];
$CName = $_POST['CName'];
$CTel = $_POST['CTel'];
$CFax = $_POST['CFax'];
$CAddress = $_POST['CAddress'];

$InvoiceYear = $_POST['InvoiceYear'];
$InvoiceMonth = $_POST['InvoiceMonth'];
$InvoiceDay = $_POST['InvoiceDay'];
if (trim($InvoiceYear) != "" && trim($InvoiceMonth) != "" && trim($InvoiceDay) != "") if (checkdate($InvoiceMonth,$InvoiceDay ,$InvoiceYear)) $InvoiceDate = $InvoiceYear."-".$InvoiceMonth."-".$InvoiceDay;
$Invoice = $_POST['Invoice'];
$PA_Mode = $_POST['PA_Mode'];
$PATax = $_POST['PATax'];

if (trim($PID) == "" || trim($PAID) == "" || trim($PAItem) == "")
		{
		mysqli_close($link);
		?>
		<script type="text/JavaScript">
			<!--
			alert ("您輸入的資料不足，請重新輸入！");
			history.go(-1);
			//-->
		</script>
		<?php
		exit;
		}

$SQL_Project="select PUID,PName from Project where Deltag='N' and PID = '".$PID."';";
$result_Project=mysqli_query($link,$SQL_Project) or die ("無法執行查詢");
if (mysqli_num_rows($result_Project) == 0)
		{
		mysqli_free_result($result_Project);
		mysqli_close($link);
		?>
		<SCRIPT language=javascript>
		<!--
		alert ("查無資料，請冾網站管理人員！"); 
		history.go(-1);
		//-->
		</SCRIPT>
		<?php 	
		exit;
		}
mysqli_free_result($result_Project);

$SQL_ProjectAccounting="select PAStatus from ProjectAccounting where Deltag='N' and PID = '".$PID."' and PAID = '".$PAID."';";
$result_ProjectAccounting=mysqli_query($link,$SQL_ProjectAccounting) or die ("無法執行查詢");
if (mysqli_num_rows($result_ProjectAccounting) == 0)
		{
		mysqli_free_result($result_ProjectAccounting);
		mysqli_close($link);
		?>
		<SCRIPT language=javascript>
		<!--
		alert ("查無資料，請冾網站管理人員！"); 
		history.go(-1);
		//-->
		</SCRIPT>
		<?php 	
		exit;
		}
list($CheckStatus)=mysqli_fetch_row($result_ProjectAccounting);		
mysqli_free_result($result_ProjectAccounting);



if (trim($InvoiceDate)=="") $InvoiceDate = "NULL";
else $InvoiceDate = "'$InvoiceDate'";
if (trim($CID) == "") $CID = 0;
if (trim($PAPDate)=="") $PAPDate = "NULL";
else $PAPDate = "'$PAPDate'";
$now_time = date("Y-m-d H:i:s",mktime());
$sql_insert = "INSERT INTO ProjectAccountingHistory(PAID,PID,PANo,PAMode,PAItem,Charges,Rate,ChargesOther,PATax,PAStatus,PAPDate,PADate,PARecord,PARecordDate,PARecordIP,CID,CName,CTel,CFax,CAddress,InvoiceDate,Invoice,PANote,AddUser,AddDate,AddIP,Deltag,ProcUser,ProcDate,ProcIP,UpdateUser,UpdateDate,UpdateIP) SELECT PAID,PID,PANo,PAMode,PAItem,Charges,Rate,ChargesOther,PATax,PAStatus,PAPDate,PADate,PARecord,PARecordDate,PARecordIP,CID,CName,CTel,CFax,CAddress,InvoiceDate,Invoice,PANote,AddUser,AddDate,AddIP,Deltag,ProcUser,ProcDate,ProcIP,'".$_SESSION["reg_MUID"]."','".$now_time."','".$_SERVER["REMOTE_ADDR"]."' FROM ProjectAccounting where Deltag='N' and PID = '".$PID."' and PAID = '".$PAID."';";
$result_insert=mysqli_query($link,$sql_insert) or die ("無法執行新增");
if (trim($PAStatus) == "S") $SqlTxt = ",PADate = '".$PADate."',PARecord = '".$_SESSION["reg_MUID"]."',PARecordDate = '".$now_time."',PARecordIP = '".$_SERVER["REMOTE_ADDR"]."'";
else if (trim($PAStatus) == "C") $SqlTxt = ",PARecord = '".$_SESSION["reg_MUID"]."',PARecordDate = '".$now_time."',PARecordIP = '".$_SERVER["REMOTE_ADDR"]."'";

if (trim($_SESSION["reg_MUID"]) == "Benson" || trim($_SESSION["reg_MUID"]) == "vivi") {
		if (trim($Charges) != "" && trim($Rate) != "") $AdminEdit=",Charges = '".$Charges."',Rate = '".$Rate."',ChargesOther = '".$ChargesOther."'";
		}
if (trim($CheckStatus) == "W") $sql_update = "update ProjectAccounting set PANo = '".$PANo."',PAItem = '".addslashes($PAItem)."',Charges = '".$Charges."',Rate = '".$Rate."',ChargesOther = '".$ChargesOther."',PATax = '".$PATax."',PAPDate = ".$PAPDate.",PAStatus = '".$PAStatus."',InvoiceDate=".$InvoiceDate.",Invoice='".$Invoice."'".$SqlTxt.",PANote = '".addslashes($PANote)."',CID = '".$CID."',CName = '".$CName."',CTel = '".$CTel."',CFax = '".$CFax."',CAddress = '".$CAddress."',ProcUser = '".$_SESSION["reg_MUID"]."',ProcDate = '".$now_time."',ProcIP = '".$_SERVER["REMOTE_ADDR"]."' where Deltag='N' and PID = '".$PID."' and PAID = '".$PAID."';";
else $sql_update = "update ProjectAccounting set PANo = '".$PANo."',PAItem = '".addslashes($PAItem)."'".$AdminEdit.",PANote = '".addslashes($PANote)."' ,InvoiceDate=".$InvoiceDate.",PATax = '".$PATax."',Invoice='".$Invoice."',CID = '".$CID."',CName = '".$CName."',CTel = '".$CTel."',CFax = '".$CFax."',CAddress = '".$CAddress."',ProcUser = '".$_SESSION["reg_MUID"]."',ProcDate = '".$now_time."',ProcIP = '".$_SERVER["REMOTE_ADDR"]."' where Deltag='N' and PID = '".$PID."' and PAID = '".$PAID."';";
//echo $sql_update;
//exit;
$result_update=mysqli_query($link,$sql_update) or die ("無法執行修改");

mysqli_close($link);
?>
<script type="text/JavaScript">
	<!--
	alert ("修改成功！");
	location.href='ProjectAccountingList.php?PID=<?php echo $PID;?>&page=<?php echo $spage;?>&QPStatus=<?php echo $QPStatus;?>&QAcc=<?php echo $QAcc;?>&KeyWord=<?php echo urlencode($KeyWord);?>&PA_Mode=<?php echo $PA_Mode;?>';
	//-->
</script>

</body>
</html>
