﻿<?php	
include "CheckPermission.php";
include "CheckCustomer.php";
include "../global.php";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $PageAdminTitle;?></title>
<link href="../type.css" rel="stylesheet" type="text/css" />
<style type="text/css">
<!--
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
}
-->
</style>
<link href="../script/DatePicker.css" rel="stylesheet" type="text/css" />
<Script LANGUAGE="Javascript" SRC="../script/DatePicker.js"></Script>
<Script type="text/javascript" language="javascript" src="../script/CheckForm.js"></Script>
<script type="text/JavaScript">
<!--
function jsCheck() 
		{
		if (ChkImp('Contact',document.form1.Contact.value,'聯絡人') == false) return false;
		if (jsTrim(document.form1.CEMail.value) != "") if (ChkEmail('CEMail',document.form1.CEMail.value,'聯絡人E-Mail') == false) return false;
		}
//-->
</script>
</head>
<body>
<?php
$CCID = $_GET['CCID'];
$CID = $_GET['CID'];
if (trim($CID) == "" || trim($CCID) == "")
		{
		mysqli_close($link);
		?>
		<script type="text/JavaScript">
			<!--
			alert ("查無資料，請冾網站管理人員！");
			self.close();
			//-->
		</script>
		<?php
		exit;
		}

$SQL_CustomerContact="select Contact,CMobile,CEMail,CDep,CNote,AddUser,AddDate,ProcUser,ProcDate from CustomerContact where Deltag='N' and CID = '".$CID."' and CCID = '".$CCID."';";
$result_CustomerContact=mysqli_query($link,$SQL_CustomerContact) or die ("無法執行查詢");
if (mysqli_num_rows($result_CustomerContact) == 0)
		{
		mysqli_free_result($result_CustomerContact);
		mysqli_close($link);
		?>
		<SCRIPT language=javascript>
		<!--
		alert ("查無資料，請冾網站管理人員！"); 
		self.close();
		//-->
		</SCRIPT>
		<?php 	
		exit;
		}
list($Contact,$CMobile,$CEMail,$CDep,$CNote,$AddUser,$AddDate,$ProcUser,$ProcDate)=mysqli_fetch_row($result_CustomerContact);
mysqli_free_result($result_CustomerContact);
?>
<table width="100%" border="0" cellpadding="0" cellspacing="0">
	<tr>
		<td>
    	<table width="100%" border="0" cellpadding="0" cellspacing="0">
    		<tr height="30">
					<td width="15" background="../images/table_bg.gif"></td>
    			<td class="c3" background="../images/table_bg.gif"><b>修改聯絡人</b></td>
    		</tr>
    	</table>
    	<table width="100%" border="0" cellpadding="0" cellspacing="0">
        <form name="form1" method="post" action="CustomerContactEditDB.php" onSubmit="return jsCheck();">
        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
					<td width="15"></td>
          <td width="80" class="c3" align="right">聯絡人：</td>
          <td class="c3"><input name="Contact" type="text" size="20" value="<?php echo $Contact;?>" /></td>
        </tr>
          <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
					<td width="15"></td>
          <td class="c3" align="right">部門：</td>
          <td class="c3"><input name="CDep" type="text" size="20" value="<?php echo $CDep;?>" /></td>
        </tr>
      <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
					<td width="15"></td>
          <td class="c3" align="right">電話：</td>
          <td class="c3"><input name="CMobile" type="text" size="20" value="<?php echo $CMobile;?>" /></td>
        </tr>
        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
					<td width="15"></td>
          <td class="c3" align="right">E-Mail：</td>
          <td class="c3"><input name="CEMail" type="text" size="60" value="<?php echo $CEMail;?>" /></td>
        </tr>
        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
					<td width="15"></td>
          <td class="c3" align="right">聯絡事項：</td>
          <td class="c3"><input name="CNote" type="text" size="40" value="<?php echo $CNote;?>" /></td>
        </tr>
        <tr height="25" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
					<td width="15"></td>
          <td colspan="2" class="c3">新增人員：<span class="h3"><?php echo $AddUser;?>　<?php echo $AddDate;?></span></td>
        </tr>
        <?php if (trim($ProcUser) != "") {?>
        <tr height="25" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
					<td width="15"></td>
          <td colspan="2" class="c3">最後更新：<span class="h3"><?php echo $ProcUser;?>　<?php echo $ProcDate;?></span>
          	<input type="button" name="edit" value="歷史記錄" class="input_bot" onclick="javascript:window.open ('CustomerContactHistory.php?CID=<?php echo $CID;?>&CCID=<?php echo $CCID;?>','CustomerFileHistory','height=500,width=850,top=200,left=200,scrollbars=yes,status=yes');">
          </td>
        </tr>
        <?php }?>
        <tr height="40" align="center">
					<td width="15"></td>
          <td colspan="2" class="h3">
          	<input type="submit" name="submit" class="input_bot" value="送 出">
          	<input name="CCID" type="hidden" id="CCID" value="<?php echo $CCID;?>" />
          	<input name="CID" type="hidden" id="CID" value="<?php echo $CID;?>" />
          </td>
        </tr>
	      </form>
      </table>
		</td>
	</tr>
</table>
</body>
</html>
<?php
mysqli_close($link);
?>