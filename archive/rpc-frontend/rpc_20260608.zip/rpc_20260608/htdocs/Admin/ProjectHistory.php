﻿<?php
include "CheckPermission.php";
include "CheckProject.php";
include "../global.php";
include "include/page_function.php";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $PageAdminTitle;?></title>
<link href="../type.css" rel="stylesheet" type="text/css" />
<style type="text/css">
<!--
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
}
-->
</style></head>

<body>
<?php
$PID = $_GET['PID'];
if (trim($PID) == "")
		{
		mysqli_close($link);
		?>
		<script type="text/JavaScript">
			<!--
			alert ("查無資料，請冾網站管理人員！");
			history.go(-1);
			//-->
		</script>
		<?php
		exit;
		}
$SQL_Project="select PUID from Project where Deltag='N' and PID = '".$PID."';";
$result_Project=mysqli_query($link,$SQL_Project) or die ("無法執行查詢");
if (mysqli_num_rows($result_Project) == 0)
		{
		mysqli_free_result($result_Project);
		mysqli_close($link);
		?>
		<SCRIPT language=javascript>
		<!--
		alert ("查無資料，請冾網站管理人員！"); 
		history.go(-1);
		//-->
		</SCRIPT>
		<?php 	
		exit;
		}
mysqli_free_result($result_Project);

?>
<table width="100%" border="0" cellpadding="0" cellspacing="0">
	<tr>
		<td>
			<?php
			$page = empty($_GET['page'])?"":$_GET['page'];
			if (trim($page) == "") $page = 1;
			$page_rows=15;  //每頁筆數
			$php_Self = "ProjectHistory.php";  //分頁web檔名

			$button_css = "h4";
			$limit_txt =" limit ".(($page-1) * $page_rows).",".$page_rows;
			$url_str = "&PID=".$PID;
			$Sql_str="select PHID from ProjectHistory where Deltag='N' and PID = '".$PID."' order by PHID desc;";
			$SQL_Project="select PHID,PUID,CID,CName,CTel,CFax,CAddress,Contact,CMobile,CEMail,PStatus,PName,ModelName,SeriesModel,PE,Quote,ApplyItem,Canon,CCCCode,SNote,PlanDate,date_format(PlanDate,'%Y'),date_format(PlanDate,'%m'),date_format(PlanDate,'%d'),CloseDate,date_format(CloseDate,'%Y'),date_format(CloseDate,'%m'),date_format(CloseDate,'%d'),PNote,EMC,POther,PADate,date_format(PADate,'%Y'),date_format(PADate,'%m'),date_format(PADate,'%d'),PNote1,QuoteDate,ReturnDate,AddUser,AddDate,ProcUser,ProcDate from ProjectHistory where Deltag='N' and PID = '".$PID."' order by PHID desc ".$limit_txt.";";
			$result_Project=mysqli_query($link,$SQL_Project) or die ("無法執行查詢");
			?>
    	<table width="100%" border="0" cellpadding="5" cellspacing="2" class="s2">
        <tr align="center">
          <td background="../images/table_bg.gif" class="t21">案件編號</td>
          <td background="../images/table_bg.gif" class="t21">產品名稱</td>
          <td background="../images/table_bg.gif" class="t21">客戶名稱</td>
          <td background="../images/table_bg.gif" class="t21">狀態</td>
          <td background="../images/table_bg.gif" class="t21">詳細</td>
          <td width="150" background="../images/table_bg.gif" class="t21">最後更新</td>
        </tr>
        <?php
        $tmp = 1;
        while(list($PHID,$PUID,$CID,$CName,$CTel,$CFax,$CAddress,$Contact,$CMobile,$CEMail,$PStatus,$PName,$ModelName,$SeriesModel,$PE,$Quote,$ApplyItem,$Canon,$CCCCode,$SNote,$PlanDate,$PlanYear,$PlanMonth,$PlanDay,$CloseDate,$CloseYear,$CloseMonth,$CloseDay,$PNote,$EMC,$POther,$PADate,$PAYear,$PAMonth,$PADay,$PNote1,$QuoteDate,$ReturnDate,$AddUser,$AddDate,$ProcUser,$ProcDate)=mysqli_fetch_row($result_Project)){
      	?>
      	<tr<?php if ($tmp%2 == 0) echo " bgcolor=\"#F6F6F6\"";?>>
          <td align="center" class="h3"><?php echo $PUID;?></td>
          <td class="h3"><?php echo $PName;?></td>
          <td class="h3"><?php echo $CName;?></td>
          <td align="center" class="h3">
          	<?php
          	if (trim($PStatus) == "A") echo "新開案";
          	else if (trim($PStatus) == "B") echo "報價中";
          	else if (trim($PStatus) == "C") echo "案件處理中";
          	else if (trim($PStatus) == "D") echo "審查中";
          	else if (trim($PStatus) == "E") echo "補件中";
          	else if (trim($PStatus) == "F") echo "待印證";
          	else if (trim($PStatus) == "G") echo "案件取消";
          	else if (trim($PStatus) == "H") echo "已結案";
          	?>
          </td>
          <td align="center" class="h3"><input type="button" name="detail" value="詳細" class="input_bot" onclick="javascript:location.href='ProjectHistoryDetail.php?PHID=<?php echo $PHID;?>&PID=<?php echo $PID;?>&page=<?php echo $page;?>';"></td>
          <td align="center" class="h3">
          	<?php
          	if (trim($ProcUser) == "") echo $AddUser."<br>".$AddDate;
          	else echo $ProcUser."<br>".$ProcDate;
          	?>
          </td>
        </tr>
        <?php
      			$tmp++;
      			}
      	mysqli_free_result($result_Project);
        ?>
      </table>
      <table width="100%" border="0" cellpadding="5" cellspacing="2" class="s2">
        <tr align="center">
          <td bgcolor="#E8F0C2" class="h4"><?php Page_show($Sql_str,$page_rows,$php_Self,$link,$page,$url_str,$button_css);?></td>
        </tr>
      </table>
		</td>
	</tr>
</table>
</body>
</html>
<?php
mysqli_close($link);
?>