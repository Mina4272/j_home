﻿<?php	
include "CheckPermission.php";
include "CheckCustomer.php";
include "../global.php";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $PageAdminTitle;?></title>
<link href="../type.css" rel="stylesheet" type="text/css" />
<style type="text/css">
<!--
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
}
-->
</style>
<Script type="text/javascript" language="javascript" src="../script/rpc.js"></Script>
<Script type="text/javascript" language="javascript" src="../script/CheckForm.js"></Script>
<script type="text/JavaScript">
<!--
function jsCheck() 
		{
		if (ChkImp('CUID',document.form1.CUID.value,'統一編號') == false) return false;
		if (isBig5(document.form1.CUID.value))
				{
				alert ('您輸入的統一編號不得含有中文字及其他符號！');
				document.form1.CUID.focus();
				document.form1.CUID.select();
				return false;
				}
		if (ChkImp('CPWD',document.form1.CPWD.value,'密碼') == false) return false;
		if (ChkImp('CPWDCheck',document.form1.CPWDCheck.value,'確認密碼') == false) return false;
		if (jsTrim(document.form1.CPWD.value) != jsTrim(document.form1.CPWDCheck.value))
				{
				alert ('您輸入的密碼與確認密碼不相同，請重新輸入！');
				document.form1.CPWD.value = '';
				document.form1.CPWDCheck.value = '';
				document.form1.CPWD.focus();
				return false;
				}
		if (document.form1.CRecord[3].checked && jsTrim(document.form1.CRecordTxt.value) == "") {
				alert ('請輸入付款記錄其他說明！');
				document.form1.CRecordTxt.focus();
				document.form1.CRecordTxt.select();
				return false;
				}
		if (ChkImp('CName',document.form1.CName.value,'公司名稱') == false) return false;
		//if (ChkImp('CTel',document.form1.CTel.value,'公司電話') == false) return false;
		//if (jsTrim(document.form1.CEMail.value) != "") if (ChkEmail('CEMail',document.form1.CEMail.value,'聯絡人E-Mail') == false) return false;
		//if (ChkImp('CAddress',document.form1.CAddress.value,'公司地址') == false) return false;
		}

function DelTrademarkImg() {
		if (confirm('您確定要刪除此圖像嗎？')) {
				document.form1.TrademarkImg.value='';
				document.getElementById('TrademarkImgPreview').style.display = 'none';
				document.getElementById('TrademarkImgPreview').innerHTML = '';
				document.getElementById('TrademarkImgDel').style.display = 'none';
				document.getElementById('TrademarkImgDel').innerHTML = '';
				}
		}

function cpa_click1() {
		if (document.form1.cpa1.checked == true) document.form1.TAddress.value=document.form1.CAddress.value;
		}
function cpa_click2() {
		if (document.form1.cpa2.checked == true) document.form1.LAddress.value=document.form1.TAddress.value;
		}
//-->
</script>
</head>
<body>
<?php include "top.php";?>
<table width="100%" border="0" cellspacing="0" cellpadding="5">
	<tr>
    <td width="160" height="600" align="left" valign="top">
			<?php include "menu.php";?>
    </td>
    <td valign="top">
    	<table width="100%" border="0" cellpadding="0" cellspacing="0">
    		<tr>
    			<td>
			    	<table width="750" border="0" cellpadding="0" cellspacing="0">
			    		<tr height="30">
			    			<td class="c2"><b>新增客戶資料</b></td>
			    		</tr>
			    	</table>
			    	<table width="750" border="0" cellpadding="0" cellspacing="0">
			        <form name="form1" method="post" action="CustomerAddDB.php" onSubmit="return jsCheck();">
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td width="130" align="right" class="c3">統一編號：</td>
			          <td class="h3"><input type="text" name="CUID" size="20"> <font color=red>( 此欄位為該客戶帳號，不得修改 )</font></td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">密 碼：</td>
			          <td class="h3"><input type="password" name="CPWD" size="20"></td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">密碼確認：</td>
			          <td class="h3"><input type="password" name="CPWDCheck" size="20"></td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">客戶種類：</td>
			          <td class="h3">
			          	<input type="checkbox" name="CType[]" value="N" checked> 一般客戶 
			          	<input type="checkbox" name="CType[]" value="P"> 供應商
			          </td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">客戶等級：</td>
			          <td class="h3">
			          	<input type="radio" name="CLevel" value="A" checked><img src="../images/A1.gif" border="0"> 優(結案後直接給證書)　
			          	<input type="radio" name="CLevel" value="B"><img src="../images/B1.gif" border="0"> 良(結案付款後給證書)
			          </td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">規費是否代付：</td>
			          <td class="h3">
			          	<input type="radio" name="CFees" value="A" checked><img src="../images/A1.gif" border="0"> 是(收據抬頭開全威)　
			          	<input type="radio" name="CFees" value="B"><img src="../images/B1.gif" border="0"> 是(收據抬頭開申請人)　
			          	<input type="radio" name="CFees" value="C"><img src="../images/C1.gif" border="0"> 否(不代送審)
			          </td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">付款記錄：</td>
			          <td class="h3">
			          	<input type="radio" name="CRecord" value="A" checked><img src="../images/A2.gif" border="0"> 優(結案後月結60天)　
			          	<input type="radio" name="CRecord" value="B"><img src="../images/B2.gif" border="0"> 良(月結30天)　
			          	<input type="radio" name="CRecord" value="C"><img src="../images/C2.gif" border="0"> 付款開案<br>
			          	<input type="radio" name="CRecord" value="D"><img src="../images/D2.gif" border="0"> 其他 
			          	<input type="text" name="CRecordTxt" size="20">
			          </td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">公司名稱：</td>
			          <td class="h3"><input type="text" name="CName" size="60"></td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">公司英文名稱：</td>
			          <td class="h3"><input type="text" name="EName" size="60"></td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">BSMI識別號碼：</td>
			          <td class="h3"><input type="text" name="BSMI" size="20"></td>
			        </tr>
			        <tr height="60" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">商 標：</td>
			          <td class="h3">
	              	<table width="100%" border="0" cellpadding="0" cellspacing="0">
	              		<tr class="h3">
	              			<td width="40" align="center">圖片</td>
	              			<td align="center"><div id="TrademarkImgPreview" style="display:none"></div></td>
	              			<td align="center" valign="bottom"><div id="TrademarkImgDel" style="display:none"></div></td>
	              			<td>
				              	<input name="TrademarkImg" type="hidden" id="TrademarkImg" />
				              	<input name="TrademarkImgUpload" type="button" class="input_bot" value="上傳" onclick="MM_openBrWindow('TrademarkImgUpload.php','_TrademarkImgUpload','scrollbars=no,resizable=no,width=450,height=180,top=200,left=200');" /> 
				              	<font color="blue">*上傳圖片限 gif 或 jpg 格式</font>
	              			</td>
	              		</tr>
	              		<tr>
	              			<td width="40" align="center" class="h3">文字</td>
	              			<td colspan="3">
				              	<input type="text" name="TrademarkTxt" size="40">
	              			</td>
	              		</tr>
	              	</table>
			          </td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">負責人：</td>
			          <td class="h3"><input type="text" name="Principal" size="60"></td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">公司電話：</td>
			          <td class="h3"><input type="text" name="CTel" size="20"></td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">公司傳真：</td>
			          <td class="h3"><input type="text" name="CFax" size="20"></td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">發票地址：</td>
			          <td class="h3"><input type="text" name="CAddress" size="60"></td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">營登地址：</td>
			          <td class="h3"><input type="text" name="TAddress" size="60">
			          	 <input type="checkbox" name="cpa1" value="1" onclick="javascript:cpa_click1();"> 同上
			          </td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">聯絡地址：</td>
			          <td class="h3"><input type="text" name="LAddress" size="60">
			          	 <input type="checkbox" name="cpa2" value="1" onclick="javascript:cpa_click2();"> 同上
			          </td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">發票用統一編號：</td>
			          <td class="h3"><input type="text" name="GUI" size="60"></td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">備 註：</td>
			          <td class="h3"><input type="text" name="CNote" size="60"></td>
			        </tr>
			        </tr>
			        <tr height="40" align="center">
			          <td colspan="2" class="h3"><input type="submit" name="submit" class="input_bot" value="送 出"></td>
			        </tr>
				      </form>
			      </table>
    			</td>
    		</tr>
    	</table>
    </td>
	</tr>
</table>
<?php include "down.php";?>
</body>
</html>
<?php
mysqli_close($link);
?>