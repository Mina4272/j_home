﻿<?php
include "CheckPermission.php";
include "CheckCustomer.php";
include "../global.php";
include "include/function.php";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $PageAdminTitle;?></title>
</head>
<body>
<?php
$CID = $_POST['CID'];
$CFName = $_POST['CFName'];

if(trim($_FILES['CFile']['tmp_name']) != "")
		{
		if($_FILES['CFile']['size'] > 20971520)
				{
				?>
				<script type="text/JavaScript">
					<!--
					alert ("您上傳的檔案 Size 超過 20 M，請重新上傳！");
					history.go(-1);
					//-->
				</script>
				<?php
				exit();
				}
		$PFIntro1 = $_POST['PFIntro1'];
		$CFile = "CFile_".$CID.date("ymdHis",mktime()).rand_string(5, 'ABCDEFGHIJKLMNPQRSTUVWXYZ23456789abcdefghijklmnopqrstuvwxyz').".".strtolower(substr($_FILES['CFile']['name'],strrpos($_FILES['CFile']['name'],".")+1,strlen($_FILES['CFile']['name'])+1));
		@copy($_FILES['CFile']['tmp_name'],$_SERVER["DOCUMENT_ROOT"]."\\Admin\\CFile\\".$CFile);
		}

if (trim($CID) == "" || trim($CFName) == "" || trim($CFile) == "")
		{
		mysqli_close($link);
		?>
		<script type="text/JavaScript">
			<!--
			alert ("您輸入的資料不足，請重新輸入！");
			self.close();
			//-->
		</script>
		<?php
		exit;
		}

$now_time = date("Y-m-d H:i:s",mktime());
$sql_insert = "insert into CustomerFile (CID,CFName,CFile,AddUser,AddDate,AddIP) values ('".$CID."','".$CFName."','".$CFile."','".$_SESSION["reg_MUID"]."','".$now_time."','".$_SERVER["REMOTE_ADDR"]."');";
$result_insert=mysqli_query($link,$sql_insert) or die ("無法執行新增");

mysqli_close($link);
?>
<script type="text/JavaScript">
	<!--
	alert ("新增成功！");
	opener.location.reload();
	self.close();
	//-->
</script>

</body>
</html>
