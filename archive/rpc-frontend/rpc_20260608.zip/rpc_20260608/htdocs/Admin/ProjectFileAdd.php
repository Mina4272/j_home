﻿<?php	
include "CheckPermission.php";
include "CheckProject.php";
include "../global.php";
include "include/utf8.php";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $PageAdminTitle;?></title>
<link href="../type.css" rel="stylesheet" type="text/css" />
<style type="text/css">
<!--
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
}
-->
</style>
<link href="../script/DatePicker.css" rel="stylesheet" type="text/css" />
<Script LANGUAGE="Javascript" SRC="../script/DatePicker.js"></Script>
<Script type="text/javascript" language="javascript" src="../script/CheckForm.js"></Script>
<script type="text/JavaScript">
<!--
function jsCheck() 
		{
    if (jsTrim(document.form1.PFileName1.value) == "" && jsTrim(document.form1.PFileName2.value) == "" && jsTrim(document.form1.PFileName3.value) == "" && jsTrim(document.form1.PFileName4.value) == "" && jsTrim(document.form1.PFileName5.value) == "")
    		{
				alert("請選擇您要上傳檔案！");
				document.form1.PFileName1.focus();
				return false;
    		}
		}
//-->
</script>
</head>
<body>
<?php include "top.php";?>
<?php
$PID = $_GET['PID'];
$PFCID = $_GET['PFCID'];
$spage = $_GET['spage'];
$KeyWord = $_GET['KeyWord'];
$QPStatus = $_GET['QPStatus'];
$QPE = $_GET['QPE'];
if (trim($PID) == "" || trim($PFCID) == "")
		{
		mysqli_close($link);
		?>
		<script type="text/JavaScript">
			<!--
			alert ("查無資料，請冾網站管理人員！");
			history.go(-1);
			//-->
		</script>
		<?php
		exit;
		}
$SQL_Project="select PUID,PName,CName,ModelName from Project where Deltag='N' and PID = '".$PID."';";
$result_Project=mysqli_query($link,$SQL_Project) or die ("無法執行查詢");
if (mysqli_num_rows($result_Project) == 0)
		{
		mysqli_free_result($result_Project);
		mysqli_close($link);
		?>
		<SCRIPT language=javascript>
		<!--
		alert ("查無資料，請冾網站管理人員！"); 
		history.go(-1);
		//-->
		</SCRIPT>
		<?php 	
		exit;
		}
list($PUID,$PName,$CName,$ModelName)=mysqli_fetch_row($result_Project);
mysqli_free_result($result_Project);
if (utf8_strlen(strip_tags($CName)) > 4) $CName = utf8_substr(strip_tags($CName),0,4);
else $CName = strip_tags($CName);

$SQL_ProjectFileClass="select PFCName from ProjectFileClass where Deltag='N' and PFCID = '".$PFCID."';";
$result_ProjectFileClass=mysqli_query($link,$SQL_ProjectFileClass) or die ("無法執行查詢");
if (mysqli_num_rows($result_ProjectFileClass) == 0)
		{
		mysqli_free_result($result_ProjectFileClass);
		mysqli_close($link);
		?>
		<SCRIPT language=javascript>
		<!--
		alert ("查無資料，請冾網站管理人員！"); 
		history.go(-1);
		//-->
		</SCRIPT>
		<?php 	
		exit;
		}
list($PFCName)=mysqli_fetch_row($result_ProjectFileClass);
mysqli_free_result($result_ProjectFileClass);
?>
<table width="100%" border="0" cellspacing="0" cellpadding="5">
	<tr>
    <td width="160" height="600" align="left" valign="top">
			<?php include "menu.php";?>
    </td>
    <td valign="top">
    	<table width="100%" border="0" cellpadding="0" cellspacing="0">
    		<tr>
    			<td>
			    	<table width="750" border="0" cellpadding="0" cellspacing="0">
			    		<tr height="30">
			    			<td class="c2"><a href="ProjectList.php?page=<?php echo $spage;?>&QPStatus=<?php echo $QPStatus;?>&QPE=<?php echo $QPE;?>&KeyWord=<?php echo urlencode($KeyWord);?>">案件資料列表</a> &gt; <a href="ProjectFileClassList.php?PID=<?php echo $PID;?>&PFCID=<?php echo $PFCID;?>&page=<?php echo $spage;?>&QPStatus=<?php echo $QPStatus;?>&QPE=<?php echo $QPE;?>&KeyWord=<?php echo urlencode($KeyWord);?>"><?php echo $CName;?> - <?php echo $ModelName;?> 類別列表</a> &gt; <a href="ProjectFileList.php?PID=<?php echo $PID;?>&PFCID=<?php echo $PFCID;?>&spage=<?php echo $spage;?>&QPStatus=<?php echo $QPStatus;?>&QPE=<?php echo $QPE;?>&KeyWord=<?php echo urlencode($KeyWord);?>"><?php echo $PFCName;?></a> &gt; 新增檔案</td>
			    		</tr>
			    	</table>
			    	<table width="750" border="0" cellpadding="0" cellspacing="0">
			        <form name="form1" method="post" action="ProjectFileAddDB.php" enctype="multipart/form-data" onSubmit="return jsCheck();">
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td width="120" align="right" class="c3">檔案 1：</td>
			          <td class="h3"><input type="file" name="PFileName1" size="60"></td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">檔案 1 說明：</td>
			          <td class="h3">
			          	<input type="hidden" name="PID" value="<?php echo $PID;?>">
			          	<input type="hidden" name="PFCID" value="<?php echo $PFCID;?>">
			          	<input type="hidden" name="spage" value="<?php echo $spage;?>">
			          	<input type="hidden" name="KeyWord" value="<?php echo $KeyWord;?>">
			          	<input type="hidden" name="QPStatus" value="<?php echo $QPStatus;?>">
			          	<input type="hidden" name="QPE" value="<?php echo $QPE;?>">
			          	<input type="text" name="PFIntro1" size="80">
			          </td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">檔案 2：</td>
			          <td class="h3"><input type="file" name="PFileName2" size="60"></td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">檔案 2 說明：</td>
			          <td class="h3">
			          	<input type="text" name="PFIntro2" size="80">
			          </td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">檔案 3：</td>
			          <td class="h3"><input type="file" name="PFileName3" size="60"></td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">檔案 3 說明：</td>
			          <td class="h3">
			          	<input type="text" name="PFIntro3" size="80">
			          </td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">檔案 4：</td>
			          <td class="h3"><input type="file" name="PFileName4" size="60"></td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">檔案 4 說明：</td>
			          <td class="h3">
			          	<input type="text" name="PFIntro4" size="80">
			          </td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">檔案 5：</td>
			          <td class="h3"><input type="file" name="PFileName5" size="60"></td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">檔案 5 說明：</td>
			          <td class="h3">
			          	<input type="text" name="PFIntro5" size="80">
			          </td>
			        </tr>
			        <tr height="40" align="center">
			          <td colspan="2" class="h3"><input type="submit" name="submit" class="input_bot" value="送 出"></td>
			        </tr>
				      </form>
			      </table>
    			</td>
    		</tr>
    	</table>
    </td>
	</tr>
</table>
<?php include "down.php";?>
</body>
</html>
<?php
mysqli_close($link);
?>