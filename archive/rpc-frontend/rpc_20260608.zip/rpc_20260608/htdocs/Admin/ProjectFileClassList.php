﻿<?php
include "CheckPermission.php";
include "CheckProject.php";
include "../global.php";
include "include/page_function.php";
include "include/utf8.php";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $PageAdminTitle;?></title>
<link href="../type.css" rel="stylesheet" type="text/css" />
<style type="text/css">
<!--
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
}
-->
</style></head>

<body>
<?php include "top.php";?>
<?php
$PID = $_GET['PID'];
$spage = $_GET['page'];
$KeyWord = $_GET['KeyWord'];
$QPStatus = $_GET['QPStatus'];
$QPE = $_GET['QPE'];
$QBMUID = empty($_GET['QBMUID'])?"":$_GET['QBMUID'];
$ISINo = empty($_GET['ISINo'])?"":$_GET['ISINo'];
$ISAdd = empty($_GET['ISAdd'])?"":$_GET['ISAdd'];

if (trim($PID) == "")
		{
		mysqli_close($link);
		?>
		<script type="text/JavaScript">
			<!--
			alert ("查無資料，請冾網站管理人員！");
			history.go(-1);
			//-->
		</script>
		<?php
		exit;
		}
$SQL_Project="select PUID,PName,CName,ModelName from Project where Deltag='N' and PID = '".$PID."';";
$result_Project=mysqli_query($link,$SQL_Project) or die ("無法執行查詢");
if (mysqli_num_rows($result_Project) == 0)
		{
		mysqli_free_result($result_Project);
		mysqli_close($link);
		?>
		<SCRIPT language=javascript>
		<!--
		alert ("查無資料，請冾網站管理人員！"); 
		history.go(-1);
		//-->
		</SCRIPT>
		<?php 	
		exit;
		}
list($PUID,$PName,$CName,$ModelName)=mysqli_fetch_row($result_Project);
mysqli_free_result($result_Project);
if (utf8_strlen(strip_tags($CName)) > 4) $CName = utf8_substr(strip_tags($CName),0,4);
else $CName = strip_tags($CName);
?>
<table width="100%" border="0" cellspacing="0" cellpadding="5">
	<tr>
    <td width="160" height="600" align="left" valign="top">
			<?php include "menu.php";?>
    </td>
    <td valign="top">
    	<table width="100%" border="0" cellpadding="0" cellspacing="0">
    		<tr>
    			<td>
			    	<table width="750" border="0" cellpadding="0" cellspacing="0">
			    		<tr height="30">
			    			<td class="c2"><a href="ProjectList.php?page=<?php echo $spage;?>&QPStatus=<?php echo $QPStatus;?>&QPE=<?php echo $QPE;?>&QBMUID=<?php echo $QBMUID;?>&ISINo=<?php echo $ISINo;?>&ISAdd=<?php echo $ISAdd;?>&KeyWord=<?php echo urlencode($KeyWord);?>">案件資料列表</a> &gt; <?php echo $CName;?> - <?php echo $ModelName;?> 類別列表</td>
			    			<td width="100"><input type="button" name="button" class="input_bot" value="其他相關資料" onclick="javascript:window.open('\\\\192.168.1.55','OtherFile','');"></td>
			    		</tr>
			    	</table>
						<?php
						$SQL_ProjectFileClass="select PFCID,PFCName,Sort,(select count(PFID) as FileCount from ProjectFile where Deltag='N' and PID = '".$PID."' and PFCID = ProjectFileClass.PFCID) as FileCount from ProjectFileClass where Deltag='N' order by Sort;";
						$result_ProjectFileClass=mysqli_query($link,$SQL_ProjectFileClass) or die ("無法執行查詢");
						?>
			    	<table width="750" border="0" cellpadding="5" cellspacing="2" class="s2">
			        <tr align="center">
			          <td width="100" align="center" background="../images/table_bg.gif" class="t21">序</td>
			          <td background="../images/table_bg.gif" class="t21">檔案類別名稱</td>
			          <td width="100" background="../images/table_bg.gif" class="t21">檔案數量</td>
			          <td width="120" background="../images/table_bg.gif" class="t21">檔案列表</td>
			        </tr>
		          <?php
		          $tmp = 1;
		          while(list($PFCID,$PFCName,$Sort,$FileCount)=mysqli_fetch_row($result_ProjectFileClass)){
		        	?>
		        	<tr<?php if ($tmp%2 == 0) echo " bgcolor=\"#F6F6F6\"";?>>
			          <td align="center" class="h3"><?php echo $Sort;?></td>
			          <td align="center" class="h3"><?php echo $PFCName;?></td>
			          <td align="center" class="h3"><?php echo $FileCount;?></td>
			          <td align="center"><input type="button" name="edit" value="檔案列表" class="input_bot" onclick="javascript:location.href='ProjectFileList.php?PID=<?php echo $PID;?>&PFCID=<?php echo $PFCID;?>&spage=<?php echo $spage;?>&QPStatus=<?php echo $QPStatus;?>&QPE=<?php echo $QPE;?>&KeyWord=<?php echo urlencode($KeyWord);?>';"></td>
			        </tr>
			        <?php
            			$tmp++;
			      			}
            	mysqli_free_result($result_ProjectFileClass);
			        ?>
			      </table>
    			</td>
    		</tr>
    	</table>
    </td>
	</tr>
</table>
<?php include "down.php";?>
</body>
</html>
<?php
mysqli_close($link);
?>