﻿<?php
include "CheckPermission.php";
include "CheckCustomer.php";
include "../global.php";
include "include/function.php";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $PageAdminTitle;?></title>
</head>
<body>
<?php
$CID = $_POST['CID'];
$page = $_POST['page'];
$CPWD = $_POST['CPWD'];
$CName = $_POST['CName'];
$EName = $_POST['EName'];
$TrademarkTxt = $_POST['TrademarkTxt'];
$TrademarkImg = $_POST['TrademarkImg'];
$CTel = $_POST['CTel'];
$CFax = $_POST['CFax'];
$Contact = $_POST['Contact'];
$CMobile = $_POST['CMobile'];
$CEMail = $_POST['CEMail'];
$CAddress = $_POST['CAddress'];
$CNote = $_POST['CNote'];
$CType = $_POST['CType'];
$CTypeTxt = join(",", $CType);
$CLevel = $_POST['CLevel'];
$CFees = $_POST['CFees'];
$CRecord = $_POST['CRecord'];
$CRecordTxt = $_POST['CRecordTxt'];
if (trim($CRecord) != "D") $CRecordTxt="";
$BSMI = $_POST['BSMI'];

$Principal = $_POST['Principal'];
$TAddress = $_POST['TAddress'];
$LAddress = $_POST['LAddress'];
$GUI = $_POST['GUI'];

if(trim($_FILES['CustomerFile']['tmp_name']) != "")
		{
		if($_FILES['CustomerFile']['size'] > 20971520)
				{
				?>
				<script type="text/JavaScript">
					<!--
					alert ("您上傳的檔案 Size 超過 20 M，請重新上傳！");
					history.go(-1);
					//-->
				</script>
				<?php
				exit();
				}
		$CustomerFile = "CustomerFile_".date("ymdHis",mktime()).rand_string(5, 'ABCDEFGHIJKLMNPQRSTUVWXYZ23456789abcdefghijklmnopqrstuvwxyz').".".strtolower(substr($_FILES['CustomerFile']['name'],strrpos($_FILES['CustomerFile']['name'],".")+1,strlen($_FILES['CustomerFile']['name'])+1));
		@copy($_FILES['CustomerFile']['tmp_name'],$_SERVER["DOCUMENT_ROOT"]."\\Admin\\CustomerFile\\".$CustomerFile);
		}


if (trim($CID) == "" || trim($CPWD) == "" || trim($CName) == "")
		{
		mysqli_close($link);
		?>
		<script type="text/JavaScript">
			<!--
			alert ("您輸入的資料不足，請重新輸入！");
			history.go(-1);
			//-->
		</script>
		<?php
		exit;
		}

$now_time = date("Y-m-d H:i:s",mktime());
$SQL_select="select CID from Customer where DelTag = 'N' and CID = '".$CID."';";
$result_select=mysqli_query($link,$SQL_select) or die ("無法執行查詢");

if (mysqli_num_rows($result_select) == 0)
		{
		mysqli_free_result($result_select);
		mysqli_close($link);
		?>
		<script type="text/JavaScript">
			<!--
			alert ("查無資料，請冾網站管理人員！");
			history.go(-1);
			//-->
		</script>
		<?php
		exit;
		}
mysqli_free_result($result_select);

$sql_insert = "INSERT INTO CustomerHistory(CID,CType,CUID,CPWD,CName,EName,BSMI,TrademarkTxt,TrademarkImg,Principal,CTel,CFax,Contact,CMobile,CEMail,CAddress,TAddress,LAddress,GUI,CNote,CLevel,CFees,CRecord,CRecordTxt,CLoginTime,AddUser,AddDate,AddIP,Deltag,ProcUser,ProcDate,ProcIP,UpdateUser,UpdateDate,UpdateIP) SELECT CID,CType,CUID,CPWD,CName,EName,BSMI,TrademarkTxt,TrademarkImg,Principal,CTel,CFax,Contact,CMobile,CEMail,CAddress,TAddress,LAddress,GUI,CNote,CLevel,CFees,CRecord,CRecordTxt,CLoginTime,AddUser,AddDate,AddIP,Deltag,ProcUser,ProcDate,ProcIP,'".$_SESSION["reg_MUID"]."','".$now_time."','".$_SERVER["REMOTE_ADDR"]."' FROM Customer where DelTag = 'N' and CID = '".$CID."';";
$result_insert=mysqli_query($link,$sql_insert) or die ("無法執行新增");
$sql_update = "update Customer set CustomerFile= '".$CustomerFile."',CPWD = '".$CPWD."',CName = '".$CName."',EName = '".$EName."',TrademarkTxt = '".$TrademarkTxt."',TrademarkImg = '".$TrademarkImg."',CTel = '".$CTel."',CFax = '".$CFax."',CAddress = '".$CAddress."',CNote = '".$CNote."',CType = '".$CTypeTxt."',CLevel = '".$CLevel."',CFees = '".$CFees."',CRecord = '".$CRecord."',CRecordTxt = '".$CRecordTxt."',BSMI = '".$BSMI."',Principal = '".$Principal."',TAddress = '".$TAddress."',LAddress = '".$LAddress."',GUI = '".$GUI."',ProcUser = '".$_SESSION["reg_MUID"]."',ProcDate = '".$now_time."',ProcIP = '".$_SERVER["REMOTE_ADDR"]."' where DelTag = 'N' and CID = '".$CID."';";
$result_update=mysqli_query($link,$sql_update) or die ("無法執行修改");

mysqli_close($link);
?>
<script type="text/JavaScript">
	<!--
	alert ("修改成功！");
	location.href='CustomerList.php?page=<?php echo $page;?>';
	//-->
</script>

</body>
</html>
