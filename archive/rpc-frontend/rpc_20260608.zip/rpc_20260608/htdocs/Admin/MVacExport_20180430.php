﻿<?php
include "CheckPermission.php";
include "CheckMVac.php";
include "../global.php";

$QMVSDate ="";
$QMVEDate = "";
$SqlTxt = "";
$limit_txt ="";

$QMVSYear = $_POST['QMVSYear'];
$QMVSMonth = $_POST['QMVSMonth'];
$QMVSDay = $_POST['QMVSDay'];
if (trim($QMVSYear) != "" || trim($QMVSMonth) != "" || trim($QMVSDay) != "") if (checkdate($QMVSMonth,$QMVSDay ,$QMVSYear)) $QMVSDate = $QMVSYear."-".$QMVSMonth."-".$QMVSDay;
$QMVEYear = $_POST['QMVEYear'];
$QMVEMonth = $_POST['QMVEMonth'];
$QMVEDay = $_POST['QMVEDay'];
if (trim($QMVEYear) != "" || trim($QMVEMonth) != "" || trim($QMVEDay) != "") if (checkdate($QMVEMonth,$QMVEDay ,$QMVEYear)) $QMVEDate = $QMVEYear."-".$QMVEMonth."-".$QMVEDay;

$QMVType = $_POST['QMVType'];
$QMUID = $_POST['QMUID'];
$KeyWord = $_POST['KeyWord'];

if (trim($QMVSDate) != "" && trim($QMVEDate) != "") $SqlTxt = $SqlTxt." and (MVSDate >= '".$QMVSDate." 00:00:00') and (MVEDate <= '".$QMVEDate." 23:59:59') ";
else if (trim($QMVSDate) != "" && trim($QMVEDate) == "") $SqlTxt = $SqlTxt." and (MVSDate >= '".$QMVSDate." 00:00:00') ";
else if (trim($QMVSDate) == "" && trim($QMVEDate) != "") $SqlTxt = $SqlTxt." and (MVEDate <= '".$QMVEDate." 23:59:59') ";
if (trim($QMVType) != "") $SqlTxt = $SqlTxt." and MVType='".$QMVType."' ";
if (trim($QMUID) != "") $SqlTxt = $SqlTxt." and MUID='".$QMUID."' ";
if (trim($KeyWord) != "") $SqlTxt = $SqlTxt." and (MVNote like '%".$KeyWord."%')";

$SQL_ManagerVac="select MVID,MUID,MVType,MVSDate,MVEDate,Hourage,Agent,(select MName from Manager where MUID=ManagerVac.Agent) AMName,(select MEName from Manager where MUID=ManagerVac.Agent) AMEName,MVNote,MVCheck,MVCNote,MVSend,MVCheckID,(select MName from Manager where MUID=ManagerVac.MVCheckID) MVCMName,(select MEName from Manager where MUID=ManagerVac.MVCheckID) MVCEMName,MVCheckDate,MVCheckIP,AddDate,AddUser,(select MName from Manager where MUID=ManagerVac.MUID) MName,(select MEName from Manager where MUID=ManagerVac.MUID) MEName from ManagerVac where Deltag='N' ".$SqlTxt." order by MVID desc ".$limit_txt.";";
$result_ManagerVac=mysqli_query($link,$SQL_ManagerVac) or die ("無法執行查詢");
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $PageAdminTitle;?></title>
<link href="style.css" rel="stylesheet" type="text/css" />
<body>
<table winth="1000" border="0">
	<tr>
		<td colspan="2"><font color=blue>若您無法正常觀看此報表！請下載此 <a href="owc11.zip" target="_File"><font color=red><b>元件</b></font></a> <font color=blue>安裝至您的電腦。</font></td>
	</tr>
</table>
<object id=ProjectAccounting classid=CLSID:0002E559-0000-0000-C000-000000000046 style="width:100%;height:90%"></object>
<script language=vbscript>
	Sub Window_OnLoad()
	Set chConstants = ProjectAccounting.Constants
	ProjectAccounting.ActiveSheet.Cells.Clear
	ProjectAccounting.Worksheets(1).Select
	ProjectAccounting.ActiveSheet.Name ="ProjectAccounting"

	ProjectAccounting.ActiveSheet.Cells(1,1).Value ="假別"
	ProjectAccounting.ActiveSheet.Cells(1,2).Value ="申請人"
	ProjectAccounting.ActiveSheet.Cells(1,3).Value ="日期"
	ProjectAccounting.ActiveSheet.Cells(1,4).Value ="時數"
	ProjectAccounting.ActiveSheet.Cells(1,5).Value ="代理人"
	ProjectAccounting.ActiveSheet.Cells(1,6).Value ="是否送審"
	ProjectAccounting.ActiveSheet.Cells(1,7).Value ="是否簽核"
	ProjectAccounting.ActiveSheet.Cells(1,8).Value ="簽核備註"
	ProjectAccounting.ActiveSheet.Cells(1,9).Value ="簽核人員"
	ProjectAccounting.ActiveSheet.Cells(1,10).Value ="簽核時間"
	ProjectAccounting.ActiveSheet.Cells(1,11).Value ="備註"
<?php  
$ECount=2;
while(list($MVID,$MUID,$MVType,$MVSDate,$MVEDate,$Hourage,$Agent,$AMName,$AMEName,$MVNote,$MVCheck,$MVCNote,$MVSend,$MVCheckID,$MVCMName,$MVCEMName,$MVCheckDate,$MVCheckIP,$AddDate,$AddUser,$MName,$MEName)=mysqli_fetch_row($result_ManagerVac)){
  	if (trim($MVType) == "A") $MVType="事假";
  	else if (trim($MVType) == "B") $MVType="病假";
  	else if (trim($MVType) == "C") $MVType="公假";
  	else if (trim($MVType) == "D") $MVType="喪假";
  	else if (trim($MVType) == "E") $MVType="婚假";
  	else if (trim($MVType) == "F") $MVType="產假";
  	else if (trim($MVType) == "G") $MVType="特休";
  	else if (trim($MVType) == "H") $MVType="其他";
  	if (trim($MVSend) == "Y") $MVSend="是";
  	else if (trim($MVSend) == "N") $MVSend="否";
  	if (trim($MVCheck) == "Y") $MVCheck="是";
  	else if (trim($MVCheck) == "N") $MVCheck="否";
  	else if (trim($MVCheck) == "W") $MVCheck="等待簽核";
		?>
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,1).Value ="'<?php echo $MVType;?>"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,2).Value ="<?php echo $MEName.$MName;?>"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,3).Value ="<?php echo $MVSDate." ~ ".$MVEDate;?>"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,4).Value ="<?php echo $Hourage;?>"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,5).Value ="<?php echo $AMEName.$AMName;?>"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,6).Value ="<?php echo $MVSend;?>"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,7).Value ="<?php echo $MVCheck;?>"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,8).Value ="<?php echo $MVCNote;?>"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,9).Value ="<?php echo $MVCEMName.$MVCMName;?>"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,10).Value ="'<?php echo $MVCheckDate;?>"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,11).Value ="<?php echo $MVNote;?>"
		<?php
		$ECount++;
		}
mysqli_free_result($result_ManagerVac);
mysqli_close($link);
?>

		ProjectAccounting.ActiveSheet.Range("A1:R<?php echo $ECount;?>").Font.Color="blue"
		ProjectAccounting.ActiveSheet.Range("A1:R<?php echo $ECount;?>").Font.Name="Courier New"
		ProjectAccounting.ActiveSheet.Range("A1:R<?php echo $ECount;?>").Font.Size="11"
		ProjectAccounting.ActiveSheet.Range("A1:R<?php echo $ECount;?>").Columns.AutoFit
		ProjectAccounting.ActiveSheet.Range("A1:R<?php echo $ECount;?>").NumberFormat ="General"

		ProjectAccounting.ActiveSheet.Range("A1:R1").Font.Bold=true
		ProjectAccounting.ActiveSheet.Range("A1:R1").Font.Color="#000000"
		ProjectAccounting.ActiveSheet.Range("A1:R1").Font.Bold=true
		ProjectAccounting.ActiveSheet.Range("A1:R1").Font.Bold=true
		ProjectAccounting.ActiveSheet.Range("A1:R1").Font.Bold=true

	End Sub
	</script>
</body>
</html>
