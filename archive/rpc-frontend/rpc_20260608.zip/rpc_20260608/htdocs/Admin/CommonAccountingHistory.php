﻿<?php
include "CheckPermission.php";
include "CheckCommonAccounting.php";
include "../global.php";
include "include/page_function.php";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $PageAdminTitle;?></title>
<link href="../type.css" rel="stylesheet" type="text/css" />
<style type="text/css">
<!--
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
}
-->
</style></head>

<body>
<?php
$CAID = $_GET['CAID'];
if (trim($CAID) == "")
		{
		mysqli_close($link);
		?>
		<script type="text/JavaScript">
			<!--
			alert ("查無資料，請冾網站管理人員！");
			history.go(-1);
			//-->
		</script>
		<?php
		exit;
		}
$SQL_CommonAccounting="select CADate from CommonAccounting where Deltag='N' and CAID = '".$CAID."';";
$result_CommonAccounting=mysqli_query($link,$SQL_CommonAccounting) or die ("無法執行查詢");
if (mysqli_num_rows($result_CommonAccounting) == 0)
		{
		mysqli_free_result($result_CommonAccounting);
		mysqli_close($link);
		?>
		<SCRIPT language=javascript>
		<!--
		alert ("查無資料，請冾網站管理人員！"); 
		history.go(-1);
		//-->
		</SCRIPT>
		<?php 	
		exit;
		}
mysqli_free_result($result_CommonAccounting);

?>
<table width="100%" border="0" cellpadding="0" cellspacing="0">
	<tr>
		<td>
			<?php
			$page = empty($_GET['page'])?"":$_GET['page'];
			if (trim($page) == "") $page = 1;
			$page_rows=15;  //每頁筆數
			$php_Self = "CommonAccountingHistory.php";  //分頁web檔名

			$button_css = "h4";
			$limit_txt =" limit ".(($page-1) * $page_rows).",".$page_rows;
			$url_str = "&CAID=".$CAID;
			$Sql_str="select CAHID from CommonAccountingHistory where Deltag='N' and CAID = '".$CAID."' order by CAHID desc;";
			$SQL_CommonAccounting="select CAHID,CAUID,CADate,CAItem,CAType,Amount,InvoiceDate,Invoice,CAStatus,PayDate,CANote,AddUser,AddDate,ProcUser,ProcDate from CommonAccountingHistory where Deltag='N' and CAID = '".$CAID."' order by CAHID desc ".$limit_txt.";";
			$result_CommonAccounting=mysqli_query($link,$SQL_CommonAccounting) or die ("無法執行查詢");
			?>
    	<table width="100%" border="0" cellpadding="5" cellspacing="2" class="s2">
        <tr align="center">
          <td background="../images/table_bg.gif" class="t21">帳目编號</td>
          <td background="../images/table_bg.gif" class="t21">項 目</td>
          <td background="../images/table_bg.gif" class="t21">類 別</td>
          <td background="../images/table_bg.gif" class="t21">金 額</td>
          <td background="../images/table_bg.gif" class="t21">狀 態</td>
          <td background="../images/table_bg.gif" class="t21">備 註</td>
          <td background="../images/table_bg.gif" class="t21">詳細</td>
          <td width="150" background="../images/table_bg.gif" class="t21">最後更新</td>
        </tr>
        <?php
        $tmp = 1;
        while(list($CAHID,$CAUID,$CADate,$CAItem,$CAType,$Amount,$InvoiceDate,$Invoice,$CAStatus,$PayDate,$CANote,$AddUser,$AddDate,$ProcUser,$ProcDate)=mysqli_fetch_row($result_CommonAccounting)){
      	?>
      	<tr<?php if ($tmp%2 == 0) echo " bgcolor=\"#F6F6F6\"";?>>
			          <td align="center" class="h3"><?php echo $CAUID;?></td>
			          <td class="h3"><?php echo $CAItem;?></td>
			          <td align="center" class="h3">
			          	<?php
			          	if (trim($CAType) == "C") echo "公司";
			          	else if (trim($CAType) == "P") echo "個人";
			          	?>
			          </td>
			          <td class="h3" align="center"><?php echo $Amount;?></td>
			          <td align="center" class="h3">
			          	<?php
			          	if (trim($CAStatus) == "W") echo "未付";
			          	else if (trim($CAStatus) == "S") echo "<font color=blue>結清</font><br>".$PayDate;
			          	else if (trim($CAStatus) == "C") echo "<font color=red>取消</font>";
			          	?>
			          </td>
			          <td class="h3"><?php echo $CANote;?></td>
          <td align="center" class="h3"><input type="button" name="detail" value="詳細" class="input_bot" onclick="javascript:location.href='CommonAccountingHistoryDetail.php?CAHID=<?php echo $CAHID;?>&CAID=<?php echo $CAID;?>&page=<?php echo $page;?>';"></td>
          <td align="center" class="h3">
          	<?php
          	if (trim($ProcUser) == "") echo $AddUser."<br>".$AddDate;
          	else echo $ProcUser."<br>".$ProcDate;
          	?>
          </td>
        </tr>
        <?php
      			$tmp++;
      			}
      	mysqli_free_result($result_CommonAccounting);
        ?>
      </table>
      <table width="100%" border="0" cellpadding="5" cellspacing="2" class="s2">
        <tr align="center">
          <td bgcolor="#E8F0C2" class="h4"><?php Page_show($Sql_str,$page_rows,$php_Self,$link,$page,$url_str,$button_css);?></td>
        </tr>
      </table>
		</td>
	</tr>
</table>
</body>
</html>
<?php
mysqli_close($link);
?>