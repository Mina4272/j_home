<?php
include "CheckPermission.php";
include "../global.php";
include "include/page_function.php";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $PageAdminTitle;?></title>
<link href="../type.css" rel="stylesheet" type="text/css" />
<style type="text/css">
<!--
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
}
-->
</style></head>

<body>
<table width="100%" border="0" cellspacing="0" cellpadding="5">
	<tr>
    <td width="160" height="600" align="left" valign="top">
			<?php include "menu.php";?>
		</td>
    <td valign="top">
    	<table width="100%" border="0" cellpadding="0" cellspacing="0">
    		<tr>
    			<td>
			    	<table width="750" border="0" cellpadding="0" cellspacing="0">
			    		<tr height="30">
			    			<td class="t2">登入成功！
			    			<span class="h3">您上次登入的時間為</span> <span class="c3"><?php echo $_SESSION["reg_MLoginTime"];?></span>
			    			</td>
			    		</tr>
			    		<tr height="30">
			    			<td class="h3">請選擇維護項目！</td>
			    		</tr>
			    		<tr height="30">
			    			<td class="c2"><b>證書到期提醒</b></td>
			    		</tr>
			    	</table>
			    	<?php
						$page = $_GET['page'];
						if (trim($page) == "") $page = 1;
						$page_rows=15;  //每頁筆數
						$php_Self = "index.php";  //分頁web檔名

						$button_css = "h4";
						$limit_txt =" limit ".(($page-1) * $page_rows).",".$page_rows;
						$url_str = "";
						$Sql_str="SELECT PCID FROM ProjectCertificate Where Deltag='N' and ISRemind='N' and PCEDate <> '0000-00-00' and PCEDate < '".date ("Y/m/d", mktime (0,0,0,date("m")+3,date("d"),date("Y")))."' order by PCEDate desc;";
						$SQL_ProjectCertificate="SELECT PCID,PID,PCNo,PCName,PCFile,PCSDate,PCEDate,PCNote,(select PName from Project where Deltag='N' and PID=ProjectCertificate.PID) as PName,(select PE from Project where Deltag='N' and PID=ProjectCertificate.PID) as PE FROM ProjectCertificate Where Deltag='N' and ISRemind='N' and PCEDate <> '0000-00-00' and PCEDate < '".date ("Y/m/d", mktime (0,0,0,date("m")+3,date("d"),date("Y")))."' order by PCEDate desc ".$limit_txt.";";
						$result_ProjectCertificate=mysql_query($SQL_ProjectCertificate,$link) or die ("無法執行查詢");
			    	?>
			    	<table width="750" border="0" cellpadding="5" cellspacing="2" class="s2">
			        <tr align="center">
			          <td width="80" align="center" background="../images/table_bg.gif" class="t21">編號</td>
			          <td width="150" background="../images/table_bg.gif" class="t21">名稱</td>
			          <td width="150" background="../images/table_bg.gif" class="t21">相關案件<br>案件工程師</td>
			          <td width="85" background="../images/table_bg.gif" class="t21">有效日期</td>
			          <td background="../images/table_bg.gif" class="t21">備註</td>
			          <td width="40" background="../images/table_bg.gif" class="t21">詳細</td>
			          <td width="70" background="../images/table_bg.gif" class="t21">取消提醒</td>
			        </tr>
		          <?php
		          $tmp = 1;
		          while(list($PCID,$PID,$PCNo,$PCName,$PCFile,$PCSDate,$PCEDate,$PCNote,$PName,$PE)=mysql_fetch_row($result_ProjectCertificate)){
								$SQL_Manager="SELECT MName FROM Manager Where Deltag='N' and MUID='".$PE."'";
								$result_Manager=mysql_query($SQL_Manager,$link) or die ("無法執行查詢");
								list($MName)=mysql_fetch_row($result_Manager);
								mysql_free_result($result_Manager);
		        	?>
		        	<tr<?php if ($tmp%2 == 0) echo " bgcolor=\"#F6F6F6\"";?>>
			          <td class="h3"><?php echo $PCNo;?></td>
			          <td class="h3"><a href="getfile.php?FolderName=Admin\\PCFile&FileName=<?php echo $PCFile;?>"><?php echo $PCName;?></a></td>
			          <td class="h3"><?php echo $PName;?><br><?php echo $MName;?></td>
			          <td class="h3" align="center"><?php echo $PCEDate;?></td>
			          <td class="h3"><?php echo $PCNote;?></td>
			          <td align="center"><input type="button" name="edit" value="詳細" class="input_bot" onclick="javascript:location.href='ProjectDetail.php?PID=<?php echo $PID;?>';"></td>
			          <td align="center"><input type="button" name="edit" value="取消" class="input_bot" onclick="javascript:if (confirm('您是否確定要取消提醒？')) location.href='ProjectCertificateRemindDB.php?PCID=<?php echo $PCID;?>&page=<?php echo $page;?><?php echo $url_str;?>';"></td>
			        </tr>
			        <?php
            			$tmp++;
			      			}
            	mysql_free_result($result_ProjectCertificate);
			        ?>
			    	</table>
			      <table width="750" border="0" cellpadding="5" cellspacing="2" class="s2">
			        <tr align="center">
			          <td bgcolor="#E8F0C2" class="h4"><?php Page_show($Sql_str,$page_rows,$php_Self,$link,$page,$url_str,$button_css);?></td>
			        </tr>
			      </table>
    			</td>
    		</tr>
    	</table>
    </td>
	</tr>
</table>
<?php include "down.php";?>
</body>
</html>
<?php
mysql_close($link);
?>