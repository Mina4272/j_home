﻿<?php
include "CheckPermission.php";
include "../global.php";
include "include/page_function.php";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $PageAdminTitle;?></title>
<link href="../type.css" rel="stylesheet" type="text/css" />
<link href="../script/DatePicker.css" rel="stylesheet" type="text/css" />
<Script LANGUAGE="Javascript" SRC="../script/DatePicker.js"></Script>
<style type="text/css">
<!--
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
}
-->
</style>
<Script type="text/javascript" language="javascript" src="../script/CheckForm.js"></Script>
<script type="text/JavaScript">
<!--
function jsCheck() 
		{
		if (jsTrim(document.form1.QMVSYear.value) != "" || jsTrim(document.form1.QMVSMonth.value) != "" || jsTrim(document.form1.QMVSDay.value) != "") if (ChkDate('QMVSYear',document.form1.QMVSYear.value,document.form1.QMVSMonth.value,document.form1.QMVSDay.value,'請假起始時間') == false) return false;
		if (jsTrim(document.form1.QMVEYear.value) != "" || jsTrim(document.form1.QMVEMonth.value) != "" || jsTrim(document.form1.QMVEDay.value) != "") if (ChkDate('QMVEYear',document.form1.QMVEYear.value,document.form1.QMVEMonth.value,document.form1.QMVEDay.value,'請假結束時間') == false) return false;
		if (jsTrim(document.form1.QMVSYear.value) != "" && jsTrim(document.form1.QMVSMonth.value) != "" && jsTrim(document.form1.QMVSDay.value) != "" && jsTrim(document.form1.QMVEYear.value) != "" && jsTrim(document.form1.QMVEMonth.value) != "" && jsTrim(document.form1.QMVEDay.value) != "") if (CompareDate('QMVSYear',document.form1.QMVSYear.value,document.form1.QMVSMonth.value,document.form1.QMVSDay.value,document.form1.QMVEYear.value,document.form1.QMVEMonth.value,document.form1.QMVEDay.value,'請假起始時間','請假結束時間') == false) return false;
		}

function MVacExport() 
		{
		document.form_exp.QMVSYear.value = document.form1.QMVSYear.value;
		document.form_exp.QMVSMonth.value = document.form1.QMVSMonth.value;
		document.form_exp.QMVSDay.value = document.form1.QMVSDay.value;
		document.form_exp.QMVEYear.value = document.form1.QMVEYear.value;
		document.form_exp.QMVEMonth.value = document.form1.QMVEMonth.value;
		document.form_exp.QMVEDay.value = document.form1.QMVEDay.value;
		document.form_exp.QMVType.value = document.form1.QMVType.value;
		document.form_exp.QMUID.value = document.form1.QMUID.value;
		document.form_exp.QAgent.value = document.form1.QAgent.value;
		document.form_exp.QMVCheck.value = document.form1.QMVCheck.value;
		document.form_exp.KeyWord.value = document.form1.KeyWord.value;
		document.form_exp.submit();
		}
//-->
</script>
</head>

<body>
<?php include "top.php";?>
<?php
$SqlTxt="";
$QMVID = empty($_GET['QMVID'])?"":$_GET['QMVID'];

$QMVSDate = empty($_POST['QMVSDate'])?"":$_POST['QMVSDate'];
if (trim($QMVSDate) == "") $QMVSDate = empty($_GET['QMVSDate'])?"":$_GET['QMVSDate'];
$QMVEDate = empty($_POST['QMVEDate'])?"":$_POST['QMVEDate'];
if (trim($QMVEDate) == "") $QMVEDate = empty($_GET['QMVEDate'])?"":$_GET['QMVEDate'];
if (trim($QMVSDate) == "") {
		$QMVSYear = empty($_POST['QMVSYear'])?"":$_POST['QMVSYear'];
		$QMVSMonth = empty($_POST['QMVSMonth'])?"":$_POST['QMVSMonth'];
		$QMVSDay = empty($_POST['QMVSDay'])?"":$_POST['QMVSDay'];
		if (trim($QMVSYear) != "" || trim($QMVSMonth) != "" || trim($QMVSDay) != "") if (checkdate($QMVSMonth,$QMVSDay ,$QMVSYear)) $QMVSDate = $QMVSYear."-".$QMVSMonth."-".$QMVSDay;
		}
if (trim($QMVEDate) == "") {
		$QMVEYear = empty($_POST['QMVEYear'])?"":$_POST['QMVEYear'];
		$QMVEMonth = empty($_POST['QMVEMonth'])?"":$_POST['QMVEMonth'];
		$QMVEDay = empty($_POST['QMVEDay'])?"":$_POST['QMVEDay'];
		if (trim($QMVEYear) != "" || trim($QMVEMonth) != "" || trim($QMVEDay) != "") if (checkdate($QMVEMonth,$QMVEDay ,$QMVEYear)) $QMVEDate = $QMVEYear."-".$QMVEMonth."-".$QMVEDay;
		}
$QMVType = empty($_POST['QMVType'])?"":$_POST['QMVType'];
if (trim($QMVType) == "") $QMVType = empty($_GET['QMVType'])?"":$_GET['QMVType'];
$QMUID = empty($_POST['QMUID'])?"":$_POST['QMUID'];
if (trim($QMUID) == "") $QMUID = empty($_GET['QMUID'])?"":$_GET['QMUID'];
$QAgent = empty($_POST['QAgent'])?"":$_POST['QAgent'];
if (trim($QAgent) == "") $QAgent = empty($_GET['QAgent'])?"":$_GET['QAgent'];
$QMVCheck = empty($_POST['QMVCheck'])?"":$_POST['QMVCheck'];
if (trim($QMVCheck) == "") $QMVCheck = empty($_GET['QMVCheck'])?"":$_GET['QMVCheck'];
$KeyWord = empty($_POST['KeyWord'])?"":$_POST['KeyWord'];
if (trim($KeyWord) == "") $KeyWord = empty($_GET['KeyWord'])?"":$_GET['KeyWord'];
?>
<table width="100%" border="0" cellspacing="0" cellpadding="5">
	<tr>
    <td width="160" height="600" align="left" valign="top">
			<?php include "menu.php";?>
    </td>
    <td valign="top">
    	<table width="100%" border="0" cellpadding="0" cellspacing="0">
    		<tr>
    			<td>
			    	<table width="750" border="0" cellpadding="0" cellspacing="0">
			    		<tr>
			    			<td class="c2" width="200">請假申請列表</td>
			    			<td align="right" class="h3"></td>
			    			<td width="20"></td>
			    		</tr>
			    	</table>
			    	<table width="750" border="0" cellpadding="0" cellspacing="0">
			    		<form name="form1" action="MVacList.php" method="post" onSubmit="return jsCheck();">
			    		<tr>
			    			<td align="left" class="h3" colspan="4">請假時間：
			            <input name="QMVSYear" type="text" size="4" value="<?php echo $QMVSYear;?>" />年
			            <input name="QMVSMonth" type="text" size="2" value="<?php echo $QMVSMonth;?>" />月
			            <input name="QMVSDay" type="text" size="2" value="<?php echo $QMVSDay;?>" />日
			            <img src="../images/icon.gif" width="16" height="18" style="cursor: hand" onclick="javascript:displayDatePicker('QMVSYear','QMVSMonth','QMVSDay');"/>～
			            <input name="QMVEYear" type="text" size="4" value="<?php echo $QMVEYear;?>" />年
			            <input name="QMVEMonth" type="text" size="2" value="<?php echo $QMVEMonth;?>" />月
			            <input name="QMVEDay" type="text" size="2" value="<?php echo $QMVEDay;?>" />日
			            <img src="../images/icon.gif" width="16" height="18" style="cursor: hand" onclick="javascript:displayDatePicker('QMVEYear','QMVEMonth','QMVEDay');"/>
			    				<?php if (trim(strstr($_SESSION["reg_MPer"],'J')) != "") {?>
								<input type="button" name="report" class="input_bot" value="報表輸出" onclick="javascript:MVacExport();">
								<input type="button" name="report" class="input_bot" value="統計報表" onclick="javascript:window.open ('MVacExportSummary.php','Exp','');">
								<?php }?>
			    			</td>
			    		</tr>
			    		<tr>
			    			<td align="left" class="h3">
			    				假　別：
			          	<select name="QMVType">
			          		<option value="">不限</option>
			          		<option value="A"<?php if (trim($QMVType) == "A") echo " selected";?>>事假</option>
			          		<option value="B"<?php if (trim($QMVType) == "B") echo " selected";?>>病假</option>
			          		<option value="C"<?php if (trim($QMVType) == "C") echo " selected";?>>公假</option>
			          		<option value="D"<?php if (trim($QMVType) == "D") echo " selected";?>>喪假</option>
			          		<option value="E"<?php if (trim($QMVType) == "E") echo " selected";?>>婚假</option>
			          		<option value="F"<?php if (trim($QMVType) == "F") echo " selected";?>>產假</option>
			          		<option value="G"<?php if (trim($QMVType) == "G") echo " selected";?>>特休</option>
							<option value="I"<?php if (trim($QMVType) == "I") echo " selected";?>>生理假</option>
			          		<option value="H"<?php if (trim($QMVType) == "H") echo " selected";?>>其他</option>
			          	</select>
			          	</select>
			    			</td>
			    			<td align="left" class="h3">
			    				申請人：
			          	<select name="QMUID">
			          		<option value="">不限</option>
			          		<?php
										$SQL_Manager="select MUID,MName,MEName from Manager where Deltag='N' and IsLeft='N' order by MID;";
										$result_Manager=mysqli_query($link,$SQL_Manager) or die ("無法執行查詢");
			          		while(list($MUID,$MName,$MEName)=mysqli_fetch_row($result_Manager)){
					          		?>
					          		<option value="<?php echo $MUID;?>"<?php if (trim($MUID) == trim($QMUID)) echo " selected";?>><?php echo $MEName.$MName;?></option>
					          		<?php
						      			}
			            	mysqli_free_result($result_Manager);
			          		?>
			          	</select>
			    			</td>
			    			<td align="left" class="h3" colspan="2">
			    				代理人：
			          	<select name="QAgent">
			          		<option value="">不限</option>
			          		<?php
										$SQL_Manager="select MUID,MName,MEName from Manager where Deltag='N' and IsLeft='N' order by MID;";
										$result_Manager=mysqli_query($link,$SQL_Manager) or die ("無法執行查詢");
			          		while(list($MUID,$MName,$MEName)=mysqli_fetch_row($result_Manager)){
					          		?>
					          		<option value="<?php echo $MUID;?>"<?php if (trim($MUID) == trim($QAgent)) echo " selected";?>><?php echo $MEName.$MName;?></option>
					          		<?php
						      			}
			            	mysqli_free_result($result_Manager);
			          		?>
			          	</select>
			    			</td>
			    		</tr>
			    		<tr>
			    			<td align="left" class="h3" width="170">
			    				狀　態：
			          	<select name="QMVCheck">
			          		<option value="">不限</option>
			          		<option value="W"<?php if (trim($QMVCheck) == "W") echo " selected";?>>等待簽核</option>
			          		<option value="Y"<?php if (trim($QMVCheck) == "Y") echo " selected";?>>已簽核</option>
			          		<option value="N"<?php if (trim($QMVCheck) == "N") echo " selected";?>>未簽核</option>
			          	</select>
			    			</td>
			    			<td align="left" class="h3" width="280">
			    				關鍵字：<input type="text" name="KeyWord" size="15" value="<?php echo $KeyWord;?>"> 
			    			</td>
			    			<td align="left" class="h3" width="170">
			    				<input type="submit" class="input_bot" name="search" value="查詢"> <input type="button" name="button" class="input_bot" value="全部列出" onclick="javascript:location.href='MVacList.php';">
			    			</td>
			    			<td align="right" class="h3" width="130">
			    				<input type="button" name="add" value="新 增" class="input_bot" onclick="javascript:location.href='MVacAdd.php';">
			    			</td>
			    		</tr>
			    		</form>
			    	</table>
						<?php
						if (trim($QMVSDate) != "" && trim($QMVEDate) != "") $SqlTxt = $SqlTxt." and (MVSDate >= '".$QMVSDate." 00:00:00') and (MVSDate <= '".$QMVEDate." 23:59:59') ";
						else if (trim($QMVSDate) != "" && trim($QMVEDate) == "") $SqlTxt = $SqlTxt." and (MVSDate >= '".$QMVSDate." 00:00:00') ";
						else if (trim($QMVSDate) == "" && trim($QMVEDate) != "") $SqlTxt = $SqlTxt." and (MVEDate <= '".$QMVEDate." 23:59:59') ";
						if (trim($QMVType) != "") $SqlTxt = $SqlTxt." and MVType='".$QMVType."' ";
						if (trim($QMUID) != "") $SqlTxt = $SqlTxt." and MUID='".$QMUID."' ";
						if (trim($QAgent) != "") $SqlTxt = $SqlTxt." and Agent='".$QAgent."' ";
						if (trim($QMVCheck) != "") $SqlTxt = $SqlTxt." and MVCheck='".$QMVCheck."' ";
						if (trim($KeyWord) != "") $SqlTxt = $SqlTxt." and (Hourage like '%".$KeyWord."%' or MVNote like '%".$KeyWord."%')";
						if (trim($QMVID) != "") $SqlTxt = $SqlTxt." and MVID=".$QMVID." ";
						$page = empty($_GET['page'])?"":$_GET['page'];
						if (trim($page) == "") $page = 1;
						$page_rows=15;  //每頁筆數
						$php_Self = "MVacList.php";  //分頁web檔名

						$button_css = "h4";
						$limit_txt =" limit ".(($page-1) * $page_rows).",".$page_rows;
						$url_str = "&QMVSDate=".$QMVSDate."&QMVEDate=".$QMVEDate."&QMVType=".$QMVType."&QMUID=".$QMUID."&QAgent=".$QAgent."&QMVCheck=".$QMVCheck."&KeyWord=".urlencode($KeyWord);
						$Sql_str="select MVID,MUID,MVType,MVSDate,MVEDate,Hourage,Agent,MVNote,MVCheck,MVFile,MVCNote,MVSend,MVCheckID,MVCheckDate,MVCheckIP,AddDate from ManagerVac where Deltag='N' ".$SqlTxt." order by MVID desc;";
						$SQL_ManagerVac="select MVID,MUID,MVType,MVSDate,MVEDate,Hourage,Agent,(select MName from Manager where DELTAG='N' and MUID=ManagerVac.Agent) AMName,(select MEName from Manager where DELTAG='N' and MUID=ManagerVac.Agent) AMEName,MVFile,MVNote,MVCheck,MVCNote,MVSend,MVCheckID,(select MName from Manager where DELTAG='N' and MUID=ManagerVac.MVCheckID) MVCMName,(select MEName from Manager where DELTAG='N' and MUID=ManagerVac.MVCheckID) MVCMEName,MVCheckDate,MVCheckIP,AddDate,AddUser,(select MName from Manager where DELTAG='N' and MUID=ManagerVac.MUID) MName,(select MEName from Manager where DELTAG='N' and MUID=ManagerVac.MUID) MEName from ManagerVac where Deltag='N' ".$SqlTxt." order by MVID desc ".$limit_txt.";";
						//echo $SQL_ManagerVac;
						$result_ManagerVac=mysqli_query($link,$SQL_ManagerVac) or die ("無法執行查詢");
						?>
			    	<table width="750" border="0" cellpadding="5" cellspacing="2" class="s2">
			        <tr align="center">
			          <td width="30" align="center" background="../images/table_bg.gif" class="t21">假別</td>
					  <?php if (trim($_SESSION["reg_MUID"]) == "TonyH" || trim($_SESSION["reg_MUID"]) == "amandas") {?>
					  <td width="110" background="../images/table_bg.gif" class="t21">請假證明</td>
					  <?php }?>
			          <td width="110" background="../images/table_bg.gif" class="t21">日期</td>
			          <td width="30" background="../images/table_bg.gif" class="t21">時數</td>
			          <td width="50" background="../images/table_bg.gif" class="t21">申請人</td>
			          <td width="50" background="../images/table_bg.gif" class="t21">代理人</td>
			          <td width="120" background="../images/table_bg.gif" class="t21">狀態</td>
			          <td width="100" background="../images/table_bg.gif" class="t21">備註</td>
			          <td width="50" background="../images/table_bg.gif" class="t21">修改<br>刪除</td>
			        </tr>
		          <?php
		          $tmp = 1;
		          while(list($MVID,$MUID,$MVType,$MVSDate,$MVEDate,$Hourage,$Agent,$AMName,$AMEName,$MVFile,$MVNote,$MVCheck,$MVCNote,$MVSend,$MVCheckID,$MVCMName,$MVCMEName,$MVCheckDate,$MVCheckIP,$AddDate,$AddUser,$MName,$MEName)=mysqli_fetch_row($result_ManagerVac)){
		        		if (trim($MVType) == "A") $MVType="事假";
		        		else if (trim($MVType) == "B") $MVType="病假";
		        		else if (trim($MVType) == "C") $MVType="公假";
		        		else if (trim($MVType) == "D") $MVType="喪假";
		        		else if (trim($MVType) == "E") $MVType="婚假";
		        		else if (trim($MVType) == "F") $MVType="產假";
		        		else if (trim($MVType) == "G") $MVType="特休";
						else if (trim($MVType) == "I") $MVType="生理假";
		        		else if (trim($MVType) == "H") $MVType="其他";
		        	?>
		        	<tr<?php if ($tmp%2 == 0) echo " bgcolor=\"#F6F6F6\"";?>>
			          <td align="center" class="h3"><?php echo $MVType;?></td>
					  <?php if (trim($_SESSION["reg_MUID"]) == "TonyH" || trim($_SESSION["reg_MUID"]) == "amandas") {?>
					  <td class="h3"><img src="MVFile/<?php echo $MVFile; ?>" width="250"/></td>
					  <?php }?>
			          <td class="h3"><?php echo $MVSDate;?> ~<br><?php echo $MVEDate;?></td>
			          <td align="center" class="h3"><?php echo $Hourage;?></td>
			          <td align="center" class="h3"><?php echo $MEName.$MName;?></td>
			          <td align="center" class="h3"><?php echo $AMEName.$AMName;?></td>
			          <td align="center" class="h3">
			          	<?php
			          	if (trim($MVSend) == "N") echo "編輯中";
			          	else if (trim($MVSend) == "Y") {
					        		if (trim($MVCheck) == "W") {
					        				echo "待簽核<br>";
					        				if (trim(strstr($_SESSION["reg_MPer"],'J')) != "") {
							        				?>
							        				<input type="button" name="audit" value="簽核" class="input_bot" onclick="javascript:window.open ('MVacAudit.php?MVID=<?php echo $MVID;?>','audit','height=340,width=700,top=200,left=200,scrollbars=yes,status=yes');">
							        				<?php
					        						}
					        				}
					        		else if (trim($MVCheck) == "Y") {
					        				echo "<font color=blue>已核準</font><br>".$MVCNote."<br>".$MVCMEName.$MVCMName."<br>".$MVCheckDate;
					        				}
					        		else if (trim($MVCheck) == "N") {
					        				echo "<font color=red>不核準</font><br>".$MVCNote."<br>".$MVCMEName.$MVCMName."<br>".$MVCheckDate;
					        				}
			          			}
			          	?>	
			          </td>
			          <td class="h4"><?php echo $MVNote;?></td>
			          <td align="center">
			          	<?php
			          	if (trim($MVCheck) != "W" || (trim($MUID) != trim($_SESSION["reg_MUID"]))) $CKT=" disabled";
			          	else $CKT="";
			          	?>
			          	<input type="button" name="edit" <?php echo $CKT;?> value="修 改" class="input_bot" onclick="javascript:location.href='MVacEdit.php?MVID=<?php echo $MVID;?>&page=<?php echo $page;?><?php echo $url_str;?>';"><br>
			          	<input type="button" <?php if (trim($_SESSION["reg_MUID"]) == "Tony" || trim($_SESSION["reg_MUID"]) == "amanda" || trim($_SESSION["reg_MUID"]) == "jacky") {} else {echo $CKT;};?> name="edit" value="刪 除" class="input_bot" onclick="javascript:if (confirm('您是否確定要刪除？')) location.href='MVacDelDB.php?MVID=<?php echo $MVID;?>&page=<?php echo $page;?><?php echo $url_str;?>';">
			          </td>
			        </tr>
			        <?php
            			$tmp++;
			      			}
            	mysqli_free_result($result_ManagerVac);
			        ?>
			      </table>
			      <table width="750" border="0" cellpadding="5" cellspacing="2" class="s2">
			        <tr align="center">
			          <td bgcolor="#E8F0C2" class="h4"><?php Page_show($Sql_str,$page_rows,$php_Self,$link,$page,$url_str,$button_css);?></td>
			        </tr>
			      </table>
    			</td>
    		</tr>
    	</table>
    </td>
	</tr>
</table>
<form name="form_exp" action="MVacExport.php" method="post" target="_MVacExport">
	<input type="hidden" name="QMVSYear">
	<input type="hidden" name="QMVSMonth">
	<input type="hidden" name="QMVSDay">
	<input type="hidden" name="QMVEYear">
	<input type="hidden" name="QMVEMonth">
	<input type="hidden" name="QMVEDay">
	<input type="hidden" name="QMVType">
	<input type="hidden" name="QMUID">
	<input type="hidden" name="QAgent">
	<input type="hidden" name="QMVCheck">
	<input type="hidden" name="KeyWord">
</form>
<?php include "down.php";?>
</body>
</html>
<?php
mysqli_close($link);
?>