﻿<?php
include "CheckPermission.php";
include "CheckProjectAccounting.php";
include "../global.php";
include "include/page_function.php";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $PageAdminTitle;?></title>
<link href="../type.css" rel="stylesheet" type="text/css" />
<style type="text/css">
<!--
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
}
-->
</style></head>

<body>
<?php include "top.php";?>
<?php
$PID = empty($_GET['PID'])?"":$_GET['PID'];
$spage = empty($_GET['page'])?"":$_GET['page'];
$KeyWord = empty($_GET['KeyWord'])?"":$_GET['KeyWord'];
$QPStatus = empty($_GET['QPStatus'])?"":$_GET['QPStatus'];
$QAcc = empty($_GET['QAcc'])?"":$_GET['QAcc'];
$PA_Mode = empty($_GET['PA_Mode'])?"":$_GET['PA_Mode'];
if (trim($PA_Mode) == "") $PA_Mode="I";

if (trim(strstr($_SESSION["reg_MPer"],'D')) == "") {
		if (trim($PA_Mode) == "I"){
				if (trim(strstr($_SESSION["reg_MPer"],'I')) == "") {
						mysqli_close($link);
						exit;
						}
				}
		if (trim($PA_Mode) == "O"){
				if (trim(strstr($_SESSION["reg_MPer"],'L')) == "") {
						mysqli_close($link);
						exit;
						}
				}
		}

if (trim($PID) == "")
		{
		mysqli_close($link);
		?>
		<script type="text/JavaScript">
			<!--
			alert ("查無資料，請冾網站管理人員！");
			history.go(-1);
			//-->
		</script>
		<?php
		exit;
		}
$SQL_Project="select PUID,PName,QuoteDate,IFlorin,OFlorin,CName,PE,ApplyItem,Agent,ModelName,PTax from Project where Deltag='N' and PID = '".$PID."';";
$result_Project=mysqli_query($link,$SQL_Project) or die ("無法執行查詢");
if (mysqli_num_rows($result_Project) == 0)
		{
		mysqli_free_result($result_Project);
		mysqli_close($link);
		?>
		<SCRIPT language=javascript>
		<!--
		alert ("查無資料，請冾網站管理人員！"); 
		history.go(-1);
		//-->
		</SCRIPT>
		<?php 	
		exit;
		}
list($PUID,$PName,$QuoteDate,$IFlorin,$OFlorin,$CName,$PE,$ApplyItem,$Agent,$ModelName,$PTax)=mysqli_fetch_row($result_Project);
mysqli_free_result($result_Project);
$QuoteCheck="";
$InputCheck="";
if (trim($QuoteDate) == "0000-00-00") $QuoteDate = "";
if (trim($QuoteDate) != "") $QuoteCheck = "True";
if (trim($IFlorin) == "") $IFlorin = "新台幣";
if (trim($OFlorin) == "") $OFlorin = "新台幣";
if (trim($QuoteCheck) == "True") if (trim($PA_Mode) == "I") $InputCheck="False";
?>
<table width="100%" border="0" cellspacing="0" cellpadding="5">
	<tr>
    <td width="160" height="600" align="left" valign="top">
			<?php include "menu.php";?>
    </td>
    <td valign="top">
    	<table width="100%" border="0" cellpadding="0" cellspacing="0">
    		<tr>
    			<td>
			    	<table width="750" border="0" cellpadding="0" cellspacing="0">
			    		<tr height="30">
			    			<td class="c2" colspan="4"><a href="ProjectAccounting.php?page=<?php echo $spage;?>&QPStatus=<?php echo $QPStatus;?>&QAcc=<?php echo $QAcc;?>&KeyWord=<?php echo urlencode($KeyWord);?>">客戶案件帳務管理</a> &gt; <?php echo $PName;?> 帳務管理</td>
			    			<td width="20"></td>
			    		</tr>
			    		<tr height="30">
			    			<td class="c2" colspan="5"><a href="ProjectEdit.php?PID=<?php echo $PID;?>"><?php echo $PUID;?></a> &gt; <?php echo $PName;?> &gt; <?php echo $CName;?> &gt; <?php echo $PE;?> &gt; <?php echo $ApplyItem;if($Agent=="RPC1"){echo "(全威代理商)";}elseif($Agent=="RPC2"){echo "(瑞寶代理商)";}elseif($Agent=="DIAM"){echo "(戴米特代理商)";} ?> &gt; <?php echo $ModelName;?></td>
			    		</tr>
			    		<tr height="30">
			    			<td align="right" class="h3"><input type="button" name="Invoice" value="發票列印" class="input_bot" onclick="javascript:window.open ('ProjectInvoiceCheck.php?PID=<?php echo $PID;?>','ProjectInvoice','');"></td>
							<td align="right" class="h3"><input type="button" name="Invoice" value="發票作廢" class="input_bot" onclick="javascript:window.open ('ProjectInvoiceCheck2.php?PID=<?php echo $PID;?>','ProjectInvoice2','');"></td>
			    			<td width="100" align="right" class="h3"><input type="button" name="Quotation" value="報價單列印" class="input_bot" onclick="javascript:window.open ('ProjectQuotationCheck.php?PID=<?php echo $PID;?>','ProjectQuotation','');"></td>
			    			<td width="80" align="right" class="h3"><input type="button" name="Quotation" value="報價記錄" class="input_bot" onclick="javascript:window.open ('ProjectQuotationList.php?PID=<?php echo $PID;?>&PA_Mode=<?php echo $PA_Mode;?>','ProjectQuotationList','height=500,width=800,top=200,left=200,scrollbars=yes,status=yes');"></td>
			    			<td width="120" align="right" class="h3"><input type="button" name="Florin" value="設定貨幣種類" class="input_bot" onclick="javascript:window.open ('ProjectFlorin.php?PID=<?php echo $PID;?>','Florin','height=200,width=400,top=200,left=200,scrollbars=yes,status=yes');"></td>
			    			<td width="100" align="right" class="h3">
			    				<?php if (trim(strstr($_SESSION["reg_MPer"],'D')) != "") {?>
				    				<input type="button" name="add" value="新 增" class="input_bot" onclick="javascript:location.href='ProjectAccountingAdd<?php if (trim($QuoteCheck) != "True") echo "New";?>.php?PID=<?php echo $PID;?>&spage=<?php echo $spage;?>&QPStatus=<?php echo $QPStatus;?>&QAcc=<?php echo $QAcc;?>&KeyWord=<?php echo urlencode($KeyWord);?>';">
			    				<?php } else {
			    					if (trim($InputCheck) != "False") {?>
			    						<input type="button" name="add" value="新 增" class="input_bot" onclick="javascript:location.href='ProjectAccountingAdd.php?PID=<?php echo $PID;?>&spage=<?php echo $spage;?>&QPStatus=<?php echo $QPStatus;?>&QAcc=<?php echo $QAcc;?>&KeyWord=<?php echo urlencode($KeyWord);?>&PA_Mode=<?php echo $PA_Mode;?>';">
				    				<?php }?>
			    				<?php }?>
				    		</td>
			    			<td width="20"></td>
			    		</tr>
			    	</table>
						<?php
						if (trim(strstr($_SESSION["reg_MPer"],'D')) != "")
							$SQL_ProjectAccounting="select PAID,PANo,PAMode,PAItem,Charges,Rate,ChargesOther,PATax,PAStatus,PADate,PANote,Invoice from ProjectAccounting where Deltag='N' and PID = '".$PID."' order by PAMode asc,PAID asc;";
						else 
							$SQL_ProjectAccounting="select PAID,PANo,PAMode,PAItem,Charges,Rate,ChargesOther,PATax,PAStatus,PADate,PANote,Invoice from ProjectAccounting where Deltag='N' and PID = '".$PID."' and PAMode = '".$PA_Mode."' order by PAMode asc,PAID asc;";
						//echo $SQL_ProjectAccounting;
						$result_ProjectAccounting=mysqli_query($link,$SQL_ProjectAccounting) or die ("無法執行查詢");
						?>
			    	<table width="750" border="0" cellpadding="5" cellspacing="2" class="s2">
			        <tr align="center">
			          <td width="80" align="center" background="../images/table_bg.gif" class="t21">收入/支出</td>
			          <td width="200" background="../images/table_bg.gif" class="t21">項 目</td>
			          <td width="120" background="../images/table_bg.gif" class="t21">費 用</td>
			          <td width="50" background="../images/table_bg.gif" class="t21">是否<br>含稅</td>
			          <td width="80" background="../images/table_bg.gif" class="t21">狀 態<br>發票號碼</td>
			          <td width="110" background="../images/table_bg.gif" class="t21">備 註<br>對帳編號</td>
			          <td width="50" background="../images/table_bg.gif" class="t21">修 改</td>
			          <td width="50" background="../images/table_bg.gif" class="t21">刪 除</td>
			        </tr>
		          <?php
		          $ChargesI = 0;
		          $ChargesO = 0;
		          $tmp = 1;
		          while(list($PAID,$PANo,$PAMode,$PAItem,$Charges,$Rate,$ChargesOther,$PATax,$PAStatus,$PADate,$PANote,$Invoice)=mysqli_fetch_row($result_ProjectAccounting)){
		        	?>
		        	<tr<?php if ($tmp%2 == 0) echo " bgcolor=\"#F6F6F6\"";?>>
			          <td align="center" class="h3">
			          	<?php
			          	if (trim($PAMode) == "I") echo "<font color=blue>收入</font>";
			          	else if (trim($PAMode) == "O") echo "<font color=red>支出</font>";
			          	?>
			          </td>
			          <td class="h3"><?php echo $PAItem;?></td>
			          <td class="h3" align="center"><?php echo number_format($Charges);?>
			          	<?php
			          	if (trim($PAMode) == "I") $ChargesI = $ChargesI + $Charges;
			          	else if (trim($PAMode) == "O") $ChargesO = $ChargesO + $Charges;
			          	if (trim($Rate) != "0") {
			          			echo "<br><font color=blue>匯率：".$Rate."</font>";
			          			if (trim($PAMode) == "I") echo "<br><font color=blue>".$IFlorin."：".$ChargesOther."</font>";
			          			else if (trim($PAMode) == "O") echo "<br><font color=blue>".$OFlorin."：".$ChargesOther."</font>";
			          			}
			          	?>
			          </td>
			          <td class="h3" align="center">
			          	<?php
			          	if (trim($PATax) != "") {
					          	if (trim($PATax) == "Y") echo "是";
					          	else if (trim($PATax) == "N") echo "否";
			          			}
			          	else {
					          	if (trim($PTax) == "Y") echo "是";
					          	else if (trim($PTax) == "N") echo "否";
			          			}
			          	?>
			          </td>
			          <td align="center" class="h3">
			          	<?php
			          	if (trim($PAStatus) == "W") {
			          			if (trim($PAMode) == "I") echo "待收"; else if (trim($PAMode) == "O") echo "未付";
			          			}
			          	else if (trim($PAStatus) == "S") echo "<font color=blue>結清</font><br>".$PADate;
			          	else if (trim($PAStatus) == "C") echo "<font color=red>取消</font>";
			          	if (trim($Invoice) != "") echo "<br><font color=blue>".$Invoice."</font>";
			          	?>
			          </td>
			          <td class="h3"><?php echo $PANote;if (trim($PANo) != "") echo "<br>".$PANo;?></td>
			          <td align="center">
			          	<input type="button" name="edit" value="修 改" class="input_bot" onclick="javascript:location.href='ProjectAccountingEdit.php?PID=<?php echo $PID;?>&PAID=<?php echo $PAID;?>&spage=<?php echo $spage;?>&QPStatus=<?php echo $QPStatus;?>&QAcc=<?php echo $QAcc;?>&KeyWord=<?php echo urlencode($KeyWord);?>&PA_Mode=<?php echo $PA_Mode;?>';">
			          	<?php if ((trim($_SESSION["reg_MUID"]) == "Benson" || trim($_SESSION["reg_MUID"]) == "amanda") && trim($PAStatus) == "S") {?>
			          	<input type="button" name="cancel" value="取消結清" class="input_bot" onclick="javascript:if (confirm('您是否確定要取消結清狀態？')) location.href='ProjectAccountingCancelDB.php?PID=<?php echo $PID;?>&PAID=<?php echo $PAID;?>&spage=<?php echo $spage;?>&QPStatus=<?php echo $QPStatus;?>&QAcc=<?php echo $QAcc;?>&KeyWord=<?php echo urlencode($KeyWord);?>&PA_Mode=<?php echo $PA_Mode;?>';">
			          	<?php }?>
			          </td>
								<?php if (trim($PAMode) == "O") {?>
			          <td align="center"><input type="button" name="edit" value="刪 除" class="input_bot" onclick="javascript:if (confirm('您是否確定要刪除？')) location.href='ProjectAccountingDelDB.php?PID=<?php echo $PID;?>&PAID=<?php echo $PAID;?>&spage=<?php echo $spage;?>&QPStatus=<?php echo $QPStatus;?>&QAcc=<?php echo $QAcc;?>&KeyWord=<?php echo urlencode($KeyWord);?>&PA_Mode=<?php echo $PA_Mode;?>';"<?php if (trim($PAStatus) == "S" && trim($_SESSION["reg_MUID"]) != "amanda") echo " disabled";?>></td>
			          <?php } else {?>
			          <td align="center"><input type="button" name="edit" value="刪 除" class="input_bot" onclick="javascript:if (confirm('您是否確定要刪除？')) location.href='ProjectAccountingDelDB.php?PID=<?php echo $PID;?>&PAID=<?php echo $PAID;?>&spage=<?php echo $spage;?>&QPStatus=<?php echo $QPStatus;?>&QAcc=<?php echo $QAcc;?>&KeyWord=<?php echo urlencode($KeyWord);?>&PA_Mode=<?php echo $PA_Mode;?>';"<?php if ((trim($PAStatus) == "S" || (trim($QuoteCheck) == "True" && trim($PAStatus) == "W"))&& trim($_SESSION["reg_MUID"]) != "amanda") echo " disabled";?>></td>
			          <?php }?>
			        </tr>
			        <?php
            			$tmp++;
			      			}
            	mysqli_free_result($result_ProjectAccounting);
			        ?>
			      </table>
			      <?php if (trim(strstr($_SESSION["reg_MPer"],'D')) != ""){?>
			    	<table width="750" border="0" cellpadding="5" cellspacing="2">
			    		<tr height="40">
			    			<td width="120" class="h3">收入：<font color=blue><?php echo number_format($ChargesI);?></font></td>
			    			<td width="120" class="h3">支出：<font color=blue><?php echo number_format($ChargesO);?></font></td>
			    			<td class="h3">總計：<font color=blue><?php echo number_format(($ChargesI - $ChargesO));?></font></td>
			    		</tr>
			      </table>
			      <?php }?>
    			</td>
    		</tr>
    	</table>
    </td>
	</tr>
</table>
<?php include "down.php";?>
</body>
</html>
<?php
mysqli_close($link);
?>