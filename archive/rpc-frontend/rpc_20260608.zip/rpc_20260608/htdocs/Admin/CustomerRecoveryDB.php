﻿<?php	
include "CheckPermission.php";
include "../global.php";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $PageAdminTitle;?></title>
<link href="../type.css" rel="stylesheet" type="text/css" />
<style type="text/css">
<!--
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
}
-->
</style>
<Script type="text/javascript" language="javascript" src="../script/rpc.js"></Script>
<Script type="text/javascript" language="javascript" src="../script/CheckForm.js"></Script>
</head>
<body>
<?php
$CID = $_GET['CID'];
$page = $_GET['page'];
if (trim($CID) == "")
		{
		mysqli_close($link);
		?>
		<script type="text/JavaScript">
			<!--
			alert ("查無資料，請冾網站管理人員！");
			history.go(-1);
			//-->
		</script>
		<?php
		exit;
		}
$SQL_Customer="select CID from Customer where Deltag='Y' and CID = '".$CID."';";
$result_Customer=mysqli_query($link,$SQL_Customer) or die ("無法執行查詢");
if (mysqli_num_rows($result_Customer) == 0)
		{
		mysqli_free_result($result_Customer);
		mysqli_close($link);
		?>
		<SCRIPT language=javascript>
		<!--
		alert ("查無資料，請冾網站管理人員！"); 
		history.go(-1);
		//-->
		</SCRIPT>
		<?php 	
		exit;
		}
mysqli_free_result($result_Customer);

$sql_insert = "INSERT INTO CustomerHistory(CID,CType,CUID,CPWD,CName,EName,BSMI,TrademarkTxt,TrademarkImg,CTel,CFax,Contact,CMobile,CEMail,CAddress,CNote,CLevel,CRecord,CLoginTime,Principal,TAddress,LAddress,GUI,AddUser,AddDate,AddIP,Deltag,ProcUser,ProcDate,ProcIP,UpdateUser,UpdateDate,UpdateIP) SELECT CID,CType,CUID,CPWD,CName,EName,BSMI,TrademarkTxt,TrademarkImg,CTel,CFax,Contact,CMobile,CEMail,CAddress,CNote,CLevel,CRecord,CLoginTime,Principal,TAddress,LAddress,GUI,AddUser,AddDate,AddIP,Deltag,ProcUser,ProcDate,ProcIP,'".$_SESSION["reg_MUID"]."','".$now_time."','".$_SERVER["REMOTE_ADDR"]."' FROM Customer where DelTag = 'N' and CID = '".$CID."';";
$result_insert=mysqli_query($link,$sql_insert) or die ("無法執行新增");
$sql_update = "update Customer set DelTag = 'N',ProcUser = '".$_SESSION["reg_MUID"]."',ProcDate = now(),ProcIP = '".$_SERVER["REMOTE_ADDR"]."' where DelTag = 'Y' and CID = '".$CID."';";
$result_update=mysqli_query($link,$sql_update) or die ("無法執行修改");
mysqli_close($link);
?>
<script type="text/JavaScript">
	<!--
	alert ("還原成功！");
	location.href='CustomerDelHistory.php?page=<?php echo $page;?>';
	//-->
</script>
</body>
</html>
