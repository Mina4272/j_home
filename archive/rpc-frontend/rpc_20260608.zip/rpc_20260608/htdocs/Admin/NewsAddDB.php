﻿<?php
include "CheckPermission.php";
include "CheckNews.php";
include "../global.php";
include "include/function.php";
require_once("../include/chinese_party.class.php");
require("class.phpmailer.php");
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $PageAdminTitle;?></title>
<link href="../type.css" rel="stylesheet" type="text/css" />
</head>

<body>
<?php
//echo "NFile=".$HTTP_POST_FILES['NFile']['name']."<br>";
//echo "NFile=".$HTTP_POST_FILES['NFile']['tmp_name']."<br>";
//exit;
$NTitle = $_POST['NTitle'];
$NContent = $_POST['NContent'];
$NContent = str_replace("\r\n","<br>",$NContent);

$now_time = date("Y-m-d H:i:s",mktime());
if(trim($_FILES['NFile']['tmp_name']) != "")
		{
		if($_FILES['NFile']['size'] > 20971520)
				{
				?>
				<script type="text/JavaScript">
					<!--
					alert ("您上傳的檔案 Size 超過 20 M，請重新上傳！");
					history.go(-1);
					//-->
				</script>
				<?php
				exit();
				}
		$NFile = "NFile_".date("ymdHis",mktime()).rand_string(5, 'ABCDEFGHIJKLMNPQRSTUVWXYZ23456789abcdefghijklmnopqrstuvwxyz').".".strtolower(substr($_FILES['NFile']['name'],strrpos($_FILES['NFile']['name'],".")+1,strlen($_FILES['NFile']['name'])+1));
		@copy($_FILES['NFile']['tmp_name'],$_SERVER["DOCUMENT_ROOT"]."\\Admin\\NFile\\".$NFile);
		}
if (trim($NTitle) == "")
		{
		mysqli_close($link);
		?>
		<script type="text/JavaScript">
			<!--
			alert ("您輸入的資料不足，請重新輸入！");
			self.close();
			//-->
		</script>
		<?php
		exit;
		}

$sql_insert = "insert into News (NTitle,NFile,NContent,AddUser,AddDate,AddIP) values ('".$NTitle."','".$NFile."','".$NContent."','".$_SESSION["reg_MUID"]."','".$now_time."','".$_SERVER["REMOTE_ADDR"]."');";
$result_insert=mysqli_query($link,$sql_insert) or die ("無法執行新增");

$EMAILFN = "News.htm";
$subject="公佈欄資訊通知 ！！";
$fp=fopen($EMAILFN,"r");
$content="";
while($line=fgets($fp,512)){
	$content.=$line;
	}
fclose($fp);

$content = str_replace("{NTitle}",$NTitle,$content);
$content = str_replace("{NContent}",$NContent,$content);

//$cconv = new chinese_party();
//$content = $cconv->u82tchi($content);
//$subject = $cconv->u82tchi($subject);

$SQL_Manager="SELECT EMail FROM Manager WHERE IsLeft ='N' and Deltag = 'N';";
$result_Manager=mysqli_query($link,$SQL_Manager) or die ("無法執行查詢");

$mail = new PHPMailer();
$mail->IsSMTP();
$mail->SMTPAuth = true; //設定SMTP需要驗證
$mail->SMTPSecure = "ssl"; // Gmail的SMTP主機需要使用SSL連線
$mail->Host = "smtp.gmail.com"; //Gamil的SMTP主機
$mail->Port = 465; //Gamil的SMTP主機的埠號(Gmail為465)。
$mail->CharSet = "utf-8"; //郵件編碼
$mail->Username = "benson@rpclab.com"; //Gamil帳號
$mail->Password = "benson6567"; //Gmail密碼
$mail->From     = "Benson@rpclab.com";
$mail->FromName = $subject;
$mail->WordWrap = 50;
$mail->IsHTML(true);                               // send as HTML
//$mail->CharSet = "big5";
$mail->Subject  = $subject;
$mail->Body     =  $content;
//$mail->AddAddress("reset20160731@gmail.com","");
while(list($EMail)=mysqli_fetch_row($result_Manager)){
	$mail->AddAddress($EMail,"");
}
$mail->AddReplyTo("Benson@rpclab.com");
if(!$mail->Send())
{
				    //echo "There has been a mail error sending to " . $SendEMail . "<br>";
				    //echo "Mailer Error: " . $mail->ErrorInfo . "<br>";
}
else
{
						//echo $SendEMail . " sending !!<br>";
}	
$mail->ClearAddresses();
$mail->ClearReplyTos();
$mail->SmtpClose();


mysqli_free_result($result_Manager);

mysqli_close($link);
?>

<script type="text/JavaScript">
	alert ("公佈欄訊息新增完成！");
	location.href='NewsList.php';
	
</script>
</body>
</html>
