﻿<?php	
include "CheckPermission.php";
include "CheckProject.php";
include "../global.php";
include "include/utf8.php";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $PageAdminTitle;?></title>
<link href="../type.css" rel="stylesheet" type="text/css" />
<style type="text/css">
<!--
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
}
-->
</style>
<link href="../script/DatePicker.css" rel="stylesheet" type="text/css" />
<Script LANGUAGE="Javascript" SRC="../script/DatePicker.js"></Script>
<Script type="text/javascript" language="javascript" src="../script/CheckForm.js"></Script>
<script type="text/JavaScript">
<!--
function jsCheck() 
		{
    //if (jsTrim(document.form1.PFileName.value) == "")
    //		{
		//		alert("請選擇您要上傳檔案！");
		//		document.form1.PFileName.focus();
		//		return false;
    //		}
		}
//-->
</script>
</head>
<body>
<?php include "top.php";?>
<?php
$PID = $_GET['PID'];
$PFCID = $_GET['PFCID'];
$PFID = $_GET['PFID'];
$spage = $_GET['spage'];
$page = $_GET['page'];
$KeyWord = $_GET['KeyWord'];
$QPStatus = $_GET['QPStatus'];
$QPE = $_GET['QPE'];
if (trim($PID) == "" || trim($PFCID) == "" || trim($PFID) == "")
		{
		mysqli_close($link);
		?>
		<script type="text/JavaScript">
			<!--
			alert ("查無資料，請冾網站管理人員！");
			history.go(-1);
			//-->
		</script>
		<?php
		exit;
		}
$SQL_Project="select PUID,PName,CName,ModelName from Project where Deltag='N' and PID = '".$PID."';";
$result_Project=mysqli_query($link,$SQL_Project) or die ("無法執行查詢");
if (mysqli_num_rows($result_Project) == 0)
		{
		mysqli_free_result($result_Project);
		mysqli_close($link);
		?>
		<SCRIPT language=javascript>
		<!--
		alert ("查無資料，請冾網站管理人員！"); 
		history.go(-1);
		//-->
		</SCRIPT>
		<?php 	
		exit;
		}
list($PUID,$PName,$CName,$ModelName)=mysqli_fetch_row($result_Project);
mysqli_free_result($result_Project);
if (utf8_strlen(strip_tags($CName)) > 4) $CName = utf8_substr(strip_tags($CName),0,4);
else $CName = strip_tags($CName);

$SQL_ProjectFileClass="select PFCName from ProjectFileClass where Deltag='N' and PFCID = '".$PFCID."';";
$result_ProjectFileClass=mysqli_query($link,$SQL_ProjectFileClass) or die ("無法執行查詢");
if (mysqli_num_rows($result_ProjectFileClass) == 0)
		{
		mysqli_free_result($result_ProjectFileClass);
		mysqli_close($link);
		?>
		<SCRIPT language=javascript>
		<!--
		alert ("查無資料，請冾網站管理人員！"); 
		history.go(-1);
		//-->
		</SCRIPT>
		<?php 	
		exit;
		}
list($PFCName)=mysqli_fetch_row($result_ProjectFileClass);
mysqli_free_result($result_ProjectFileClass);

$SQL_ProjectFile="select PFName,PFileName,PFIntro,AddUser,AddDate,ProcUser,ProcDate from ProjectFile where Deltag='N' and PID = '".$PID."' and PFCID = '".$PFCID."' and PFID = '".$PFID."';";
$result_ProjectFile=mysqli_query($link,$SQL_ProjectFile) or die ("無法執行查詢");
if (mysqli_num_rows($result_ProjectFile) == 0)
		{
		mysqli_free_result($result_ProjectFile);
		mysqli_close($link);
		?>
		<SCRIPT language=javascript>
		<!--
		alert ("查無資料，請冾網站管理人員！"); 
		history.go(-1);
		//-->
		</SCRIPT>
		<?php 	
		exit;
		}
list($PFName,$PFileName,$PFIntro,$AddUser,$AddDate,$ProcUser,$ProcDate)=mysqli_fetch_row($result_ProjectFile);
mysqli_free_result($result_ProjectFile);
?>
<table width="100%" border="0" cellspacing="0" cellpadding="5">
	<tr>
    <td width="160" height="600" align="left" valign="top">
			<?php include "menu.php";?>
    </td>
    <td valign="top">
    	<table width="100%" border="0" cellpadding="0" cellspacing="0">
    		<tr>
    			<td>
			    	<table width="750" border="0" cellpadding="0" cellspacing="0">
			    		<tr height="30">
			    			<td class="c2"><a href="ProjectList.php?page=<?php echo $spage;?>&QPStatus=<?php echo $QPStatus;?>&QPE=<?php echo $QPE;?>&KeyWord=<?php echo urlencode($KeyWord);?>">案件資料列表</a> &gt; <a href="ProjectFileClassList.php?PID=<?php echo $PID;?>&PFCID=<?php echo $PFCID;?>&page=<?php echo $spage;?>&QPStatus=<?php echo $QPStatus;?>&QPE=<?php echo $QPE;?>&KeyWord=<?php echo urlencode($KeyWord);?>"><?php echo $CName;?> - <?php echo $ModelName;?> 類別列表</a> &gt; <a href="ProjectFileList.php?PID=<?php echo $PID;?>&PFCID=<?php echo $PFCID;?>&spage=<?php echo $spage;?>&QPStatus=<?php echo $QPStatus;?>&QPE=<?php echo $QPE;?>&KeyWord=<?php echo urlencode($KeyWord);?>"><?php echo $PFCName;?></a> &gt; 修改檔案</td>
			    		</tr>
			    	</table>
			    	<table width="750" border="0" cellpadding="0" cellspacing="0">
			        <form name="form1" method="post" action="ProjectFileEditDB.php" enctype="multipart/form-data" onSubmit="return jsCheck();">
			        <tr height="40" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td width="120" align="right" class="c3">檔案：</td>
			          <td class="h3">
			          	<input type="file" name="PFileName" size="60"> 
			          	<input type="button" name="edit" value="下 載" class="input_bot" onclick="javascript:window.open ('PFile/<?php echo $PFileName;?>','PFileName','height=300,width=550,top=200,left=200,scrollbars=yes,status=yes');">
			          </td>
			        </tr>
			        <tr height="40" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">檔案說明：</td>
			          <td class="h3">
			          	<input type="hidden" name="PID" value="<?php echo $PID;?>">
			          	<input type="hidden" name="PFCID" value="<?php echo $PFCID;?>">
			          	<input type="hidden" name="PFID" value="<?php echo $PFID;?>">
			          	<input type="hidden" name="spage" value="<?php echo $spage;?>">
			          	<input type="hidden" name="page" value="<?php echo $page;?>">
			          	<input type="hidden" name="KeyWord" value="<?php echo $KeyWord;?>">
			          	<input type="hidden" name="QPStatus" value="<?php echo $QPStatus;?>">
			          	<input type="hidden" name="QPE" value="<?php echo $QPE;?>">
			          	<input type="text" name="PFIntro" size="80" value="<?php echo $PFIntro;?>">
			          </td>
			        </tr>
			        <tr height="40" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">新增人員：</td>
			          <td class="h3"><?php echo $AddUser;?>　<?php echo $AddDate;?></td>
			        </tr>
			        <?php if (trim($ProcUser) != "") {?>
			        <tr height="40" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">最後更新：</td>
			          <td class="h3"><?php echo $ProcUser;?>　<?php echo $ProcDate;?>
			          	<input type="button" name="edit" value="歷史記錄" class="input_bot" onclick="javascript:window.open ('ProjectFileHistory.php?PFID=<?php echo $PFID;?>&PID=<?php echo $PID;?>&PFCID=<?php echo $PFCID;?>','ProjectFileHistory','height=500,width=750,top=200,left=200,scrollbars=yes,status=yes');">
			          </td>
			        </tr>
			        <?php }?>
			        <tr height="40" align="center">
			          <td colspan="2" class="h3"><input type="submit" name="submit" class="input_bot" value="送 出"></td>
			        </tr>
				      </form>
			      </table>
    			</td>
    		</tr>
    	</table>
    </td>
	</tr>
</table>
<?php include "down.php";?>
</body>
</html>
<?php
mysqli_close($link);
?>