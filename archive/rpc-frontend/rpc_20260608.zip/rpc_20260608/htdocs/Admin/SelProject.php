﻿<?php
include "CheckPermission.php";
include "../global.php";
include "include/page_function.php";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $PageAdminTitle;?></title>
<link href="../type.css" rel="stylesheet" type="text/css" />
<Script type="text/javascript" language="javascript" src="../script/CheckForm.js"></Script>
<script type="text/JavaScript">
<!--
function SelProject(PID) {
		document.Selform.PID.value=PID;
		document.Selform.submit();
		}
//-->
</script>
</head>

<body>
<table width="520" border="0" align="center" cellpadding="2" cellspacing="0">
  <tr>
    <td align="left"><span class="c2"><b>選擇案件</b></span>
    </td>
  </tr>
  <tr>
    <td align="left">
    	<table width="100%" border="0" cellpadding="0" cellspacing="0">
    		<form name="form1" action="SelProject.php" method="post">
    		<tr>
    			<td align="left" class="h3">
    				關鍵字：<input type="text" name="KeyWord" size="20"> 
    				工程師：
	    			<?php
						$SQL_Manager="select MUID,MName,MEName from Manager where Deltag='N' and ISEngineer = 'Y' and IsLeft='N';";
						$result_Manager=mysqli_query($link,$SQL_Manager) or die ("無法執行查詢");
	    			?>
    				<select name="QPE">
    					<option value="">不限</option>
          		<?php while(list($MUID,$MName,$MEName)=mysqli_fetch_row($result_Manager)){?>
          		<option value="<?php echo $MUID;?>"<?php if (trim($MUID) == trim(empty($_POST['QPE'])?"":$_POST['QPE'])) echo " selected";?>><?php echo $MEName.$MName;?></option>
          		<?php }?>
    				</select>
		        <?php
		        mysqli_free_result($result_Manager);
		        ?>
    				<input type="submit" name="search" value="查詢">
    			</td>
    		</tr>
    		</form>
    	</table>
			<?php
		$SqlPID = "";
		$SqlTxt ="";
    	$QPE = empty($_POST['QPE'])?"":$_POST['QPE'];
    	if (trim($QPE) == "") $QPE = empty($_GET['QPE'])?"":$_GET['QPE'];
    	$KeyWord = empty($_POST['KeyWord'])?"":$_POST['KeyWord'];
    	if (trim($KeyWord) == "") $KeyWord = empty($_GET['KeyWord'])?"":$_GET['KeyWord'];
			if (trim($KeyWord) != "") {
					$SQL_ProjectCertificate="select PID from ProjectCertificate where Deltag='N' and PCNo like '%".$KeyWord."%' group by PID order by PID;";
					$result_ProjectCertificate=mysqli_query($link,$SQL_ProjectCertificate) or die ("無法執行查詢");
					
					while(list($PC_PID)=mysqli_fetch_row($result_ProjectCertificate)){
							if (trim($SqlPID) == "") $SqlPID = $PC_PID;
							else $SqlPID = $SqlPID.",".$PC_PID;
							}
					mysqli_free_result($result_ProjectCertificate);
					}
			if (trim($SqlPID) != "") $SqlPID = " PID in (".$SqlPID.")";
    	if (trim($KeyWord) != "") {
    			if (trim($SqlPID) == "") $SqlTxt = $SqlTxt." and (PUID like '%".$KeyWord."%' or CName like '%".$KeyWord."%' or CTel like '%".$KeyWord."%' or CFax like '%".$KeyWord."%' or Contact like '%".$KeyWord."%' or CMobile like '%".$KeyWord."%' or CEMail like '%".$KeyWord."%' or CAddress like '%".$KeyWord."%' or PName like '%".$KeyWord."%' or ModelName like '%".$KeyWord."%' or SeriesModel like '%".$KeyWord."%' or PE like '%".$KeyWord."%' or PNote like '%".$KeyWord."%' or ApplyItem like '%".$KeyWord."%')";
    			else $SqlTxt = $SqlTxt." and (PUID like '%".$KeyWord."%' or CName like '%".$KeyWord."%' or CTel like '%".$KeyWord."%' or CFax like '%".$KeyWord."%' or Contact like '%".$KeyWord."%' or CMobile like '%".$KeyWord."%' or CEMail like '%".$KeyWord."%' or CAddress like '%".$KeyWord."%' or PName like '%".$KeyWord."%' or ModelName like '%".$KeyWord."%' or SeriesModel like '%".$KeyWord."%' or PE like '%".$KeyWord."%' or PNote like '%".$KeyWord."%' or ApplyItem like '%".$KeyWord."%' or ".$SqlPID.")";
    			}
    	if (trim($QPE) != "") $SqlTxt = $SqlTxt." and PE='".$QPE."' ";
			$page = empty($_GET['page'])?"":$_GET['page'];
			if (trim($page) == "") $page = 1;
			$page_rows=15;  //每頁筆數
			$php_Self = "SelProject.php";  //分頁web檔名

			$button_css = "h4";
			$limit_txt =" limit ".(($page-1) * $page_rows).",".$page_rows;
			$url_str = "&QPE=".$QPE."&KeyWord=".urlencode($KeyWord);
			$Sql_str="select PID,PUID,PName,ModelName from Project where Deltag='N' ".$SqlTxt." order by PID desc;";
			$SQL_Project="select PID,PUID,PName,ModelName from Project where Deltag='N' ".$SqlTxt." order by PID desc ".$limit_txt.";";
			$result_Project=mysqli_query($link,$SQL_Project) or die ("無法執行查詢");
			?>
    	<table width="100%" border="0" cellpadding="2" cellspacing="2" class="s2">
        <tr align="center">
          <td width="100" background="../images/table_bg.gif" class="t21">案件編號</td>
          <td background="../images/table_bg.gif" class="t21">產品名稱 / 型號</td>
        </tr>
        <?php
        $tmp = 1;
        while(list($PID,$PUID,$PName,$ModelName)=mysqli_fetch_row($result_Project)){
      	?>
    	  <form name="CForm<?php echo $PID;?>" method="post">
	    	<tr<?php if ($tmp%2 == 0) echo " bgcolor=\"#F6F6F6\"";?>>
          <td align="center" class="h3"><?php echo $PUID;?></td>
          <td align="center" class="h3"><?php echo $PName;?> <font color=blue><b>/</b></font> <?php echo $ModelName;?>
          	<input type="button" name="button" class="input_bot" value="選擇" onclick="javascript:SelProject(<?php echo $PID;?>);">
          </td>
        </tr>
    		</form>
        <?php
      			$tmp++;
      			}
      	mysqli_free_result($result_Project);
        ?>
      </table>
      <table width="100%" border="0" cellpadding="2" cellspacing="2" class="s2">
        <tr align="center">
          <td bgcolor="#E8F0C2" class="h4"><?php Page_show($Sql_str,$page_rows,$php_Self,$link,$page,$url_str,$button_css);?></td>
        </tr>
      </table>

    </td>
  </tr>
</table>
<form name="Selform" action="SelProjectDB.php" method="post">
	<input type="hidden" name="PID">
</form>
</body>
</html>
<?php
mysqli_close($link);
?>