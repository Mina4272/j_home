﻿<?php
session_start();
include "../global.php";
$now_time = date("Y-m-d H:i:s",mktime());
$sql_update = "update manager set MLoginTime = '".$now_time."' where DelTag = 'N' and MUID = '".$_SESSION["reg_MUID"]."'";
$result_update=mysqli_query($link,$sql_update) or die ("無法執行修改");
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta http-equiv="refresh" content="120"> 
<title><?php echo $PageTitle;?></title>
</head>
<body>
</body>
</html>
<?php
mysqli_close($link);
?>