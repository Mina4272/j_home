﻿<?php
include "CheckPermission.php";
include "CheckProject.php";
include "../global.php";
include "include/page_function.php";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $PageAdminTitle;?></title>
<link href="../type.css" rel="stylesheet" type="text/css" />
<style type="text/css">
<!--
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
}
-->
</style></head>

<body>
<?php
$PID = $_GET['PID'];
$PCID = $_GET['PCID'];
if (trim($PID) == "" || trim($PCID) == "")
		{
		mysqli_close($link);
		?>
		<script type="text/JavaScript">
			<!--
			alert ("查無資料，請冾網站管理人員！");
			history.go(-1);
			//-->
		</script>
		<?php
		exit;
		}
$SQL_Project="select PUID,PName from Project where Deltag='N' and PID = '".$PID."';";
$result_Project=mysqli_query($link,$SQL_Project) or die ("無法執行查詢");
if (mysqli_num_rows($result_Project) == 0)
		{
		mysqli_free_result($result_Project);
		mysqli_close($link);
		?>
		<SCRIPT language=javascript>
		<!--
		alert ("查無資料，請冾網站管理人員！"); 
		history.go(-1);
		//-->
		</SCRIPT>
		<?php 	
		exit;
		}
list($PUID,$PName)=mysqli_fetch_row($result_Project);
mysqli_free_result($result_Project);

$SQL_ProjectCertificate="select PCNo,PCName,PCType,PCTypeName,PCFile,PCSDate,PCEDate,PCNote,ExpireDate,date_format(ExpireDate,'%Y'),date_format(ExpireDate,'%m'),AddUser,AddDate,ProcUser,ProcDate from ProjectCertificate where Deltag='N' and PID = '".$PID."' and PCID = '".$PCID."';";
$result_ProjectCertificate=mysqli_query($link,$SQL_ProjectCertificate) or die ("無法執行查詢");
if (mysqli_num_rows($result_ProjectCertificate) == 0)
		{
		mysqli_free_result($result_ProjectCertificate);
		mysqli_close($link);
		?>
		<SCRIPT language=javascript>
		<!--
		alert ("查無資料，請冾網站管理人員！"); 
		history.go(-1);
		//-->
		</SCRIPT>
		<?php 	
		exit;
		}
list($PCNo,$PCName,$PCType,$PCTypeName,$PCFile,$PCSDate,$PCEDate,$PCNote,$ExpireDate,$ExpireYear,$ExpireMonth,$AddUser,$AddDate,$ProcUser,$ProcDate)=mysqli_fetch_row($result_ProjectCertificate);
mysqli_free_result($result_ProjectCertificate);
?>
<table width="100%" border="0" cellpadding="0" cellspacing="0">
	<tr>
		<td>
			<?php
			$page = empty($_GET['page'])?"":$_GET['page'];
			if (trim($page) == "") $page = 1;
			$page_rows=15;  //每頁筆數
			$php_Self = "ProjectCertificateHistory.php";  //分頁web檔名

			$button_css = "h4";
			$limit_txt =" limit ".(($page-1) * $page_rows).",".$page_rows;
			$url_str = "&PID=".$PID."&PCID=".$PCID;
			$Sql_str="select PCNo,PCName,PCFile,PCSDate,PCEDate,PCNote,AddUser,AddDate,ProcUser,ProcDate from ProjectCertificateHistory where Deltag='N' and PID = '".$PID."' and PCID = '".$PCID."' order by PCHID desc;";
			$SQL_ProjectCertificate="select PCNo,PCName,PCType,PCTypeName,PCFile,PCSDate,PCEDate,PCNote,ExpireDate,date_format(ExpireDate,'%Y'),date_format(ExpireDate,'%m'),AddUser,AddDate,ProcUser,ProcDate from ProjectCertificateHistory where Deltag='N' and PID = '".$PID."' and PCID = '".$PCID."' order by PCHID desc ".$limit_txt.";";
			$result_ProjectCertificate=mysqli_query($link,$SQL_ProjectCertificate) or die ("無法執行查詢");
			?>
    	<table width="100%" border="0" cellpadding="5" cellspacing="2" class="s2">
        <tr align="center">
          <td width="100" align="center" background="../images/table_bg.gif" class="t21">編號 </td>
          <td width="120" background="../images/table_bg.gif" class="t21">証書名稱</td>
          <td width="120" background="../images/table_bg.gif" class="t21">證書種類</td>
          <td width="180" background="../images/table_bg.gif" class="t21">有效日期</td>
          <td background="../images/table_bg.gif" class="t21">備註</td>
          <td width="120" background="../images/table_bg.gif" class="t21">證書到期提醒時間</td>
          <td width="150" background="../images/table_bg.gif" class="t21">最後更新</td>
        </tr>
        <?php
        $tmp = 1;
        while(list($PCNo,$PCName,$PCType,$PCTypeName,$PCFile,$PCSDate,$PCEDate,$PCNote,$ExpireDate,$ExpireYear,$ExpireMonth,$AddUser,$AddDate,$ProcUser,$ProcDate)=mysqli_fetch_row($result_ProjectCertificate)){
					if (trim($PCSDate) == "0000-00-00") $PCSDate = "";
					if (trim($PCEDate) == "0000-00-00") $PCEDate = "";
      	?>
      	<tr<?php if ($tmp%2 == 0) echo " bgcolor=\"#F6F6F6\"";?>>
          <td align="center" class="h3"><?php echo $PCNo;?></td>
          <td align="center" class="h3"><a href="PCFile/<?php echo $PCFile;?>" target="_ProjectCertificateHistory"><?php echo $PCName;?></a></td>
          <td align="center" class="h3">
          	<?php
          	if (trim($PCType) == "A") echo "環保標章";
          	else if (trim($PCType) == "B") echo "BSMI證書";
          	else if (trim($PCType) == "C") echo "消防證書";
          	else if (trim($PCType) == "D") echo $PCTypeName;
          	?>
          </td>
          <td align="center" class="h3"><?php echo $PCSDate;?>～<?php echo $PCEDate;?></td>
          <td align="center" class="h3"><?php echo $PCNote;?></td>
          <td align="center" class="h3"><?php echo $ExpireDate;?></td>
          <td align="center" class="h3">
          	<?php
          	if (trim($ProcUser) == "") echo $AddUser."<br>".$AddDate;
          	else echo $ProcUser."<br>".$ProcDate;
          	?>
          </td>
        </tr>
        <?php
      			$tmp++;
      			}
      	mysqli_free_result($result_ProjectCertificate);
        ?>
      </table>
      <table width="100%" border="0" cellpadding="5" cellspacing="2" class="s2">
        <tr align="center">
          <td bgcolor="#E8F0C2" class="h4"><?php Page_show($Sql_str,$page_rows,$php_Self,$link,$page,$url_str,$button_css);?></td>
        </tr>
      </table>
		</td>
	</tr>
</table>
</body>
</html>
<?php
mysqli_close($link);
?>