﻿<?php
include "CheckPermission.php";
include "CheckTraining.php";
include "../global.php";
include "include/function.php";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $PageAdminTitle;?></title>
<link href="../type.css" rel="stylesheet" type="text/css" />
</head>

<body>
<?php
$TID = $_POST['TID'];
$TYear = $_POST['TYear'];
$TMonth = $_POST['TMonth'];
$TDay = $_POST['TDay'];
if (trim($TYear) != "" || trim($TMonth) != "" || trim($TDay) != "") if (checkdate($TMonth,$TDay ,$TYear)) $TDate = $TYear."-".$TMonth."-".$TDay;
$TCID = $_POST['TCID'];
$TTitle = $_POST['TTitle'];
$Lecturer = $_POST['Lecturer'];
$TLocation = $_POST['TLocation'];
if($TLocation == "other"){
	$othertext = $_POST['othertext'];
}else{
	$othertext = "NULL";
}
$TTrain = $_POST['TTrain'];
if($TTrain == "out"){
	$outtext = $_POST['outtext'];
}else{
	$outtext = "NULL";
}
$THour = $_POST['THour'];
$TExam = $_POST['TExam'];
if($TExam =="other"){
	$othernote = $_POST['othernote'];
}else{
	$othernote = "NULL";
}
$TContent = $_POST['TContent'];
$TContent = str_replace("\r\n","<br>",$TContent);
$page = $_POST['page'];
$KeyWord = $_POST['KeyWord'];
if (trim($TID) == "")
		{
		mysqli_close($link);
		?>
		<script type="text/JavaScript">
			<!--
			alert ("查無資料，請冾網站管理人員！");
			history.go(-1);
			//-->
		</script>
		<?php
		exit;
		}

$SQL_Training="select TTitle,TFile,AddUser,AddDate,ProcUser,ProcDate from Training where Deltag='N' and TID = '".$TID."';";
$result_Training=mysqli_query($link,$SQL_Training) or die ("無法執行查詢");
if (mysqli_num_rows($result_Training) == 0)
		{
		mysqli_free_result($result_Training);
		mysqli_close($link);
		?>
		<SCRIPT language=javascript>
		<!--
		alert ("查無資料，請冾網站管理人員！"); 
		history.go(-1);
		//-->
		</SCRIPT>
		<?php 	
		exit;
		}
mysqli_free_result($result_Training);

$now_time = date("Y-m-d H:i:s",mktime());
if(trim($_FILES['TFile']['tmp_name']) != "")
		{
		if($_FILES['TFile']['size'] > 20971520)
				{
				?>
				<script type="text/JavaScript">
					<!--
					alert ("您上傳的檔案 Size 超過 20 M，請重新上傳！");
					history.go(-1);
					//-->
				</script>
				<?php
				exit();
				}
		$TFile = "TFile_".date("ymdHis",mktime()).rand_string(5, 'ABCDEFGHIJKLMNPQRSTUVWXYZ23456789abcdefghijklmnopqrstuvwxyz').".".strtolower(substr($_FILES['TFile']['name'],strrpos($_FILES['TFile']['name'],".")+1,strlen($_FILES['TFile']['name'])+1));
		@copy($_FILES['TFile']['tmp_name'],$_SERVER["DOCUMENT_ROOT"]."\\Admin\\TFile\\".$TFile);
		}
		
$now_time = date("Y-m-d H:i:s",mktime());
if(trim($_FILES['TTrainRecord']['tmp_name']) != "")
		{
		if($_FILES['TTrainRecord']['size'] > 20971520)
				{
				?>
				<script type="text/JavaScript">
					<!--
					alert ("您上傳的檔案 Size 超過 20 M，請重新上傳！");
					history.go(-1);
					//-->
				</script>
				<?php
				exit();
				}
		$TTrainRecord = "TTrainRecord_".date("ymdHis",mktime()).rand_string(5, 'ABCDEFGHIJKLMNPQRSTUVWXYZ23456789abcdefghijklmnopqrstuvwxyz').".".strtolower(substr($_FILES['TTrainRecord']['name'],strrpos($_FILES['TTrainRecord']['name'],".")+1,strlen($_FILES['TTrainRecord']['name'])+1));
		@copy($_FILES['TTrainRecord']['tmp_name'],$_SERVER["DOCUMENT_ROOT"]."\\Admin\\TTFile\\".$TTrainRecord);
		}
		
if (trim($TFile) != "") $SqlTxt .= ",TFile='".$TFile."'";
if (trim($TTrainRecord) != "") $SqlTxt .= ",TTrainRecord='".$TTrainRecord."'";
//$sql_insert = "INSERT INTO TrainingHistory(TID,TDate,TTitle,Lecturer,TFile,TContent,AddUser,AddDate,AddIP,Deltag,ProcUser,ProcDate,ProcIP,UpdateUser,UpdateDate,UpdateIP) SELECT TID,TDate,TTitle,Lecturer,TFile,TContent,AddUser,AddDate,AddIP,Deltag,ProcUser,ProcDate,ProcIP,'".$_SESSION["reg_MUID"]."','".$now_time."','".$_SERVER["REMOTE_ADDR"]."' FROM Training where Deltag='N' and TID = '".$TID."';";
//$result_insert=mysqli_query($link,$sql_insert) or die ("無法執行新增");

$sql_update = "update Training set TDate = '".$TDate."',TCID ='".$TCID."',TTitle = '".$TTitle."',Lecturer = '".$Lecturer."',TLocation = '".$TLocation."',othertext = '".$othertext."',TTrain = '".$TTrain."',outtext='".$outtext."',THour = '".$THour."',TExam = '".$TExam."',othernote = '".$othernote."',TContent = '".$TContent."' ".$SqlTxt." ,ProcUser = '".$_SESSION["reg_MUID"]."',ProcDate = '".$now_time."',ProcIP = '".$_SERVER["REMOTE_ADDR"]."' where Deltag='N' and TID = '".$TID."';";
$result_update=mysqli_query($link,$sql_update) or die ("無法執行修改");

mysqli_close($link);
?>
<script type="text/JavaScript">
	<!--
	alert ("檔案修改成功！");
	location.href='TrainingList.php';
	//-->
</script>

</body>
</html>
