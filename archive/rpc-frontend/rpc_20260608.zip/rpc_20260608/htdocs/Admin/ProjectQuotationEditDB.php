﻿<?php
include "CheckPermission.php";
include "CheckProjectAccounting.php";
include "../global.php";
include "include/function.php";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $PageAdminTitle;?></title>
</head>
<body>
<?php
$PQID = $_POST['PQID'];
$PID = $_POST['PID'];
$PQName = $_POST['PQName'];
$PQType = $_POST['PQType'];

if(trim($_FILES['PQFile']['tmp_name']) != "")
		{
		if($_FILES['PQFile']['size'] > 20971520)
				{
				?>
				<script type="text/JavaScript">
					<!--
					alert ("您上傳的檔案 Size 超過 20 M，請重新上傳！");
					history.go(-1);
					//-->
				</script>
				<?php
				exit();
				}
		$PQFile = "PQFile_".$PID.date("ymdHis",mktime()).rand_string(5, 'ABCDEFGHIJKLMNPQRSTUVWXYZ23456789abcdefghijklmnopqrstuvwxyz').".".strtolower(substr($_FILES['PQFile']['name'],strrpos($_FILES['PQFile']['name'],".")+1,strlen($_FILES['PQFile']['name'])+1));
		@copy($_FILES['PQFile']['tmp_name'],$_SERVER["DOCUMENT_ROOT"]."\\Admin\\PQFile\\".$PQFile);
		}

if (trim($PQID) == "" || trim($PID) == "" || trim($PQName) == "" || trim($PQType) == "")
		{
		mysqli_close($link);
		?>
		<script type="text/JavaScript">
			<!--
			alert ("您輸入的資料不足，請重新輸入！");
			self.close();
			//-->
		</script>
		<?php
		exit;
		}

$SQL_ProjectQuotationList="select PQFile,AddUser,AddDate,ProcUser,ProcDate from ProjectQuotationList where Deltag='N' and PID = '".$PID."' and PQID = '".$PQID."';";
$result_ProjectQuotationList=mysqli_query($link,$SQL_ProjectQuotationList) or die ("無法執行查詢");
if (mysqli_num_rows($result_ProjectQuotationList) == 0)
		{
		mysqli_free_result($result_ProjectQuotationList);
		mysqli_close($link);
		?>
		<SCRIPT language=javascript>
		<!--
		alert ("查無資料，請冾網站管理人員！"); 
		self.close();
		//-->
		</SCRIPT>
		<?php 	
		exit;
		}
mysqli_free_result($result_ProjectQuotationList);

$now_time = date("Y-m-d H:i:s",mktime());
$sql_insert = "INSERT INTO ProjectQuotationListHistory(PQID,PID,PQFile,PQName,PQType,AddUser,AddDate,AddIP,Deltag,ProcUser,ProcDate,ProcIP,UpdateUser,UpdateDate,UpdateIP) SELECT PQID,PID,PQFile,PQName,PQType,AddUser,AddDate,AddIP,Deltag,ProcUser,ProcDate,ProcIP,'".$_SESSION["reg_MUID"]."','".$now_time."','".$_SERVER["REMOTE_ADDR"]."' FROM ProjectQuotationList where Deltag='N' and PID = '".$PID."' and PQID = '".$PQID."';";
$result_insert=mysqli_query($link,$sql_insert) or die ("無法執行新增");
if (trim($PQFile) != "") $sql_txt=",PQFile = '".$PQFile."'";
$sql_update = "update ProjectQuotationList set PQName = '".$PQName."',PQType = '".$PQType."' ".$sql_txt." ,ProcUser = '".$_SESSION["reg_MUID"]."',ProcDate = '".$now_time."',ProcIP = '".$_SERVER["REMOTE_ADDR"]."' where Deltag='N' and PID = '".$PID."' and PQID = '".$PQID."';";
$result_update=mysqli_query($link,$sql_update) or die ("無法執行修改");

mysqli_close($link);
?>
<script type="text/JavaScript">
	<!--
	alert ("修改成功！");
	location.href='ProjectQuotationList.php?PID=<?php echo $PID;?>';
	//-->
</script>

</body>
</html>
