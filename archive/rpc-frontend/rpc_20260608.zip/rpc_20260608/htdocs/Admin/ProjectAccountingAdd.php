﻿<?php	
include "CheckPermission.php";
include "CheckProjectAccounting.php";
include "../global.php";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<?php
$QuoteCheck ="";
$PID = empty($_GET['PID'])?"":$_GET['PID'];
$spage = empty($_GET['spage'])?"":$_GET['spage'];
$KeyWord = empty($_GET['KeyWord'])?"":$_GET['KeyWord'];
$QPStatus = empty($_GET['QPStatus'])?"":$_GET['QPStatus'];
$QAcc = empty($_GET['QAcc'])?"":$_GET['QAcc'];
$PA_Mode = empty($_GET['PA_Mode'])?"":$_GET['PA_Mode'];
if (trim($PA_Mode) == "") $PA_Mode="I";
if (trim(strstr($_SESSION["reg_MPer"],'I')) != "" && trim($PA_Mode) != "I") {
		mysqli_close($link);
		exit;
		}
if (trim(strstr($_SESSION["reg_MPer"],'L')) != "" && trim($PA_Mode) != "O") {
		mysqli_close($link);
		exit;
		}

if (trim($PID) == "")
		{
		mysqli_close($link);
		?>
		<script type="text/JavaScript">
			<!--
			alert ("查無資料，請冾網站管理人員！");
			history.go(-1);
			//-->
		</script>
		<?php
		exit;
		}
$SQL_Project="select PUID,PName,QuoteDate,IFlorin,OFlorin,PTax,(select CRecord from Customer where CID=Project.CID) CRecord,(select CRecordTxt from Customer where CID=Project.CID) CRecordTxt from Project  where Deltag='N' and PID = '".$PID."';";
$result_Project=mysqli_query($link,$SQL_Project) or die ("無法執行查詢");
if (mysqli_num_rows($result_Project) == 0)
		{
		mysqli_free_result($result_Project);
		mysqli_close($link);
		?>
		<SCRIPT language=javascript>
		<!--
		alert ("查無資料，請冾網站管理人員！"); 
		history.go(-1);
		//-->
		</SCRIPT>
		<?php 	
		exit;
		}
list($PUID,$PName,$QuoteDate,$IFlorin,$OFlorin,$PTax,$CRecord,$CRecordTxt)=mysqli_fetch_row($result_Project);
mysqli_free_result($result_Project);
if (trim($QuoteDate) == "0000-00-00") $QuoteDate = "";
if (trim($QuoteDate) != "") $QuoteCheck = "True";
if (trim($_SESSION["reg_MUID"]) == "Benson" || trim($_SESSION["reg_MUID"]) == "vivi") $QuoteCheck = "";
if (trim($IFlorin) == "") $IFlorin = "新台幣";
if (trim($OFlorin) == "") $OFlorin = "新台幣";
if (trim($CRecord) == "A") $CRecordDay=60;
else if (trim($CRecord) == "B") $CRecordDay=30;
else if (trim($CRecord) == "C") $CRecordDay=0;
else if (trim($CRecord) == "D") {
		if (is_numeric($CRecordTxt)) $CRecordDay=$CRecordTxt;
		else $CRecordDay=0;
		}
else $CRecordDay=0;
?>
<title><?php echo $PageAdminTitle;?></title>
<link href="../type.css" rel="stylesheet" type="text/css" />
<style type="text/css">
<!--
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
}
-->
</style>
<link href="../script/DatePicker.css" rel="stylesheet" type="text/css" />
<Script LANGUAGE="Javascript" SRC="../script/DatePicker.js"></Script>
<Script type="text/javascript" language="javascript" src="../script/CheckForm.js"></Script>
<script type="text/JavaScript">
<!--
function jsCheck() 
		{
		<?php if (trim($QuoteCheck) != "True" && trim(strstr($_SESSION["reg_MPer"],'D')) != "") {?>
		if (document.form1.PAMode[0].checked == false && document.form1.PAMode[1].checked == false)
				{
				alert ('請選擇新增類型 !!');
				form1.PAMode[0].focus();
				return false ; 
				}
		<?php }?>
		if (ChkImp('PAItem',document.form1.PAItem.value,'項目') == false) return false;
		if (ChkNaN('Charges',document.form1.Charges.value,'新台幣費用','') == false) return false;
		if (ChkNaN('Rate',document.form1.Rate.value,'匯率','') == false) return false;
		if (document.form1.Rate.value != "0") {
				if (document.form1.ChargesOther.value == "0") {
						alert ('請輸入外幣費用 !!');
						form1.ChargesOther.focus();
						return false ; 
						}
				if (ChkNaN('ChargesOther',document.form1.ChargesOther.value,'外幣費用','') == false) return false;
				}
		if (jsTrim(document.form1.PAPYear.value) != "" || jsTrim(document.form1.PAPMonth.value) != "" || jsTrim(document.form1.PAPDay.value) != "") if (ChkDate('PAPYear',document.form1.PAPYear.value,document.form1.PAPMonth.value,document.form1.PAPDay.value,'預計結清日期') == false) return false;
		if (jsTrim(document.form1.InvoiceYear.value) != "" || jsTrim(document.form1.InvoiceMonth.value) != "" || jsTrim(document.form1.InvoiceDay.value) != "") if (ChkDate('InvoiceYear',document.form1.InvoiceYear.value,document.form1.InvoiceMonth.value,document.form1.InvoiceDay.value,'發票日期') == false) return false;
		}
function CheckMode(CMode) {
		if (CMode == "I") {
				document.getElementById('ChargesOtherText').innerHTML = "<?php echo $IFlorin;?>：";
				document.getElementById('CheckCustomer').style.display = 'none';
				}
		else if (CMode == "O") {
				document.getElementById('ChargesOtherText').innerHTML = "<?php echo $OFlorin;?>：";
				document.getElementById('CheckCustomer').style.display = '';
				}
		}
function CheckRate() {
		if (ChkNaN('Rate',document.form1.Rate.value,'匯率','') == false) return false;
		if (document.form1.Rate.value != "0") {
				document.getElementById('ChargesOtherText').style.display = '';
				document.getElementById('ChargesOtherValue').style.display = '';
				}
		else {
				document.getElementById('ChargesOtherText').style.display = 'none';
				document.getElementById('ChargesOtherValue').style.display = 'none';
				}
		}

function DateAdd(interval,number,date){
	// date 可以是時間對象也可以是字符串，如果是後者，形式必須為: yyyy-mm-dd hh:mm:ss 
	// 其中分隔符不定。"2006年12月29日 16點01分23秒" 也是合法的
	number = parseInt(number);
	if (typeof(date)=="string"){
		date = date.split(/\D/);
		--date[1];
		eval("var date = new Date("+date.join(",")+")");
		}
	if (typeof(date)=="object"){
		var date = date
		}
	switch(interval){
		case "y": date.setFullYear(date.getFullYear()+number); break;
		case "m": date.setMonth(date.getMonth()+number); break;
		case "d": date.setDate(date.getDate()+number); break;
		case "w": date.setDate(date.getDate()+7*number); break;
		case "h": date.setHours(date.getHour()+number); break;
		case "n": date.setMinutes(date.getMinutes()+number); break;
		case "s": date.setSeconds(date.getSeconds()+number); break;
		case "l": date.setMilliseconds(date.getMilliseconds()+number); break;
		}
	return date;
	}
function InvoiceCheck(){
	<?php if (trim($PAStatus) != "S"){?>
	if (jsTrim(document.form1.InvoiceYear.value) != "" && jsTrim(document.form1.InvoiceMonth.value) != "" && jsTrim(document.form1.InvoiceDay.value) != "") {
			if (ChkDate('InvoiceYear',document.form1.InvoiceYear.value,document.form1.InvoiceMonth.value,document.form1.InvoiceDay.value,'發票日期') == false) return false;
			var dd = DateAdd('d',<?php echo $CRecordDay;?>,document.form1.InvoiceYear.value+'-'+document.form1.InvoiceMonth.value+'-'+document.form1.InvoiceDay.value);
			if (jsTrim(document.form1.PAPYear.value) == "") document.form1.PAPYear.value = dd.getFullYear();
			var jPAPMonth = dd.getMonth()+2;
			if (jPAPMonth.toString().length < 2) jPAPMonth='0'+jPAPMonth.toString();
			var jPAPDay = dd.getDate();
			if (jPAPDay.toString().length < 2) jPAPDay='0'+jPAPDay.toString();
			if (jsTrim(document.form1.PAPMonth.value) == "") document.form1.PAPMonth.value = jPAPMonth;
			if (jsTrim(document.form1.PAPDay.value) == "") document.form1.PAPDay.value = jPAPDay;
			return false;
			}
	<?php }?>
	}
//-->
</script>
</head>
<body>
<?php include "top.php";?>
<table width="100%" border="0" cellspacing="0" cellpadding="5">
	<tr>
    <td width="160" height="600" align="left" valign="top">
			<?php include "menu.php";?>
    </td>
    <td valign="top">
    	<table width="100%" border="0" cellpadding="0" cellspacing="0">
    		<tr>
    			<td>
			    	<table width="750" border="0" cellpadding="0" cellspacing="0">
			    		<tr height="30">
			    			<td class="c2"><a href="ProjectAccounting.php?page=<?php echo $spage;?>&QPStatus=<?php echo $QPStatus;?>&QAcc=<?php echo $QAcc;?>&KeyWord=<?php echo urlencode($KeyWord);?>">客戶案件帳務管理</a> &gt; <a href="ProjectAccountingList.php?PID=<?php echo $PID;?>&page=<?php echo $spage;?>&QPStatus=<?php echo $QPStatus;?>&QAcc=<?php echo $QAcc;?>&KeyWord=<?php echo urlencode($KeyWord);?>"><?php echo $PName;?> 帳務管理</a> &gt; 新增項目</td>
			    		</tr>
			    	</table>
			    	<table width="750" border="0" cellpadding="0" cellspacing="0">
			        <form name="form1" method="post" action="ProjectAccountingAddDB.php" onSubmit="return jsCheck();">
			        <tr height="35" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td width="130" align="right" class="c3">新增類型：</td>
			          <td class="h3">
			          	<?php if (trim($QuoteCheck) != "True") {
				    				if (trim(strstr($_SESSION["reg_MPer"],'D')) != "") {?>
					          	<input type="radio" name="PAMode" value="I" onclick="CheckMode('I');"> 收入 
					          	<input type="radio" name="PAMode" value="O" onclick="CheckMode('O');"> 支出
				          	<?php } else {
				          		if (trim($PA_Mode) == "I") {?>
						          	<input type="radio" name="PAMode" value="I" onclick="CheckMode('I');" checked> 收入 
				          		<?php } else if (trim($PA_Mode) == "O") {?>
						          	<input type="radio" name="PAMode" value="O" onclick="CheckMode('O');" checked> 支出
					          	<?php }
				          		}
			          		} else {?>
			          		<input type="radio" name="PAMode" value="O" checked> 支出
			          	<?php }?>
			          </td>
			        </tr>
			        <tr height="35" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">項 目：</td>
			          <td class="h3">
			          	<input type="text" id="PAItem" name="PAItem" size="60">
			          </td>
			        </tr>
			        <tr height="35" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">費 用：</td>
			          <td class="h3">
			          	<table width="100%" border="0" cellpadding="0" cellspacing="0">
			          		<tr class="c3">
			          			<td width="90" align="right">新台幣：</td>
			          			<td width="100"><input type="text" id="Charges" name="Charges" size="10"></td>
			          			<td width="80" align="right">匯率：</td>
			          			<td width="100"><input type="text" id="Rate" name="Rate" size="10" value="0" onKeyUp="CheckRate();"></td>
			          			<td width="100" align="right"><div id="ChargesOtherText" style="display:<?php if (trim($IFlorin) == "新台幣") echo "none";?>"><?php if (trim($IFlorin) != "") echo $IFlorin;?>：</div></td>
			          			<td width="300"><div id="ChargesOtherValue" style="display:<?php if (trim($IFlorin) == "新台幣") echo "none";?>"><input type="text" id="ChargesOther" name="ChargesOther" size="10"></div></td>
								<!--<td width="80" align="right"><div id="ChargesOtherText" style="display:none">外幣：</div></td>
								<td width="300"><div id="ChargesOtherValue" style="display:none"><input type="text" id="ChargesOther" name="ChargesOther" size="10"></div></td>
								-->
							</tr>
			          	</table>
			          </td>
			        </tr>
			        <tr height="35" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">是否含稅：</td>
			          <td class="h3">
			          	<input type="radio" name="PATax" value="Y"<?php if (trim($PTax) == "Y") echo " checked";?>> 是 
			          	<input type="radio" name="PATax" value="N"<?php if (trim($PTax) == "N") echo " checked";?>> 否 
			          </td>
			        </tr>
			        <tr id="CheckCustomer" style="display:<?php if (trim($QuoteCheck) != "True") echo "none";?>" height="35" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">供應商：</td>
			          <td class="h3">
						    	<table width="100%" border="0" cellpadding="0" cellspacing="0">
						        <form name="form1" method="post" action="CustomerSurveyExport.php" onSubmit="return jsCheck();" target="_CustomerSurvey">
						        <tr height="30">
						          <td width="90" align="right" class="c3">客戶名稱：</td>
						          <td class="h3">
						          	<table width="100%" border="0" cellpadding="0" cellspacing="0">
						          		<tr>
						          			<td><div id="CNamePreview" style="display:none"></div></td>
						          			<td>
									          	<input type="hidden" id="CID" name="CID">
									          	<input type="hidden" id="CName" name="CName">
									          	<input type="button" id="SelCID" name="SelCID" class="input_bot" value="請選擇" onclick="javascript:window.open ('SelCustomer.php?QCType=P','SelCustomer','height=300,width=550,top=200,left=200,scrollbars=yes,status=yes');">
						          			</td>
						          		</tr>
						          	</table>
						          	
						          </td>
						        </tr>
						        <tr height="30">
						          <td align="right" class="c3">客戶電話：</td>
						          <td class="h3">
						          	<table width="100%" border="0" cellpadding="0" cellspacing="0">
						          		<tr>
						          			<td width="150">
						          				<div id="CTelPreview" style="display:none"></div>
									          	<input type="hidden" id="CTel" name="CTel">
						          			</td>
						          			<td width="60" align="right" class="c3">傳真：</td>
						          			<td>
						          				<div id="CFaxPreview" style="display:none"></div>
						          				<input type="hidden" id="CFax" name="CFax">
						          				<input type="hidden" id="Contact" name="Contact" size="20">
						          				<input type="hidden" id="CMobile" name="CMobile" size="20">
						          				<input type="hidden" id="CEMail" name="CEMail" size="60">
						          			</td>
						          		</tr>
						          	</table>
						          </td>
						        </tr>
						        <tr height="30">
						          <td align="right" class="c3">客戶地址：</td>
						          <td class="h3">
						          	<div id="CAddressPreview" style="display:none"></div>
						          	<input type="hidden" id="CAddress" name="CAddress">
						          </td>
						        </tr>
						      </table>
			          </td>
			        </tr>
			        <tr height="35" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">發票日期：</td>
			          <td class="h3">
		              <input id="InvoiceYear" name="InvoiceYear" type="text" size="4" onblur="javascript:InvoiceCheck();" /> 年 
		              <input id="InvoiceMonth" name="InvoiceMonth" type="text" size="2" onblur="javascript:InvoiceCheck();" /> 月 
		              <input id="InvoiceDay" name="InvoiceDay" type="text" size="2" onblur="javascript:InvoiceCheck();" /> 日 
		              <img src="../images/icon.gif" width="16" height="18" style="cursor: hand" onclick="javascript:displayDatePicker('InvoiceYear','InvoiceMonth','InvoiceDay');"/>
			          </td>
			        </tr>
			        <tr height="35" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">發票號碼：</td>
			          <td class="h3">
			          	<input type="text" id="Invoice" name="Invoice" size="20">
			          </td>
			        </tr>
			        <tr height="35" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">預計結清日期：</td>
			          <td class="h3">
		              <input id="PAPYear" name="PAPYear" type="text" size="4" value="<?php echo empty($_POST['PAPYear'])?"":$_POST['PAPYear'];?>" /> 年 
		              <input id="PAPMonth" name="PAPMonth" type="text" size="2" value="<?php echo empty($_POST['PAPMonth'])?"":$_POST['PAPMonth'];?>" /> 月 
		              <input id="PAPDay" name="PAPDay" type="text" size="2" value="<?php echo empty($_POST['PAPDay'])?"":$_POST['PAPDay'];?>" /> 日 
		              <img src="../images/icon.gif" width="16" height="18" style="cursor: hand" onclick="javascript:displayDatePicker('PAPYear','PAPMonth','PAPDay');"/>
			          </td>
			        </tr>
			        <tr height="35" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">備 註：</td>
			          <td class="h3">
			          	<textarea rows="3" id="PANote" name="PANote" cols="60"></textarea>
			          	<input type="hidden" id="PID" name="PID" value="<?php echo $PID;?>">
			          	<input type="hidden" id="spage" name="spage" value="<?php echo $spage;?>">
			          	<input type="hidden" id="KeyWord" name="KeyWord" value="<?php echo $KeyWord;?>">
			          	<input type="hidden" id="QPStatus" name="QPStatus" value="<?php echo $QPStatus;?>">
			          	<input type="hidden" id="QAcc" name="QAcc" value="<?php echo $QAcc;?>">
			          	<input type="hidden" id="PA_Mode" name="PA_Mode" value="<?php echo $PA_Mode;?>">
			          </td>
			        </tr>
			        <tr height="40" align="center">
			          <td colspan="2" class="h3"><input type="submit" name="submit" class="input_bot" value="送 出"></td>
			        </tr>
				      </form>
			      </table>
    			</td>
    		</tr>
    	</table>
    </td>
	</tr>
</table>
<?php include "down.php";?>
</body>
</html>
<?php
mysqli_close($link);
?>