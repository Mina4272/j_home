<?php
include "CheckPermission.php";
include "CheckMVac.php";
include "../global.php";

$KeyWord = $_POST['KeyWord'];
if (trim($KeyWord) == "") $KeyWord = $_GET['KeyWord'];
$QPStatus = $_POST['QPStatus'];
if (trim($QPStatus) == "") $QPStatus = $_GET['QPStatus'];
$QPE = $_POST['QPE'];
if (trim($QPE) == "") $QPE = $_GET['QPE'];
$QBMUID = $_POST['QBMUID'];
if (trim($QBMUID) == "") $QBMUID = $_GET['QBMUID'];
$ISINo = $_POST['ISINo'];
if (trim($ISINo) == "") $ISINo = $_GET['ISINo'];
$ISAdd = $_POST['ISAdd'];
if (trim($ISAdd) == "") $ISAdd = $_GET['ISAdd'];

if (trim($KeyWord) != "") {
		$SQL_ProjectCertificate="select PID from ProjectCertificate where Deltag='N' and PCNo like '%".$KeyWord."%' group by PID order by PID;";
		$result_ProjectCertificate=mysql_query($SQL_ProjectCertificate,$link) or die ("無法執行查詢");
		$SqlPID = "";
		while(list($PC_PID)=mysql_fetch_row($result_ProjectCertificate)){
				//if (trim($SqlPID) == "") $SqlPID = "PID='".$PC_PID."'";
				//else $SqlPID = $SqlPID." or PID='".$PC_PID."'";
				if (trim($SqlPID) == "") $SqlPID = $PC_PID;
				else $SqlPID = $SqlPID.",".$PC_PID;
				}
		mysql_free_result($result_ProjectCertificate);
		}
if (trim($SqlPID) != "") $SqlPID = " PID in (".$SqlPID.")";
if (trim($KeyWord) != "") {
		if (trim($SqlPID) == "") $SqlTxt = $SqlTxt." and (PUID like '%".$KeyWord."%' or CName like '%".$KeyWord."%' or CTel like '%".$KeyWord."%' or CFax like '%".$KeyWord."%' or Contact like '%".$KeyWord."%' or CMobile like '%".$KeyWord."%' or CEMail like '%".$KeyWord."%' or CAddress like '%".$KeyWord."%' or PName like '%".$KeyWord."%' or ModelName like '%".$KeyWord."%' or SeriesModel like '%".$KeyWord."%' or PE like '%".$KeyWord."%' or PNote like '%".$KeyWord."%' or ApplyItem like '%".$KeyWord."%')";
		else $SqlTxt = $SqlTxt." and (PUID like '%".$KeyWord."%' or CName like '%".$KeyWord."%' or CTel like '%".$KeyWord."%' or CFax like '%".$KeyWord."%' or Contact like '%".$KeyWord."%' or CMobile like '%".$KeyWord."%' or CEMail like '%".$KeyWord."%' or CAddress like '%".$KeyWord."%' or PName like '%".$KeyWord."%' or ModelName like '%".$KeyWord."%' or SeriesModel like '%".$KeyWord."%' or PE like '%".$KeyWord."%' or PNote like '%".$KeyWord."%' or ApplyItem like '%".$KeyWord."%' or ".$SqlPID.")";
		
		}
if (trim($QPStatus) != "") $SqlTxt = $SqlTxt." and PStatus='".$QPStatus."' ";
if (trim($QPE) != "") $SqlTxt = $SqlTxt." and PE='".$QPE."' ";
if (trim($QBMUID) != "") $SqlTxt = $SqlTxt." and ifnull(BMUID,'vivi')='".$QBMUID."' ";
if (trim($ISINo) != "") {
		if (trim($ISINo) == "Y") $SqlTxt = $SqlTxt." and INo <> '' ";
		else $SqlTxt = $SqlTxt." and INo = '' ";
		}
if (trim($ISAdd) != "") {
		if (trim($ISAdd) == "Y") $SqlTxt2 = " WHERE a.PCount > 0";
		else $SqlTxt2 = " WHERE a.PCount = 0";
		}

$SQL_Project="select a.* from (select PID,PUID,CID,CName,CTel,CFax,Contact,CMobile,CEMail,CAddress,PStatus,PName,ModelName,SeriesModel,PE,(select MName from Manager where MUID = Project.PE) PEName,(select MEName from Manager where MUID = Project.PE) PEEName,Quote,ApplyItem,Canon,SNote,StartDate,PlanDate,replace(CloseDate,'0000-00-00',''),ifnull(DATEDIFF(CloseDate,StartDate),0) ProcDate,PNote,QuoteDate,ReturnDate,(select count(PAAID) PCount from ProjectAccountingAdd where PAACheck='N' and PID=Project.PID) PCount from Project where Deltag='N' ".$SqlTxt.") as a ".$SqlTxt2." order by a.PStatus asc,a.PID desc;";
$result_Project=mysql_query($SQL_Project,$link) or die ("無法執行查詢");
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $PageAdminTitle;?></title>
<link href="style.css" rel="stylesheet" type="text/css" />
<body>
<table winth="1000" border="0">
	<tr>
		<td colspan="2"><font color=blue>若您無法正常觀看此報表！請下載此 <a href="owc11.zip" target="_File"><font color=red><b>元件</b></font></a> <font color=blue>安裝至您的電腦。</font></td>
	</tr>
</table>
<object id=Project classid=CLSID:0002E559-0000-0000-C000-000000000046 style="width:100%;height:90%"></object>
<script language=vbscript>
	Sub Window_OnLoad()
	Set chConstants = Project.Constants
	Project.ActiveSheet.Cells.Clear
	Project.Worksheets(1).Select
	Project.ActiveSheet.Name ="Project"

	Project.ActiveSheet.Cells(1,1).Value ="案件編號"
	Project.ActiveSheet.Cells(1,2).Value ="案件工程師"
	Project.ActiveSheet.Cells(1,3).Value ="客戶名稱"
	Project.ActiveSheet.Cells(1,4).Value ="產品名稱"
	Project.ActiveSheet.Cells(1,5).Value ="型號"
	Project.ActiveSheet.Cells(1,6).Value ="系列型式"
	Project.ActiveSheet.Cells(1,7).Value ="申請項目"
	Project.ActiveSheet.Cells(1,8).Value ="案件開始日期"
	Project.ActiveSheet.Cells(1,9).Value ="結案日期"
	Project.ActiveSheet.Cells(1,10).Value ="案件處理時間(天)"
	Project.ActiveSheet.Cells(1,11).Value ="案件狀態"
<?php  
$ECount=2;
while(list($PID,$PUID,$CID,$CName,$CTel,$CFax,$Contact,$CMobile,$CEMail,$CAddress,$PStatus,$PName,$ModelName,$SeriesModel,$PE,$PEName,$PEEName,$Quote,$ApplyItem,$Canon,$SNote,$StartDate,$PlanDate,$CloseDate,$ProcDate,$PNote,$QuoteDate,$ReturnDate)=mysql_fetch_row($result_Project)){
  	if (trim($PStatus) == "A") $PStatus = "新開案";
  	else if (trim($PStatus) == "B") $PStatus = "報價中";
  	else if (trim($PStatus) == "C") $PStatus = "案件處理中";
  	else if (trim($PStatus) == "D") $PStatus = "審查中";
  	else if (trim($PStatus) == "E") $PStatus = "補件中";
  	else if (trim($PStatus) == "F") $PStatus = "待印證";
  	else if (trim($PStatus) == "G") $PStatus = "案件取消";
  	else if (trim($PStatus) == "H") $PStatus = "已結案";
		?>
		Project.ActiveSheet.Cells(<?php echo $ECount;?>,1).Value ="'<?php echo $PUID;?>"
		Project.ActiveSheet.Cells(<?php echo $ECount;?>,2).Value ="<?php echo $PEEName.$PEName;?>"
		Project.ActiveSheet.Cells(<?php echo $ECount;?>,3).Value ="<?php echo $CName;?>"
		Project.ActiveSheet.Cells(<?php echo $ECount;?>,4).Value ="<?php echo $PName;?>"
		Project.ActiveSheet.Cells(<?php echo $ECount;?>,5).Value ="<?php echo $ModelName;?>"
		Project.ActiveSheet.Cells(<?php echo $ECount;?>,6).Value ="<?php echo $SeriesModel;?>"
		Project.ActiveSheet.Cells(<?php echo $ECount;?>,7).Value ="<?php echo $ApplyItem;?>"
		Project.ActiveSheet.Cells(<?php echo $ECount;?>,8).Value ="'<?php echo $StartDate;?>"
		Project.ActiveSheet.Cells(<?php echo $ECount;?>,9).Value ="'<?php echo $CloseDate;?>"
		Project.ActiveSheet.Cells(<?php echo $ECount;?>,10).Value ="<?php echo $ProcDate;?>"
		Project.ActiveSheet.Cells(<?php echo $ECount;?>,11).Value ="<?php echo $PStatus;?>"
		<?php
		$ECount++;
		}
mysql_free_result($result_Project);
mysql_close($link);
?>

		Project.ActiveSheet.Range("A1:R<?php echo $ECount;?>").Font.Color="blue"
		Project.ActiveSheet.Range("A1:R<?php echo $ECount;?>").Font.Name="Courier New"
		Project.ActiveSheet.Range("A1:R<?php echo $ECount;?>").Font.Size="11"
		Project.ActiveSheet.Range("A1:R<?php echo $ECount;?>").Columns.AutoFit
		Project.ActiveSheet.Range("A1:R<?php echo $ECount;?>").NumberFormat ="General"

		Project.ActiveSheet.Range("A1:R1").Font.Bold=true
		Project.ActiveSheet.Range("A1:R1").Font.Color="#000000"
		Project.ActiveSheet.Range("A1:R1").Font.Bold=true
		Project.ActiveSheet.Range("A1:R1").Font.Bold=true
		Project.ActiveSheet.Range("A1:R1").Font.Bold=true

	End Sub
	</script>
</body>
</html>
