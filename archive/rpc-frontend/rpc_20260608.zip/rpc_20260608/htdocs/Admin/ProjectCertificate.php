﻿<?php
include "CheckPermission.php";
include "CheckProject.php";
include "../global.php";
include "include/page_function.php";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $PageAdminTitle;?></title>
<link href="../type.css" rel="stylesheet" type="text/css" />
<style type="text/css">
<!--
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
}
-->
</style></head>

<body>
<?php
$PID = $_GET['PID'];
$page = empty($_GET['page'])?"":$_GET['page'];
if (trim($page) == "") $page = 1;
$page_rows=10;  //每頁筆數
$php_Self = "ProjectCertificate.php";  //分頁web檔名

$button_css = "h4";
$limit_txt =" limit ".(($page-1) * $page_rows).",".$page_rows;
$url_str = "&PID=".$PID;
$SqlTxt = "";
$Sql_str="select PCID,PCNo,PCName,PCFile,PCSDate,PCEDate,PCNote,AddUser,AddDate,ProcUser,ProcDate from ProjectCertificate where Deltag='N' and PID = '".$PID."' ".$SqlTxt." order by PCID desc;";
$SQL_ProjectCertificate="select PCID,PCNo,PCName,PCFile,PCSDate,PCEDate,PCNote,AddUser,AddDate,ProcUser,ProcDate from ProjectCertificate where Deltag='N' and PID = '".$PID."' ".$SqlTxt." order by PCID desc ".$limit_txt.";";
$result_ProjectCertificate=mysqli_query($link,$SQL_ProjectCertificate) or die ("無法執行查詢");
?>
<table width="100%" border="0" cellpadding="5" cellspacing="2" class="s2">
  <tr>
    <td width="100" background="../images/table_bg.gif" class="t21">
    	<input type="button" name="add" value="新 增" class="input_bot" onclick="javascript:window.open ('ProjectCertificateAdd.php?PID=<?php echo $PID;?>','ProjectCertificate','height=320,width=700,top=200,left=200,scrollbars=yes,status=yes');">
    	編號
    </td>
    <td width="120" align="center" background="../images/table_bg.gif" class="t21">名稱</td>
    <td width="180" align="center" background="../images/table_bg.gif" class="t21">有效日期</td>
    <td align="center" background="../images/table_bg.gif" class="t21">備註</td>
    <td width="45" align="center" background="../images/table_bg.gif" class="t21">修 改</td>
    <td width="45" align="center" background="../images/table_bg.gif" class="t21">刪 除</td>
  </tr>
  <?php
  $tmp = 1;
  while(list($PCID,$PCNo,$PCName,$PCFile,$PCSDate,$PCEDate,$PCNote,$AddUser,$AddDate,$ProcUser,$ProcDate)=mysqli_fetch_row($result_ProjectCertificate)){
	if (trim($PCSDate) == "0000-00-00") $PCSDate = "";
	if (trim($PCEDate) == "0000-00-00") $PCEDate = "";
	?>
	<tr<?php if ($tmp%2 == 0) echo " bgcolor=\"#F6F6F6\"";?>>
    <td class="h3" align="center"><?php echo $PCNo;?></td>
    <td class="h3" align="center"><a href="getfile.php?FolderName=Admin\\PCFile&FileName=<?php echo $PCFile;?>"><?php echo $PCName;?></a></td>
    <td class="h3" align="center">
    	<?php
    	if (trim($PCSDate) != "" || trim($PCEDate) != "") echo $PCSDate."～".$PCEDate;
    	?>
    </td>
    <td class="h3" align="center"><?php echo $PCNote;?></td>
    <td align="center"><input type="button" name="edit" value="修 改" class="input_bot" onclick="javascript:window.open ('ProjectCertificateEdit.php?PID=<?php echo $PID;?>&PCID=<?php echo $PCID;?>','SelCustomer','height=340,width=700,top=200,left=200,scrollbars=yes,status=yes');"></td>
    <td align="center"><input type="button" name="edit" value="刪 除" class="input_bot" onclick="javascript:if (confirm('您是否確定要刪除？')) location.href='ProjectCertificateDelDB.php?PID=<?php echo $PID;?>&PCID=<?php echo $PCID;?>&page=<?php echo $page;?>';"></td>
  </tr>
  <?php
			$tmp++;
			}
	mysqli_free_result($result_ProjectCertificate);
  ?>
</table>
<table width="100%" border="0" cellpadding="5" cellspacing="2" class="s2">
  <tr align="center">
    <td bgcolor="#E8F0C2" class="h4"><?php Page_show($Sql_str,$page_rows,$php_Self,$link,$page,$url_str,$button_css);?></td>
  </tr>
</table>
</body>
</html>
<?php
mysqli_close($link);
?>