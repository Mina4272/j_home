﻿<?php
include "CheckPermission.php";
include "../global.php";
include "include/page_function.php";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $PageAdminTitle;?></title>
<link href="../type.css" rel="stylesheet" type="text/css" />
<style type="text/css">
<!--
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
}
-->
</style></head>

<body>
<?php include "top.php";?>
<table width="100%" border="0" cellspacing="0" cellpadding="5">
	<tr>
    <td width="160" height="600" align="left" valign="top">
	<?php include "menu.php";?>
    </td>

	<?php 						
		$MID = $_GET['MID'];	
		//$MName = $_GET['MName'];
		
		$SQL_Manager="select MUID,MName from Manager where MID='".$MID."';";
		$result_Manager=mysqli_query($link,$SQL_Manager) or die ("沒有人!");
		list($MUID,$MName)=mysqli_fetch_row($result_Manager);
		mysqli_free_result($result_Manager);

		//echo strtolower($_SESSION["reg_MUID"]);
		//echo strtolower($MUID);
	?>					

    <td valign="top">
    	<table width="100%" border="0" cellpadding="0" cellspacing="0">
    		<tr>
    			<td>
			    	<table width="750" border="0" cellpadding="0" cellspacing="0">
			    		<tr height="30">
			    			<td class="c2"><?php echo $MName;?> 例行工作</td>
			    		</tr>
			    	</table>
						<?php
						$page = empty($_GET['page'])?"":$_GET['page'];
						if (trim($page) == "") $page = 1;
						$page_rows=150;  //每頁筆數
						$php_Self = "ManagerJob.php";  //分頁web檔名

						$button_css = "h4";
						$limit_txt =" limit ".(($page-1) * $page_rows).",".$page_rows;
						$url_str = "";
						$Sql_str="select MID,MUID,MPassword,MName,MEName,EmployeeNo,EMail,MIntro,MPer from Manager where Deltag='N' order by MID;";
						//$SQL_Manager="select MID,MUID,MPassword,MName,MEName,EmployeeNo,EMail,MIntro,MPer from Manager where Deltag='N' order by MID desc ".$limit_txt.";";
					
						$SQL_ManagerJob="select a.MJID, a.MJPeriod, a.MJTitle, a.MJDescription, a.MJDeputyID, a.MJNote, b.MName as MJDeputy,IFNULL(a.ReceiveMid,0) as c from ManagerJob as a, Manager as b where a.MJDeputyID=b.MID and a.MID='".$MID."' and a.Deltag='N' order by a.MJID ".$limit_txt.";";						
						//$SQL_ManagerJob="SELECT a.MJID, a.MJPeriod, a.MJTitle, a.MJDescription, a.MJDeputyID, a.MJNote, b.MName as MJDeputy,IFNULL(c.MJID,0) as c from managerjob a inner join manager b on a.MJDeputyID = b.MID left join managerjobchange c on a.MJID = c.MJID where a.MID='".$MID."' and a.Deltag='N' order by a.MJID ".$limit_txt.";";
						//echo $SQL_ManagerJob;
						$result_ManagerJob=mysqli_query($link,$SQL_ManagerJob) or die ("沒有例行工作項目!");
						?>
			    	<table width="750" border="0" cellpadding="5" cellspacing="2" class="s2">
			        <form name="form1" method="post" action="ManagerJobChangeDB.php?MID=<?php echo $MID; ?>?">
					<tr align="center">
					  <td class="t21"></td>	
			          <td width="80" align="center" class="t21">工作週期</td>
			          <td width="80" align="center" class="t21">工作名稱</td>
			          <td width="80" class="t21"> 工作內容</td>
			          <td width="100" class="t21">代理人</td>
					  <?php
						$SQL_Manager="select MID,MUID,MName,MEName from Manager where Deltag='N' and IsLeft='N';";
						$result_Manager=mysqli_query($link,$SQL_Manager) or die ("無法執行查詢");
						?>
						<td align="left" class="h3">接受人員：
							<select name="MIDC">
							<option value="">不限</option>
							 <?php while(list($MIDC,$MUID,$MName,$MEName)=mysqli_fetch_row($result_Manager)){?>
							  <option value="<?php echo $MIDC;?>"><?php echo $MEName.$MName;?></option>
							  <?php }?>
							</select>
						</td>
						<?php mysqli_free_result($result_Manager);?>
			        </tr>
					<?php
					$tmp = 1;
					while(list($MJID,$MJPeriod,$MJTitle,$MJDescription,$MJDeputyID,$MJNote, $MJDeputy ,$c)=mysqli_fetch_row($result_ManagerJob)){
		        	?>
		        	<tr<?php if ($tmp%2 == 0) echo " bgcolor=\"#F6F6F6\"";?>>
					<td align="center" class="h3">
					<?php
						if($c==0){
					?>
					<input type="checkbox" value="<?php echo $MJID;?>" name="ID[]">
					<?php
						}else{
					?>
					移轉中
					<?php		
						}
					?>
					
					</td>
					<?php
					if ($MJPeriod == 'D') echo "<td align='center' class='h3'> 每天</td>";
					if ($MJPeriod == 'W') echo "<td align='center' class='h3'>每周</td>";
					if ($MJPeriod == 'M') echo "<td align='center' class='h3'>每月</td>";
					if ($MJPeriod == 'Y') echo "<td align='center' class='h3'>每年</td>";
					if ($MJPeriod == 'U') echo "<td align='center' class='h3'>不定期</td>";
		
					?>
			          <td align="center" class="h3"><?php echo $MJTitle;?></td>
			          <td align="center" class="h3"><?php echo $MJDescription;?></td>
			          <td align="center" class="h3"><?php echo $MJDeputy;?></td>
					  </tr>
			       <?php
            			$tmp++;
					}
					mysqli_free_result($result_ManagerJob);
					?>
					<tr height="40" align="center">
						<td align="center" class="h3"></td>
						<td align="center" class="h3"></td>
						<td align="center" class="h3"></td>
						<td align="center" class="h3"></td>
					   <td colspan="2" class="h3"><input type="submit" name="submit" class="input_bot" value="送 出"></td>
			        </tr>
					</form>
			      </table>
			      <table width="750" border="0" cellpadding="5" cellspacing="2" class="s2">
			        <tr align="center">
			          <td bgcolor="#E8F0C2" class="h4"><?php Page_show($Sql_str,$page_rows,$php_Self,$link,$page,$url_str,$button_css);?></td>
			        </tr>
			      </table>
    			</td>
    		</tr>
    	</table>
    </td>
	</tr>
</table>
<?php include "down.php";?>
</body>
</html>
<?php
mysqli_close($link);
?>