﻿<?php	
include "CheckPermission.php";
include "CheckProjectAccounting.php";
include "../global.php";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $PageAdminTitle;?></title>
<link href="../type.css" rel="stylesheet" type="text/css" />
<style type="text/css">
<!--
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
}
-->
</style>
<link href="../script/DatePicker.css" rel="stylesheet" type="text/css" />
<Script LANGUAGE="Javascript" SRC="../script/DatePicker.js"></Script>
<Script type="text/javascript" language="javascript" src="../script/CheckForm.js"></Script>
<script type="text/JavaScript">
<!--
function jsCheck() 
		{
		if (ChkDate('QuoteYear',document.form1.QuoteYear.value,document.form1.QuoteMonth.value,document.form1.QuoteDay.value,'報價日期') == false) return false;
		}
//-->
</script>
</head>
<body>
<?php
$PID = $_GET['PID'];
if (trim($PID) == "")
		{
		mysqli_close($link);
		?>
		<script type="text/JavaScript">
			<!--
			alert ("查無資料，請冾網站管理人員！");
			history.go(-1);
			//-->
		</script>
		<?php
		exit;
		}
$SQL_Project="select QuoteDate,date_format(QuoteDate,'%Y'),date_format(QuoteDate,'%m'),date_format(QuoteDate,'%d'),IFlorin,InvoiceCUID,InvoiceTitle,InvoiceAddress,Leadtime,Trademark,PTax,PStatus,BMUID from Project where Deltag='N' and PID = '".$PID."';";
$result_Project=mysqli_query($link,$SQL_Project) or die ("無法執行查詢");
if (mysqli_num_rows($result_Project) == 0)
		{
		mysqli_free_result($result_Project);
		mysqli_close($link);
		?>
		<SCRIPT language=javascript>
		<!--
		alert ("查無資料，請冾網站管理人員！"); 
		history.go(-1);
		//-->
		</SCRIPT>
		<?php 	
		exit;
		}
list($QuoteDate,$QuoteYear,$QuoteMonth,$QuoteDay,$IFlorin,$InvoiceCUID,$InvoiceTitle,$InvoiceAddress,$Leadtime,$Trademark,$PTax,$PStatus,$BMUID)=mysqli_fetch_row($result_Project);
mysqli_free_result($result_Project);
if (trim($QuoteDate) == "0000-00-00") $QuoteDate = "";
if (trim($BMUID) == "") $BMUID = "vivi";
//if (trim($QuoteDate) != "") {
//		mysqli_close($link);
		?>
		<script type="text/JavaScript">
			<!--
			//location.href='ProjectQuotation.php?PID=<?php echo $PID;?>';
			//-->
		</script>
		<?php
//		exit;
//		}
$SQL_ProjectAccounting="select PAID,PAMode,PAItem,Charges,Rate,PAStatus,PADate,PANote from ProjectAccounting where Deltag='N' and PAMode='I' and PID = '".$PID."' and (PAStatus = 'W' or PAStatus = 'S') order by PAMode asc,PAID asc;";
$result_ProjectAccounting=mysqli_query($link,$SQL_ProjectAccounting) or die ("無法執行查詢");
if (mysqli_num_rows($result_ProjectAccounting) == 0)
		{
		mysqli_free_result($result_ProjectAccounting);
		mysqli_close($link);
		?>
		<SCRIPT language=javascript>
		<!--
		alert ("您未新增報價資料！"); 
		self.close();
		//-->
		</SCRIPT>
		<?php 	
		exit;
		}
mysqli_free_result($result_ProjectAccounting);

?>
<center>
<table width="100%" border="0" cellpadding="0" cellspacing="0">
	<tr>
		<td>
    	<table width="600" border="0" cellpadding="0" cellspacing="0">
    		<tr height="40" align="center">
    			<td></td>
    		</tr>
    		<tr height="30" align="center">
    			<td class="c2" background="../images/table_bg.gif"><b>請輸入報價日期</b></td>
    		</tr>
    	</table>
    	<table width="600" border="0" cellpadding="0" cellspacing="0">
        <form name="form1" method="post" action="ProjectQuotationCheckDB.php" onSubmit="return jsCheck();">
        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
          <td width="150" align="right" class="c3">報價日期：</td>
          <td class="h3" align="left">
            <input id="QuoteYear" name="QuoteYear" type="text" size="4" value="<?php echo $QuoteYear;?>" /> 年 
            <input id="QuoteMonth" name="QuoteMonth" type="text" size="2" value="<?php echo $QuoteMonth;?>" /> 月 
            <input id="QuoteDay" name="QuoteDay" type="text" size="2" value="<?php echo $QuoteDay;?>" /> 日 
            <img src="../images/icon.gif" width="16" height="18" style="cursor: hand" onclick="javascript:displayDatePicker('QuoteYear','QuoteMonth','QuoteDay');"/>
            <input id="PID" name="PID" type="hidden" value="<?php echo $PID;?>" />
          </td>
        </tr>
        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
          <td align="right" class="c3">使用幣別：</td>
          <td class="h3" align="left">
            <input id="Florin" name="Florin" type="radio" value="T" checked /> 新台幣　
            <?php if (trim($IFlorin) != "") {?>
            <input id="Florin" name="Florin" type="radio" value="O" /> <?php echo $IFlorin;?>
            <?php }?>
          </td>
        </tr>
        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
          <td align="right" class="c3">統一編號：</td>
          <td class="h3" align="left">
            <input id="InvoiceCUID" name="InvoiceCUID" type="text" size="20" value="<?php echo $InvoiceCUID;?>" />
          </td>
        </tr>
        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
          <td align="right" class="c3">發票抬頭：</td>
          <td class="h3" align="left">
            <input id="InvoiceTitle" name="InvoiceTitle" type="text" size="40" value="<?php echo $InvoiceTitle;?>" />
          </td>
        </tr>
        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
          <td align="right" class="c3">發票寄送地址：</td>
          <td class="h3" align="left">
            <input id="InvoiceAddress" name="InvoiceAddress" type="text" size="60" value="<?php echo $InvoiceAddress;?>" />
          </td>
        </tr>
        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
          <td align="right" class="c3">Lead-time：</td>
          <td class="h3" align="left">
            <input id="Leadtime" name="Leadtime" type="text" size="40" value="<?php echo $Leadtime;?>" />
          </td>
        </tr>
		<!--
        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
          <td align="right" class="c3">Trademark：</td>
          <td class="h3" align="left">
            <input id="Trademark" name="Trademark" type="text" size="40" value="<?php echo $Trademark;?>" />
          </td>
        </tr>
		-->
	      <?php
				$SQL_Manager="select MUID,MName,MEName from Manager where Deltag='N' and ISBusiness = 'Y' and IsLeft='N';";
				$result_Manager=mysqli_query($link,$SQL_Manager) or die ("無法執行查詢");
	      ?>
        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
          <td align="right" class="c3">承辦業務：</td>
          <td class="h3" align="left">
            <select id="BMUID" name="BMUID">
	        		<?php while(list($MUID,$MName,$MEName)=mysqli_fetch_row($result_Manager)){?>
	        		<option value="<?php echo $MUID;?>"<?php if (trim($MUID) == trim($BMUID)) echo " selected";?>><?php echo $MEName.$MName;?></option>
	        		<?php }?>
            </select>
          </td>
        </tr>
        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
          <td align="right" class="c3">是否含稅：</td>
          <td class="h3" align="left">
            <input id="PTax" name="PTax" type="radio" size="40" value="Y"<?php if (trim($PTax) == "Y") echo " checked";?> /> 是 
            <input id="PTax" name="PTax" type="radio" size="40" value="N"<?php if (trim($PTax) == "N") echo " checked";?> /> 否
          </td>
        </tr>
        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
          <td align="right" class="c3">已報價：</td>
          <td class="h3" align="left">
            <table width="100%" border="0" cellpadding="0" cellspacing="2">
            	<tr>
            		<td width="10"><input id="CheckQuotation" name="CheckQuotation" type="checkbox" size="40" value="Y"<?php if (trim($QuoteDate) != "") echo " checked disabled";?> /></td>
            		<td class="h3"> <font color=blue>確認報價後，此案件將</font><font color=red>無法</font><font color=blue>新增收入項目，<br>案件狀況將會自動改為[報價中]</font></td>
            	</tr>
            </table>
          </td>
        </tr>
        <?php
		$PStatused="";
        if (trim($PStatus) == "C" || trim($PStatus) == "D" || trim($PStatus) == "E" || trim($PStatus) == "F" || trim($PStatus) == "G" || trim($PStatus) == "H") $PStatused="True";
        ?>
        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
          <td align="right" class="c3">確認客戶簽回：</td>
          <td class="h3" align="left">
            <table width="100%" border="0" cellpadding="0" cellspacing="2">
            	<tr>
            		<td width="10"><input id="CheckQuotation2" name="CheckQuotation2" type="checkbox" size="40" value="Y"<?php if (trim($PStatused) == "True") echo " checked disabled";?> /></td>
            		<td class="h3"> <font color=blue>確認報價後，此案件將</font><font color=red>無法</font><font color=blue>新增收入項目，<br>案件狀況將會自動改為[案件處理中]</font></td>
            	</tr>
            </table>
          </td>
        </tr>
		<tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
          <td align="right" class="c3">公司：</td>
          <td class="h3" align="left">
            <input id="Company" name="Company" type="radio" value="RPC" checked /> 全威 
            <!--<input id="Company" name="Company" type="radio" value="RPC2" disabled/> 瑞寶
			 <input id="Company" name="Company" type="radio" value="OBU" disabled/> OBU-->
          </td>
        </tr>
        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
          <td align="right" class="c3">報價單版本：</td>
          <td class="h3" align="left">
            <input id="QVersion" name="QVersion" type="radio" value="Cht" checked /> 中文版 
            <input id="QVersion" name="QVersion" type="radio" value="Eng" /> 英文版
          </td>
        </tr>
        
        <tr height="40" align="center" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
          <td colspan="2" class="h3"><input type="submit" name="submit" class="input_bot" value="送 出"></td>
        </tr>
	      </form>
      </table>
		</td>
	</tr>
</table>
</center>
</body>
</html>
<?php
mysqli_close($link);
?>