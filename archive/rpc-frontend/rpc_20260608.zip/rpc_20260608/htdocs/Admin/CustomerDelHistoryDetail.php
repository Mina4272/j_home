<?php	
include "CheckPermission.php";
include "CheckCustomer.php";
include "../global.php";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $PageAdminTitle;?></title>
<link href="../type.css" rel="stylesheet" type="text/css" />
<style type="text/css">
<!--
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
}
-->
</style>
<Script type="text/javascript" language="javascript" src="../script/rpc.js"></Script>
<Script type="text/javascript" language="javascript" src="../script/CheckForm.js"></Script>
</head>
<body>
<?php
$CID = $_GET['CID'];
$page = $_GET['page'];
if (trim($CID) == "")
		{
		mysqli_close($link);
		?>
		<script type="text/JavaScript">
			<!--
			alert ("查無資料，請冾網站管理人員！");
			history.go(-1);
			//-->
		</script>
		<?php
		exit;
		}
$SQL_Customer="select CUID,CPWD,CName,EName,TrademarkTxt,TrademarkImg,CTel,CFax,Contact,CMobile,CEMail,CAddress,CNote,CType,CLevel,CRecord,BSMI,AddUser,AddDate,ProcUser,ProcDate,Principal,TAddress,LAddress,GUI from Customer where Deltag='Y' and CID = '".$CID."';";
$result_Customer=mysqli_query($link,$SQL_Customer) or die ("無法執行查詢");
if (mysqli_num_rows($result_Customer) == 0)
		{
		mysqli_free_result($result_Customer);
		mysqli_close($link);
		?>
		<SCRIPT language=javascript>
		<!--
		alert ("查無資料，請冾網站管理人員！"); 
		history.go(-1);
		//-->
		</SCRIPT>
		<?php 	
		exit;
		}
list($CUID,$CPWD,$CName,$EName,$TrademarkTxt,$TrademarkImg,$CTel,$CFax,$Contact,$CMobile,$CEMail,$CAddress,$CNote,$CType,$CLevel,$CRecord,$BSMI,$AddUser,$AddDate,$ProcUser,$ProcDate,$Principal,$TAddress,$LAddress,$GUI)=mysqli_fetch_row($result_Customer);
mysqli_free_result($result_Customer);

?>
    	<table width="100%" border="0" cellpadding="0" cellspacing="0">
    		<tr>
    			<td>
			    	<table width="750" border="0" cellpadding="0" cellspacing="0">
			    		<tr height="30">
			    			<td class="c2"><b>修改客戶資料</b></td>
			    		</tr>
			    	</table>
			    	<table width="750" border="0" cellpadding="0" cellspacing="0">
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">統一編號：</td>
			          <td class="h3"><?php echo $CUID;?>
			          	<input type="hidden" name="CID" value="<?php echo $CID;?>">
			          	<input type="hidden" name="page" value="<?php echo $page;?>">
			          </td>
			        </tr>
			        <!--
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">密 碼：</td>
			          <td class="h3"><input type="password" name="CPWD" size="20" value="<?php echo $CPWD;?>"></td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">密碼確認：</td>
			          <td class="h3"><input type="password" name="CPWDCheck" size="20" value="<?php echo $CPWD;?>"></td>
			        </tr>
			        -->
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">客戶種類：</td>
			          <td class="h3">
			          	<?php if (trim(strstr($CType,'N')) != "") echo "一般客戶";?>
			          	<?php if (trim(strstr($CType,'P')) != "") echo "供應商";?>
			          </td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">客戶等級：</td>
			          <td class="h3">
			          	<?php 
			          	if (trim($CLevel) == "A") echo "<img src='../images/A1.gif' border='0'> 好(文件齊全，態度好)";
			          	else if (trim($CLevel) == "B") echo "<img src='../images/B1.gif' border='0'> 中(普普)";
			          	else if (trim($CLevel) == "C") echo "<img src='../images/C1.gif' border='0'> 差(文件不齊全，態度不好)";
			          	?>
			          </td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">付款記錄：</td>
			          <td class="h3">
			          	<?php 
			          	if (trim($CRecord) == "A") echo "<img src='../images/A2.gif' border='0'> 優良(結案後月結60天)";
			          	else if (trim($CRecord) == "B") echo "<img src='../images/B2.gif' border='0'> 尚可(結案後月結)";
			          	else if (trim($CRecord) == "C") echo "<img src='../images/C2.gif' border='0'> 不好(付款領證)";
			          	?>
			          </td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">公司名稱：</td>
			          <td class="h3"><?php echo $CName;?></td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">公司英文名稱：</td>
			          <td class="h3"><?php echo $EName;?></td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">BSMI識別號碼：</td>
			          <td class="h3"><?php echo $BSMI;?></td>
			        </tr>
			        <tr height="60" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">商 標：</td>
			          <td class="h3">
	              	<table width="100%" border="0" cellpadding="0" cellspacing="0">
	              		<tr class="h3">
	              			<td width="40" align="center">圖片</td>
	              			<td align="center"><div id="TrademarkImgPreview" style="display:none"></div></td>
	              			<td align="center" valign="bottom"><div id="TrademarkImgDel" style="display:none"></div></td>
	              			<td>
				              	<input name="TrademarkImg" type="hidden" id="TrademarkImg" value="<?php echo $TrademarkImg;?>" />
				              	<!--<input name="TrademarkImgUpload" type="button" class="input_bot" value="上傳" onclick="MM_openBrWindow('TrademarkImgUpload.php','_TrademarkImgUpload','scrollbars=no,resizable=no,width=450,height=180,top=200,left=200');" /> 
				              	<font color="blue">*上傳圖片限 gif 或 jpg 格式</font>-->
	              			</td>
	              		</tr>
	              		<tr>
	              			<td width="40" align="center" class="h3">文字</td>
	              			<td colspan="3"><?php echo $TrademarkTxt;?></td>
	              		</tr>
	              	</table>
			          </td>
			        </tr>
							<?php
							if (trim($TrademarkImg) != "") {
									?>
									<SCRIPT language=javascript>
									<!--
											document.getElementById('TrademarkImgPreview').style.display = '';
											document.getElementById('TrademarkImgPreview').innerHTML = '<a href="getfile.php?FolderName=Admin\\TrademarkImg&FileName=<?php echo $TrademarkImg;?>"><img src="TrademarkImg/s<?php echo $TrademarkImg;?>" border="0"></a>';
											document.getElementById('TrademarkImgDel').style.display = '';
											//document.getElementById('TrademarkImgDel').innerHTML = '<a href="javascript:;" onclick="javascript:DelTrademarkImg();">刪除</a>';
									//-->
									</SCRIPT>
									<?php
									}
							?>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">負責人：</td>
			          <td class="h3"><?php echo $Principal;?></td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">公司電話：</td>
			          <td class="h3"><?php echo $CTel;?></td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">公司傳真：</td>
			          <td class="h3"><?php echo $CFax;?></td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">發票地址：</td>
			          <td class="h3"><?php echo $CAddress;?></td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">營登地址：</td>
			          <td class="h3"><?php echo $TAddress;?></td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">聯絡地址：</td>
			          <td class="h3"><?php echo $LAddress;?></td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">發票用統一編號：</td>
			          <td class="h3"><?php echo $GUI;?></td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">備 註：</td>
			          <td class="h3"><?php echo $CNote;?></td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">新增人員：</td>
			          <td class="h3"><?php echo $AddUser;?>　<?php echo $AddDate;?></td>
			        </tr>
			        <?php if (trim($ProcUser) != "") {?>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">最後更新：</td>
			          <td class="h3"><?php echo $ProcUser;?>　<?php echo $ProcDate;?> 
			          </td>
			        </tr>
			        <?php }?>
			        <!--
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td class="c3">備註：</td>
			          <td class="h3"></td>
			        </tr>
			        <tr height="40" align="center">
			          <td colspan="2" class="h3">
			          	<IFRAME marginWidth="0" marginHeight="0" src="CustomerNote.php?CID=<?php echo $CID;?>" frameBorder="1" width="100%" scrolling="yes" height=250></IFRAME> 
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td class="c3">聯絡人：</td>
			          <td class="h3"></td>
			        </tr>
			        <tr height="40" align="center">
			          <td colspan="2" class="h3">
			          	<IFRAME marginWidth="0" marginHeight="0" src="CustomerContact.php?CID=<?php echo $CID;?>" frameBorder="1" width="100%" scrolling="yes" height=250></IFRAME> 
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td class="c3">相關檔案：</td>
			          <td class="h3"></td>
			        </tr>
			        <tr height="40" align="center">
			          <td colspan="2" class="h3">
			          	<IFRAME marginWidth="0" marginHeight="0" src="CustomerFile.php?CID=<?php echo $CID;?>" frameBorder="1" width="100%" scrolling="yes" height=250></IFRAME> 
			        </tr>
			        -->
			        <tr height="40" align="center">
			          <td colspan="2" class="h3"><input type="button" name="button" class="input_bot" value="回列表" onclick="javascript:location.href='CustomerDelHistory.php?page=<?php echo $page;?>';"></td>
			        </tr>
			      </table>
    			</td>
    		</tr>
    	</table>
</body>
</html>
<?php
mysqli_close($link);
?>