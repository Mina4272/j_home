﻿<?php
include "CheckPermission.php";
include "CheckProjectAccounting.php";
include "../global.php";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $PageAdminTitle;?></title>
</head>
<body>
<?php
$PID = $_POST['PID'];
$spage = $_POST['spage'];
$KeyWord = $_POST['KeyWord'];
$QPStatus = $_POST['QPStatus'];
$QAcc = $_POST['QAcc'];

$PANo_I = $_POST['PANo_I'];
$PAItem_I = $_POST['PAItem_I'];
$Charges_I = $_POST['Charges_I'];
$ChargesOther_I = $_POST['ChargesOther_I'];
$Rate_I = $_POST['Rate_I'];
if (trim($Rate_I) == "") $Rate_I = "0";
if (trim($Rate_I) == "0") $ChargesOther_I = "0";
$PANote_I = $_POST['PANote_I'];
$PANote_I = str_replace("\r\n","<br>",$PANote_I);
$PAPYear_I = $_POST['PAPYear_I'];
$PAPMonth_I = $_POST['PAPMonth_I'];
$PAPDay_I = $_POST['PAPDay_I'];
if (trim($PAPYear_I) != "" || trim($PAPMonth_I) != "" || trim($PAPDay_I) != "") if (checkdate($PAPMonth_I,$PAPDay_I ,$PAPYear_I)) $PAPDate_I = $PAPYear_I."-".$PAPMonth_I."-".$PAPDay_I;

$InvoiceYear_I = $_POST['InvoiceYear_I'];
$InvoiceMonth_I = $_POST['InvoiceMonth_I'];
$InvoiceDay_I = $_POST['InvoiceDay_I'];
if (trim($InvoiceYear_I) != "" && trim($InvoiceMonth_I) != "" && trim($InvoiceDay_I) != "") if (checkdate($InvoiceMonth_I,$InvoiceDay_I,$InvoiceYear_I)) $InvoiceDate_I = $InvoiceYear_I."-".$InvoiceMonth_I."-".$InvoiceDay_I;
$Invoice_I = $_POST['Invoice_I'];
$PATax_I = $_POST['PATax_I'];

$PANo_O = $_POST['PANo_O'];
$PAItem_O = $_POST['PAItem_O'];
$Charges_O = $_POST['Charges_O'];
$ChargesOther_O = $_POST['ChargesOther_O'];
$Rate_O = $_POST['Rate_O'];
if (trim($Rate_O) == "") $Rate_O = "0";
if (trim($Rate_O) == "0") $ChargesOther_O = "0";
$PANote_O = $_POST['PANote_O'];
$PANote_O = str_replace("\r\n","<br>",$PANote_O);
$PAPYear_O = $_POST['PAPYear_O'];
$PAPMonth_O = $_POST['PAPMonth_O'];
$PAPDay_O = $_POST['PAPDay_O'];
if (trim($PAPYear_O) != "" || trim($PAPMonth_O) != "" || trim($PAPDay_O) != "") if (checkdate($PAPMonth_O,$PAPDay_O ,$PAPYear_O)) $PAPDate_O = $PAPYear_O."-".$PAPMonth_O."-".$PAPDay_O;

$InvoiceYear_O = $_POST['InvoiceYear_O'];
$InvoiceMonth_O = $_POST['InvoiceMonth_O'];
$InvoiceDay_O = $_POST['InvoiceDay_O'];
if (trim($InvoiceYear_O) != "" && trim($InvoiceMonth_O) != "" && trim($InvoiceDay_O) != "") if (checkdate($InvoiceMonth_O,$InvoiceDay_O,$InvoiceYear_O)) $InvoiceDate_O = $InvoiceYear_O."-".$InvoiceMonth_O."-".$InvoiceDay_O;
$Invoice_I = $_POST['Invoice_I'];

$CID = $_POST['CID'];
$CName = $_POST['CName'];
$CTel = $_POST['CTel'];
$CFax = $_POST['CFax'];
$CAddress = $_POST['CAddress'];
$PATax_O = $_POST['PATax_O'];

if (trim($PID) == "")
		{
		mysqli_close($link);
		?>
		<script type="text/JavaScript">
			<!--
			alert ("您輸入的資料不足，請重新輸入！");
			history.go(-1);
			//-->
		</script>
		<?php
		exit;
		}

$SQL_Project="select PUID,PName from Project where Deltag='N' and PID = '".$PID."';";
$result_Project=mysqli_query($link,$SQL_Project) or die ("無法執行查詢");
if (mysqli_num_rows($result_Project) == 0)
		{
		mysqli_free_result($result_Project);
		mysqli_close($link);
		?>
		<SCRIPT language=javascript>
		<!--
		alert ("查無資料，請冾網站管理人員！"); 
		history.go(-1);
		//-->
		</SCRIPT>
		<?php 	
		exit;
		}
mysqli_free_result($result_Project);

$now_time = date("Y-m-d H:i:s",mktime());
if (trim($CID) == "") $CID = 0;

if (trim($InvoiceDate_I)=="") $InvoiceDate_I = "NULL";
else $InvoiceDate_I = "'$InvoiceDate_I'";
if (trim($InvoiceDate_O)=="") $InvoiceDate_O = "NULL";
else $InvoiceDate_O = "'$InvoiceDate_O'";

if (trim($PAPDate_I)=="") $PAPDate_I = "NULL";
else $PAPDate_I = "'$PAPDate_I'";
if (trim($PAPDate_O)=="") $PAPDate_O = "NULL";
else $PAPDate_O = "'$PAPDate_O'";

if (trim($PAItem_I) != "" && trim($Charges_I) != "") {
		$sql_insert = "insert into ProjectAccounting (PID,PANo,PAMode,PAItem,Charges,Rate,ChargesOther,PATax,PAPDate,InvoiceDate,Invoice,PANote,AddUser,AddDate,AddIP) values ('".$PID."','".$PANo_I."','I','".addslashes($PAItem_I)."','".$Charges_I."','".$Rate_I."','".$ChargesOther_I."','".$PATax_I."',".$PAPDate_I.",".$InvoiceDate_I.",'".$Invoice_I."','".$PANote_I."','".$_SESSION["reg_MUID"]."','".$now_time."','".$_SERVER["REMOTE_ADDR"]."');";
		$result_insert=mysqli_query($link,$sql_insert) or die ("無法執行新增");
		}

if (trim($PAItem_O) != "" && trim($Charges_O) != "") {
		$sql_insert = "insert into ProjectAccounting (PID,PANo,PAMode,PAItem,Charges,Rate,ChargesOther,PATax,PAPDate,InvoiceDate,Invoice,PANote,CID,CName,CTel,CFax,CAddress,AddUser,AddDate,AddIP) values ('".$PID."','".$PANo_O."','O','".addslashes($PAItem_O)."','".$Charges_O."','".$Rate_O."','".$ChargesOther_O."','".$PATax_O."',".$PAPDate_O.",".$InvoiceDate_O.",'".$Invoice_O."','".$PANote_O."','".$CID."','".$CName."','".$CTel."','".$CFax."','".$CAddress."','".$_SESSION["reg_MUID"]."','".$now_time."','".$_SERVER["REMOTE_ADDR"]."');";
		$result_insert=mysqli_query($link,$sql_insert) or die ("無法執行新增");
		}


mysqli_close($link);
?>
<script type="text/JavaScript">
	<!--
	alert ("新增成功！");
	location.href='ProjectAccountingList.php?PID=<?php echo $PID;?>&page=<?php echo $spage;?>&QPStatus=<?php echo $QPStatus;?>&QAcc=<?php echo $QAcc;?>&KeyWord=<?php echo urlencode($KeyWord);?>';
	//-->
</script>

</body>
</html>
