<?php	
include "CheckPermission.php";
//include "CheckAgendum.php";
include "../global.php";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $PageAdminTitle;?></title>
<link href="../type.css" rel="stylesheet" type="text/css" />
<style type="text/css">
<!--
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
}
-->
</style>
<link href="../script/DatePicker.css" rel="stylesheet" type="text/css" />
<Script LANGUAGE="Javascript" SRC="../script/DatePicker.js"></Script>
<Script type="text/javascript" language="javascript" src="../script/CheckForm.js"></Script>
<script type="text/JavaScript">
<!--
function jsCheck() 
		{
		if (ChkDate('DMYear',document.form1.DMYear.value,document.form1.DMMonth.value,document.form1.DMDay.value,'保養日期') == false) return false;
		}
//-->
</script>
</head>
<body>
<?php
$device_no = $_GET['device_no'];
if (trim($device_no) == "")
		{
		mysqli_close($link);
		?>
		<script type="text/JavaScript">
			<!--
			alert ("查無資料，請冾網站管理人員！");
			self.close();
			//-->
		</script>
		<?php
		exit;
		}
?>
<table width="100%" border="0" cellpadding="0" cellspacing="0">
	<tr>
		<td>
    	<table width="100%" border="0" cellpadding="0" cellspacing="0">
    		<tr height="30">
					<td width="15" background="../images/table_bg.gif"></td>
    			<td class="c3" background="../images/table_bg.gif"><b>新增儀器保養紀錄</b></td>
    		</tr>
    	</table>
    	<table width="100%" border="0" cellpadding="0" cellspacing="0">
        <form name="form1" method="post" action="DeviceMaintenanceAddDB.php" onSubmit="return jsCheck();">
		<tr  onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td width="70" class="c3">保養<br/>日期:</td>
			          <td class="h3">
		              <input id="DMYear" name="DMYear" type="text" size="4" /> 年 
		              <input id="DMMonth" name="DMMonth" type="text" size="2" /> 月 
		              <input id="DMDay" name="DMDay" type="text" size="2" /> 日 
		              <img src="../images/icon.gif" width="16" height="18" style="cursor: hand" onclick="javascript:displayDatePicker('DMYear','DMMonth','DMDay');"/>
			          </td>
			        </tr>
		<tr  onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
	      <td width="auto" class="c3">清潔<br/>保養:</td>
		  <td class="h3">
			<input type="radio" id="DM_clean" name="DM_clean" value="Y" checked>完成
			<input type="radio" id="DM_clean" name="DM_clean" value="N">停用
		  </td>
        </tr>
		<tr  onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
	      <td width="auto" class="c3">儀器<br/>功能:</td>
		  <td class="h3">
			<input type="radio" id="DM_function" name="DM_function" value="Y" checked>正常
			<input type="radio" id="DM_function" name="DM_function" value="N">異常
		  </td>
        </tr>
        <tr height="40" align="center">
			<td width="15"><input name="device_no" type="hidden" id="device_no" value="<?php echo $device_no;?>" /></td>
          <td class="h3"><input type="submit" name="submit" class="input_bot" value="送 出"></td>
        </tr>
	      </form>
      </table>
		</td>
	</tr>
</table>
</body>
</html>
<?php
mysqli_close($link);
?>