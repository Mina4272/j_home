<?php
include "CheckPermission.php";
//include "CheckAgendum.php";
include "../global.php";
include "include/page_function.php";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $PageAdminTitle;?></title>
<link href="../type.css" rel="stylesheet" type="text/css" />
<style type="text/css">
<!--
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
}
-->
</style></head>

<body>
<?php
$device_no = $_POST['device_no'];
$DP_people = $_POST['DP_people'];
$DP_place = $_POST['DP_place'];
$DSYear = $_POST['DSYear'];
$DSMonth = $_POST['DSMonth'];
$DSDay = $_POST['DSDay'];
if (trim($DSYear) != "" || trim($DSMonth) != "" || trim($DSDay) != "") if (checkdate($DSMonth,$DSDay ,$DSYear)) $DP_send_date = $DSYear."-".$DSMonth."-".$DSDay;
$DTYear = $_POST['DTYear'];
$DTMonth = $_POST['DTMonth'];
$DTDay = $_POST['DTDay'];
if (trim($DTYear) != "" || trim($DTMonth) != "" || trim($DTDay) != "") if (checkdate($DTMonth,$DTDay ,$DTYear)) $DP_take_date = $DTYear."-".$DTMonth."-".$DTDay;
$DP_status = $_POST['DP_status'];

if (trim($DP_people) == "" || trim($DP_place) == "" || trim($DP_send_date) == "" || trim($DP_take_date) == "" || trim($DP_status) == "" )
{
	mysqli_close($link);
		
?>
<script type="text/JavaScript">
<!--
	alert ("您輸入的資料不足，請重新輸入！");
	history.go(-1);
	//-->
</script>
<?php
	exit;
}


$sql_insert = "insert into devicepass (D_no,DP_people,DP_place,DP_send_date,DP_take_date,DP_status) values ('".$device_no."','".$DP_people."','".$DP_place."','".$DP_send_date."','".$DP_take_date."','".$DP_status."');";
//echo $sql_insert;
$result_insert=mysqli_query($link,$sql_insert) or die ("無法執行新增");
mysqli_close($link);
	
?>
<script type="text/JavaScript">
	
	alert("新增成功！");
	opener.location.reload();
	self.close();
	
</script>
</body>
</html>
<?php
mysqli_close($link);
?>