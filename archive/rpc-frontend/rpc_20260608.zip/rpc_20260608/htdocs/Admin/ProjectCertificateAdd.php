﻿<?php	
include "CheckPermission.php";
include "CheckProject.php";
include "../global.php";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $PageAdminTitle;?></title>
<link href="../type.css" rel="stylesheet" type="text/css" />
<style type="text/css">
<!--
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
}
-->
</style>
<link href="../script/DatePicker.css" rel="stylesheet" type="text/css" />
<Script LANGUAGE="Javascript" SRC="../script/DatePicker.js"></Script>
<Script type="text/javascript" language="javascript" src="../script/CheckForm.js"></Script>
<script type="text/JavaScript">
<!--
function jsCheck() 
		{
		if (ChkImp('PCNo',document.form1.PCNo.value,'証書編號') == false) return false;
		if (ChkImp('PCName',document.form1.PCName.value,'証書名稱') == false) return false;
		if (document.form1.PCType.value == "D") if (ChkImp('PCTypeName',document.form1.PCTypeName.value,'其他種類名稱') == false) return false;
		if (ChkImp('PCFile',document.form1.PCFile.value,'証書檔案') == false) return false;
		if (jsTrim(document.form1.PCSYear.value) != "" || jsTrim(document.form1.PCSMonth.value) != "" || jsTrim(document.form1.PCSDay.value) != "") if (ChkDate('PCSYear',document.form1.PCSYear.value,document.form1.PCSMonth.value,document.form1.PCSDay.value,'証書有效起始日期') == false) return false;
		if (jsTrim(document.form1.PCEYear.value) != "" || jsTrim(document.form1.PCEMonth.value) != "" || jsTrim(document.form1.PCEDay.value) != "") if (ChkDate('PCEYear',document.form1.PCEYear.value,document.form1.PCEMonth.value,document.form1.PCEDay.value,'証書有效結束日期') == false) return false;
		//if (jsTrim(document.form1.PCSYear.value) != "" || jsTrim(document.form1.PCSMonth.value) != "" || jsTrim(document.form1.PCSDay.value) != "" || jsTrim(document.form1.PCEYear.value) != "" || jsTrim(document.form1.PCEMonth.value) != "" || jsTrim(document.form1.PCEDay.value) != "") {
		//		if (jsTrim(document.form1.PCSYear.value) == "" || jsTrim(document.form1.PCSMonth.value) == "" || jsTrim(document.form1.PCSDay.value) == "" || jsTrim(document.form1.PCEYear.value) == "" || jsTrim(document.form1.PCEMonth.value) == "" || jsTrim(document.form1.PCEDay.value) == "") {
		//				alert("請輸入完整的有效日期！");
		//				return false;
		//				}
		//		}
		if (jsTrim(document.form1.PCSYear.value) != "" && jsTrim(document.form1.PCSMonth.value) != "" && jsTrim(document.form1.PCSDay.value) != "" && jsTrim(document.form1.PCEYear.value) != "" && jsTrim(document.form1.PCEMonth.value) != "" && jsTrim(document.form1.PCEDay.value) != "") if (CompareDate('PCSYear',document.form1.PCSYear.value,document.form1.PCSMonth.value,document.form1.PCSDay.value,document.form1.PCEYear.value,document.form1.PCEMonth.value,document.form1.PCEDay.value,'啟始日期','結束日期') == false) return false;
		}
//-->
</script>
</head>
<body>
<?php
$PID = $_GET['PID'];
if (trim($PID) == "")
		{
		mysqli_close($link);
		?>
		<script type="text/JavaScript">
			<!--
			alert ("查無資料，請冾網站管理人員！");
			self.close();
			//-->
		</script>
		<?php
		exit;
		}
?>
<table width="100%" border="0" cellpadding="0" cellspacing="0">
	<tr>
		<td>
    	<table width="100%" border="0" cellpadding="0" cellspacing="0">
    		<tr height="30">
					<td width="15" background="../images/table_bg.gif"></td>
    			<td class="c3" background="../images/table_bg.gif"><b>新增案件証書資料</b></td>
    		</tr>
    	</table>
    	<table width="100%" border="0" cellpadding="0" cellspacing="0">
        <form name="form1" method="post" action="ProjectCertificateAddDB.php" enctype="multipart/form-data" onSubmit="return jsCheck();">
        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
					<td width="5"></td>
          <td width="160" class="c3" align="right">証書編號：</td>
          <td class="c3">
          	<input id="PCNo" name="PCNo" type="text" size="20" />
          </td>
        </tr>
        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
					<td width="15"></td>
          <td class="c3" align="right">証書名稱：</td>
          <td class="c3">
          	<input id="PCName" name="PCName" type="text" size="20" />
          </td>
        </tr>
        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
					<td width="15"></td>
          <td class="c3" align="right">証書種類：</td>
          <td class="c3">
          	<select id="PCType" name="PCType">
				<option value="B">BSMI證書</option>
          		<option value="A">環保標章</option>
          		<option value="C">消防證書</option>
				<option value="E">NCC</option>
				<option value="F">BSMI DOC</option>
          		<option value="D">其他</option>
          	</select> 其他種類名稱：<input type="text" name="PCTypeName" size="10">
          </td>
        </tr>
        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
					<td width="15"></td>
          <td class="c3" align="right">証書檔案：</td>
          <td class="c3">
          	<input  type="file" name="PCFile" size="60" />
          </td>
        </tr>
        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
					<td width="15"></td>
          <td class="c3" align="right">有效日期：</td>
          <td class="h3">
            <input id="PCSYear" name="PCSYear" type="text" size="4" />年
            <input id="PCSMonth" name="PCSMonth" type="text" size="2" />月
            <input id="PCSDay" name="PCSDay" type="text" size="2" />日
            <img src="../images/icon.gif" width="16" height="18" style="cursor: hand" onclick="javascript:displayDatePicker('PCSYear','PCSMonth','PCSDay');"/>～
            <input id="PCEYear" name="PCEYear" type="text" size="4" />年
            <input id="PCEMonth" name="PCEMonth" type="text" size="2" />月
            <input id="PCEDay" name="PCEDay" type="text" size="2" />日
            <img src="../images/icon.gif" width="16" height="18" style="cursor: hand" onclick="javascript:displayDatePicker('PCEYear','PCEMonth','PCEDay');"/>
          </td>
        </tr>
        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
					<td width="15"></td>
          <td class="c3" align="right">備註：</td>
          <td class="h3">
            <input id="PCNote" name="PCNote" type="text" size="40" />
          </td>
        </tr>
        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
					<td width="15"></td>
          <td class="c3" align="right">延長證書提醒時間：</td>
          <td class="h3">
            <select id="ExpireMonth" name="ExpireMonth">
            	<option value=""></option>
            	<option value="01">01</option>
            	<option value="02">02</option>
            	<option value="03">03</option>
            	<option value="04">04</option>
            	<option value="05">05</option>
            	<option value="06">06</option>
            	<option value="07">07</option>
            	<option value="08">08</option>
            	<option value="09">09</option>
            	<option value="10">10</option>
            	<option value="11">11</option>
            	<option value="12">12</option>
            </select> 月
          </td>
        </tr>
        <tr height="40" align="center">
					<td width="15"></td>
          <td colspan="2" class="h3">
          	<input type="submit" name="submit" class="input_bot" value="送 出">
          	<input name="PID" type="hidden" id="PID" value="<?php echo $PID;?>" />
          </td>
        </tr>
	      </form>
      </table>
		</td>
	</tr>
</table>
</body>
</html>
<?php
mysqli_close($link);
?>