﻿<?php	
include "CheckPermission.php";
include "CheckProject.php";
include "../global.php";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $PageAdminTitle;?></title>
<link href="../type.css" rel="stylesheet" type="text/css" />
<style type="text/css">
<!--
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
}
-->
</style>
<Script type="text/javascript" language="javascript" src="../script/rpc.js"></Script>
<Script type="text/javascript" language="javascript" src="../script/CheckForm.js"></Script>
</head>
<body>
<?php
$PHID = $_GET['PHID'];
$PID = $_GET['PID'];
$page = $_GET['page'];
if (trim($PID) == "" || trim($PHID) == "")
		{
		mysqli_close($link);
		?>
		<script type="text/JavaScript">
			<!--
			alert ("查無資料，請冾網站管理人員！");
			history.go(-1);
			//-->
		</script>
		<?php
		exit;
		}
$SQL_Project="select PUID from Project where Deltag='N' and PID = '".$PID."';";
$result_Project=mysqli_query($link,$SQL_Project) or die ("無法執行查詢");
if (mysqli_num_rows($result_Project) == 0)
		{
		mysqli_free_result($result_Project);
		mysqli_close($link);
		?>
		<SCRIPT language=javascript>
		<!--
		alert ("查無資料，請冾網站管理人員！"); 
		history.go(-1);
		//-->
		</SCRIPT>
		<?php 	
		exit;
		}
mysqli_free_result($result_Project);

$SQL_Project="select PHID,PUID,CID,CName,CTel,CFax,CAddress,Contact,CMobile,CEMail,PStatus,PName,ModelName,SeriesModel,PE,Quote,ApplyItem,Canon,CCCCode,SNote,StartDate,date_format(StartDate,'%Y'),date_format(StartDate,'%m'),date_format(StartDate,'%d'),PlanDate,date_format(PlanDate,'%Y'),date_format(PlanDate,'%m'),date_format(PlanDate,'%d'),CloseDate,date_format(CloseDate,'%Y'),date_format(CloseDate,'%m'),date_format(CloseDate,'%d'),PNote,PNoteDate,EMC,POther,PADate,date_format(PADate,'%Y'),date_format(PADate,'%m'),date_format(PADate,'%d'),PNote1,QuoteDate,ReturnDate,AddUser,AddDate,ProcUser,ProcDate from ProjectHistory where Deltag='N' and PHID = '".$PHID."';";
$result_Project=mysqli_query($link,$SQL_Project) or die ("無法執行查詢");
if (mysqli_num_rows($result_Project) == 0)
		{
		mysqli_free_result($result_Project);
		mysqli_close($link);
		?>
		<SCRIPT language=javascript>
		<!--
		alert ("查無資料，請冾網站管理人員！"); 
		history.go(-1);
		//-->
		</SCRIPT>
		<?php 	
		exit;
		}
list($PHID,$PUID,$CID,$CName,$CTel,$CFax,$CAddress,$Contact,$CMobile,$CEMail,$PStatus,$PName,$ModelName,$SeriesModel,$PE,$Quote,$ApplyItem,$Canon,$CCCCode,$SNote,$StartDate,$StartYear,$StartMonth,$StartDay,$PlanDate,$PlanYear,$PlanMonth,$PlanDay,$CloseDate,$CloseYear,$CloseMonth,$CloseDay,$PNote,$PNoteDate,$EMC,$POther,$PADate,$PAYear,$PAMonth,$PADay,$PNote1,$QuoteDate,$ReturnDate,$AddUser,$AddDate,$ProcUser,$ProcDate)=mysqli_fetch_row($result_Project);
mysqli_free_result($result_Project);

?>
    	<table width="100%" border="0" cellpadding="0" cellspacing="0">
    		<tr>
    			<td>
			    	<table width="750" border="0" cellpadding="0" cellspacing="0">
			    		<tr height="30">
			    			<td class="c2" background="../images/table_bg.gif">管理案件歷史資料</td>
			    		</tr>
			    	</table>
			    	<table width="750" border="0" cellpadding="0" cellspacing="0">
			        <form name="form1" method="post" action="ProjectEditDB.php" onSubmit="return jsCheck();">
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td width="230" align="right" class="c3">案件編號：</td>
			          <td class="h3"><font color=blue><?php echo $PUID;?></font>
			         	</td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">客戶名稱：</td>
			          <td class="h3">
			          	<table width="100%" border="0" cellpadding="0" cellspacing="0">
			          		<tr>
			          			<td><div id="CNamePreview" style="display:"><?php echo $CName;?></div></td>
			          			<td>
						          	<input type="hidden" name="CID" value="<?php echo $CID;?>">
						          	<input type="hidden" name="CName" value="<?php echo $CName;?>">
			          			</td>
			          		</tr>
			          	</table>
			          	
			          </td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">客戶電話：</td>
			          <td class="h3">
			          	<table width="100%" border="0" cellpadding="0" cellspacing="0">
			          		<tr>
			          			<td width="150">
			          				<div id="CTelPreview" style="display:"><?php echo $CTel;?></div>
						          	<input type="hidden" name="CTel" value="<?php echo $CTel;?>">
			          			</td>
			          			<td width="60" align="right" class="c3">傳真：</td>
			          			<td>
			          				<div id="CFaxPreview" style="display:"><?php echo $CFax;?></div>
			          				<input type="hidden" name="CFax" value="<?php echo $CFax;?>">
			          			</td>
			          		</tr>
			          	</table>
			          </td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">客戶地址：</td>
			          <td class="h3">
			          	<div id="CAddressPreview" style="display:"><?php echo $CAddress;?></div>
			          	<input type="hidden" name="CAddress" value="<?php echo $CAddress;?>">
			          </td>
			        </tr>
			        <tr height="60" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">連絡人：</td>
			          <td class="h3">
			          	<table width="100%" border="0" cellpadding="0" cellspacing="0">
			          		<tr height="30">
			          			<td width="70" align="right">姓名：</td>
			          			<td width="180"><?php echo $Contact;?></td>
			          			<td width="60" align="right">電話：</td>
			          			<td><?php echo $CMobile;?></td>
			          		</tr>
			          		<tr height="30">
			          			<td width="70" align="right">E-MAil：</td>
			          			<td colspan="3"><?php echo $CEMail;?></td>
			          		</tr>
			          	</table>
			          </td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">產品名稱：</td>
			          <td class="h3"><?php echo $PName;?></td>
			        </tr>
			        <?php if (trim($ModelName) == "") $ModelName = "NA";?>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">型號：</td>
			          <td class="h3"><?php echo $ModelName;?></td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">系列型號：</td>
			          <td class="h3"><?php echo $SeriesModel;?></td>
			        </tr>
			        <?php
							$SQL_Manager="select MName,MEName from Manager where Deltag='N' and ISEngineer = 'Y' and MUID = '".$PE."';";
							$result_Manager=mysqli_query($link,$SQL_Manager) or die ("無法執行查詢");
							list($MName,$MEName)=mysqli_fetch_row($result_Manager);
							mysqli_free_result($result_Manager);
			        ?>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">案件工程師：</td>
			          <td class="h3"><?php echo $MEName.$MName;?></td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">申請項目：</td>
			          <td class="h3"><?php echo $ApplyItem;?></td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">規範：</td>
			          <td class="h3"><?php echo $Canon;?></td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">商品分類號列(C.C.C.Code)：</td>
			          <td class="h3"><?php echo $CCCCode;?></td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">案件開始日期：</td>
			          <td class="h3"><?php echo $StartDate;?></td>
			        </tr>
			        <?php
			        if (trim($PlanDate) == "0000-00-00") $PlanDate = "";
			        ?>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">預計完成時間：</td>
			          <td class="h3"><?php echo $PlanDate;?></td>
			        </tr>
			        <?php
			        if (trim($CloseDate) == "0000-00-00") $CloseDate = "";
			        ?>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">結案日期：</td>
			          <td class="h3"><?php echo $CloseDate;?></td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">案件狀態：</td>
			          <td class="h3">
		          		<?php
		          		if (trim($PStatus) == "A") echo "新開案";
		          		else if (trim($PStatus) == "B") echo "報價中";
		          		else if (trim($PStatus) == "C") echo "案件處理中";
		          		else if (trim($PStatus) == "D") echo "審查中";
		          		else if (trim($PStatus) == "E") echo "補件中";
		          		else if (trim($PStatus) == "F") echo "待印證";
		          		else if (trim($PStatus) == "G") echo "案件取消";
		          		else if (trim($PStatus) == "H") echo "已結案";
		          		?>
			          </td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">本案特別備註：</td>
			          <td class="h3"><?php echo $SNote;?></td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">Safety：</td>
			          <td class="h3"><?php echo $PNote;?></td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">Safety 申請日期：</td>
			          <td class="h3"><?php echo $PNoteDate;?></td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">EMC：</td>
			          <td class="h3"><?php echo $EMC;?></td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">EMC 申請日期：</td>
			          <td class="h3"><?php echo $PADate;?></td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">其他：</td>
			          <td class="h3"><?php echo $POther;?></td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">備 註：</td>
			          <td class="h3"><?php echo $PNote1;?></td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">新增人員：</td>
			          <td class="h3"><?php echo $AddUser;?>　<?php echo $AddDate;?></td>
			        </tr>
			        <?php if (trim($ProcUser) != "") {?>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">最後更新：</td>
			          <td class="h3"><?php echo $ProcUser;?>　<?php echo $ProcDate;?> 
			         	</td>
			        </tr>
			        <?php }?>
			        <tr height="40" align="center">
			          <td colspan="2" class="h3"><input type="button" name="button" class="input_bot" value="回列表" onclick="javascript:location.href='ProjectHistory.php?PID=<?php echo $PID;?>&page=<?php echo $page;?>';"></td>
			        </tr>
				      </form>
			      </table>
    			</td>
    		</tr>
    	</table>
</body>
</html>
<?php
mysqli_close($link);
?>