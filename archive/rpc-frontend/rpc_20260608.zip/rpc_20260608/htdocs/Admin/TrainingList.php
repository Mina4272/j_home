﻿<?php
include "CheckPermission.php";
include "../global.php";
include "include/page_function.php";
include "include/utf8.php";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $PageAdminTitle;?></title>
<link href="../type.css" rel="stylesheet" type="text/css" />
<script type="text/JavaScript">
<!--
function TrainingExport() 
		{
		document.form_exp.MID.value = document.form1.QMUID.value;
		document.form_exp.submit();
		}
//-->
</script>
<style type="text/css">
<!--
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
}
-->
</style></head>

<body>
<?php include "top.php";?>
<table width="100%" border="0" cellspacing="0" cellpadding="5">
	<tr>
    <td width="160" height="600" align="left" valign="top">
			<?php include "menu.php";?>
    </td>
		<?php
	$SqlTxt="";
	$Txt="";
	$tmp="0";
	$QSCADate = empty($_POST['QSCADate'])?"":$_POST['QSCADate'];
	if (trim($QSCADate) == "") $QSCADate = empty($_GET['QSCADate'])?"":$_GET['QSCADate'];
	$QECADate = empty($_POST['QECADate'])?"":$_POST['QECADate'];
	if (trim($QECADate) == "") $QECADate = empty($_GET['QECADate'])?"":$_GET['QECADate'];
	if (trim($QSCADate) == "") {
		$QSCAYear = empty($_POST['QSCAYear'])?"":$_POST['QSCAYear'];
		$QSCAMonth = empty($_POST['QSCAMonth'])?"":$_POST['QSCAMonth'];
		$QSCADay = empty($_POST['QSCADay'])?"":$_POST['QSCADay'];
		if (trim($QSCAYear) != "" || trim($QSCAMonth) != "") if (checkdate($QSCAMonth,$QSCADay ,$QSCAYear)) $QSCADate = $QSCAYear."-".$QSCAMonth;//."-".$QSCADay;
		}
	if (trim($QECADate) == "") {
		$QECAYear = empty($_POST['QECAYear'])?"":$_POST['QECAYear'];
		$QECAMonth = empty($_POST['QECAMonth'])?"":$_POST['QECAMonth'];
		$QECADay = empty($_POST['QECADay'])?"":$_POST['QECADay'];
		if (trim($QECAYear) != "" || trim($QECAMonth) != "") if (checkdate($QECAMonth,$QECADay ,$QECAYear)) $QECADate = $QECAYear."-".$QECAMonth;//."-".$QECADay;
		}
	if (trim($QSCADate) != "" && trim($QECADate) != "") $SqlTxt = $SqlTxt." and (SUBSTR(t.TDate,1,7) >= '".$QSCADate."') and (SUBSTR(t.TDate,1,7) <= '".$QECADate."') ";
else if (trim($QSCADate) != "" && trim($QECADate) == "") $SqlTxt = $SqlTxt." and (SUBSTR(t.TDate,1,7) >= '".$QSCADate."') ";
else if (trim($QSCADate) == "" && trim($QECADate) != "") $SqlTxt = $SqlTxt." and (SUBSTR(t.TDate,1,7)<= '".$QECADate."') ";
//echo $QECADate;
  	$KeyWord = empty($_POST['KeyWord'])?"":$_POST['KeyWord'];
  	if (trim($KeyWord) == "") $KeyWord = empty($_GET['KeyWord'])?"":$_GET['KeyWord'];
  	if (trim($KeyWord) != "") $SqlTxt = $SqlTxt." and (t.TTitle like '%".$KeyWord."%' or t.Lecturer like '%".$KeyWord."%' or t.TContent like '%".$KeyWord."%')";
	$main = empty($_POST['main'])?"":$_POST['main'];
  	if (trim($main) == "") $main = empty($_GET['main'])?"":$_GET['main'];
  	if (trim($main) != "") $SqlTxt = $SqlTxt." and (t.TCID = '".$main."')";
	$QMUID = empty($_POST['QMUID'])?"":$_POST['QMUID'];
	if (trim($QMUID) == "") $QMUID = empty($_GET['QMUID'])?"":$_GET['QMUID'];
	if (trim($QMUID) != "") $Txt = $Txt."and MID ='".$QMUID."'";
	$SQL="select TID from trainingexam where Deltag='N' ".$Txt." order by TEID";
	//echo $SQL;
	$result=mysqli_query($link,$SQL) or die ("無法執行查詢");
	while(list($TID)=mysqli_fetch_row($result)){
		if(empty($tmp)){
			$tmp = "'".$TID."'";
		}else{
			$tmp .= ",'".$TID."'";
		}
	}
	if (trim($QMUID) != "") $SqlTxt = $SqlTxt."and t.TID in (".$tmp.")";
	
		$page = empty($_GET['page'])?"":$_GET['page'];
		if (trim($page) == "") $page = 1;
		$page_rows=15;  //每頁筆數
		$php_Self = "TrainingList.php";  //分頁web檔名

		$button_css = "h4";
		$limit_txt =" limit ".(($page-1) * $page_rows).",".$page_rows;
		$url_str = "&main=".$main."&QMUID=".$QMUID."&QSCADate=".$QSCADate."&QECADate=".$QECADate."&KeyWord=".urlencode($KeyWord);
		?>
    <td valign="top">
    	<table width="100%" border="0" cellpadding="0" cellspacing="0">
    		<tr>
    			<td>
			    	<table width="1000" border="0" cellpadding="0" cellspacing="0">
			    		<form name="form1" action="TrainingList.php" method="post">
			    		<tr height="30">
			    			<td width="120" class="c2">教育訓練資訊</td>
			    		</tr>
						<tr height="30">
			    			<td class="h3"><font color=blue><b>所屬月份：</b></font>
			    				<select name="QSCAYear">
			    					<option value=""></option>
			    					<option value="2008"<?php if (trim($QSCAYear) == "2008") echo " selected";?>>2008</option>
			    					<option value="2009"<?php if (trim($QSCAYear) == "2009") echo " selected";?>>2009</option>
			    					<option value="2010"<?php if (trim($QSCAYear) == "2010") echo " selected";?>>2010</option>
			    					<option value="2011"<?php if (trim($QSCAYear) == "2011") echo " selected";?>>2011</option>
			    					<option value="2012"<?php if (trim($QSCAYear) == "2012") echo " selected";?>>2012</option>
			    					<option value="2013"<?php if (trim($QSCAYear) == "2013") echo " selected";?>>2013</option>
			    					<option value="2014"<?php if (trim($QSCAYear) == "2014") echo " selected";?>>2014</option>
			    					<option value="2015"<?php if (trim($QSCAYear) == "2015") echo " selected";?>>2015</option>
			    					<option value="2016"<?php if (trim($QSCAYear) == "2016") echo " selected";?>>2016</option>
			    					<option value="2017"<?php if (trim($QSCAYear) == "2017") echo " selected";?>>2017</option>
			    					<option value="2018"<?php if (trim($QSCAYear) == "2018") echo " selected";?>>2018</option>
			    					<option value="2019"<?php if (trim($QSCAYear) == "2019") echo " selected";?>>2019</option>
			    					<option value="2020"<?php if (trim($QSCAYear) == "2020") echo " selected";?>>2020</option>
			    					<option value="2021"<?php if (trim($QSCAYear) == "2021") echo " selected";?>>2021</option>
			    					<option value="2022"<?php if (trim($QSCAYear) == "2022") echo " selected";?>>2022</option>
			    					<option value="2023"<?php if (trim($QSCAYear) == "2023") echo " selected";?>>2023</option>
			    					<option value="2024"<?php if (trim($QSCAYear) == "2024") echo " selected";?>>2024</option>
			    					<option value="2025"<?php if (trim($QSCAYear) == "2025") echo " selected";?>>2025</option>
									<option value="2026"<?php if (trim($QSCAYear) == "2026") echo " selected";?>>2026</option>
									<option value="2027"<?php if (trim($QSCAYear) == "2027") echo " selected";?>>2027</option>
									<option value="2028"<?php if (trim($QSCAYear) == "2028") echo " selected";?>>2028</option>
									<option value="2029"<?php if (trim($QSCAYear) == "2029") echo " selected";?>>2029</option>
									<option value="2030"<?php if (trim($QSCAYear) == "2030") echo " selected";?>>2030</option>
									<option value="2031"<?php if (trim($QSCAYear) == "2031") echo " selected";?>>2031</option>
									<option value="2032"<?php if (trim($QSCAYear) == "2032") echo " selected";?>>2032</option>
									<option value="2033"<?php if (trim($QSCAYear) == "2033") echo " selected";?>>2033</option>
									<option value="2034"<?php if (trim($QSCAYear) == "2034") echo " selected";?>>2034</option>
									<option value="2035"<?php if (trim($QSCAYear) == "2035") echo " selected";?>>2035</option>
			    				</select> <font color=blue><b>年</b></font> 
			    				<select name="QSCAMonth">
			    					<option value=""></option>
			    					<option value="01"<?php if (trim($QSCAMonth) == "01") echo " selected";?>>01</option>
			    					<option value="02"<?php if (trim($QSCAMonth) == "02") echo " selected";?>>02</option>
			    					<option value="03"<?php if (trim($QSCAMonth) == "03") echo " selected";?>>03</option>
			    					<option value="04"<?php if (trim($QSCAMonth) == "04") echo " selected";?>>04</option>
			    					<option value="05"<?php if (trim($QSCAMonth) == "05") echo " selected";?>>05</option>
			    					<option value="06"<?php if (trim($QSCAMonth) == "06") echo " selected";?>>06</option>
			    					<option value="07"<?php if (trim($QSCAMonth) == "07") echo " selected";?>>07</option>
			    					<option value="08"<?php if (trim($QSCAMonth) == "08") echo " selected";?>>08</option>
			    					<option value="09"<?php if (trim($QSCAMonth) == "09") echo " selected";?>>09</option>
			    					<option value="10"<?php if (trim($QSCAMonth) == "10") echo " selected";?>>10</option>
			    					<option value="11"<?php if (trim($QSCAMonth) == "11") echo " selected";?>>11</option>
			    					<option value="12"<?php if (trim($QSCAMonth) == "12") echo " selected";?>>12</option>
			    				</select> <font color=blue><b>月</b></font><input type="hidden" name="QSCADay" value="1"> ~ 
			    				<select name="QECAYear">
			    					<option value=""></option>
			    					<option value="2008"<?php if (trim($QECAYear) == "2008") echo " selected";?>>2008</option>
			    					<option value="2009"<?php if (trim($QECAYear) == "2009") echo " selected";?>>2009</option>
			    					<option value="2010"<?php if (trim($QECAYear) == "2010") echo " selected";?>>2010</option>
			    					<option value="2011"<?php if (trim($QECAYear) == "2011") echo " selected";?>>2011</option>
			    					<option value="2012"<?php if (trim($QECAYear) == "2012") echo " selected";?>>2012</option>
			    					<option value="2013"<?php if (trim($QECAYear) == "2013") echo " selected";?>>2013</option>
			    					<option value="2014"<?php if (trim($QECAYear) == "2014") echo " selected";?>>2014</option>
			    					<option value="2015"<?php if (trim($QECAYear) == "2015") echo " selected";?>>2015</option>
			    					<option value="2016"<?php if (trim($QECAYear) == "2016") echo " selected";?>>2016</option>
			    					<option value="2017"<?php if (trim($QECAYear) == "2017") echo " selected";?>>2017</option>
			    					<option value="2018"<?php if (trim($QECAYear) == "2018") echo " selected";?>>2018</option>
			    					<option value="2019"<?php if (trim($QECAYear) == "2019") echo " selected";?>>2019</option>
			    					<option value="2020"<?php if (trim($QECAYear) == "2020") echo " selected";?>>2020</option>
			    					<option value="2021"<?php if (trim($QECAYear) == "2021") echo " selected";?>>2021</option>
			    					<option value="2022"<?php if (trim($QECAYear) == "2022") echo " selected";?>>2022</option>
			    					<option value="2023"<?php if (trim($QECAYear) == "2023") echo " selected";?>>2023</option>
			    					<option value="2024"<?php if (trim($QECAYear) == "2024") echo " selected";?>>2024</option>
			    					<option value="2025"<?php if (trim($QECAYear) == "2025") echo " selected";?>>2025</option>
									<option value="2026"<?php if (trim($QECAYear) == "2025") echo " selected";?>>2026</option>
									<option value="2027"<?php if (trim($QECAYear) == "2025") echo " selected";?>>2027</option>
									<option value="2028"<?php if (trim($QECAYear) == "2025") echo " selected";?>>2028</option>
									<option value="2029"<?php if (trim($QECAYear) == "2025") echo " selected";?>>2029</option>
									<option value="2030"<?php if (trim($QECAYear) == "2025") echo " selected";?>>2030</option>
									<option value="2031"<?php if (trim($QECAYear) == "2025") echo " selected";?>>2031</option>
									<option value="2032"<?php if (trim($QECAYear) == "2025") echo " selected";?>>2032</option>
									<option value="2033"<?php if (trim($QECAYear) == "2025") echo " selected";?>>2033</option>
									<option value="2034"<?php if (trim($QECAYear) == "2025") echo " selected";?>>2034</option>
									<option value="2035"<?php if (trim($QECAYear) == "2025") echo " selected";?>>2035</option>
			    				</select> <font color=blue><b>年</b></font> 
			    				<select name="QECAMonth">
			    					<option value=""></option>
			    					<option value="01"<?php if (trim($QECAMonth) == "01") echo " selected";?>>01</option>
			    					<option value="02"<?php if (trim($QECAMonth) == "02") echo " selected";?>>02</option>
			    					<option value="03"<?php if (trim($QECAMonth) == "03") echo " selected";?>>03</option>
			    					<option value="04"<?php if (trim($QECAMonth) == "04") echo " selected";?>>04</option>
			    					<option value="05"<?php if (trim($QECAMonth) == "05") echo " selected";?>>05</option>
			    					<option value="06"<?php if (trim($QECAMonth) == "06") echo " selected";?>>06</option>
			    					<option value="07"<?php if (trim($QECAMonth) == "07") echo " selected";?>>07</option>
			    					<option value="08"<?php if (trim($QECAMonth) == "08") echo " selected";?>>08</option>
			    					<option value="09"<?php if (trim($QECAMonth) == "09") echo " selected";?>>09</option>
			    					<option value="10"<?php if (trim($QECAMonth) == "10") echo " selected";?>>10</option>
			    					<option value="11"<?php if (trim($QECAMonth) == "11") echo " selected";?>>11</option>
			    					<option value="12"<?php if (trim($QECAMonth) == "12") echo " selected";?>>12</option>
			    				</select> <font color=blue><b>月</b></font><input type="hidden" name="QECADay" value="1">
			    			</td>
			    		</tr>
						<tr height="30">
			    			<td align="left" class="h3">關鍵字：<input type="text" name="KeyWord" size="10"><!--</td>-->
							<!--<td align="left" class="h3">-->
			    				課程主要名稱：
								<select name="main">
									<option value="">不限</option>
										<?php
											$SQL_Manager="select TCID,TCTTitle from trainingcamp where Deltag='N' order by TCID;";
											$result_Manager=mysqli_query($link,$SQL_Manager) or die ("無法執行查詢");
											while(list($TCID,$TCTTitle)=mysqli_fetch_row($result_Manager)){
										?>
											<option value="<?php echo $TCID;?>"<?php if (trim($TCID) == trim($main)) echo " selected";?>><?php echo $TCTTitle;?></option>
										<?php
											}
											mysqli_free_result($result_Manager);
										?>
								</select>
			    			<!--</td>-->
							<!--<td align="left" class="h3">-->
			    				參與人員：
								<select name="QMUID">
									<option value="">不限</option>
										<?php
											$SQL_Manager="select MID,MUID,MName,MEName from Manager where Deltag='N' and IsLeft='N' order by MID;";
											$result_Manager=mysqli_query($link,$SQL_Manager) or die ("無法執行查詢");
											while(list($MID,$MUID,$MName,$MEName)=mysqli_fetch_row($result_Manager)){
										?>
											<option value="<?php echo $MID;?>"<?php if (trim($MID) == trim($QMUID)) echo " selected";?>><?php echo $MEName.$MName;?></option>
										<?php
											}
											mysqli_free_result($result_Manager);
										?>
								</select>
			    			<!--</td>-->
							<!--<td class="h3">--><input type="submit" name="search" class="input_bot" value="查詢"><!--<td>-->
			    			<!--<td width="20">--><input type="button" name="report" class="input_bot" value="報表輸出" onclick="javascript:TrainingExport();"><!--</td>-->
							<!--<td align="right" class="h3">--><?php if (trim(strstr($_SESSION["reg_MPer"],'N')) != ""){?><input type="button" name="add" value="新 增" class="input_bot" onclick="javascript:location.href='TrainingAdd.php';"><?php }?></td>
			    		</tr>
			    	</form>
			    	</table>
						<?php
						$Sql_str="select t.TID,t.TDate,t.TTitle,t.TFile,t.Lecturer,t.AddDate,t.ProcDate from Training t where t.Deltag='N' ".$SqlTxt." order by t.TDate desc;";
						$SQL_Training="select t.TID,t.TDate,t.TTitle,t.TFile,t.Lecturer,t.AddDate,t.ProcDate from Training t where t.Deltag='N' ".$SqlTxt." order by t.TDate desc ".$limit_txt.";";
						//echo $SQL_Training;
						$result_Training=mysqli_query($link,$SQL_Training) or die ("無法執行查詢");
						?>
			    	<table width="750" border="0" cellpadding="5" cellspacing="2" class="s2">
			        <tr align="center">
			          <td width="100" align="center" background="../images/table_bg.gif" class="t21">日 期</td>
			          <td width="450" align="center" background="../images/table_bg.gif" class="t21">課程名稱</td>
			          <td width="100" background="../images/table_bg.gif" class="t21">詳 細</td>
			          <?php if (trim(strstr($_SESSION["reg_MPer"],'H')) != ""){?>
			          <td width="50" background="../images/table_bg.gif" class="t21">修 改</td>
			          <td width="50" background="../images/table_bg.gif" class="t21">刪 除</td>
			          <?php }?>
			        </tr>
		          <?php
		          $tmp = 1;
		          while(list($TID,$TDate,$TTitle,$TFile,$Lecturer,$AddDate,$ProcDate)=mysqli_fetch_row($result_Training)){
		        	?>
		        	<tr<?php if ($tmp%2 == 0) echo " bgcolor=\"#F6F6F6\"";?>>
			          <td class="h3"><?php echo $TDate;?></td>
			          <td class="h3">
			          	<?php if (trim($TFile) == "") echo $TTitle;
			          	else {?>
			          		<a href="getfile.php?FolderName=Admin\\TFile&FileName=<?php echo $TFile;?>"><?php echo $TTitle;?></a>
			          	<?php }?>
			          </td>
			          <td align="center"><input type="button" name="edit" value="詳 細" class="input_bot" onclick="javascript:location.href='TrainingDetail.php?TID=<?php echo $TID;?>&page=<?php echo $page;?><?php echo $url_str;?>';"></td>
			          <?php if (trim(strstr($_SESSION["reg_MPer"],'N')) != ""){?>
			          <td align="center"><input type="button" name="edit" value="修 改" class="input_bot" onclick="javascript:location.href='TrainingEdit.php?TID=<?php echo $TID;?>&page=<?php echo $page;?><?php echo $url_str;?>';"></td>
			          <td align="center"><input type="button" name="edit" value="刪 除" class="input_bot" onclick="javascript:if (confirm('您是否確定要刪除？')) location.href='TrainingDelDB.php?TID=<?php echo $TID;?>&page=<?php echo $page;?><?php echo $url_str;?>';"></td>
			          <?php }?>
			        </tr>
			        <?php
            			$tmp++;
			      			}
            	mysqli_free_result($result_Training);
			        ?>
			      </table>
			      <table width="750" border="0" cellpadding="5" cellspacing="2" class="s2">
			        <tr align="center">
			          <td bgcolor="#E8F0C2" class="h4"><?php Page_show($Sql_str,$page_rows,$php_Self,$link,$page,$url_str,$button_css);?></td>
			        </tr>
			      </table>
    			</td>
    		</tr>
    	</table>
    </td>
	</tr>
</table>
<form name="form_exp" action="TrainingExport.php" method="post" target="_TrainingExport">
	<input type="hidden" name="MID">
</form>
<?php include "down.php";?>
</body>
</html>
<?php
mysqli_close($link);
?>