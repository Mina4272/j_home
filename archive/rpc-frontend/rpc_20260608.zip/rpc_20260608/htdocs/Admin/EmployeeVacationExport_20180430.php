﻿<?php
include "CheckPermission.php";
include "CheckAccountingReport.php";
include "../global.php";

function chk_str($chkstr) {
	$chkstr = str_replace('"','〞',$chkstr);
	return $chkstr;
}

$SDate = "";
$EDate ="";
$SqlMID = "";
$SqlTxt="";
$SYear = $_POST['SYear'];
$SMonth = $_POST['SMonth'];
$SDay = $_POST['SDay'];
if (trim($SYear) != "" || trim($SMonth) != "" || trim($SDay) != "") if (checkdate($SMonth,$SDay ,$SYear)) $SDate = $SYear."-".$SMonth."-".$SDay;
$EYear = $_POST['EYear'];
$EMonth = $_POST['EMonth'];
$EDay = $_POST['EDay'];
if (trim($EYear) != "" || trim($EMonth) != "" || trim($EDay) != "") if (checkdate($EMonth,$EDay ,$EYear)) $EDate = $EYear."-".$EMonth."-".$EDay;
$QEVType = $_POST['QEVType'];
$KeyWord = $_POST['KeyWord'];

if (trim($SDate) != "" && trim($EDate) != "") $SqlTxt = $SqlTxt." and (AddDate >= '".$SDate." 00:00:00') and (AddDate <= '".$EDate." 23:59:59') ";
else if (trim($SDate) != "" && trim($EDate) == "") $SqlTxt = $SqlTxt." and (AddDate >= '".$SDate." 00:00:00') ";
else if (trim($SDate) == "" && trim($EDate) != "") $SqlTxt = $SqlTxt." and (AddDate <= '".$EDate." 23:59:59') ";
if (trim($QEVType) != "") $SqlTxt = $SqlTxt." and EVType = '".$QEVType."' ";
if (trim($KeyWord) != "") {
		$SQL_Manager="select MID from Manager where EmployeeNo like '%".$KeyWord."%' or MUID like '%".$KeyWord."%' or MName like '%".$KeyWord."%' order by MID;";
		$result_Manager=mysqli_query($link,$SQL_Manager) or die ("無法執行查詢");
		
		while(list($MMID)=mysqli_fetch_row($result_Manager)){
				if (trim($SqlMID) == "") $SqlMID = $MMID;
				else $SqlMID = $SqlMID.",".$MMID;
				}
		mysqli_free_result($result_Manager);
		}
if (trim($SqlMID) != "") $SqlMID = " MID in (".$SqlMID.")";
if (trim($KeyWord) != "") {
		if (trim($SqlMID) == "") $SqlTxt = $SqlTxt." and EVDesc like '%".$KeyWord."%'";
		else $SqlTxt = $SqlTxt." and (EVDesc like '%".$KeyWord."%' or ".$SqlMID.")";
		}

$SQL_EmployeeVacation="select EVID,MID,(select MName from Manager where MID=EmployeeVacation.MID) MName,(select MEName from Manager where MID=EmployeeVacation.MID) MEName,(select EmployeeNo from Manager where MID=EmployeeVacation.MID) EmployeeNo,EVType,MVID,date_format(EPDate,'%Y'),date_format(EPDate,'%m'),EVCount,EVDesc,date_format(AddDate,'%Y'),date_format(AddDate,'%m'),date_format(AddDate,'%d') from EmployeeVacation where Deltag='N' ".$SqlTxt." order by EVID desc;";
$result_EmployeeVacation=mysqli_query($link,$SQL_EmployeeVacation) or die ("無法執行查詢");
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $PageAdminTitle;?></title>
<link href="style.css" rel="stylesheet" type="text/css" />
<body>
<table winth="1000" border="0">
	<tr>
		<td colspan="2"><font color=blue>若您無法正常觀看此報表！請下載此 <a href="owc11.zip" target="_File"><font color=red><b>元件</b></font></a> <font color=blue>安裝至您的電腦。</font></td>
	</tr>
</table>
<object id=EmployeeVacation classid=CLSID:0002E559-0000-0000-C000-000000000046 style="width:100%;height:90%"></object>
<script language=vbscript>
	Sub Window_OnLoad()
	Set chConstants = EmployeeVacation.Constants
	EmployeeVacation.ActiveSheet.Cells.Clear
	EmployeeVacation.Worksheets(1).Select
	EmployeeVacation.ActiveSheet.Name ="EmployeeVacation"
	<?php  
	$ECount=1;
	?>
	EmployeeVacation.ActiveSheet.Cells(<?php echo $ECount;?>,1).Value ="使用時間"
	EmployeeVacation.ActiveSheet.Cells(<?php echo $ECount;?>,2).Value ="員工編號"
	EmployeeVacation.ActiveSheet.Cells(<?php echo $ECount;?>,3).Value ="姓名"
	EmployeeVacation.ActiveSheet.Cells(<?php echo $ECount;?>,4).Value ="類型"
	EmployeeVacation.ActiveSheet.Cells(<?php echo $ECount;?>,5).Value ="年假天數"
	EmployeeVacation.ActiveSheet.Cells(<?php echo $ECount;?>,6).Value ="說明"
	<?php
	$ECount++;
	while(list($EVID,$MID,$MName,$MEName,$EmployeeNo,$EVType,$MVID,$EPYear,$EPMonth,$EVCount,$EVDesc,$AddYear,$AddMonth,$AddDay)=mysqli_fetch_row($result_EmployeeVacation)){
	    if (trim($EVType) == "A") $EVTypeTxt="新增年假";
	    else if (trim($EVType) == "B") $EVTypeTxt="使用年假";
	    else if (trim($EVType) == "C") $EVTypeTxt="年假折現";
	    else $EVTypeTxt=$EVType;
	    if (trim($EVType) == "C") $EVDescTxt = "折現月份：".$EPYear."-".$EPMonth;
			?>
			EmployeeVacation.ActiveSheet.Cells(<?php echo $ECount;?>,1).Value ="'<?php echo $AddYear."-".$AddMonth."-".$AddDay;?>"
			EmployeeVacation.ActiveSheet.Cells(<?php echo $ECount;?>,2).Value ="'<?php echo $EmployeeNo;?>"
			EmployeeVacation.ActiveSheet.Cells(<?php echo $ECount;?>,3).Value ="<?php echo $MEName.$MName;?>"
			EmployeeVacation.ActiveSheet.Cells(<?php echo $ECount;?>,4).Value ="<?php echo $EVTypeTxt;?>"
			EmployeeVacation.ActiveSheet.Cells(<?php echo $ECount;?>,5).Value ="<?php echo $EVCount;?>"
			EmployeeVacation.ActiveSheet.Cells(<?php echo $ECount;?>,6).Value ="<?php echo chk_str($EVDesc) . $EVDescTxt;?>"
			<?php
			$ECount++;
			}
	mysqli_free_result($result_EmployeeVacation);
	mysqli_close($link);
	?>
	EmployeeVacation.ActiveSheet.Range("A1:P<?php echo $ECount;?>").Font.Color="blue"
	EmployeeVacation.ActiveSheet.Range("A1:P<?php echo $ECount;?>").Font.Name="Courier New"
	EmployeeVacation.ActiveSheet.Range("A1:P<?php echo $ECount;?>").Font.Size="11"
	EmployeeVacation.ActiveSheet.Range("A1:P<?php echo $ECount;?>").Columns.AutoFit
	EmployeeVacation.ActiveSheet.Range("A1:P<?php echo $ECount;?>").NumberFormat ="General"
	EmployeeVacation.ActiveSheet.Range("A<?php echo $ECount;?>:J<?php echo $ECount;?>").Font.Bold=true
	<?php
	$TitleLineArr = split(",",$TitleLine);
	$count_i=count($TitleLineArr);
	for ($tmp=0;$tmp<=$count_i-1;$tmp++){
			?>
			EmployeeVacation.ActiveSheet.Range("A<?php echo $TitleLineArr[$tmp];?>:P<?php echo $TitleLineArr[$tmp];?>").Font.Color="#000000"
			EmployeeVacation.ActiveSheet.Range("A<?php echo $TitleLineArr[$tmp]+1;?>:P<?php echo $TitleLineArr[$tmp]+1;?>").Font.Bold=true
			<?php
			}
	?>
	End Sub
	</script>
</body>
</html>
