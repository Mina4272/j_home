﻿<?php	
include "CheckPermission.php";
//include "CheckManager.php";
include "../global.php";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $PageAdminTitle;?></title>
<link href="../type.css" rel="stylesheet" type="text/css" />
<style type="text/css">
<!--
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
}
-->
</style>
<link href="../script/DatePicker.css" rel="stylesheet" type="text/css" />
<Script LANGUAGE="Javascript" SRC="../script/DatePicker.js"></Script>
<Script type="text/javascript" language="javascript" src="../script/CheckForm.js"></Script>
<script type="text/JavaScript">
<!--
function jsCheck() 
		{
		if (ChkImp('MJTitle',document.form1.MJTitle.value,'工作名稱') == false) return false;
		}
//-->
</script>
</head>
<body>
<?php include "top.php";?>
<?php
$MJID = $_GET['MJID'];
if (trim($MJID) == "" || trim($MJID) == "")
		{
		mysqli_close($link);
		?>
		<script type="text/JavaScript">
			<!--
			alert ("查無資料，請冾網站管理人員！");
			self.close();
			//-->
		</script>
		<?php
		exit;
		}
$SQL_ManagerJob="select a.MID, a.MJID, a.MJPeriod, a.MJTitle, a.MJDescription, a.MJDeputyID, a.MJNote, b.MName as MJDeputy from ManagerJob as a, Manager as b where a.MJDeputyID=b.MID and a.MJID='".$MJID."';";
$result_Manager=mysqli_query($link,$SQL_ManagerJob) or die ("沒有例行工作項目!");

if (mysqli_num_rows($result_Manager) == 0)
		{
		mysqli_free_result($result_Manager);
		mysqli_close($link);
		?>
		<SCRIPT language=javascript>
		<!--
		alert ("查無資料，請冾網站管理人員@！"); 
		history.go(-1);
		//-->
		</SCRIPT>
		<?php 	
		exit;
		}

list($MID,$MJID,$MJPeriod,$MJTitle,$MJDescription,$MJDeputyID,$MJNote, $MJDeputy)=mysqli_fetch_row($result_Manager);
mysqli_free_result($result_Manager);

$SQL_Manager="select MName from Manager where MID='".$MID."';";
$result_Manager=mysqli_query($link,$SQL_Manager) or die ("沒有例行工作項目!");
list($MName)=mysqli_fetch_row($result_Manager);
mysqli_free_result($result_Manager);

?>
<table width="100%" border="0" cellspacing="0" cellpadding="5">
	<tr>
    <td width="160" height="600" align="left" valign="top">
			<?php include "menu.php";?>
    </td>
    <td valign="top">
    <table width="100%" border="0" cellpadding="0" cellspacing="0">
	<tr>
		<td>
    	<table width="100%" border="0" cellpadding="0" cellspacing="0">
    		<tr height="30">
					<td width="15" background="../images/table_bg.gif"></td>
    			<td class="c3" background="../images/table_bg.gif"><b>修改員工例行工作資料</b></td>
    		</tr>
    	</table>
    	<table width="100%" border="0" cellpadding="0" cellspacing="0">
        <form name="form1" method="post" action="ManagerJobEditDB.php" enctype="multipart/form-data" onSubmit="return jsCheck();">
        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
					<td width="15"></td>
          <td width="160" class="c3" align="right">工作人員：</td>
          <td class="h3"><?php echo $MName;?>
        </tr>
         <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
					<td width="15"></td>
          <td class="c3" align="right">工作週期：</td>
	  <td class="h3">
	       	<select id="MJPeriod" name="MJPeriod">
	       		<option value="D" <?php if($MJPeriod=="D") echo "selected='selected'";?>>每日</option>
	       		<option value="W" <?php if($MJPeriod=="W") echo "selected='selected'";?>>每週</option>
	       		<option value="M" <?php if($MJPeriod=="M") echo "selected='selected'";?>>每月</option>
	       		<option value="Y" <?php if($MJPeriod=="Y") echo "selected='selected'";?>>每年</option>
	       		<option value="U" <?php if($MJPeriod=="U") echo "selected='selected'";?>>不定期</option>
	       	</select>
	  </td>
        </tr>
        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
					<td width="15"></td>
          <td width="160" class="c3" align="right">工作名稱：</td>
          <td class="h3"><input type="text" id="MJTitle" name="MJTitle" size="30" value="<?php echo $MJTitle;?>"></td>
        </tr>
        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
					<td width="15"></td>
          <td width="160" class="c3" align="right">工作描述：</td>
          <td class="h3"><input type="text" id="MJDescription" name="MJDescription" size="100" value="<?php echo $MJDescription;?>"></td>
        </tr>
        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
					<td width="15"></td>
          <td width="160" class="c3" align="right">代理人：</td>
	  <td class="h3">
          	<select id="MJDeputyID" name="MJDeputyID">
<?php 

$SQL_select="select MID, MUID, MName from Manager where IsLeft = 'N' and DelTag = 'N';";
$result_Manager=mysqli_query($link,$SQL_select) or die ("無法執行查詢");

while(list($MID,$MUID,$MName)=mysqli_fetch_row($result_Manager)){
	if($MID==$MJDeputyID)
		echo "<option value='".$MID."' selected='selected'>".$MName."</option>";
	else
		echo "<option value='".$MID."'>".$MName."</option>";


}

mysqli_free_result($result_Manager);

?>
          	</select>
          </td>
        </tr>
        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
					<td width="15"></td>
          <td width="160" class="c3" align="right">備註：</td>
          <td class="h3"><input type="text" id="MJNote" name="MJNote" size="100" value="<?php echo $MJNote;?>"></td>
        </tr>

        <tr height="40" align="center">
					<td width="15"></td>
          <td colspan="2" class="h3">
          	<input type="submit" name="submit" class="input_bot" value="送 出">
          	<input name="MJID" type="hidden" id="MJID" value="<?php echo $MJID;?>" />
          	<input name="MID" type="hidden" id="MID" value="<?php echo $MID;?>" />
          </td>
        </tr>
	      </form>
      </table>
		</td>
	</tr>
    </table>
    </td>
	</tr>
</table>
<?php include "down.php";?>

</body>
</html>
<?php
mysqli_close($link);
?>