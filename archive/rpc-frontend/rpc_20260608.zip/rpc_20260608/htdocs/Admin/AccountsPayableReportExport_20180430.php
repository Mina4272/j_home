﻿<?php
include "CheckPermission.php";
if (trim(strstr($_SESSION["reg_MPer"],'F')) == "" || trim(strstr($_SESSION["reg_MPer"],'D')) == "" || trim(strstr($_SESSION["reg_MPer"],'I')) == "" || trim(strstr($_SESSION["reg_MPer"],'L')) == "") {}
else exit;
include "../global.php";

function chk_str($chkstr) {
	$chkstr = str_replace('"','〞',$chkstr);
	return $chkstr;
}
$SDate = "";
$EDate = "";
$SqlTxt = " ";
$SYear = $_POST['SYear'];
$SMonth = $_POST['SMonth'];
$SDay = $_POST['SDay'];
if (trim($SYear) != "" || trim($SMonth) != "" || trim($SDay) != "") if (checkdate($SMonth,$SDay ,$SYear)) $SDate = $SYear."-".$SMonth."-".$SDay;
$EYear = $_POST['EYear'];
$EMonth = $_POST['EMonth'];
$EDay = $_POST['EDay'];
if (trim($EYear) != "" || trim($EMonth) != "" || trim($EDay) != "") if (checkdate($EMonth,$EDay ,$EYear)) $EDate = $EYear."-".$EMonth."-".$EDay;

$KeyWord = $_POST['KeyWord'];
$QPAStatus = $_POST['QPAStatus'];
$QPAMode = $_POST['QPAMode'];
$QInvoice = $_POST['QInvoice'];

//if (trim($SDate) != "" && trim($EDate) != "") $SqlTxt = $SqlTxt." and (a.AddDate >= '".$SDate." 00:00:00') and (a.AddDate <= '".$EDate." 23:59:59') ";
//else if (trim($SDate) != "" && trim($EDate) == "") $SqlTxt = $SqlTxt." and (a.AddDate >= '".$SDate." 00:00:00') ";
//else if (trim($SDate) == "" && trim($EDate) != "") $SqlTxt = $SqlTxt." and (a.AddDate <= '".$EDate." 23:59:59') ";
if (trim($SDate) != "" && trim($EDate) != "") $SqlTxt = $SqlTxt." and (b.InvoiceDate >= '".$SDate."') and (b.InvoiceDate <= '".$EDate."') ";
else if (trim($SDate) != "" && trim($EDate) == "") $SqlTxt = $SqlTxt." and (b.InvoiceDate >= '".$SDate."') ";
else if (trim($SDate) == "" && trim($EDate) != "") $SqlTxt = $SqlTxt." and (b.InvoiceDate <= '".$EDate."') ";
if (trim($QPAStatus) != "") $SqlTxt .= " and b.PAStatus='".$QPAStatus."'";
if (trim($QPAMode) != "") $SqlTxt .= " and b.PAMode='".$QPAMode."' ";
if (trim($KeyWord) != "") $SqlTxt .= " and (a.PUID like '%".$KeyWord."%' or a.CName like '%".$KeyWord."%' or a.CTel like '%".$KeyWord."%' or a.CFax like '%".$KeyWord."%' or a.Contact like '%".$KeyWord."%' or a.CMobile like '%".$KeyWord."%' or a.CEMail like '%".$KeyWord."%' or a.CAddress like '%".$KeyWord."%' or a.PName like '%".$KeyWord."%' or a.ModelName like '%".$KeyWord."%' or a.SeriesModel like '%".$KeyWord."%' or a.PE like '%".$KeyWord."%' or b.PAItem like '%".$KeyWord."%' or b.Invoice like '%".$KeyWord."%' or b.CName like '%".$KeyWord."%' or b.PANote like '%".$KeyWord."%' or b.PANo like '%".$KeyWord."%')";
if (trim($QInvoice) != "") {
		if (trim($QInvoice) == "Y") $SqlTxt .= " and b.Invoice <> ''";
		else if (trim($QInvoice) == "N") $SqlTxt .= " and b.Invoice = ''";
		}

$SQL_Project="SELECT b.PAID,b.PAMode,b.PAItem,b.Charges,b.Rate,b.ChargesOther,b.PAStatus,b.PADate,b.PANote,b.Invoice,a.PUID,a.PName,a.ModelName,a.QuoteDate,a.IFlorin,a.OFlorin,a.CName,a.PE,a.ApplyItem,a.PStatus,a.PTax,b.PATax,b.InvoiceDate,b.CName,b.PAPDate,b.PANo FROM Project a, ProjectAccounting b WHERE a.PID = b.PID AND a.Deltag = 'N' AND b.Deltag = 'N' ".$SqlTxt." order by a.PID desc,b.PAID,b.PAMode";
//echo $SQL_Project;
$result_Project=mysqli_query($link,$SQL_Project) or die ("無法執行查詢");
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $PageAdminTitle;?></title>
<link href="style.css" rel="stylesheet" type="text/css" />
<body>
<table winth="1000" border="0">
	<tr>
		<td colspan="2"><font color=blue>若您無法正常觀看此報表！請下載此 <a href="owc11.zip" target="_File"><font color=red><b>元件</b></font></a> <font color=blue>安裝至您的電腦。</font></td>
	</tr>
</table>
<object id=ProjectAccounting classid=CLSID:0002E559-0000-0000-C000-000000000046 style="width:100%;height:90%"></object>
<script language=vbscript>
	Sub Window_OnLoad()
	Set chConstants = ProjectAccounting.Constants
	ProjectAccounting.ActiveSheet.Cells.Clear
	ProjectAccounting.Worksheets(1).Select
	ProjectAccounting.ActiveSheet.Name ="ProjectAccounting"

	ProjectAccounting.ActiveSheet.Cells(1,1).Value ="案件編號"
	ProjectAccounting.ActiveSheet.Cells(1,2).Value ="產品名稱"
	ProjectAccounting.ActiveSheet.Cells(1,3).Value ="主型式"
	ProjectAccounting.ActiveSheet.Cells(1,4).Value ="客戶名稱"
	ProjectAccounting.ActiveSheet.Cells(1,5).Value ="收入/支出"
	ProjectAccounting.ActiveSheet.Cells(1,6).Value ="項目"
	ProjectAccounting.ActiveSheet.Cells(1,7).Value ="費用"
	ProjectAccounting.ActiveSheet.Cells(1,8).Value ="稅金"
	ProjectAccounting.ActiveSheet.Cells(1,9).Value ="匯率"
	ProjectAccounting.ActiveSheet.Cells(1,10).Value ="外幣別"
	ProjectAccounting.ActiveSheet.Cells(1,11).Value ="外幣費用"
	ProjectAccounting.ActiveSheet.Cells(1,12).Value ="狀態"
	ProjectAccounting.ActiveSheet.Cells(1,13).Value ="預計結清日期"
	ProjectAccounting.ActiveSheet.Cells(1,14).Value ="收款日/付款日"
	ProjectAccounting.ActiveSheet.Cells(1,15).Value ="發票日期"
	ProjectAccounting.ActiveSheet.Cells(1,16).Value ="發票號碼"
	ProjectAccounting.ActiveSheet.Cells(1,17).Value ="對帳編號"
	ProjectAccounting.ActiveSheet.Cells(1,18).Value ="供應商"
	ProjectAccounting.ActiveSheet.Cells(1,19).Value ="備註"
<?php  
$ECount=2;
$SumInput=0;
$SumInputTax=0;
$SumOutput=0;
$SumOutputTax=0;
$SumCharges = 0;
while(list($PAID,$PAMode,$PAItem,$Charges,$Rate,$ChargesOther,$PAStatus,$PADate,$PANote,$Invoice,$PUID,$PName,$ModelName,$QuoteDate,$IFlorin,$OFlorin,$CName,$PE,$ApplyItem,$PStatus,$PTax,$PATax,$InvoiceDate,$PCName,$PAPDate,$PANo)=mysqli_fetch_row($result_Project)){
		if (trim($QuoteDate) == "0000-00-00") $QuoteDate = "";
		if (trim($QuoteDate) != "") $QuoteCheck = "True";
		if (trim($IFlorin) == "") $IFlorin = "新台幣";
		if (trim($OFlorin) == "") $OFlorin = "新台幣";

  	if (trim($PAStatus) == "W") {
  			if (trim($PAMode) == "I") $PAStatus="待收"; else if (trim($PAMode) == "O") $PAStatus="未付";
  			}
  	else if (trim($PAStatus) == "S") $PAStatus="結清";
  	else if (trim($PAStatus) == "C") $PAStatus="取消";
  	$FlorinTxt="";
  	if (trim($PAMode) == "I") $FlorinTxt=$IFlorin;
  	else if (trim($PAMode) == "O") $FlorinTxt=$OFlorin;
  	
  	if (trim($PATax) == "") $PATax = $PTax;

  	if (trim($PAMode) == "I") {
  			$SumInput=$SumInput+$Charges;
  			if (trim($PATax) == "Y") $SumInputTax = $SumInputTax + round($Charges * 0.05);
  			}
  	else if (trim($PAMode) == "O") {
  			$SumOutput=$SumOutput+$Charges;
  			$SumCharges=$SumCharges-$Charges;
  			if (trim($PATax) == "Y") $SumOutputTax = $SumOutputTax + round($Charges * 0.05);
  			}
  	if (trim($PAMode) == "I") $PAMode="收入";
  	else if (trim($PAMode) == "O") $PAMode="支出";
		?>
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,1).Value ="<?php echo $PUID;?>"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,2).Value ="<?php echo chk_str($PName);?>"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,3).Value ="<?php echo chk_str($ModelName);?>"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,4).Value ="<?php echo chk_str($CName);?>"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,5).Value ="<?php echo chk_str($PAMode);?>"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,6).Value ="<?php echo chk_str($PAItem);?>"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,7).Value ="<?php echo $Charges;?>"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,8).Value ="<?php if (trim($PATax) == "Y") echo round($Charges * 0.05); else echo "0";?>"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,9).Value ="<?php echo $Rate;?>"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,10).Value ="<?php echo $FlorinTxt;?>"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,11).Value ="<?php echo $ChargesOther;?>"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,12).Value ="<?php echo $PAStatus;?>"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,13).Value ="'<?php echo $PAPDate;?>"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,14).Value ="'<?php echo $PADate;?>"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,15).Value ="'<?php echo $InvoiceDate;?>"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,16).Value ="'<?php echo $Invoice;?>"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,17).Value ="'<?php echo $PANo;?>"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,18).Value ="<?php echo chk_str($PCName);?>"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,19).Value ="<?php echo chk_str($PANote);?>"
		<?php
		$ECount++;
		}
mysqli_free_result($result_Project);
mysqli_close($link);
?>
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,1).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,2).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,3).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,4).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,5).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,6).Value ="總收入"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,7).Value ="<?php echo $SumInput;?>"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,8).Value ="<?php echo $SumInputTax;?>"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,9).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,10).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,11).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,12).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,13).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,14).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,15).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,16).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,17).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,18).Value =""
		<?php $ECount++;?>
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,1).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,2).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,3).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,4).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,5).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,6).Value ="總支出"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,7).Value ="<?php echo $SumOutput;?>"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,8).Value ="<?php echo $SumOutputTax;?>"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,9).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,10).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,11).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,12).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,13).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,14).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,15).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,16).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,17).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,18).Value =""
		<?php $ECount++;?>
		ProjectAccounting.ActiveSheet.Range("A1:S<?php echo $ECount;?>").Font.Color="blue"
		ProjectAccounting.ActiveSheet.Range("A1:S<?php echo $ECount;?>").Font.Name="Courier New"
		ProjectAccounting.ActiveSheet.Range("A1:S<?php echo $ECount;?>").Font.Size="11"
		ProjectAccounting.ActiveSheet.Range("A1:S<?php echo $ECount;?>").Columns.AutoFit
		ProjectAccounting.ActiveSheet.Range("A1:S<?php echo $ECount;?>").NumberFormat ="General"

		ProjectAccounting.ActiveSheet.Range("A1:S1").Font.Bold=true
		ProjectAccounting.ActiveSheet.Range("A1:S1").Font.Color="#000000"
		ProjectAccounting.ActiveSheet.Range("A1:S1").Font.Bold=true
		ProjectAccounting.ActiveSheet.Range("A1:S1").Font.Bold=true
		ProjectAccounting.ActiveSheet.Range("A1:S1").Font.Bold=true

	End Sub
	</script>
</body>
</html>
