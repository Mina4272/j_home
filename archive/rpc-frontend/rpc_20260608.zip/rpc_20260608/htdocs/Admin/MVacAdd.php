﻿<?php	
include "CheckPermission.php";
include "../global.php";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $PageAdminTitle;?></title>
<link href="../type.css" rel="stylesheet" type="text/css" />
<style type="text/css">
<!--
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
}
-->
</style>
<link href="../script/DatePicker.css" rel="stylesheet" type="text/css" />
<Script LANGUAGE="Javascript" SRC="../script/DatePicker.js"></Script>
<Script type="text/javascript" language="javascript" src="../script/CheckForm.js"></Script>
<script type="text/JavaScript">
<!--
function jsCheck() 
		{
		if (ChkDate('MVSYear',document.form1.MVSYear.value,document.form1.MVSMonth.value,document.form1.MVSDay.value,'請假起始時間') == false) return false;
		if (ChkDate('MVEYear',document.form1.MVEYear.value,document.form1.MVEMonth.value,document.form1.MVEDay.value,'請假結束時間') == false) return false;
		if (CompareDate('MVSYear',document.form1.MVSYear.value,document.form1.MVSMonth.value,document.form1.MVSDay.value,document.form1.MVEYear.value,document.form1.MVEMonth.value,document.form1.MVEDay.value,'請假起始時間','請假結束時間') == false) return false;
		if (ChkNaN('Hourage',document.form1.Hourage.value,'時數','') == false) return false;
		}
//-->
</script>
</head>
<body>
<?php include "top.php";?>
<table width="100%" border="0" cellspacing="0" cellpadding="5">
	<tr>
    <td width="160" height="600" align="left" valign="top">
			<?php include "menu.php";?>
    </td>
    <td valign="top">
    	<table width="100%" border="0" cellpadding="0" cellspacing="0">
    		<tr>
    			<td>
			    	<table width="750" border="0" cellpadding="0" cellspacing="0">
			    		<tr height="30">
			    			<td class="c2"><b>新增請假資料</b></td>
			    		</tr>
			    	</table>
			    	<table width="750" border="0" cellpadding="0" cellspacing="0">
			        <form name="form1" method="post" action="MVacAddDB.php" enctype="multipart/form-data" onSubmit="return jsCheck();">
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td width="160" align="right" class="c3">申請人：</td>
			          <td class="h3"><?php echo $_SESSION["reg_MName"];?></td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">假別：</td>
			          <td class="h3">
			          	<select name="MVType">
			          		<option value="A">事假</option>
			          		<option value="B">病假</option>
			          		<option value="C">公假</option>
			          		<option value="D">喪假</option>
			          		<option value="E">婚假</option>
			          		<option value="F">產假</option>
			          		<option value="G" selected>特休</option>
							<option value="I">生理假</option>
			          		<option value="H">其他</option>
			          	</select>
						特休:<?php echo $_SESSION["reg_EVCount"];?>天
			          </td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">請假起始時間：</td>
			          <td class="h3">
			            <input id="MVSYear" name="MVSYear" type="text" size="4" />年
			            <input id="MVSMonth" name="MVSMonth" type="text" size="2" />月
			            <input id="MVSDay" name="MVSDay" type="text" size="2" />日
			            <img src="../images/icon.gif" width="16" height="18" style="cursor: hand" onclick="javascript:displayDatePicker('MVSYear','MVSMonth','MVSDay');"/> 
			          	<select name="MVSHouse">
			          		<option value="00">00</option>
			          		<option value="01">01</option>
			          		<option value="02">02</option>
			          		<option value="03">03</option>
			          		<option value="04">04</option>
			          		<option value="05">05</option>
			          		<option value="06">06</option>
			          		<option value="07">07</option>
			          		<option value="08" selected>08</option>
			          		<option value="09">09</option>
			          		<option value="10">10</option>
			          		<option value="11">11</option>
			          		<option value="12">12</option>
			          		<option value="13">13</option>
			          		<option value="14">14</option>
			          		<option value="15">15</option>
			          		<option value="16">16</option>
			          		<option value="17">17</option>
			          		<option value="18">18</option>
			          		<option value="19">19</option>
			          		<option value="20">20</option>
			          		<option value="21">21</option>
			          		<option value="22">22</option>
			          		<option value="23">23</option>
			          	</select> 時 
			          	<select name="MVSMin">
			          		<option value="00">00</option>
			          		<option value="01">01</option>
			          		<option value="02">02</option>
			          		<option value="03">03</option>
			          		<option value="04">04</option>
			          		<option value="05">05</option>
			          		<option value="06">06</option>
			          		<option value="07">07</option>
			          		<option value="08">08</option>
			          		<option value="09">09</option>
			          		<option value="10">10</option>
			          		<option value="11">11</option>
			          		<option value="12">12</option>
			          		<option value="13">13</option>
			          		<option value="14">14</option>
			          		<option value="15">15</option>
			          		<option value="16">16</option>
			          		<option value="17">17</option>
			          		<option value="18">18</option>
			          		<option value="19">19</option>
			          		<option value="20">20</option>
			          		<option value="21">21</option>
			          		<option value="22">22</option>
			          		<option value="23">23</option>
			          		<option value="24">24</option>
			          		<option value="25">25</option>
			          		<option value="26">26</option>
			          		<option value="27">27</option>
			          		<option value="28">28</option>
			          		<option value="29">29</option>
			          		<option value="30" selected>30</option>
			          		<option value="31">31</option>
			          		<option value="32">32</option>
			          		<option value="33">33</option>
			          		<option value="34">34</option>
			          		<option value="35">35</option>
			          		<option value="36">36</option>
			          		<option value="37">37</option>
			          		<option value="38">38</option>
			          		<option value="39">39</option>
			          		<option value="40">40</option>
			          		<option value="41">41</option>
			          		<option value="42">42</option>
			          		<option value="43">43</option>
			          		<option value="44">44</option>
			          		<option value="45">45</option>
			          		<option value="46">46</option>
			          		<option value="47">47</option>
			          		<option value="48">48</option>
			          		<option value="49">49</option>
			          		<option value="50">50</option>
			          		<option value="51">51</option>
			          		<option value="52">52</option>
			          		<option value="53">53</option>
			          		<option value="54">54</option>
			          		<option value="55">55</option>
			          		<option value="56">56</option>
			          		<option value="57">57</option>
			          		<option value="58">58</option>
			          		<option value="59">59</option>
			          	</select> 分
			          </td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">請假結束時間：</td>
			          <td class="h3">
			            <input id="MVEYear" name="MVEYear" type="text" size="4" />年
			            <input id="MVEMonth" name="MVEMonth" type="text" size="2" />月
			            <input id="MVEDay" name="MVEDay" type="text" size="2" />日
			            <img src="../images/icon.gif" width="16" height="18" style="cursor: hand" onclick="javascript:displayDatePicker('MVEYear','MVEMonth','MVEDay');"/> 
			          	<select name="MVEHouse">
			          		<option value="00">00</option>
			          		<option value="01">01</option>
			          		<option value="02">02</option>
			          		<option value="03">03</option>
			          		<option value="04">04</option>
			          		<option value="05">05</option>
			          		<option value="06">06</option>
			          		<option value="07">07</option>
			          		<option value="08">08</option>
			          		<option value="09">09</option>
			          		<option value="10">10</option>
			          		<option value="11">11</option>
			          		<option value="12">12</option>
			          		<option value="13">13</option>
			          		<option value="14">14</option>
			          		<option value="15">15</option>
			          		<option value="16">16</option>
			          		<option value="17" selected>17</option>
			          		<option value="18">18</option>
			          		<option value="19">19</option>
			          		<option value="20">20</option>
			          		<option value="21">21</option>
			          		<option value="22">22</option>
			          		<option value="23">23</option>
			          	</select> 時 
			          	<select name="MVEMin">
			          		<option value="00">00</option>
			          		<option value="01">01</option>
			          		<option value="02">02</option>
			          		<option value="03">03</option>
			          		<option value="04">04</option>
			          		<option value="05">05</option>
			          		<option value="06">06</option>
			          		<option value="07">07</option>
			          		<option value="08">08</option>
			          		<option value="09">09</option>
			          		<option value="10">10</option>
			          		<option value="11">11</option>
			          		<option value="12">12</option>
			          		<option value="13">13</option>
			          		<option value="14">14</option>
			          		<option value="15">15</option>
			          		<option value="16">16</option>
			          		<option value="17">17</option>
			          		<option value="18">18</option>
			          		<option value="19">19</option>
			          		<option value="20">20</option>
			          		<option value="21">21</option>
			          		<option value="22">22</option>
			          		<option value="23">23</option>
			          		<option value="24">24</option>
			          		<option value="25">25</option>
			          		<option value="26">26</option>
			          		<option value="27">27</option>
			          		<option value="28">28</option>
			          		<option value="29">29</option>
			          		<option value="30" selected>30</option>
			          		<option value="31">31</option>
			          		<option value="32">32</option>
			          		<option value="33">33</option>
			          		<option value="34">34</option>
			          		<option value="35">35</option>
			          		<option value="36">36</option>
			          		<option value="37">37</option>
			          		<option value="38">38</option>
			          		<option value="39">39</option>
			          		<option value="40">40</option>
			          		<option value="41">41</option>
			          		<option value="42">42</option>
			          		<option value="43">43</option>
			          		<option value="44">44</option>
			          		<option value="45">45</option>
			          		<option value="46">46</option>
			          		<option value="47">47</option>
			          		<option value="48">48</option>
			          		<option value="49">49</option>
			          		<option value="50">50</option>
			          		<option value="51">51</option>
			          		<option value="52">52</option>
			          		<option value="53">53</option>
			          		<option value="54">54</option>
			          		<option value="55">55</option>
			          		<option value="56">56</option>
			          		<option value="57">57</option>
			          		<option value="58">58</option>
			          		<option value="59">59</option>
			          	</select> 分
			          </td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">時數：</td>
			          <td class="h3"><input type="text" id="Hourage" name="Hourage" size="10"></td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">代理人：</td>
			          <td class="h3">
			          	<select name="Agent">
			          		<?php
										$SQL_Manager="select MUID,MName,MEName from Manager where MUID not in ('".$_SESSION["reg_MUID"]."') and Deltag='N' and IsLeft='N' order by MID;";
										$result_Manager=mysqli_query($link,$SQL_Manager) or die ("無法執行查詢");
			          		while(list($MUID,$MName,$MEName)=mysqli_fetch_row($result_Manager)){
					          		?>
					          		<option value="<?php echo $MUID;?>"><?php echo $MEName.$MName;?></option>
					          		<?php
						      			}
			            	mysqli_free_result($result_Manager);
			          		?>
			          	</select>
			          </td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">備註：</td>
			          <td class="h3"><input type="text" name="MVNote" size="60"></td>
			        </tr>
					<tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">檔案上傳：</td>
			          <td class="h3"><input type="file" name="MVFile"></td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">是否送審：</td>
			          <td class="h3">
			          	<input type="radio" name="MVSend" value="N" checked> 否 
			          	<input type="radio" name="MVSend" value="Y"> 是
			          </td>
			        </tr>
			        <tr height="40" align="center">
			          <td colspan="2" class="h3"><input type="submit" name="submit" class="input_bot" value="送 出"></td>
			        </tr>
				      </form>
			      </table>
    			</td>
    		</tr>
    	</table>
    </td>
	</tr>
</table>
<?php include "down.php";?>
</body>
</html>
<?php
mysqli_close($link);
?>