﻿<?php
include "CheckPermission.php";
include "CheckMFees.php";
include "../global.php";

$MFYear = $_POST['MFYear'];
$MFMonth = $_POST['MFMonth'];
$MFDay = date("t",strtotime($MFYear."-".$MFMonth."-01"));

$MFType = $_POST['MFType'];
if (trim($MFType) == "A") $MFTypeTxt="加班費";
else if (trim($MFType) == "B") $MFTypeTxt="交通費-公里";
else if (trim($MFType) == "C") $MFTypeTxt="交通費-實報實銷";

//$SQL_Manager="select MUID,MName from Manager where Deltag='N' order by MID;";
$SQL_Manager="select MUID,MName from Manager where Deltag='N' and IsLeft='N' order by MID;";

$result_Manager=mysqli_query($link,$SQL_Manager) or die ("無法執行查詢");
while(list($MUID,$MName)=mysqli_fetch_row($result_Manager)){
		$Manager[$MUID]=$MName;
		}
mysqli_free_result($result_Manager);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $PageAdminTitle;?></title>
<link href="style.css" rel="stylesheet" type="text/css" />
<body>
<table winth="1000" border="0">
	<tr>
		<td colspan="2"><font color=blue>若您無法正常觀看此報表！請下載此 <a href="owc11.zip" target="_File"><font color=red><b>元件</b></font></a> <font color=blue>安裝至您的電腦。</font></td>
	</tr>
</table>
<object id=ProjectAccounting classid=CLSID:0002E559-0000-0000-C000-000000000046 style="width:100%;height:90%"></object>
<script language=vbscript>
	Sub Window_OnLoad()
	Set chConstants = ProjectAccounting.Constants
	ProjectAccounting.ActiveSheet.Cells.Clear
	ProjectAccounting.Worksheets(1).Select
	ProjectAccounting.ActiveSheet.Name ="ProjectAccounting"

	ProjectAccounting.ActiveSheet.Cells(1,1).Value ="<?php echo $MFTypeTxt;?>"
	<?php
	$tmp=2;
	//$SQL_Manager="select MUID,MName from Manager where Deltag='N' order by MID;";
	$SQL_Manager="select MUID,MName from Manager where Deltag='N' and IsLeft='N' order by MID;";
	$result_Manager=mysqli_query($link,$SQL_Manager) or die ("無法執行查詢");
	while(list($MUID,$MName)=mysqli_fetch_row($result_Manager)){
		?>
		ProjectAccounting.ActiveSheet.Cells(1,<?php echo $tmp?>).Value ="<?php echo $MName;?>"
		<?php
		$tmp++;
		}
	mysqli_free_result($result_Manager);
	$ECount=2;
	for($day=1;$day<=$MFDay;$day++){
		?>
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,1).Value ="'<?php echo $MFYear."-".$MFMonth."-".$day;?>"
		<?php
		//$SQL_Manager="select MUID,ifnull((select sum(Quantity) from ManagerFees where Deltag='N' and MFCheck='Y' and MFType='".$MFType."' and MUID=Manager.MUID and MFDate='".$MFYear."-".$MFMonth."-".$day."'),0) Quantity from Manager where Deltag='N' order by MID;";
		$SQL_Manager="select MUID,ifnull((select sum(Quantity) from ManagerFees where Deltag='N' and IsLeft='N' and MFCheck='Y' and MFType='".$MFType."' and MUID=Manager.MUID and MFDate='".$MFYear."-".$MFMonth."-".$day."'),0) Quantity from Manager where Deltag='N' and IsLeft='N' order by MID;";
		$result_Manager=mysqli_query($link,$SQL_Manager) or die ("無法執行查詢");
		$tmp=2;
		while(list($MUID,$Quantity)=mysqli_fetch_row($result_Manager)){
			?>
			ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,<?php echo $tmp;?>).Value ="<?php echo $Quantity;?>"
			<?php
			$QuantitySum[$MUID]=$QuantitySum[$MUID]+$Quantity;
			$tmp++;
			}
		mysqli_free_result($result_Manager);
			?>
		<?php 
		$ECount++;
		}
	?>
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,1).Value ="總計"
		<?php
		$tmp=2;
		//$SQL_Manager="select MUID,MName from Manager where Deltag='N' order by MID;";
		$SQL_Manager="select MUID,MName from Manager where Deltag='N' and IsLeft='N' order by MID;";
		$result_Manager=mysqli_query($link,$SQL_Manager) or die ("無法執行查詢");
		while(list($MUID,$MName)=mysqli_fetch_row($result_Manager)){
			?>
			ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,<?php echo $tmp?>).Value ="<?php echo $QuantitySum[$MUID];?>"
			<?php
			$tmp++;
			}
		mysqli_free_result($result_Manager);
		?>
		ProjectAccounting.ActiveSheet.Range("A1:ZZ<?php echo $ECount;?>").Font.Color="blue"
		ProjectAccounting.ActiveSheet.Range("A1:ZZ<?php echo $ECount;?>").Font.Name="Courier New"
		ProjectAccounting.ActiveSheet.Range("A1:ZZ<?php echo $ECount;?>").Font.Size="11"
		ProjectAccounting.ActiveSheet.Range("A1:ZZ<?php echo $ECount;?>").Columns.AutoFit
		ProjectAccounting.ActiveSheet.Range("A1:ZZ<?php echo $ECount;?>").NumberFormat ="General"

		ProjectAccounting.ActiveSheet.Range("A1:ZZ1").Font.Bold=true
		ProjectAccounting.ActiveSheet.Range("A1:ZZ1").Font.Color="#000000"
		ProjectAccounting.ActiveSheet.Range("A1:ZZ1").Font.Bold=true
		ProjectAccounting.ActiveSheet.Range("A1:ZZ1").Font.Bold=true
		ProjectAccounting.ActiveSheet.Range("A1:ZZ1").Font.Bold=true

	End Sub
	</script>
</body>
</html>