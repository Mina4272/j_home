﻿<?php	
include "CheckPermission.php";
include "CheckProjectAccounting.php";
include "../global.php";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $PageAdminTitle;?></title>
<link href="../type.css" rel="stylesheet" type="text/css" />
<style type="text/css">
<!--
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
}
-->
</style>
<link href="../script/DatePicker.css" rel="stylesheet" type="text/css" />
<Script LANGUAGE="Javascript" SRC="../script/DatePicker.js"></Script>
<Script type="text/javascript" language="javascript" src="../script/CheckForm.js"></Script>
<script type="text/JavaScript">
<!--
function jsCheck() 
		{
		if (ChkImp('Invoice',document.form1.Invoice.value,'發票號碼') == false) return false;
		//if (ChkDate('InvoiceYear',document.form1.InvoiceYear.value,document.form1.InvoiceMonth.value,document.form1.InvoiceDay.value,'發票日期') == false) return false;
		if (ChkDate('PAYear',document.form1.PAYear.value,document.form1.PAMonth.value,document.form1.PADay.value,'結清日期') == false) return false;
		}
//-->
</script>
</head>
<body>
<?php include "top.php";?>
<table width="100%" border="0" cellspacing="0" cellpadding="5">
	<tr>
    <td width="160" height="600" align="left" valign="top">
			<?php include "menu.php";?>
    </td>
    <td valign="top">
    	<table width="100%" border="0" cellpadding="0" cellspacing="0">
    		<tr>
    			<td>
			    	<table width="750" border="0" cellpadding="0" cellspacing="0">
			    		<tr height="30">
			    			<td class="c2"><a href="ProjectAccounting.php">客戶案件帳務管理</a> &gt; 單一發票結清</td>
			    		</tr>
			    	</table>
			    	<table width="750" border="0" cellpadding="0" cellspacing="0">
			        <form name="form1" method="post" action="ProjectAccountingInvoiceDB.php" onSubmit="return jsCheck();">
			        <tr height="35" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">發票號碼：</td>
			          <td class="h3">
			          	<input type="text" id="Invoice" name="Invoice" size="20"> 
			          	<font color=red><b>註：此功能只結清待收(未付)之帳務資料</b></font>
			          </td>
			        </tr>
			        <!--<tr height="35" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">發票日期：</td>
			          <td class="h3">
		              <input id="InvoiceYear" name="InvoiceYear" type="text" size="4" /> 年 
		              <input id="InvoiceMonth" name="InvoiceMonth" type="text" size="2" /> 月 
		              <input id="InvoiceDay" name="InvoiceDay" type="text" size="2" /> 日 
		              <img src="../images/icon.gif" width="16" height="18" style="cursor: hand" onclick="javascript:displayDatePicker('InvoiceYear','InvoiceMonth','InvoiceDay');"/>
			          </td>
			        </tr>-->
			        <tr height="35" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">結清日期：</td>
			          <td class="h3">
		              <input id="PAYear" name="PAYear" type="text" size="4" /> 年 
		              <input id="PAMonth" name="PAMonth" type="text" size="2" /> 月 
		              <input id="PADay" name="PADay" type="text" size="2" /> 日 
		              <img src="../images/icon.gif" width="16" height="18" style="cursor: hand" onclick="javascript:displayDatePicker('PAYear','PAMonth','PADay');"/>
			          </td>
			        </tr>
			        <tr height="35" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">對帳編號：</td>
			          <td class="h3">
			          	<input type="text" id="PANo" name="PANo" size="20">
			          </td>
			        </tr>
			        <tr height="35" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">備 註：</td>
			          <td class="h3">
			          	<input type="text" id="PANote" name="PANote" size="80">
			          </td>
			        </tr>
			        <tr height="40" align="center">
			          <td colspan="2" class="h3"><input type="submit" name="submit" class="input_bot" value="送 出"></td>
			        </tr>
				      </form>
			      </table>
    			</td>
    		</tr>
    	</table>
    </td>
	</tr>
</table>
<?php include "down.php";?>
</body>
</html>
<?php
mysqli_close($link);
?>