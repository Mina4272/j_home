﻿<?php
include "CheckPermission.php";
include "CheckProject.php";
include "../global.php";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $PageAdminTitle;?></title>
</head>
<body>
<?php
$PID = $_POST['PID'];
$PContent = $_POST['PContent'];
$PContent = str_replace("\r\n","<br>",$PContent);
if (trim($PID) == "" || trim($PContent) == "")
		{
		mysqli_close($link);
		?>
		<script type="text/JavaScript">
			<!--
			alert ("您輸入的資料不足，請重新輸入！");
			self.close();
			//-->
		</script>
		<?php
		exit;
		}
date_default_timezone_set("Asia/Taipei");
$now_time = date("Y-m-d H:i:s",mktime());
//echo $now_time;
//exit;
$sql_insert = "insert into ProjectNote (PID,PContent,AddUser,AddDate,AddIP) values ('".$PID."','".addslashes($PContent)."','".$_SESSION["reg_MUID"]."','".$now_time."','".$_SERVER["REMOTE_ADDR"]."');";
$result_insert=mysqli_query($link,$sql_insert) or die ("無法執行新增");

mysqli_close($link);
?>
<script type="text/JavaScript">
	<!--
	alert ("新增成功！");
	opener.location.reload();
	self.close();
	//-->
</script>

</body>
</html>
