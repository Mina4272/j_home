<?php	
include "CheckPermission.php";
//include "CheckAgendum.php";
include "../global.php";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $PageAdminTitle;?></title>
<link href="../type.css" rel="stylesheet" type="text/css" />
<style type="text/css">
<!--
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
}
-->
</style>
<link href="../script/DatePicker.css" rel="stylesheet" type="text/css" />
<Script LANGUAGE="Javascript" SRC="../script/DatePicker.js"></Script>
<Script type="text/javascript" language="javascript" src="../script/CheckForm.js"></Script>
<script type="text/JavaScript">
<!--
function jsCheck() 
		{
		if (ChkImp('DC_cycle',document.form1.DC_cycle.value,'校驗週期') == false) return false;
		if (ChkDate('DCYear',document.form1.DCYear.value,document.form1.DCMonth.value,document.form1.DCDay.value,'校驗日期') == false) return false;
		if (ChkImp('D_status',document.form1.D_status.value,'儀器狀態') == false) return false;
		if (ChkImp('DC_Note',document.form1.DC_Note.value,'備註') == false) return false;
		}
//-->
</script>
</head>
<body>
<?php
$device_no = $_GET['device_no'];
if (trim($device_no) == "")
		{
		mysqli_close($link);
		?>
		<script type="text/JavaScript">
			<!--
			alert ("查無資料，請冾網站管理人員！");
			self.close();
			//-->
		</script>
		<?php
		exit;
		}
?>
<table width="100%" border="0" cellpadding="0" cellspacing="0">
	<tr>
		<td>
    	<table width="100%" border="0" cellpadding="0" cellspacing="0">
    		<tr height="30">
					<td width="15" background="../images/table_bg.gif"></td>
    			<td class="c3" background="../images/table_bg.gif"><b>新增儀器校驗紀錄</b></td>
    		</tr>
    	</table>
    	<table width="100%" border="0" cellpadding="0" cellspacing="0">
        <form name="form1" method="post" action="DeviceCheckAddDB.php" onSubmit="return jsCheck();">
        <tr onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
		  <td class="c3" width="60">校驗<br/>週期:</td>
		  <td class="h3"><input type="text" id="DC_cycle" name="DC_cycle" size="60"></td>
        </tr>
		<tr  onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td width="auto" class="c3">校驗<br/>日期:</td>
			          <td class="h3">
		              <input id="DCYear" name="DCYear" type="text" size="4" /> 年 
		              <input id="DCMonth" name="DCMonth" type="text" size="2" /> 月 
		              <input id="DCDay" name="DCDay" type="text" size="2" /> 日 
		              <img src="../images/icon.gif" width="16" height="18" style="cursor: hand" onclick="javascript:displayDatePicker('DCYear','DCMonth','DCDay');"/>
			          </td>
			        </tr>
		<tr  onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
		  <td width="auto" class="c3">儀器<br/>狀態：</td>
		  <td class="h3"><input type="text" id="D_status" name="D_status" size="60"></td>
        </tr>
		<tr  onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
	      <td width="auto" class="c3">校驗<br/>結果：</td>
		  <td class="h3">
			<input type="radio" id="DC_result" name="DC_result" value="Y" checked>符合
			<input type="radio" id="DC_result" name="DC_result" value="N">不符合
		  </td>
        </tr>
        <tr  onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
					<td width="auto" class="c3">備註:</td>
          <td class="h3">
          	<textarea id="DC_Note" name="DC_Note" cols="60" rows="10" class="h3"></textarea>
          	<input name="device_no" type="hidden" id="device_no" value="<?php echo $device_no;?>" />
          </td>
        </tr>
        <tr height="40" align="center">
			<td width="15"></td>
          <td class="h3"><input type="submit" name="submit" class="input_bot" value="送 出"></td>
        </tr>
	      </form>
      </table>
		</td>
	</tr>
</table>
</body>
</html>
<?php
mysqli_close($link);
?>