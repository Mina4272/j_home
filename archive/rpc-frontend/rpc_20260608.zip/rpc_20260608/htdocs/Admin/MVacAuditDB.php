﻿<?php
include "CheckPermission.php";
include "CheckMVac.php";
include "../global.php";
require_once("../include/chinese_party.class.php");
require("class.phpmailer.php");
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $PageAdminTitle;?></title>
</head>
<body>
<?php
$MVCheckAns = $_POST['MVCheckAns'];
$MVCNote = $_POST['MVCNote'];
$MVID = $_POST['MVID'];

if (trim($MVID) == "" || trim($MVCheckAns) == "")
		{
		mysqli_close($link);
		?>
		<script type="text/JavaScript">
			<!--
			alert ("您輸入的資料不足，請重新輸入！");
			history.go(-1);
			//-->
		</script>
		<?php
		exit;
		}

$SQL_ManagerVac="select (select MID from Manager where DELTAG='N' and MUID=ManagerVac.MUID) MID,MUID,MVType,MVSDate,MVEDate,Hourage,Agent,MVNote,MVCheck from ManagerVac where Deltag='N' and MVID=".$MVID.";";
$result_ManagerVac=mysqli_query($link,$SQL_ManagerVac) or die ("無法執行查詢");
if (mysqli_num_rows($result_ManagerVac) == 0)
		{
		mysqli_free_result($result_Manager);
		mysqli_close($link);
		?>
		<SCRIPT language=javascript>
		<!--
		alert ("查無資料，請冾網站管理人員！"); 
		self.close();
		//-->
		</SCRIPT>
		<?php 	
		exit;
		}
list($MID,$MUID,$MVType,$MVSDate,$MVEDate,$Hourage,$Agent,$MVNote,$MVCheck)=mysqli_fetch_row($result_ManagerVac);
mysqli_free_result($result_ManagerVac);

if (trim($MVCheck) != "W")
		{
		mysqli_close($link);
		?>
		<script type="text/JavaScript">
			<!--
			alert ("此請假單已簽核，不需再作簽核！");
			self.close();
			//-->
		</script>
		<?php
		exit;
		}

$now_time = date("Y-m-d H:i:s",mktime());
if (trim($MVType) == "G" && trim($MVCheckAns) == "Y") {
		$sql_insert = "insert into EmployeeVacation (MID,EVType,MVID,EVCount,EVDesc,AddUser,AddDate,AddIP) values (".$MID.",'B',".$MVID.",-".($Hourage/8).",'','".$_SESSION["reg_MUID"]."',now(),'".$_SERVER["REMOTE_ADDR"]."');";
		$result_insert=mysqli_query($link,$sql_insert) or die ("無法執行新增");
		}
$sql_insert = "INSERT INTO ManagerVacHistory(MVID,MUID,MVType,MVSDate,MVEDate,Hourage,Agent,MVNote,MVSend,MVCheck,MVCNote,MVCheckID,MVCheckDate,MVCheckIP,AddUser,AddDate,AddIP,Deltag,ProcUser,ProcDate,ProcIP,UpdateUser,UpdateDate,UpdateIP) SELECT MVID,MUID,MVType,MVSDate,MVEDate,Hourage,Agent,MVNote,MVSend,MVCheck,MVCNote,MVCheckID,MVCheckDate,MVCheckIP,AddUser,AddDate,AddIP,Deltag,ProcUser,ProcDate,ProcIP,'".$_SESSION["reg_MUID"]."','".$now_time."','".$_SERVER["REMOTE_ADDR"]."' from ManagerVac where Deltag='N' and MVID=".$MVID.";";
$result_insert=mysqli_query($link,$sql_insert) or die ("無法執行新增");
$sql_update = "update ManagerVac set MVCheck = '".$MVCheckAns."',MVCNote = '".$MVCNote."',MVCheckID = '".$_SESSION["reg_MUID"]."',MVCheckDate = '".$now_time."',MVCheckIP = '".$_SERVER["REMOTE_ADDR"]."',ProcUser = '".$_SESSION["reg_MUID"]."',ProcDate = '".$now_time."',ProcIP = '".$_SERVER["REMOTE_ADDR"]."' where Deltag='N' and MVID=".$MVID.";";
$result_update=mysqli_query($link,$sql_update) or die ("無法執行修改");

if (trim($MVType) == "A") $MVType="事假";
else if (trim($MVType) == "B") $MVType="病假";
else if (trim($MVType) == "C") $MVType="公假";
else if (trim($MVType) == "D") $MVType="喪假";
else if (trim($MVType) == "E") $MVType="婚假";
else if (trim($MVType) == "F") $MVType="產假";
else if (trim($MVType) == "G") $MVType="特休";
else if (trim($MVType) == "H") $MVType="其他";

if (trim($MVCheckAns) == "Y") $MVCheckAns="同意";
else if (trim($MVCheckAns) == "Y") $MVCheckAns="不同意";

$SQL_Manager="select MName,EMail from Manager where MUID='".$MUID."'and Deltag='N';";
$result_Manager=mysqli_query($link,$SQL_Manager) or die ("無法執行查詢");
list($MName,$EMail)=mysqli_fetch_row($result_Manager);
mysqli_free_result($result_Manager);

$SQL_Manager="select MName,EMail from Manager where MUID='".$Agent."'and Deltag='N';";
$result_Manager=mysqli_query($link,$SQL_Manager) or die ("無法執行查詢");
list($AMName,$AEMail)=mysqli_fetch_row($result_Manager);
mysqli_free_result($result_Manager);

$EMAILFN = "MVacAudit.htm";
$subject="請假申請審核通知 ！！";
$fp=fopen($EMAILFN,"r");
$content="";
while($line=fgets($fp,512)){
	$content.=$line;
	}
fclose($fp);

$content = str_replace("{MName}",$MName.$MUID,$content);
$content = str_replace("{MVType}",$MVType,$content);
$content = str_replace("{MVDate}",$MVSDate." ~ ".$MVEDate,$content);
$content = str_replace("{Hourage}",$Hourage,$content);
$content = str_replace("{Agent}",$AMName,$content);
$content = str_replace("{MVNote}",$MVNote,$content);

$content = str_replace("{MVCheck}",$MVCheckAns,$content);
$content = str_replace("{MVCheckID}",$_SESSION["reg_MName"],$content);
$content = str_replace("{MVCheckDate}",$now_time,$content);
$content = str_replace("{MVCNote}",$MVCNote,$content);

//$cconv =& new chinese_party();
//$content = $cconv->u82tchi($content);
//$subject = $cconv->u82tchi($subject);

$mail = new PHPMailer();
$mail->IsSMTP();
$mail->SMTPAuth = true; //設定SMTP需要驗證
$mail->SMTPSecure = "ssl"; // Gmail的SMTP主機需要使用SSL連線
$mail->Host = "smtp.gmail.com"; //Gamil的SMTP主機
$mail->Port = 465; //Gamil的SMTP主機的埠號(Gmail為465)。
$mail->CharSet = "utf-8"; //郵件編碼
$mail->Username = "Benson@rpclab.com"; //Gamil帳號
$mail->Password = "76197619"; //Gmail密碼
$mail->From     = "Benson@rpclab.com";
$mail->FromName = $subject;
$mail->WordWrap = 50;
$mail->IsHTML(true);                               // send as HTML
//$mail->CharSet = "big5";
$mail->Subject  = $subject;
$mail->Body     =  $content;
$mail->AddAddress($EMail,"");
$mail->AddBCC($AEMail);
$mail->AddReplyTo("Benson@rpclab.com");
if(!$mail->Send())
		{
    //echo "There has been a mail error sending to " . $EMail . "<br>";
    //echo "Mailer Error: " . $mail->ErrorInfo . "<br>";
  	}
else
		{
		//echo $EMail . " sending !!<br>";
		}
		
$mail->ClearAddresses();
$mail->ClearReplyTos();
$mail->SmtpClose();

mysqli_close($link);
?>
<script type="text/JavaScript">
	<!--
	alert ("簽核完成！");
	opener.location.reload();
	self.close();
	//-->
</script>

</body>
</html>
