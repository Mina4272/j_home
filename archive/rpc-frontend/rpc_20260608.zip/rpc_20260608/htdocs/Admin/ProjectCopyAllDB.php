﻿<?php
include "CheckPermission.php";
include "CheckProject.php";
include "../global.php";
require_once("../include/chinese_party.class.php");
require("class.phpmailer.php");
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $PageAdminTitle;?></title>
</head>
<body>
<?php
$TCID = $_POST['TCID'];

if (trim($TCID) == "")
		{
		mysqli_close($link);
		?>
		<script type="text/JavaScript">
			<!--
			alert ("您輸入的資料不足，請重新輸入！");
			self.close();
			//-->
		</script>
		<?php
		exit;
		}
$SQL="select TCID from training where Deltag='N' and TCID = '".$TCID."';";
$result=mysqli_query($link,$SQL) or die ("無法執行查詢");
if (mysqli_num_rows($result) == 0)
		{
		mysqli_free_result($result);
		mysqli_close($link);
		?>
		<SCRIPT language=javascript>
		<!--
		alert ("查無資料，請冾網站管理人員！"); 
		self.close();
		//-->
		</SCRIPT>
		<?php 	
		exit;
		}
		
$TDate = date("Y-m-d");
$now_time = date("Y-m-d H:i:s",mktime());		

$SQL="INSERT INTO training (TDate,TCID,TTitle,Lecturer,TLocation,othertext,TTrain,outtext,THour,TExam,othernote,TFile,TContent,TTrainRecord,AddUser,AddDate,AddIP) select '".$TDate."',TCID,TTitle,Lecturer,TLocation,othertext,TTrain,outtext,THour,TExam,othernote,TFile,TContent,TTrainRecord,'".$_SESSION["reg_MUID"]."','".$now_time."','".$_SERVER["REMOTE_ADDR"]."' from training where Deltag='N' and TCID = '".$TCID."';";
$result=mysqli_query($link,$SQL) or die ("無法執行查詢");
mysqli_close($link);
?>
<script type="text/JavaScript">
	<!--
	alert ("複製課程新增成功！");
	self.close();
	//-->
</script>

</body>
</html>
