﻿<?php
include "CheckPermission.php";
include "CheckCustomer.php";
include "include/function.php";
include "../global.php";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $PageAdminTitle;?></title>
</head>
<body>
<?php
$TID = $_POST['TID'];
$MID = $_POST['MID'];
$Grade = $_POST['Grade'];
$CheckGrade=$_POST['CheckGrade'];

if (trim($TID) == "" || trim($MID) == "" || trim($Grade) == "" || trim($CheckGrade) == "")
		{
		mysqli_close($link);
		?>
		<script type="text/JavaScript">
			<!--
			alert ("您輸入的資料不足，請重新輸入！");
			self.close();
			//-->
		</script>
		<?php
		exit;
		}
$SQL="select * from trainingexam where Deltag='N' and MID = '".$MID."' and TID = '".$TID."';";
$result=mysqli_query($link,$SQL) or die ("無法執行查詢");
if (mysqli_num_rows($result) == 0)
		{
		mysqli_free_result($result);
		mysqli_close($link);
		?>
		<SCRIPT language=javascript>
		<!--
		alert ("查無資料，請冾網站管理人員！"); 
		self.close();
		//-->
		</SCRIPT>
		<?php 	
		exit;
		}
mysqli_free_result($result);

$now_time = date("Y-m-d H:i:s",mktime());
if(trim($_FILES['TEFile']['tmp_name']) != "")
		{
		if($_FILES['TEFile']['size'] > 20971520)
				{
				?>
				<script type="text/JavaScript">
					<!--
					alert ("您上傳的檔案 Size 超過 20 M，請重新上傳！");
					history.go(-1);
					//-->
				</script>
				<?php
				exit();
				}
		$TEFile = "TEFile_".date("ymdHis",mktime()).rand_string(5, 'ABCDEFGHIJKLMNPQRSTUVWXYZ23456789abcdefghijklmnopqrstuvwxyz').".".strtolower(substr($_FILES['TEFile']['name'],strrpos($_FILES['TEFile']['name'],".")+1,strlen($_FILES['TEFile']['name'])+1));
		@copy($_FILES['TEFile']['tmp_name'],$_SERVER["DOCUMENT_ROOT"]."\\Admin\\TEFile\\".$TEFile);
		}
if (trim($TEFile) != "") $SqlTxt = ",TEFile='".$TEFile."'";
//$sql_insert = "INSERT INTO CustomerContactHistory(CCID,CID,Contact,CMobile,CEMail,CDep,CNote,AddUser,AddDate,AddIP,Deltag,ProcUser,ProcDate,ProcIP,UpdateUser,UpdateDate,UpdateIP) SELECT CCID,CID,Contact,CMobile,CEMail,CDep,CNote,AddUser,AddDate,AddIP,Deltag,ProcUser,ProcDate,ProcIP,'".$_SESSION["reg_MUID"]."','".$now_time."','".$_SERVER["REMOTE_ADDR"]."' FROM CustomerContact where Deltag='N' and CID = '".$CID."' and CCID = '".$CCID."';";
//$result_insert=mysqli_query($link,$sql_insert) or die ("無法執行新增");
$sql_update = "update trainingexam set Grade='".$Grade."',CheckGrade='".$CheckGrade."',ProcUser = '".$_SESSION["reg_MUID"]."',ProcDate = '".$now_time."',ProcIP = '".$_SERVER["REMOTE_ADDR"]."'".$SqlTxt." where Deltag='N' and TID = '".$TID."' and MID = '".$MID."';";
$result_update=mysqli_query($link,$sql_update) or die ("無法執行修改");

mysqli_close($link);
?>
<script type="text/JavaScript">
	<!--
	alert ("修改成功！");
	opener.location.reload();
	self.close();
	//-->
</script>

</body>
</html>
