﻿<?php
include "CheckPermission.php";
include "CheckPartLibrary.php";
include "../global.php";
include "include/function.php";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $PageAdminTitle;?></title>
<link href="../type.css" rel="stylesheet" type="text/css" />
</head>

<body>
<?php
//echo "PartCertification=".$HTTP_POST_FILES['PartCertification']['tmp_name']."<br>";
//if(file_exists($HTTP_POST_FILES['PartCertification']['tmp_name'])) echo "true";
//else echo "false";
$PartCertification = "PartCertification_".rand_string(12, 'ABCDEFGHIJKLMNPQRSTUVWXYZ23456789abcdefghijklmnopqrstuvwxyz').".".strtolower(substr($_FILES['PartCertification']['name'],strrpos($_FILES['PartCertification']['name'],".")+1,strlen($_FILES['PartCertification']['name'])+1));
//if(file_exists($HTTP_POST_FILES['PartCertification']['tmp_name']))
if(trim($_FILES['PartCertification']['tmp_name']) != "")
		{
		if($_FILES['PartCertification']['size'] > 20971520)
				{
				?>
				<script type="text/JavaScript">
					<!--
					alert ("您上傳的檔案 Size 超過 20 M，請重新上傳！");
					location.href='PartCertificationUpload.php';
					//-->
				</script>
				<?php
				exit();
				}

		@copy($_FILES['PartCertification']['tmp_name'],$_SERVER["DOCUMENT_ROOT"]."\\Admin\\PartCertification\\".$PartCertification);
		mysqli_close($link);
		?>
		<SCRIPT language=javascript>
		<!--
				alert ("上傳成功！"); 
				opener.document.form1.PartCertification.value='<?php echo $PartCertification;?>';
				opener.document.getElementById('PartCertificationPreview').style.display = '';
				opener.document.getElementById('PartCertificationPreview').innerHTML = '<a href="getfile.php?FolderName=Admin\\PartCertification&FileName=<?php echo $PartCertification;?>">預覽</a>';
				opener.document.getElementById('PartCertificationDel').style.display = '';
				opener.document.getElementById('PartCertificationDel').innerHTML = '<a href="javascript:;" onclick="javascript:DelPartCertification();">刪除</a>';
				self.close();
		//-->
		</SCRIPT>
		<?php
		}
else
		{
		mysqli_close($link);
		?>
		<SCRIPT language=javascript>
		<!--
				alert ("上傳失敗！"); 
				self.close();
		//-->
		</SCRIPT>
		<?php
		}
?>
</body>
</html>
