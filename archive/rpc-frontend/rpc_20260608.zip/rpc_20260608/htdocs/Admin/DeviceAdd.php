﻿<?php	
include "CheckPermission.php";
//include "CheckAgendum.php";
include "../global.php";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $PageAdminTitle;?></title>
<link href="../type.css" rel="stylesheet" type="text/css" />
<style type="text/css">
<!--
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
}
-->
</style>
<link href="../script/DatePicker.css" rel="stylesheet" type="text/css" />
<Script LANGUAGE="Javascript" SRC="../script/DatePicker.js"></Script>
<Script type="text/javascript" language="javascript" src="../script/CheckForm.js"></Script>
<script type="text/JavaScript">
function jsCheck() 
		{
		if (ChkDate('DYear',document.form1.DYear.value,document.form1.DMonth.value,document.form1.DDay.value,'儀器購入日期') == false) return false;
		if (jsTrim(document.form1.DYear.value) != "" || jsTrim(document.form1.DMonth.value) != "" || jsTrim(document.form1.DDay.value) != "") if (ChkDate('DYear',document.form1.DYear.value,document.form1.DMonth.value,document.form1.DDay.value,'儀器購入日期') == false) return false;
		if (ChkImp('device_name_english',document.form1.device_name_english.value,'儀器名稱(英文)') == false) return false;
		if (ChkImp('device_name_chinese',document.form1.device_name_chinese.value,'儀器名稱(中文)') == false) return false;
		if (ChkImp('device_label',document.form1.device_label.value,'廠牌') == false) return false;
		if (ChkImp('device_model',document.form1.device_model.value,'儀器型號') == false) return false;
		if (ChkImp('device_serial',document.form1.device_serial.value,'儀器序號') == false) return false;
		if (ChkImp('device_specification',document.form1.device_specification.value,'儀器規格') == false) return false;
		if (ChkImp('device_money',document.form1.device_money.value,'儀器採購金額') == false) return false;
		
		}


</script>
</head>
<body>
<?php include "top.php";?>
<table width="100%" border="0" cellspacing="0" cellpadding="5">
	<tr>
    <td width="160" height="600" align="left" valign="top">
			<?php include "menu.php";?>
    </td>
    <td valign="top">
    	<table width="100%" border="0" cellpadding="0" cellspacing="0">
    		<tr>
    			<td>
			    	<table width="750" border="0" cellpadding="0" cellspacing="0">
			    		<tr height="30">
			    			<td class="c2"><b>儀器設備管理</b></td>
			    		</tr>
			    	</table>
			    	<table width="1000" border="0" cellpadding="0" cellspacing="0">
			        <form name="form1" method="post" action="DeviceAddDB.php" onSubmit="return jsCheck();">
			        <?php
							$SQL_Manager="select MUID,MName,MEName from Manager where Deltag='N' and IsLeft='N';";
							$result_Manager=mysqli_query($link,$SQL_Manager) or die ("無法執行查詢");
			        ?>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td width="150" align="right" class="c3"><font color=red><b>*</b></font>儀器負責人</td>
			          <td class="h3">
			          	<select id="device_people" name="device_people" >
			          		<?php while(list($MUID,$MName,$MEName)=mysqli_fetch_row($result_Manager)){?>
			          		<option value="<?php echo $MName;?>"<?php if (trim(strtolower($MUID))==trim(strtolower($_SESSION["reg_MUID"]))) echo " selected";?>><?php echo $MEName.$MName;?></option>
			          		<?php }?>
			          	</select>
			          </td>
			        </tr>
			        <?php mysqli_free_result($result_Manager);?>
					<tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3"><font color=red><b>*</b></font>儀器名稱(中文)：</td>
			          <td class="h3"><input type="text" id="device_name_chinese" name="device_name_chinese" size="60"></td>
			        </tr>
					<tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3"><font color=red><b>*</b></font>儀器名稱(英文)：</td>
			          <td class="h3"><input type="text" id="device_name_english" name="device_name_english" size="60"></td>
			        </tr>
			       
			        
					<tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3"><font color=red><b>*</b></font>儀器廠牌:</td>
			          <td class="h3"><input type="text" id="device_label" name="device_label" size="60"></td>
			        </tr>
					<tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3"><font color=red><b>*</b></font>儀器型號:</td>
			          <td class="h3"><input type="text" id="device_model" name="device_model" size="60"></td>
			        </tr>
					<tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3"><font color=red><b>*</b></font>儀器序號:</td>
			          <td class="h3"><input type="text" id="device_serial" name="device_serial" size="60"></td>
			        </tr>
					<tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3"><font color=red><b>*</b></font>儀器規格:</td>
			          <td class="h3"><input type="text" id="device_specification" name="device_specification" size="60"></td>
			        </tr>
					<tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3"><font color=red><b>*</b></font>儀器購入日期:</td>
			          <td class="h3">
		              <input id="DYear" name="DYear" type="text" size="4" /> 年 
		              <input id="DMonth" name="DMonth" type="text" size="2" /> 月 
		              <input id="DDay" name="DDay" type="text" size="2" /> 日 
		              <img src="../images/icon.gif" width="16" height="18" style="cursor: hand" onclick="javascript:displayDatePicker('DYear','DMonth','DDay');"/>
			          </td>
			        </tr>
					<tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3"><font color=red><b>*</b></font>儀器採購金額:</td>
			          <td class="h3"><input type="text" id="device_money" name="device_money" size="60"></td>
			        </tr>
					 <tr id="CheckCustomer" height="35" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">供應商：</td>
			          <td class="h3">
						    	<table width="100%" border="0" cellpadding="0" cellspacing="0">
						       <tr height="30">
						          <td width="90" align="right" class="c3">客戶名稱：</td>
						          <td class="h3">
						          	<table width="100%" border="0" cellpadding="0" cellspacing="0">
						          		<tr>
						          			<td><div id="CNamePreview" style="display:none"></div></td>
						          			<td>
									          	<input type="hidden" id="CID" name="CID">
									          	<input type="hidden" id="CName" name="CName">
									          	<input type="button" id="SelCID" name="SelCID" class="input_bot" value="請選擇" onclick="javascript:window.open ('SelCustomer.php?QCType=P','SelCustomer','height=300,width=550,top=200,left=200,scrollbars=yes,status=yes');">
						          			</td>
						          		</tr>
						          	</table>
						          	
						          </td>
						        </tr>
						        <tr height="30">
						          <td align="right" class="c3">客戶電話：</td>
						          <td class="h3">
						          	<table width="100%" border="0" cellpadding="0" cellspacing="0">
						          		<tr>
						          			<td width="150">
						          				<div id="CTelPreview" style="display:none"></div>
									          	<input type="hidden" id="CTel" name="CTel">
						          			</td>
						          			<td width="60" align="right" class="c3">傳真：</td>
						          			<td>
						          				<div id="CFaxPreview" style="display:none"></div>
						          				<input type="hidden" id="CFax" name="CFax">
						          				<input type="hidden" id="Contact" name="Contact" size="20">
						          				<input type="hidden" id="CMobile" name="CMobile" size="20">
						          				<input type="hidden" id="CEMail" name="CEMail" size="60">
						          			</td>
						          		</tr>
						          	</table>
						          </td>
						        </tr>
						        <tr height="30">
						          <td align="right" class="c3">客戶地址：</td>
						          <td class="h3">
						          	<div id="CAddressPreview" style="display:none"></div>
						          	<input type="hidden" id="CAddress" name="CAddress">
						          </td>
						        </tr>
						      </table>
			          </td>
			        </tr>
			        <tr height="40" align="center">
			          <td colspan="2" class="h3">
			          	
			          	<input type="submit" name="submit" class="input_bot" value="送 出">
			          </td>
			        </tr>
					<?php						
						
						$code = 0;  
						$_SESSION['code'] = $code;
						
						
					  ?>
					  <td><input type="hidden" name="code" value="0"></td>
				      </form>
			      </table>
    			</td>
    		</tr>
    	</table>
    </td>
	</tr>
</table>
<?php include "down.php";?>
</body>
</html>
<?php
mysqli_close($link);
?>