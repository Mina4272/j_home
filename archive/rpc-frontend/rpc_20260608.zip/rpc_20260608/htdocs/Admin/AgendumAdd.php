﻿<?php	
include "CheckPermission.php";
include "CheckAgendum.php";
include "../global.php";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $PageAdminTitle;?></title>
<link href="../type.css" rel="stylesheet" type="text/css" />
<style type="text/css">
<!--
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
}
-->
</style>
<link href="../script/DatePicker.css" rel="stylesheet" type="text/css" />
<Script LANGUAGE="Javascript" SRC="../script/DatePicker.js"></Script>
<Script type="text/javascript" language="javascript" src="../script/CheckForm.js"></Script>
<script type="text/JavaScript">
<!--
function jsCheck() 
		{
		if (ChkDate('AYear',document.form1.AYear.value,document.form1.AMonth.value,document.form1.ADay.value,'派案時間') == false) return false;
		if (ChkDate('AEYear',document.form1.AEYear.value,document.form1.AEMonth.value,document.form1.AEDay.value,'預計完成時間') == false) return false;
		if (jsTrim(document.form1.ACYear.value) != "" || jsTrim(document.form1.ACMonth.value) != "" || jsTrim(document.form1.ACDay.value) != "") if (ChkDate('ACYear',document.form1.ACYear.value,document.form1.ACMonth.value,document.form1.ACDay.value,'結案時間') == false) return false;
		if (ChkImp('AItem',document.form1.AItem.value,'項目/測試項目') == false) return false;
		if (jsTrim(document.form1.PID.value) == "" && document.form1.Attribute.selectedIndex == 0)
				{
				alert ('請選擇連結案件！');
				document.form1.SelPID.focus();
				return false;
				}
		//if (jsTrim(document.form1.CName.value) == "")
		//		{
		//		alert ('請選擇所屬客戶！');
		//		document.form1.SelCID.focus();
		//		return false;
		//		}
		}
function ChkAttribute() 
		{
		document.getElementById('PNamePreview').style.display = 'none';
		document.getElementById('PNamePreview').innerHTML = '';
		document.form1.PID.value='';
		document.getElementById('CNamePreview').style.display = 'none';
		document.getElementById('CNamePreview').innerHTML = '';
		document.form1.CID.value='';
		document.form1.CName.value='';
		document.getElementById('CTelPreview').style.display = 'none';
		document.getElementById('CTelPreview').innerHTML = '';
		document.form1.CTel.value='';
		document.getElementById('CFaxPreview').style.display = 'none';
		document.getElementById('CFaxPreview').innerHTML = '';
		document.form1.CFax.value='';
		document.getElementById('CAddressPreview').style.display = 'none';
		document.getElementById('CAddressPreview').innerHTML = '';
		document.form1.CAddress.value='';
		document.form1.Contact.value='';
		document.form1.CMobile.value='';
		document.form1.CEMail.value='';
		}
function SelCust() {
		if (document.form1.Attribute.value == "A") window.open ('SelProject.php','SelProject','height=300,width=550,top=200,left=200,scrollbars=yes,status=yes');
		else if (document.form1.Attribute.value == "B" || document.form1.Attribute.value == "C") window.open ('SelCustomer.php','SelCustomer','height=300,width=550,top=200,left=200,scrollbars=yes,status=yes');
		}
//-->
</script>
</head>
<body>
<?php include "top.php";?>
<table width="100%" border="0" cellspacing="0" cellpadding="5">
	<tr>
    <td width="160" height="600" align="left" valign="top">
			<?php include "menu.php";?>
    </td>
    <td valign="top">
    	<table width="100%" border="0" cellpadding="0" cellspacing="0">
    		<tr>
    			<td>
			    	<table width="750" border="0" cellpadding="0" cellspacing="0">
			    		<tr height="30">
			    			<td class="c2"><b>新增事項處理</b></td>
			    		</tr>
			    	</table>
			    	<table width="750" border="0" cellpadding="0" cellspacing="0">
			        <form name="form1" method="post" action="AgendumAddDB.php" enctype="multipart/form-data" onSubmit="return jsCheck();">
			        <?php
							$SQL_Manager="select MUID,MName,MEName from Manager where Deltag='N' and IsLeft='N';";
							$result_Manager=mysqli_query($link,$SQL_Manager) or die ("無法執行查詢");
			        ?>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td width="150" align="right" class="c3"><font color=red><b>*</b></font>派案人：</td>
			          <td class="h3">
			          	<select id="ASID" name="ASID" disabled>
			          		<?php while(list($MUID,$MName,$MEName)=mysqli_fetch_row($result_Manager)){?>
			          		<option value="<?php echo $MUID;?>"<?php if (trim(strtolower($MUID))==trim(strtolower($_SESSION["reg_MUID"]))) echo " selected";?>><?php echo $MEName.$MName;?></option>
			          		<?php }?>
			          	</select>
			          </td>
			        </tr>
			        <?php mysqli_free_result($result_Manager);?>
			        <?php
							$SQL_Manager="select MUID,MName,MEName from Manager where Deltag='N' and MUID <> 'jacky' and IsLeft='N';";
							$result_Manager=mysqli_query($link,$SQL_Manager) or die ("無法執行查詢");
			        ?>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3"><font color=red><b>*</b></font>接案人：</td>
			          <td class="h3">
			          	<select id="ARID" name="ARID">
			          		<?php while(list($MUID,$MName,$MEName)=mysqli_fetch_row($result_Manager)){?>
			          		<option value="<?php echo $MUID;?>"><?php echo $MEName.$MName;?></option>
			          		<?php }?>
			          	</select> 
			          </td>
			        </tr>
			        <?php mysqli_free_result($result_Manager);?>
			        <?php
							$SQL_Manager="select MUID,MName,MEName from Manager where Deltag='N' and MUID <> 'jacky' and IsLeft='N';";
							$result_Manager=mysqli_query($link,$SQL_Manager) or die ("無法執行查詢");
			        ?>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3"><font color=red><b>*</b></font>審核人：</td>
			          <td class="h3">
			          	<select id="ACID" name="ACID">
			          		<?php while(list($MUID,$MName,$MEName)=mysqli_fetch_row($result_Manager)){?>
			          		<option value="<?php echo $MUID;?>"><?php echo $MEName.$MName;?></option>
			          		<?php }?>
			          	</select> 
			          </td>
			        </tr>
			        <?php mysqli_free_result($result_Manager);?>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3"><font color=red><b>*</b></font>派案時間：</td>
			          <td class="h3">
		              <input id="AYear" name="AYear" type="text" size="4" /> 年 
		              <input id="AMonth" name="AMonth" type="text" size="2" /> 月 
		              <input id="ADay" name="ADay" type="text" size="2" /> 日 
		              <img src="../images/icon.gif" width="16" height="18" style="cursor: hand" onclick="javascript:displayDatePicker('AYear','AMonth','ADay');"/>
			          </td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3"><font color=red><b>*</b></font>預計完成時間：</td>
			          <td class="h3">
		              <input id="AEYear" name="AEYear" type="text" size="4" /> 年 
		              <input id="AEMonth" name="AEMonth" type="text" size="2" /> 月 
		              <input id="AEDay" name="AEDay" type="text" size="2" /> 日 
		              <img src="../images/icon.gif" width="16" height="18" style="cursor: hand" onclick="javascript:displayDatePicker('AEYear','AEMonth','AEDay');"/>
			          </td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">結案時間：</td>
			          <td class="h3">
		              <input id="ACYear" name="ACYear" type="text" size="4" /> 年 
		              <input id="ACMonth" name="ACMonth" type="text" size="2" /> 月 
		              <input id="ACDay" name="ACDay" type="text" size="2" /> 日 
		              <img src="../images/icon.gif" width="16" height="18" style="cursor: hand" onclick="javascript:displayDatePicker('ACYear','ACMonth','ACDay');"/>
			          </td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3"><font color=red><b>*</b></font>項目/測試項目：</td>
			          <td class="h3"><input type="text" id="AItem" name="AItem" size="60"></td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3"><font color=red><b>*</b></font>屬性：</td>
			          <td class="h3">
			          	<select id="Attribute" name="Attribute" onchange="javascript:ChkAttribute();">
			          		<option value="A">測試</option>
			          		<option value="B">事項處理</option>
			          		<option value="C">採購</option>
			          	</select>
			          </td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3"><font color=red></font>連結案件：</td>
			          <td class="h3">
			          	<table width="100%" border="0" cellpadding="0" cellspacing="0">
			          		<tr>
			          			<td><div id="PNamePreview" style="display:none"></div></td>
			          			<td>
						          	<input type="hidden" id="PID" name="PID">
						          	<input type="button" id="SelPID" name="SelPID" class="input_bot" value="選 擇" onclick="javascript:SelCust();">
			          			</td>
			          		</tr>
			          	</table>
			          </td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3"><font color=red><b>*</b></font>客戶名稱：</td>
			          <td class="h3">
			          	<table width="100%" border="0" cellpadding="0" cellspacing="0">
			          		<tr>
			          			<td><div id="CNamePreview" style="display:none"></div></td>
			          			<td>
						          	<input type="hidden" id="CID" name="CID">
						          	<input type="hidden" id="CName" name="CName">
						          	<!--<input type="button" id="SelCID" name="SelCID" class="input_bot" value="選 擇" onclick="javascript:window.open ('SelCustomer.php','SelCustomer','height=300,width=550,top=200,left=200,scrollbars=yes,status=yes');">-->
			          			</td>
			          		</tr>
			          	</table>
			          </td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">客戶電話：</td>
			          <td class="h3">
			          	<table width="100%" border="0" cellpadding="0" cellspacing="0">
			          		<tr>
			          			<td width="150">
			          				<div id="CTelPreview" style="display:none"></div>
						          	<input type="hidden" id="CTel" name="CTel">
			          			</td>
			          			<td width="60" align="right" class="c3">傳真：</td>
			          			<td>
			          				<div id="CFaxPreview" style="display:none"></div>
			          				<input type="hidden" id="CFax" name="CFax">
			          			</td>
			          		</tr>
			          	</table>
			          </td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">客戶地址：</td>
			          <td class="h3">
			          	<div id="CAddressPreview" style="display:none"></div>
			          	<input type="hidden" id="CAddress" name="CAddress">
			          </td>
			        </tr>
			        <tr height="60" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">連絡人：</td>
			          <td class="h3">
			          	<table width="100%" border="0" cellpadding="0" cellspacing="0">
			          		<tr height="30">
			          			<td width="75" align="right">姓名：</td>
			          			<td width="180"><input type="text" id="Contact" name="Contact" size="20"></td>
			          			<td width="60" align="right">電話：</td>
			          			<td><input type="text" id="CMobile" name="CMobile" size="20"></td>
			          		</tr>
			          		<tr height="30">
			          			<td width="75" align="right">E-MAil：</td>
			          			<td colspan="3"><input type="text" id="CEMail" name="CEMail" size="60"></td>
			          		</tr>
			          	</table>
			          </td>
			        </tr>
			        <tr height="40" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">相關檔案：</td>
			          <td class="h3"><input type="file" id="AFile" name="AFile" size="60"></td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">檔案說明：</td>
			          <td class="h3"><input type="text" id="ANote" name="ANote" size="60"></td>
			        </tr>
			        <tr height="40" align="center">
			          <td colspan="2" class="h3">
			          	<input type="hidden" id="CheckProc" name="CheckProc" value="Y">
			          	<input type="submit" name="submit" class="input_bot" value="送 出">
			          </td>
			        </tr>
					<?php						
						
						$code = 0;  
						$_SESSION['code'] = $code;
						
						
					  ?>
					  <td><input type="hidden" name="code" value="0"></td>
				      </form>
			      </table>
    			</td>
    		</tr>
    	</table>
    </td>
	</tr>
</table>
<?php include "down.php";?>
</body>
</html>
<?php
mysqli_close($link);
?>