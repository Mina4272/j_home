﻿<?php
include "CheckPermission.php";
include "CheckProjectAccounting.php";
include "../global.php";
include "include/page_function.php";
include "include/utf8.php";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $PageAdminTitle;?></title>
<link href="../type.css" rel="stylesheet" type="text/css" />
<style type="text/css">
<!--
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
}
-->
</style></head>

<body>
<?php include "top.php";?>

				<?php
					$Sql_Txt="";
					$SqlTxt="";
					$Sql_PID = "";
					$SqlPID = "";
			    	$QAcc = empty($_POST['QAcc'])?"":$_POST['QAcc'];
			    	if (trim($QAcc) == "") $QAcc = empty($_GET['QAcc'])?"":$_GET['QAcc'];
			    	$KeyWord = empty($_POST['KeyWord'])?"":$_POST['KeyWord'];
			    	if (trim($KeyWord) == "") $KeyWord = empty($_GET['KeyWord'])?"":$_GET['KeyWord'];
			    	$QPStatus = empty($_POST['QPStatus'])?"":$_POST['QPStatus'];
			    	if (trim($QPStatus) == "") $QPStatus = empty($_GET['QPStatus'])?"":$_GET['QPStatus'];

						if (trim($KeyWord) != "") {
							$SQL_ProjectCertificate="select PID from ProjectCertificate where Deltag='N' and (PCNo like '%".$KeyWord."%' or PCName like '%".$KeyWord."%') group by PID order by PID;";
							$result_ProjectCertificate=mysqli_query($link,$SQL_ProjectCertificate) or die ("無法執行查詢");
							while(list($PC_PID)=mysqli_fetch_row($result_ProjectCertificate)){
								if (trim($SqlPID) == "") $SqlPID = $PC_PID;
								else $SqlPID = $SqlPID.",".$PC_PID;
							}
							mysqli_free_result($result_ProjectCertificate);
												
												// 2013/10/3, change to table ProjectCertificate 
												//$SQL_ProjectAccounting="select PID from ProjectAccounting where Deltag='N'  and (PANo like '%".$KeyWordArr[$temp]."%' or PAItem like '%".$KeyWordArr[$temp]."%' or Invoice like '%".$KeyWordArr[$temp]."%' or PANote like '%".$KeyWordArr[$temp]."%') group by PID order by PID;";
							$SQL_ProjectAccounting="select PID from ProjectCertificate where Deltag='N' and (PCNo like '%".$KeyWord."%' or PCName like '%".$KeyWord."%') group by PID order by PID;";
							$result_ProjectAccounting=mysqli_query($link,$SQL_ProjectAccounting) or die ("無法執行查詢x");
							while(list($PC_PID)=mysqli_fetch_row($result_ProjectAccounting)){
								if (trim($SqlPID) == "") $SqlPID = $PC_PID;
								else $SqlPID = $SqlPID.",".$PC_PID;
							}
							mysqli_free_result($result_ProjectAccounting);

							if (trim($Sql_Txt) == "") $Sql_Txt = "PUID like '%".$KeyWord."%' or CName like '%".$KeyWord."%' or CTel like '%".$KeyWord."%' or CFax like '%".$KeyWord."%' or Contact like '%".$KeyWord."%' or CMobile like '%".$KeyWord."%' or CEMail like '%".$KeyWord."%' or CAddress like '%".$KeyWord."%' or PName like '%".$KeyWord."%' or ModelName like '%".$KeyWord."%' or SeriesModel like '%".$KeyWord."%' or PE like '%".$KeyWord."%' or PNote like '%".$KeyWord."%' or ApplyItem like '%".$KeyWord."%' or EMC like '%".$KeyWord."%' or Canon like '%".$KeyWord."%'";
							else $Sql_Txt = $Sql_Txt." or PUID like '%".$KeyWord."%' or CName like '%".$KeyWord."%' or CTel like '%".$KeyWord."%' or CFax like '%".$KeyWord."%' or Contact like '%".$KeyWord."%' or CMobile like '%".$KeyWord."%' or CEMail like '%".$KeyWord."%' or CAddress like '%".$KeyWord."%' or PName like '%".$KeyWord."%' or ModelName like '%".$KeyWord."%' or SeriesModel like '%".$KeyWord."%' or PE like '%".$KeyWord."%' or PNote like '%".$KeyWord."%' or ApplyItem like '%".$KeyWord."%' or EMC like '%".$KeyWord."%' or Canon like '%".$KeyWord."%'";
												
							/**
								$KeyWordArr = split("\+",$KeyWord);
								$count_i=count($KeyWordArr);
								$SqlPID = "";
								for ($temp=0;$temp<=$count_i-1;$temp++){
										//echo "KeyWordArr=".$KeyWordArr[$temp]."<br>";
										if (trim($KeyWordArr[$temp]) != "") {
												$SQL_ProjectCertificate="select PID from ProjectCertificate where Deltag='N' and (PCNo like '%".$KeyWordArr[$temp]."%' or PCName like '%".$KeyWordArr[$temp]."%') group by PID order by PID;";
												$result_ProjectCertificate=mysqli_query($link,$SQL_ProjectCertificate) or die ("無法執行查詢");
												while(list($PC_PID)=mysqli_fetch_row($result_ProjectCertificate)){
														if (trim($SqlPID) == "") $SqlPID = $PC_PID;
														else $SqlPID = $SqlPID.",".$PC_PID;
														}
												mysqli_free_result($result_ProjectCertificate);
												
												// 2013/10/3, change to table ProjectCertificate 
												//$SQL_ProjectAccounting="select PID from ProjectAccounting where Deltag='N'  and (PANo like '%".$KeyWordArr[$temp]."%' or PAItem like '%".$KeyWordArr[$temp]."%' or Invoice like '%".$KeyWordArr[$temp]."%' or PANote like '%".$KeyWordArr[$temp]."%') group by PID order by PID;";
												$SQL_ProjectAccounting="select PID from ProjectCertificate where Deltag='N' and (PCNo like '%".$KeyWordArr[$temp]."%' or PCName like '%".$KeyWordArr[$temp]."%') group by PID order by PID;";
												$result_ProjectAccounting=mysqli_query($link,$SQL_ProjectAccounting) or die ("無法執行查詢x");
												while(list($PC_PID)=mysqli_fetch_row($result_ProjectAccounting)){
														if (trim($SqlPID) == "") $SqlPID = $PC_PID;
														else $SqlPID = $SqlPID.",".$PC_PID;
														}
												mysqli_free_result($result_ProjectAccounting);

												if (trim($Sql_Txt) == "") $Sql_Txt = "PUID like '%".$KeyWordArr[$temp]."%' or CName like '%".$KeyWordArr[$temp]."%' or CTel like '%".$KeyWordArr[$temp]."%' or CFax like '%".$KeyWordArr[$temp]."%' or Contact like '%".$KeyWordArr[$temp]."%' or CMobile like '%".$KeyWordArr[$temp]."%' or CEMail like '%".$KeyWordArr[$temp]."%' or CAddress like '%".$KeyWordArr[$temp]."%' or PName like '%".$KeyWordArr[$temp]."%' or ModelName like '%".$KeyWordArr[$temp]."%' or SeriesModel like '%".$KeyWordArr[$temp]."%' or PE like '%".$KeyWordArr[$temp]."%' or PNote like '%".$KeyWordArr[$temp]."%' or ApplyItem like '%".$KeyWordArr[$temp]."%' or EMC like '%".$KeyWordArr[$temp]."%' or Canon like '%".$KeyWordArr[$temp]."%'";
												else $Sql_Txt = $Sql_Txt." or PUID like '%".$KeyWordArr[$temp]."%' or CName like '%".$KeyWordArr[$temp]."%' or CTel like '%".$KeyWordArr[$temp]."%' or CFax like '%".$KeyWordArr[$temp]."%' or Contact like '%".$KeyWordArr[$temp]."%' or CMobile like '%".$KeyWordArr[$temp]."%' or CEMail like '%".$KeyWordArr[$temp]."%' or CAddress like '%".$KeyWordArr[$temp]."%' or PName like '%".$KeyWordArr[$temp]."%' or ModelName like '%".$KeyWordArr[$temp]."%' or SeriesModel like '%".$KeyWordArr[$temp]."%' or PE like '%".$KeyWordArr[$temp]."%' or PNote like '%".$KeyWordArr[$temp]."%' or ApplyItem like '%".$KeyWordArr[$temp]."%' or EMC like '%".$KeyWordArr[$temp]."%' or Canon like '%".$KeyWordArr[$temp]."%'";
												}
										}
								*/
								}
						if (trim($Sql_Txt) != "" && trim($SqlPID) != "") $SqlTxt = $SqlTxt." and (".$Sql_Txt." or PID in (".$SqlPID."))";
						else if (trim($Sql_Txt) != "" && trim($SqlPID) == "") $SqlTxt = $SqlTxt." and (".$Sql_Txt.")";
						else if (trim($Sql_Txt) != "" && trim($SqlPID) == "") $SqlTxt = $SqlTxt." and PID in (".$SqlPID.")";		

						/*
						if (trim($KeyWord) != "") {
								$KeyWordArr = split("\+",$KeyWord);
								$count_i=count($KeyWordArr);
								$SqlPID = "";
								for ($temp=0;$temp<=$count_i-1;$temp++){
										if (trim($KeyWordArr[$temp]) != "") {
												$SQL_ProjectCertificate="select PID from ProjectCertificate where Deltag='N' and PCNo like '%".$KeyWordArr[$temp]."%' group by PID order by PID;";
												$result_ProjectCertificate=mysqli_query($link,$SQL_ProjectCertificate) or die ("無法執行查詢");
												while(list($PC_PID)=mysqli_fetch_row($result_ProjectCertificate)){
														if (trim($SqlPID) == "") $SqlPID = $PC_PID;
														else $SqlPID = $SqlPID.",".$PC_PID;
														}
												mysqli_free_result($result_ProjectCertificate);
												}
							    	if (trim($KeyWordArr[$temp]) != "") {
												$Sql_Txt = " and (PUID like '%".$KeyWordArr[$temp]."%' or CName like '%".$KeyWordArr[$temp]."%' or CTel like '%".$KeyWordArr[$temp]."%' or CFax like '%".$KeyWordArr[$temp]."%' or Contact like '%".$KeyWordArr[$temp]."%' or CMobile like '%".$KeyWordArr[$temp]."%' or CEMail like '%".$KeyWordArr[$temp]."%' or CAddress like '%".$KeyWordArr[$temp]."%' or PName like '%".$KeyWordArr[$temp]."%' or ModelName like '%".$KeyWordArr[$temp]."%' or SeriesModel like '%".$KeyWordArr[$temp]."%' or PE like '%".$KeyWordArr[$temp]."%' or PNote like '%".$KeyWordArr[$temp]."%' or ApplyItem like '%".$KeyWordArr[$temp]."%' or EMC like '%".$KeyWordArr[$temp]."%' or Canon like '%".$KeyWordArr[$temp]."%')";
												$SQL_Project="select PID from Project where Deltag='N' ".$Sql_Txt." group by PID order by PID;";
												$result_Project=mysqli_query($link,$SQL_Project) or die ("無法執行查詢");
												while(list($PC_PID)=mysqli_fetch_row($result_Project)){
														if (trim($SqlPID) == "") $SqlPID = $PC_PID;
														else $SqlPID = $SqlPID.",".$PC_PID;
														}
												mysqli_free_result($result_Project);
							    			}

							    	if (trim($KeyWordArr[$temp]) != "") {
												$Sql_Txt = " and (PANo like '%".$KeyWordArr[$temp]."%' or PAItem like '%".$KeyWordArr[$temp]."%' or Invoice like '%".$KeyWordArr[$temp]."%' or PANote like '%".$KeyWordArr[$temp]."%')";
												$SQL_ProjectAccounting="select PID from ProjectAccounting where Deltag='N' ".$Sql_Txt." group by PID order by PID;";
												$result_ProjectAccounting=mysqli_query($link,$SQL_ProjectAccounting) or die ("無法執行查詢");
												while(list($PC_PID)=mysqli_fetch_row($result_ProjectAccounting)){
														if (trim($SqlPID) == "") $SqlPID = $PC_PID;
														else $SqlPID = $SqlPID.",".$PC_PID;
														}
												mysqli_free_result($result_ProjectAccounting);
							    			}
					    			}
								if (trim($SqlPID) != "") $SqlTxt = "  and PID in (".$SqlPID.")";
								else $SqlTxt = "  and PID = 0";
			    			}
						*/
						if (trim($QAcc) != "") {
								if (trim($QAcc) == "C") $SQL_QAcc="SELECT DISTINCT a.PID FROM Project a, ProjectAccounting b WHERE a.PID = b.PID AND a.Deltag = 'N' AND b.Deltag = 'N' AND PStatus = 'H' AND b.PAStatus = 'W' ORDER BY a.PID";
								else if (trim($QAcc) == "I") $SQL_QAcc="SELECT DISTINCT PID FROM Project WHERE Deltag = 'N' AND PStatus = 'H' AND INo IS NULL ORDER BY PID";
								$result_QAcc=mysqli_query($link,$SQL_QAcc) or die ("無法執行查詢");
									while(list($PQ_PID)=mysqli_fetch_row($result_QAcc)){
										if (trim($Sql_PID) == "") $Sql_PID = $PQ_PID;
										else $Sql_PID = $Sql_PID.",".$PQ_PID;
										}
									mysqli_free_result($result_QAcc);
								
								
								}
						if (trim($Sql_PID) != "") $SqlTxt = $SqlTxt . " and PID in (".$Sql_PID.")";
	
			    	//if (trim($KeyWord) != "") $SqlTxt = " and (PUID like '%".$KeyWord."%' or CName like '%".$KeyWord."%' or CTel like '%".$KeyWord."%' or CFax like '%".$KeyWord."%' or Contact like '%".$KeyWord."%' or CMobile like '%".$KeyWord."%' or CEMail like '%".$KeyWord."%' or CAddress like '%".$KeyWord."%' or PName like '%".$KeyWord."%' or ModelName like '%".$KeyWord."%' or SeriesModel like '%".$KeyWord."%' or PE like '%".$KeyWord."%' or INo like '%".$KeyWord."%')";
			    	if (trim($QPStatus) != "") $SqlTxt = $SqlTxt." and PStatus='".$QPStatus."' ";
						$page = empty($_GET['page'])?"":$_GET['page'];
						if (trim($page) == "") $page = 1;
						$page_rows=15;  //每頁筆數
						$php_Self = "ProjectAccounting.php";  //分頁web檔名

						$button_css = "h4";
						$limit_txt =" limit ".(($page-1) * $page_rows).",".$page_rows;
						$url_str = "&QPStatus=".$QPStatus."&QAcc=".$QAcc."&KeyWord=".urlencode($KeyWord);
						$Sql_str="select PID,PUID,CID,CName,CTel,CFax,Contact,CMobile,CEMail,CAddress,PStatus,PName,ModelName,SeriesModel,PE,BMUID,test,Quote,ApplyItem,Canon,SNote,PlanDate,CloseDate,PNote,QuoteDate,ReturnDate from Project where Deltag='N' ".$SqlTxt." order by PStatus asc,PID desc;";
						$SQL_Project="select PID,PUID,CID,CName,CTel,CFax,Contact,CMobile,CEMail,CAddress,PStatus,PName,ModelName,SeriesModel,PE,BMUID,test,Quote,ApplyItem,Canon,SNote,PlanDate,CloseDate,PNote,QuoteDate,ReturnDate,(SELECT count( PAID ) AS PACount FROM ProjectAccounting WHERE PID = Project.PID AND PAStatus = 'W' AND Deltag = 'N') as PACount,INo from Project where Deltag='N' ".$SqlTxt." order by PStatus asc,PID desc ".$limit_txt.";";
						$result_Project=mysqli_query($link,$SQL_Project) or die ("無法執行查詢");
						
						//echo $SQL_Project;

						$result_ProjectCount=mysqli_query($link,$Sql_str) or die ("無法執行查詢");
						?>


<table width="100%" border="0" cellspacing="0" cellpadding="5">
	<tr>
    <td width="160" height="600" align="left" valign="top">
			<?php include "menu.php";?>
    </td>
    <td valign="top">
    	<table width="100%" border="0" cellpadding="0" cellspacing="0">
    		<tr>
    			<td>
			    	<table width="750" border="0" cellpadding="0" cellspacing="0">
			    		<tr height="30">
			    			<td class="c2"> 客戶案件帳務管理</td>
			    		</tr>
			    		<tr height="30">
			    			<td class="c2" align="left">
					    		<input type="button" name="button" class="input_bot" value="全部列出" onclick="javascript:location.href='ProjectAccounting.php';">
							<input type="button" name="button" value="已結案未結清列表" class="input_bot" onclick="javascript:location.href='ProjectAccounting.php?QAcc=C';">
			    				<input type="button" name="button" value="已結案未開發票列表" class="input_bot" onclick="javascript:location.href='ProjectAccounting.php?QAcc=I';">
			    				<input type="button" name="button" value="單一發票結清" class="input_bot" onclick="javascript:location.href='ProjectAccountingInvoice.php';">
			    				<input type="button" name="button" value="對帳編號結清" class="input_bot" onclick="javascript:location.href='ProjectAccountingPANo.php';">
								<input type="button" name="button" value="應收應付報表" class="input_bot" onclick="javascript:location.href='AccountsPayableReport.php';">
							<font color=blue>共 <?php echo mysqli_num_rows($result_ProjectCount);?> 筆</font>	
			    			</td>
			    		</tr>
			    	</table>
			    	<table width="750" border="0" cellpadding="0" cellspacing="0">
			    		<form name="form1" action="ProjectAccounting.php" method="post">
			    		<tr>
			    			<td width="240" align="left" class="h3">關鍵字：<input type="text" name="KeyWord" size="20" value="<?php echo $KeyWord;?>"></td>
			    			<td align="left" class="h3">狀態：
			    				<select name="QPStatus">
			    					<option value="">不限</option>
			    					<option value="A"<?php if (trim($QPStatus) == "A") echo " selected";?>>新開案</option>
			    					<option value="B"<?php if (trim($QPStatus) == "B") echo " selected";?>>報價中</option>
			    					<option value="C"<?php if (trim($QPStatus) == "C") echo " selected";?>>案件處理中</option>
			    					<option value="D"<?php if (trim($QPStatus) == "D") echo " selected";?>>審查中</option>
			    					<option value="E"<?php if (trim($QPStatus) == "E") echo " selected";?>>補件中</option>
			    					<option value="F"<?php if (trim($QPStatus) == "F") echo " selected";?>>待印證</option>
			    					<option value="G"<?php if (trim($QPStatus) == "G") echo " selected";?>>案件取消</option>
			    					<option value="H"<?php if (trim($QPStatus) == "H") echo " selected";?>>已結案</option>
			    				</select>　<input type="submit" name="search" class="input_bot" value="查詢">　 
			    				
			    			</td>
			    			<td></td>
			    		</tr>
			    		<?php 
			    		mysqli_free_result($result_ProjectCount);
			    		?>
			    		</form>
			    	</table>
			    	<table width="800" border="0" cellpadding="5" cellspacing="2" class="s2">
			        <tr align="center">
			          <td width="80" align="center" background="../images/table_bg.gif" class="t21">案件編號</td>
			          <td background="../images/table_bg.gif" class="t21">產品名稱</td>
			          <td width="70" background="../images/table_bg.gif" class="t21">客戶名稱</td>
			          <td width="90" background="../images/table_bg.gif" class="t21">狀態<br>發票號碼</td>
					   <td width="50" background="../images/table_bg.gif" class="t21">客服</td>
			          <td width="50" background="../images/table_bg.gif" class="t21">工程師</td>
					   <td width="50" background="../images/table_bg.gif" class="t21">測試</td>
			          <td width="130" background="../images/table_bg.gif" class="t21">申請項目</td>
			          <td width="70" background="../images/table_bg.gif" class="t21">帳務管理</td>
			        </tr>
		          <?php
		          $tmp = 1;
		          while(list($PID,$PUID,$CID,$CName,$CTel,$CFax,$Contact,$CMobile,$CEMail,$CAddress,$PStatus,$PName,$ModelName,$SeriesModel,$PE,$BMUID,$test,$Quote,$ApplyItem,$Canon,$SNote,$PlanDate,$CloseDate,$PNote,$QuoteDate,$ReturnDate,$PACount,$INo)=mysqli_fetch_row($result_Project)){
	          	if (utf8_strlen(strip_tags($CName)) > 4) $CName = utf8_substr(strip_tags($CName),0,4);
	          	else $CName = strip_tags($CName);

							//$SQL_Manager="select MName from Manager where Deltag='N' and ISEngineer = 'Y' and MUID = '".$PE."';";
							$SQL_Manager="select MName,MEName from Manager where MUID = '".$PE."';";
							$result_Manager=mysqli_query($link,$SQL_Manager) or die ("無法執行查詢");
							list($MName,$MEName)=mysqli_fetch_row($result_Manager);
							mysqli_free_result($result_Manager);
							
							//查詢客服
							//echo $BMUID;
							$SQL_Manager="select MName,MEName from Manager where MUID = '".$BMUID."';";
							$result_Manager=mysqli_query($link,$SQL_Manager) or die ("無法執行查詢");
							list($MBName,$MBEName)=mysqli_fetch_row($result_Manager);
							mysqli_free_result($result_Manager);
							
							//查詢測試
							$SQL_Manager="select MName,MEName from Manager where MUID = '".$test."';";
							$result_Manager=mysqli_query($link,$SQL_Manager) or die ("無法執行查詢");
							list($MTName,$MTEName)=mysqli_fetch_row($result_Manager);
							mysqli_free_result($result_Manager);
							
							//開出報價後，超過三天請轉成藍色字體提醒
	          	if ($QuoteDate < date ("Y-m-d", mktime (0,0,0,date("m"),date("d")-3,date("Y"))) and trim($PStatus) == "B") $cssStr="b";
	          	else $cssStr="";
		        	?>
		        	<tr<?php if ($tmp%2 == 0) echo " bgcolor=\"#F6F6F6\"";?>>
			          <td align="center" class="h3<?php if (trim($PStatus) == "H" && $PACount > 0) echo "r"; else echo $cssStr;?>"><a href="ProjectEdit.php?PID=<?php echo $PID;?>&page=<?php echo $page;?><?php echo $url_str;?>&Source=ProjectAccounting"><?php echo $PUID;?></a></td>
			          <td class="h3<?php if (trim($PStatus) == "H" && $PACount > 0) echo "r"; else echo $cssStr;?>"><?php echo $PName;?><br><?php echo $ModelName;?></td>
			          <td class="h3<?php if (trim($PStatus) == "H" && $PACount > 0) echo "r"; else echo $cssStr;?>" align="center"><?php echo $CName;?></td>
			          <td align="center" class="h3<?php if (trim($PStatus) == "H" && $PACount > 0) echo "r"; else echo $cssStr;?>">
			          	<?php
			          	if (trim($PStatus) == "A") echo "新開案";
			          	else if (trim($PStatus) == "B") echo "報價中";
			          	else if (trim($PStatus) == "C") echo "案件處理中";
			          	else if (trim($PStatus) == "D") echo "審查中";
			          	else if (trim($PStatus) == "E") echo "補件中";
			          	else if (trim($PStatus) == "F") echo "待印證";
			          	else if (trim($PStatus) == "G") echo "案件取消";
			          	else if (trim($PStatus) == "H") echo "已結案";
			          	if (trim($INo) != "") echo "<br>".$INo;
			          	?>
			          </td>
					  <td align="center" class="h3<?php echo $cssStr;?>"><?php echo $MBEName."<br>".$MBName;?></td>
			          <td align="center" class="h3<?php echo $cssStr;?>"><?php echo $MEName."<br>".$MName;?></td>
			          <td align="center" class="h3<?php echo $cssStr;?>"><?php echo $MTEName."<br>".$MTName;?></td>
			          <td align="center" class="h3"><?php echo $ApplyItem;?></td>
			          <td align="center">
			          	<?php if (trim(strstr($_SESSION["reg_MPer"],'D')) != ""){?>
			          		<input type="button" name="edit" value="帳務管理" class="input_bot" onclick="javascript:location.href='ProjectAccountingList.php?PID=<?php echo $PID;?>&page=<?php echo $page;?><?php echo $url_str;?>';">
			          	<?php }
			          	else {
				          	if (trim(strstr($_SESSION["reg_MPer"],'I')) != ""){?>
				          		<input type="button" name="edit" value="帳務收入管理" class="input_bot" onclick="javascript:location.href='ProjectAccountingList.php?PID=<?php echo $PID;?>&page=<?php echo $page;?>&PA_Mode=I<?php echo $url_str;?>';">
				          	<?php }
				          	if (trim(strstr($_SESSION["reg_MPer"],'L')) != ""){?>
				          		<input type="button" name="edit" value="帳務支出管理" class="input_bot" onclick="javascript:location.href='ProjectAccountingList.php?PID=<?php echo $PID;?>&page=<?php echo $page;?>&PA_Mode=O<?php echo $url_str;?>';">
				          	<?php }?>
			          	<?php }?>
			          </td>
			        </tr>
			        <?php
            			$tmp++;
			      			}
            	mysqli_free_result($result_Project);
			        ?>
			      </table>
			      <table width="750" border="0" cellpadding="5" cellspacing="2" class="s2">
			        <tr align="center">
			          <td bgcolor="#E8F0C2" class="h4"><?php Page_show($Sql_str,$page_rows,$php_Self,$link,$page,$url_str,$button_css);?></td>
			        </tr>
			      </table>
    			</td>
    		</tr>
    	</table>
    </td>
	</tr>
</table>
<?php include "down.php";?>
</body>
</html>
<?php
mysqli_close($link);
?>