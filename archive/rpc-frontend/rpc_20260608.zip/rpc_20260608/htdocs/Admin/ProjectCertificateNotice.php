﻿<?php	
include "CheckPermission.php";
include "CheckProject.php";
include "../global.php";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $PageAdminTitle;?></title>
<link href="../type.css" rel="stylesheet" type="text/css" />
<style type="text/css">
<!--
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
}
-->
</style>
<link href="../script/DatePicker.css" rel="stylesheet" type="text/css" />
<Script LANGUAGE="Javascript" SRC="../script/DatePicker.js"></Script>
<Script type="text/javascript" language="javascript" src="../script/CheckForm.js"></Script>
<script type="text/JavaScript">
<!--
function jsCheck() 
		{
		if (ChkImp('NoticeNote',document.form1.NoticeNote.value,'取消原因') == false) return false;
		}
//-->
</script>
</head>
<body>
<?php
$PCID = $_GET['PCID'];
$PID = $_GET['PID'];
if (trim($PID) == "" || trim($PCID) == "")
		{
		mysqli_close($link);
		?>
		<script type="text/JavaScript">
			<!--
			alert ("查無資料，請冾網站管理人員！");
			self.close();
			//-->
		</script>
		<?php
		exit;
		}
$SQL_ProjectCertificate="select PCNo,PCName,PCType,PCTypeName,PCFile,PCSDate,date_format(PCSDate,'%Y'),date_format(PCSDate,'%m'),date_format(PCSDate,'%d'),PCEDate,date_format(PCEDate,'%Y'),date_format(PCEDate,'%m'),date_format(PCEDate,'%d'),PCNote,ExpireDate,date_format(ExpireDate,'%Y'),date_format(ExpireDate,'%m'),DateDiff(ExpireDate, PCEDate) ExpireNum,AddUser,AddDate,ProcUser,ProcDate from ProjectCertificate where Deltag='N' and PID = '".$PID."' and PCID = '".$PCID."';";
$result_ProjectCertificate=mysqli_query($link,$SQL_ProjectCertificate) or die ("無法執行查詢");
if (mysqli_num_rows($result_ProjectCertificate) == 0)
		{
		mysqli_free_result($result_ProjectCertificate);
		mysqli_close($link);
		?>
		<SCRIPT language=javascript>
		<!--
		alert ("查無資料，請冾網站管理人員！"); 
		self.close();
		//-->
		</SCRIPT>
		<?php 	
		exit;
		}
list($PCNo,$PCName,$PCType,$PCTypeName,$PCFile,$PCSDate,$PCSYear,$PCSMonth,$PCSDay,$PCEDate,$PCEYear,$PCEMonth,$PCEDay,$PCNote,$ExpireDate,$ExpireYear,$ExpireMonth,$ExpireNum,$AddUser,$AddDate,$ProcUser,$ProcDate)=mysqli_fetch_row($result_ProjectCertificate);
mysqli_free_result($result_ProjectCertificate);
?>
<table width="100%" border="0" cellpadding="0" cellspacing="0">
	<tr>
		<td>
    	<table width="100%" border="0" cellpadding="0" cellspacing="0">
    		<tr height="30">
					<td width="15" background="../images/table_bg.gif"></td>
    			<td class="c3" background="../images/table_bg.gif"><b>客戶證書通知</b></td>
    		</tr>
    	</table>
    	<table width="100%" border="0" cellpadding="0" cellspacing="0">
        <form name="form1" method="post" action="ProjectCertificateNoticeDB.php" enctype="multipart/form-data" onSubmit="return jsCheck();">
        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
					<td width="15"></td>
          <td width="160" class="c3" align="right">証書編號：</td>
          <td class="c3"><?php echo $PCNo;?></td>
        </tr>
        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
					<td width="15"></td>
          <td class="c3" align="right">証書名稱：</td>
          <td class="c3"><?php echo $PCName;?></td>
        </tr>
        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
					<td width="15"></td>
          <td class="c3" align="right">証書種類：</td>
          <td class="c3">
          	<?php
          	if (trim($PCType) == "A") echo "環保標章";
          	else if (trim($PCType) == "B") echo "BSMI證書";
          	else if (trim($PCType) == "C") echo "消防證書";
          	else if (trim($PCType) == "D") echo $PCTypeName;
          	?>
          </td>
        </tr>
        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
					<td width="15"></td>
          <td class="c3" align="right">証書檔案：</td>
          <td class="c3">
          	<input type="button" name="edit" value="下 載" class="input_bot" onclick="javascript:location.href='getfile.php?FolderName=Admin\\PCFile&FileName=<?php echo $PCFile;?>';">
          </td>
        </tr>
        <?php
        if (trim($PCSYear) == "0000") $PCSYear = "";
        if (trim($PCSMonth) == "00") $PCSMonth = "";
        if (trim($PCSDay) == "00") $PCSDay = "";
        if (trim($PCEYear) == "0000") $PCEYear = "";
        if (trim($PCEMonth) == "00") $PCEMonth = "";
        if (trim($PCEDay) == "00") $PCEDay = "";
        if (trim($ExpireNum) == 0 || is_numeric($ExpireNum) == false) $ExpireMonth="";
        else {
        		$ExpireMonth = round($ExpireNum/30);
        		if (strlen($ExpireMonth) < 2) $ExpireMonth="0".$ExpireMonth;
        		}
        ?>
        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
					<td width="15"></td>
          <td class="c3" align="right">有效日期：</td>
          <td class="h3"><?php echo $PCSDate;?>～<?php echo $PCEDate;?></td>
        </tr>
        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
					<td width="15"></td>
          <td class="c3" align="right">備註：</td>
          <td class="h3"><?php echo $PCNote;?></td>
        </tr>
        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
					<td width="15"></td>
          <td class="c3" align="right">證書到期提醒時間：</td>
          <td class="h3"><?php echo $ExpireDate;?></td>
        </tr>
        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
					<td width="15"></td>
          <td class="c3" align="right">通知狀況：</td>
          <td class="h3">
            <input name="NoticeNote" type="text" size="40" />
          </td>
        </tr>
        <tr height="40" align="center">
					<td width="15"></td>
          <td colspan="2" class="h3">
          	<input type="submit" name="submit" class="input_bot" value="送 出">
          	<input name="PCID" type="hidden" id="PCID" value="<?php echo $PCID;?>" />
          	<input name="PID" type="hidden" id="PID" value="<?php echo $PID;?>" />
          </td>
        </tr>
	      </form>
      </table>
		</td>
	</tr>
</table>
</body>
</html>
<?php
mysqli_close($link);
?>