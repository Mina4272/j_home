﻿<?php	
include "CheckPermission.php";
include "CheckCustomer.php";
include "../global.php";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $PageAdminTitle;?></title>
<link href="../type.css" rel="stylesheet" type="text/css" />
<style type="text/css">
<!--
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
}
-->
</style>
<link href="../script/DatePicker.css" rel="stylesheet" type="text/css" />
<Script LANGUAGE="Javascript" SRC="../script/DatePicker.js"></Script>
<Script type="text/javascript" language="javascript" src="../script/CheckForm.js"></Script>
<script type="text/JavaScript">
<!--
function jsCheck() 
		{
		if (ChkImp('Contact',document.form1.Contact.value,'聯絡人') == false) return false;
		if (jsTrim(document.form1.CEMail.value) != "") if (ChkEmail('CEMail',document.form1.CEMail.value,'聯絡人E-Mail') == false) return false;
		}
//-->
</script>
</head>
<body>
<?php
$TID = $_GET['TID'];
if (trim($TID) == "")
		{
		mysqli_close($link);
		?>
		<script type="text/JavaScript">
			<!--
			alert ("查無資料，請冾網站管理人員！");
			self.close();
			//-->
		</script>
		<?php
		exit;
		}
?>
<table width="100%" border="0" cellpadding="0" cellspacing="0">
	<tr>
		<td>
    	<table width="100%" border="0" cellpadding="0" cellspacing="0">
    		<tr height="30">
					<td width="15" background="../images/table_bg.gif"></td>
    			<td class="c3" background="../images/table_bg.gif"><b>新增參與人員</b></td>
    		</tr>
    	</table>
    	<table width="100%" border="0" cellpadding="0" cellspacing="0">
        <form name="form1" method="post" action="EmployeeContactAddDB.php" onSubmit="return jsCheck();">
        <tr height="30">
			<td align="left" class="h3">
			參與人員：
			<select name="MID">
				<option value="">不限</option>
				<?php
				$SQL_Manager="select MID,MUID,MName,MEName from Manager where Deltag='N' and IsLeft='N' order by MID;";
				$result_Manager=mysqli_query($link,$SQL_Manager) or die ("無法執行查詢");
				while(list($MID,$MUID,$MName,$MEName)=mysqli_fetch_row($result_Manager)){
				?>
					<option value="<?php echo $MID;?>"><?php echo $MEName.$MName;?></option>
				<?php
				}
				mysqli_free_result($result_Manager);
				?>
			</select>
			</td>
		</tr>
        <tr height="40" align="center">
					<td width="15"></td>
          <td colspan="2" class="h3">
          	<input type="submit" name="submit" class="input_bot" value="送 出">
          	<input name="TID" type="hidden" id="TID" value="<?php echo $TID;?>" />
          </td>
        </tr>
	      </form>
      </table>
		</td>
	</tr>
</table>
</body>
</html>
<?php
mysqli_close($link);
?>