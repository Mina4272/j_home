﻿<?php
include "CheckPermission.php";
include "CheckPartLibrary.php";
include "../global.php";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $PageAdminTitle;?></title>
</head>
<body>
<?php
$PLID = $_POST['PLID'];
$page = $_POST['page'];

$PLCID = $_POST['PLCID'];
$PartName = $_POST['PartName'];
$Firm = $_POST['Firm'];
$Model = $_POST['Model'];
$Spec = $_POST['Spec'];
$Standard = $_POST['Standard'];
$Mark = $_POST['Mark'];
$PartCertification = $_POST['PartCertification'];

if (trim($PLID) == "" || trim($PLCID) == "" || trim($PartName) == "")
		{
		mysqli_close($link);
		?>
		<script type="text/JavaScript">
			<!--
			alert ("您輸入的資料不足，請重新輸入！");
			history.go(-1);
			//-->
		</script>
		<?php
		exit;
		}
$SQL_PartLibrary="select PLCID from PartLibrary where Deltag='N' and PLID = '".$PLID."';";
$result_PartLibrary=mysqli_query($link,$SQL_PartLibrary) or die ("無法執行查詢");
if (mysqli_num_rows($result_PartLibrary) == 0)
		{
		mysqli_free_result($result_PartLibrary);
		mysqli_close($link);
		?>
		<SCRIPT language=javascript>
		<!--
		alert ("查無資料，請冾網站管理人員！"); 
		history.go(-1);
		//-->
		</SCRIPT>
		<?php 	
		exit;
		}
mysqli_free_result($result_PartLibrary);

$now_time = date("Y-m-d H:i:s",mktime());
$sql_insert = "INSERT INTO PartLibraryHistory(PLID,PLCID,PartName,Firm,Model,Spec,Standard,Mark,PartCertification,AddUser,AddDate,AddIP,Deltag,ProcUser,ProcDate,ProcIP,UpdateUser,UpdateDate,UpdateIP) SELECT PLID,PLCID,PartName,Firm,Model,Spec,Standard,Mark,PartCertification,AddUser,AddDate,AddIP,Deltag,ProcUser,ProcDate,ProcIP,'".$_SESSION["reg_MUID"]."','".$now_time."','".$_SERVER["REMOTE_ADDR"]."' FROM PartLibrary where Deltag='N' and PLID = '".$PLID."';";
$result_insert=mysqli_query($link,$sql_insert) or die ("無法執行新增");
$sql_update = "update PartLibrary set PLCID = '".$PLCID."',PartName = '".$PartName."',Firm = '".$Firm."',Model = '".$Model."',Spec = '".$Spec."',Standard = '".$Standard."',Mark = '".$Mark."',PartCertification = '".$PartCertification."',ProcUser = '".$_SESSION["reg_MUID"]."',ProcDate = '".$now_time."',ProcIP = '".$_SERVER["REMOTE_ADDR"]."' where Deltag='N' and PLID = '".$PLID."';";
$result_update=mysqli_query($link,$sql_update) or die ("無法執行修改");

mysqli_close($link);
?>
<script type="text/JavaScript">
	<!--
	alert ("修改成功！");
	location.href='PartLibrary.php?page=<?php echo $page;?>';
	//-->
</script>

</body>
</html>
