﻿<?php
include "CheckPermission.php";
include "CheckPartLibrary.php";
include "../global.php";
include "include/page_function.php";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $PageAdminTitle;?></title>
<link href="../type.css" rel="stylesheet" type="text/css" />
<style type="text/css">
<!--
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
}
-->
</style></head>

<body>
<table width="100%" border="0" cellpadding="5" cellspacing="2" class="s2">
	<tr>
		<td class="c2" align="center">零組件/檔案查詢</td>
		<td align="right" class="h3"><input type="button" name="add" value="新 增" class="input_bot" onclick="javascript:location.href='PartLibraryClassAdd.php';"></td>
		<td width="20"></td>
	</tr>
</table>
<?php
$page = empty($_GET['page'])?"":$_GET['page'];
if (trim($page) == "") $page = 1;
$page_rows=10;  //每頁筆數
$php_Self = "PartLibraryClass.php";  //分頁web檔名

$button_css = "h4";
$limit_txt =" limit ".(($page-1) * $page_rows).",".$page_rows;
$url_str = "";
$Sql_str="select PLCID,PLCName,AddUser,AddDate,ProcUser,ProcDate from PartLibraryClass where Deltag='N' order by PLCID;";
$SQL_PartLibraryClass="select PLCID,PLCName,AddUser,AddDate,ProcUser,ProcDate from PartLibraryClass where Deltag='N' order by PLCID ".$limit_txt.";";
$result_PartLibraryClass=mysqli_query($link,$SQL_PartLibraryClass) or die ("無法執行查詢");
?>
<table width="100%" border="0" cellpadding="5" cellspacing="2" class="s2">
  <tr>
    <td align="center" background="../images/table_bg.gif" class="t21">類別名稱</td>
    <td width="140" align="center" background="../images/table_bg.gif" class="t21">記錄人員</td>
    <td width="45" align="center" background="../images/table_bg.gif" class="t21">修 改</td>
    <td width="45" align="center" background="../images/table_bg.gif" class="t21">刪 除</td>
  </tr>
  <?php
  $tmp = 1;
  while(list($PLCID,$PLCName,$AddUser,$AddDate,$ProcUser,$ProcDate)=mysqli_fetch_row($result_PartLibraryClass)){
	?>
	<tr<?php if ($tmp%2 == 0) echo " bgcolor=\"#F6F6F6\"";?>>
    <td class="h3"><?php echo $PLCName;?></td>
    <td class="h3" align="center">
    	<?php
    	if (trim($ProcUser) == "") echo $AddUser."<br>".$AddDate;
    	else echo $ProcUser."<br>".$ProcDate;
    	?>	
    </td>
    <td align="center"><input type="button" name="edit" value="修 改" class="input_bot" onclick="javascript:location.href='PartLibraryClassEdit.php?PLCID=<?php echo $PLCID;?>&page=<?php echo $page;?>';"></td>
    <td align="center"><input type="button" name="edit" value="刪 除" class="input_bot" onclick="javascript:if (confirm('您是否確定要刪除？')) location.href='PartLibraryClassDelDB.php?PLCID=<?php echo $PLCID;?>&page=<?php echo $page;?>';"></td>
  </tr>
  <?php
			$tmp++;
			}
	mysqli_free_result($result_PartLibraryClass);
  ?>
</table>
<table width="100%" border="0" cellpadding="5" cellspacing="2" class="s2">
  <tr align="center">
    <td bgcolor="#E8F0C2" class="h4"><?php Page_show($Sql_str,$page_rows,$php_Self,$link,$page,$url_str,$button_css);?></td>
  </tr>
</table>
</body>
</html>
<?php
mysqli_close($link);
?>