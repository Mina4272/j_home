<?php
include "CheckPermission.php";
include "../global.php";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $PageAdminTitle;?></title>
</head>

<body>
<?php
$MID = $_POST['MID'];
$EVType = $_POST['EVType'];

if (trim($EVType) == "C") {
		$SQL_EmployeeVacation="SELECT ifnull( sum( EVCount ) , 0 ) FROM EmployeeVacation WHERE Deltag = 'N' and MID=".$MID.";";
		$result_EmployeeVacation=mysql_query($SQL_EmployeeVacation,$link) or die ("無法執行查詢");
		list($NVDate)=mysql_fetch_row($result_EmployeeVacation);
		mysql_free_result($result_EmployeeVacation);
		}

$SQL_Manager="select MUID,MName,MEName,RDate,date_format(RDate,'%m'),DATEDIFF(NOW(),RDate) RDateCount from Manager where Deltag='N' and MID=".$MID.";";
$result_Manager=mysql_query($SQL_Manager,$link) or die ("無法執行查詢");
list($MUID,$MName,$MEName,$RDate,$RMonth,$RDateCount)=mysql_fetch_row($result_Manager);
mysql_free_result($result_Manager);

$SDate = (floor($RDateCount / 365));
if ($SDate < 1) $VDate = 0;
else if ($SDate >= 1 && $SDate < 3) $VDate = 7;
else if ($SDate >= 3 && $SDate < 5) $VDate = 10;
else if ($SDate >= 5 && $SDate < 10) $VDate = 14;
else if ($SDate >= 10) {
		$VDate = 14 + ($SDate-10);
		if ($VDate > 30) $VDate = 30;
		}
/*
$SDate = (floor($RDateCount / 365));
if ($SDate > 1) {
		$SQL_Vacation="select VDay1,VDay2,VDay3,VDay4,VDay5,VDay6 from Vacation where VDate ='2011-".$RMonth."-01';";
		$result_Vacation=mysql_query($SQL_Vacation,$link) or die ("無法執行查詢");
		list($VDay1,$VDay2,$VDay3,$VDay4,$VDay5,$VDay6)=mysql_fetch_row($result_Vacation);
		mysql_free_result($result_Vacation);
		$VDay = array($VDay1,$VDay2,$VDay3,$VDay4,$VDay5,$VDay6);
		$VIndex = $SDate;
		if ($VIndex > 6) $VIndex = 6;
		$VDate=$VDay[$VIndex-1];
		if ($SDate > 10) {
				$VDate = $VDate + ($SDate-10);
				if ($VDate > 30) $VDate = 30;
				}
		}
else $VDate=0;
*/
?>
<script type="text/JavaScript">
		<!--
		opener.document.form1.MID.value='<?php echo $MID;?>';
		opener.document.getElementById('MNamePreview').style.display = '';
		<?php if (trim($EVType) == "C") {?>
		opener.document.form1.NVDate.value='<?php echo $NVDate;?>';
		opener.document.getElementById('MNamePreview').innerHTML = '<?php echo $MEName.$MName;?>(<?php echo $MUID;?>)　<font color=blue>到職日：<?php echo $RDate;?>　剩餘年假：<?php echo $NVDate;?> 天</font>';
		<?php } else {?>
		opener.document.getElementById('MNamePreview').innerHTML = '<?php echo $MEName.$MName;?>(<?php echo $MUID;?>)　<font color=blue>到職日：<?php echo $RDate;?>　建議年假：<?php echo $VDate;?> 天</font>';
		opener.document.form1.EVCount.value='<?php echo $VDate;?>';
		<?php }?>
		self.close();
		//-->
</script>
</body>
</html>
<?php
mysql_close($link);
?>