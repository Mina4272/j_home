﻿<?php
include "CheckPermission.php";
include "CheckManager.php";
include "../global.php";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $PageAdminTitle;?></title>
<link href="../type.css" rel="stylesheet" type="text/css" />
<style type="text/css">
<!--
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
}
-->
</style>
<link href="../script/DatePicker.css" rel="stylesheet" type="text/css" />
<Script LANGUAGE="Javascript" SRC="../script/DatePicker.js"></Script>
<Script type="text/javascript" language="javascript" src="../script/CheckForm.js"></Script>
<script type="text/JavaScript">
<!--
function jsCheck() 
		{
		if (ChkImp('MPassword',document.form1.MPassword.value,'密碼') == false) return false;
		if (ChkImp('MPasswordCheck',document.form1.MPasswordCheck.value,'確認密碼') == false) return false;
		if (jsTrim(document.form1.MPassword.value) != jsTrim(document.form1.MPasswordCheck.value))
				{
				alert ('您輸入的密碼與確認密碼不相同，請重新輸入！');
				document.form1.MPassword.value = '';
				document.form1.MPasswordCheck.value = '';
				document.form1.MPassword.focus();
				return false;
				}
		if (ChkImp('MName',document.form1.MName.value,'姓名') == false) return false;
    <?php if (trim($_SESSION["reg_MUID"]) == "Benson" || trim($_SESSION["reg_MUID"]) == "vivi" || trim($_SESSION["reg_MUID"]) == "jacky") {?>
		if (jsTrim(document.form1.Salary.value) != "") if (ChkNaN('Salary',document.form1.Salary.value,'本薪','') == false) return false;
		if (jsTrim(document.form1.Allowance.value) != "") if (ChkNaN('Allowance',document.form1.Allowance.value,'職務加給','') == false) return false;
		if (jsTrim(document.form1.FullAttendance.value) != "") if (ChkNaN('FullAttendance',document.form1.FullAttendance.value,'全勤獎金','') == false) return false;
		if (jsTrim(document.form1.Bonus.value) != "") if (ChkNaN('Bonus',document.form1.Bonus.value,'績效獎金','') == false) return false;
		if (jsTrim(document.form1.CLabor.value) != "") if (ChkNaN('CLabor',document.form1.CLabor.value,'勞保費-公司負擔','') == false) return false;
		if (jsTrim(document.form1.ELabor.value) != "") if (ChkNaN('ELabor',document.form1.ELabor.value,'勞保費-員工負擔','') == false) return false;
		if (jsTrim(document.form1.CHealth.value) != "") if (ChkNaN('CHealth',document.form1.CHealth.value,'健保費-公司負擔','') == false) return false;
		if (jsTrim(document.form1.EHealth.value) != "") if (ChkNaN('EHealth',document.form1.EHealth.value,'健保費-員工負擔','') == false) return false;
		if (jsTrim(document.form1.CRetirement.value) != "") if (ChkNaN('CRetirement',document.form1.CRetirement.value,'勞退提撥-公司負擔','') == false) return false;
		<?php }?>
		if (ChkEmail('EMail',document.form1.EMail.value,'E-Mail') == false) return false;
		if (document.form1.MPer[0].checked == false && document.form1.MPer[1].checked == false && document.form1.MPer[2].checked == false && document.form1.MPer[3].checked == false && document.form1.MPer[4].checked == false && document.form1.MPer[5].checked == false && document.form1.MPer[6].checked == false && document.form1.MPer[7].checked == false && document.form1.MPer[8].checked == false && document.form1.MPer[9].checked == false && document.form1.MPer[10].checked == false && document.form1.MPer[11].checked == false && document.form1.MPer[12].checked == false && document.form1.MPer[13].checked == false && document.form1.MPer[14].checked == false && document.form1.MPer[15].checked == false && document.form1.MPer[16].checked == false)
				{
				alert ('您必須選擇一項權限！');
				document.form1.MPer[0].focus();
				return false;
				}
		if (document.form1.IsLeft[0].checked) if (ChkDate('LeftYear',document.form1.LeftYear.value,document.form1.LeftMonth.value,document.form1.LeftDay.value,'離職日期') == false) return false;
		}
function CheckMPer(MPerValue)
		{
		if (MPerValue == "D") {
				if (document.form1.MPer[5].checked==true) {
						if (document.form1.MPer[6].checked==true) document.form1.MPer[6].checked=false;
						if (document.form1.MPer[7].checked==true) document.form1.MPer[7].checked=false;
						}
				}
		else if (MPerValue == "I") {
				if (document.form1.MPer[6].checked==true) if (document.form1.MPer[5].checked==true) document.form1.MPer[5].checked=false;
				}
		else if (MPerValue == "L") {
				if (document.form1.MPer[7].checked==true) if (document.form1.MPer[5].checked==true) document.form1.MPer[5].checked=false;
				}
		}
//-->
</script>
<style>
.button {
  background-color: #4CAF50; /* Green */
  border: none;
  color: white;
  padding: 16px 32px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 10px;
  margin: 4px 2px;
  -webkit-transition-duration: 0.4s; /* Safari */
  transition-duration: 0.4s;
  cursor: pointer;
}

.button1 {
  background-color: white; 
  color: black; 
  border: 2px solid #4CAF50;
  font-size: 15px;
}

.button1:hover {
  background-color: #4CAF50;
  color: white;
  font-size: 15px;
}

.button2 {
  background-color: white; 
  color: black; 
  border: 2px solid #008CBA;
}

.button2:hover {
  background-color: #008CBA;
  color: white;
}

.button3 {
  background-color: white; 
  color: black; 
  border: 2px solid #f44336;
}

.button3:hover {
  background-color: #f44336;
  color: white;
}

.button4 {
  background-color: white;
  color: black;
  border: 2px solid #e7e7e7;
}

.button4:hover {background-color: #e7e7e7;}

.button5 {
  background-color: white;
  color: black;
  border: 2px solid #555555;
}

.button5:hover {
  background-color: #555555;
  color: white;
}
</style>
</head>
<body>
<?php include "top.php";?>
<?php
$MID = $_GET['MID'];
$page = $_GET['page'];
if (trim($MID) == "")
		{
		mysqli_close($link);
		?>
		<script type="text/JavaScript">
			<!--
			alert ("查無資料，請冾網站管理人員！");
			history.go(-1);
			//-->
		</script>
		<?php
		exit;
		}
$SQL_Manager="select MUID,MPassword,MName,MEName,EmployeeNo,MPID,Salary,Allowance,FullAttendance,Bonus,CLabor,CHealth,ELabor,EHealth,CRetirement,CRetirementEmployee,Departments,Title,Ext,EMail,MIntro,MPer,ISEngineer,ISBusiness,DATEDIFF(NOW(),RDate) RDateCount,date_format(RDate,'%Y'),date_format(RDate,'%m'),date_format(RDate,'%d'),date_format(BirthDay,'%Y'),date_format(BirthDay,'%m'),date_format(BirthDay,'%d'),Address,RAddress,Tel,Mobile,BCode,BAccount,ifnull((SELECT sum(EVCount) FROM EmployeeVacation WHERE Deltag = 'N' AND MID=Manager.MID ),0) EVCount,IsLeft,date_format(LeftDate,'%Y'),date_format(LeftDate,'%m'),date_format(LeftDate,'%d') from Manager where Deltag='N' and MID = '".$MID."';";
$result_Manager=mysqli_query($link,$SQL_Manager) or die ("無法執行查詢");
if (mysqli_num_rows($result_Manager) == 0)
		{
		mysqli_free_result($result_Manager);
		mysqli_close($link);
		?>
		<SCRIPT language=javascript>
		<!--
		alert ("查無資料，請冾網站管理人員！"); 
		history.go(-1);
		//-->
		</SCRIPT>
		<?php 	
		exit;
		}
list($MUID,$MPassword,$MName,$MEName,$EmployeeNo,$MPID,$Salary,$Allowance,$FullAttendance,$Bonus,$CLabor,$CHealth,$ELabor,$EHealth,$CRetirement,$CRetirementEmployee,$Departments,$Title,$Ext,$EMail,$MIntro,$MPer,$ISEngineer,$ISBusiness,$RDateCount,$RYear,$RMonth,$RDay,$BirthYear,$BirthMonth,$BirthDay,$Address,$RAddress,$Tel,$Mobile,$BCode,$BAccount,$EVCount,$IsLeft,$LeftYear,$LeftMonth,$LeftDay)=mysqli_fetch_row($result_Manager);
mysqli_free_result($result_Manager);

?>
<table width="100%" border="0" cellspacing="0" cellpadding="5">
	<tr>
    <td width="160" height="600" align="left" valign="top">
			<?php include "menu.php";?>
    </td>
    <td valign="top">
    	<table width="100%" border="0" cellpadding="0" cellspacing="0" >
    		<tr>
    			<td>
			    	<table width="750" border="0" cellpadding="0" cellspacing="0">
			    		<tr height="30">
			    			<td class="c2"><b>修改帳號資料</b></td>
			    		</tr>
			    	</table>
			    	<table width="750" border="0" cellpadding="0" cellspacing="0">
			        <form name="form1" method="post" action="ManagerEditDB.php" onSubmit="return jsCheck();">
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td width="160" align="right" class="c3">帳 號：</td>
			          <td class="h3"><?php echo $MUID;?>                  
			          	<input type="hidden" id="MID" name="MID" value="<?php echo $MID;?>">
			          	<input type="hidden" id="page" name="page" value="<?php echo $page;?>">
			          </td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">密 碼：</td>
			          <td class="h3"><input type="password" id="MPassword" name="MPassword" size="20" value="<?php echo $MPassword;?>"></td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">密碼確認：</td>
			          <td class="h3"><input type="password" id="MPasswordCheck" name="MPasswordCheck" size="20" value="<?php echo $MPassword;?>"></td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">中文姓名：</td>
			          <td class="h3"><input type="text" id="MName" name="MName" size="20" value="<?php echo $MName;?>"></td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">英文姓名：</td>
			          <td class="h3"><input type="text" id="MEName" name="MEName" size="20" value="<?php echo $MEName;?>"></td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">員工編號：</td>
			          <td class="h3"><input type="text" id="EmployeeNo" name="EmployeeNo" size="20" value="<?php echo $EmployeeNo;?>"></td>
			        </tr>
			        <?php if (trim(strtolower($_SESSION["reg_MUID"])) == strtolower("Benson") || trim(strtolower($_SESSION["reg_MUID"])) == "amanda" || trim(strtolower($_SESSION["reg_MUID"])) == "jacky") {?>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">身份證號：</td>
			          <td class="h3"><input type="text" id="MPID" name="MPID" size="20" value="<?php echo $MPID;?>"></td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">本薪：</td>
			          <td class="h3"><input type="text" id="Salary" name="Salary" size="20" value="<?php echo $Salary;?>"><a href="SalaryHistory.php?MID=<?php echo $MID;?>" class="button1" target="_blank">歷史薪資</a></td>
					  <!--<td><input type="button" name="SalaryHistory" value="歷史薪資" class="input_bot" onclick="javascript:location.href='SalaryHistory.php?MID=<?php echo $MID;?>'"></td>-->
					 </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">職務加給：</td>
			          <td class="h3"><input type="text" id="Allowance" name="Allowance" size="20" value="<?php echo $Allowance;?>"></td>
			        </tr>
					<tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">全勤獎金：</td>
			          <td class="h3"><input type="text" id="FullAttendance" name="FullAttendance" size="20" value="<?php echo $FullAttendance;?>"></td>
			        </tr>
					<tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">績效獎金：</td>
			          <td class="h3"><input type="text" id="Bonus" name="Bonus" size="20" value="<?php echo $Bonus;?>"></td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">勞保費-公司負擔：</td>
			          <td class="h3"><input type="text" id="CLabor" name="CLabor" size="20" value="<?php echo $CLabor;?>"></td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">勞保費-員工負擔：</td>
			          <td class="h3"><input type="text" id="ELabor" name="ELabor" size="20" value="<?php echo $ELabor;?>"></td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">健保費-公司負擔：</td>
			          <td class="h3"><input type="text" id="CHealth" name="CHealth" size="20" value="<?php echo $CHealth;?>"></td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">健保費-員工負擔：</td>
			          <td class="h3"><input type="text" id="EHealth" name="EHealth" size="20" value="<?php echo $EHealth;?>"></td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">勞退提撥-公司負擔：</td>
			          <td class="h3"><input type="text" id="CRetirement" name="CRetirement" size="20" value="<?php echo $CRetirement;?>"></td>
			        </tr>
					<tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">自願勞退提撥-員工負擔：</td>
			          <td class="h3"><input type="text" id="CRetirementEmployee" name="CRetirementEmployee" size="20" value="<?php echo $CRetirementEmployee;?>"></td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">行庫代號：</td>
			          <td class="h3"><input type="text" id="BCode" name="BCode" size="10" value="<?php echo $BCode;?>"></td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">銀行帳號：</td>
			          <td class="h3"><input type="text" id="BAccount" name="BAccount" size="60" value="<?php echo $BAccount;?>"></td>
			        </tr>
			        <?php }?>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">部門別：</td>
			          <td class="h3">
			          	<select id="Departments" name="Departments">
			          		<option value="A"<?php if (trim($Departments) == "A") echo " selected";?>>工程部</option>
			          		<option value="B"<?php if (trim($Departments) == "B") echo " selected";?>>行政品質部</option>
			          		<option value="C"<?php if (trim($Departments) == "C") echo " selected";?>>客服部</option>
			          	</select>
			          </td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">職稱：</td>
			          <td class="h3"><input type="text" id="Title" name="Title" size="20" value="<?php echo $Title;?>"></td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">分機號碼：</td>
			          <td class="h3"><input type="text" id="Ext" name="Ext" size="10" value="<?php echo $Ext;?>"></td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">E-Mail：</td>
			          <td class="h3"><input type="text" id="EMail" name="EMail" size="60" value="<?php echo $EMail;?>"></td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">是否為案件工程師：</td>
			          <td class="h3">
			          	<input type="radio" name="ISEngineer" value="Y"<?php if (trim($ISEngineer) == "Y") echo " checked";?>> 是　
			          	<input type="radio" name="ISEngineer" value="N"<?php if (trim($ISEngineer) == "N") echo " checked";?>> 否
			          </td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">是否為客服：</td>
			          <td class="h3">
			          	<input type="radio" name="ISBusiness" value="Y"<?php if (trim($ISBusiness) == "Y") echo " checked";?>> 是　
			          	<input type="radio" name="ISBusiness" value="N"<?php if (trim($ISBusiness) == "N") echo " checked";?>> 否
			          </td>
			        </tr>
			        <tr height="60" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">權限管理：</td>
			          <td class="h3">
			          	<input type="checkbox" id="MPer" name="MPer[]" value="A"<?php if (trim(strstr($MPer,'A')) != "") echo " checked";?>> 客戶資料管理
			          	<input type="checkbox" id="MPer" name="MPer[]" value="P"<?php if (trim(strstr($MPer,'P')) != "") echo " checked";?>> 報價/機密約定事項(收入)
			          	<input type="checkbox" id="MPer" name="MPer[]" value="Q"<?php if (trim(strstr($MPer,'Q')) != "") echo " checked";?>> 報價/機密約定事項(支出)<br>
			          	<input type="checkbox" id="MPer" name="MPer[]" value="B"<?php if (trim(strstr($MPer,'B')) != "") echo " checked";?>> 客戶案件管理
			          	<input type="checkbox" id="MPer" name="MPer[]" value="C"<?php if (trim(strstr($MPer,'C')) != "") echo " checked";?>> 重要零組件搜尋引擎<br>
			          	<input type="checkbox" id="MPer" name="MPer[]" value="D"<?php if (trim(strstr($MPer,'D')) != "") echo " checked";?> onclick="javascript:CheckMPer('D');"> 客戶案件帳務管理
			          	<input type="checkbox" id="MPer" name="MPer[]" value="I"<?php if (trim(strstr($MPer,'I')) != "") echo " checked";?> onclick="javascript:CheckMPer('I');"> 帳務收入管理
			          	<input type="checkbox" id="MPer" name="MPer[]" value="L"<?php if (trim(strstr($MPer,'L')) != "") echo " checked";?> onclick="javascript:CheckMPer('L');"> 帳務支出管理
			          	<input type="checkbox" id="MPer" name="MPer[]" value="E"<?php if (trim(strstr($MPer,'E')) != "") echo " checked";?>> 一般帳務管理<br>
			          	<input type="checkbox" id="MPer" name="MPer[]" value="F"<?php if (trim(strstr($MPer,'F')) != "") echo " checked";?>> 帳務報表
			          	<input type="checkbox" id="MPer" name="MPer[]" value="G"<?php if (trim(strstr($MPer,'G')) != "") echo " checked";?>> 系統帳號管理
			          	<input type="checkbox" id="MPer" name="MPer[]" value="H"<?php if (trim(strstr($MPer,'H')) != "") echo " checked";?>> 公佈欄管理
			          	<input type="checkbox" id="MPer" name="MPer[]" value="J"<?php if (trim(strstr($MPer,'J')) != "") echo " checked";?>> 請假單簽核<br>
			          	<input type="checkbox" id="MPer" name="MPer[]" value="K"<?php if (trim(strstr($MPer,'K')) != "") echo " checked";?>> 費用申請簽核
			          	<input type="checkbox" id="MPer" name="MPer[]" value="M"<?php if (trim(strstr($MPer,'M')) != "") echo " checked";?>> 事項處理
			          	<input type="checkbox" id="MPer" name="MPer[]" value="N"<?php if (trim(strstr($MPer,'N')) != "") echo " checked";?>> 教育訓練
			          	<input type="checkbox" id="MPer" name="MPer[]" value="O"<?php if (trim(strstr($MPer,'O')) != "") echo " checked";?>> 薪資管理
			          </td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">到職日：</td>
			          <td class="h3">
		              <input id="RYear" name="RYear" type="text" size="4" value="<?php echo $RYear;?>" /> 年 
		              <input id="RMonth" name="RMonth" type="text" size="2" value="<?php echo $RMonth;?>" /> 月 
		              <input id="RDay" name="RDay" type="text" size="2" value="<?php echo $RDay;?>" /> 日 
		              <img src="../images/icon.gif" width="16" height="18" style="cursor: hand" onclick="javascript:displayDatePicker('RYear','RMonth','RDay');"/> 
			          </td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">特別休假：</td>
			          <td class="h3">
		              <?php
		              //$SDate = (floor($RDateCount / 365));
		              //if ($SDate < 1) $VDate = 0;
		              //else if ($SDate >= 1 && $SDate < 3) $VDate = 7;
		              //else if ($SDate >= 3 && $SDate < 5) $VDate = 10;
		              //else if ($SDate >= 5 && $SDate < 10) $VDate = 14;
		              //else if ($SDate >= 10) {
		              //		$VDate = 14 + ($SDate-10);
		              //		if ($VDate > 30) $VDate = 30;
		              //		}
		              echo "<font color=blue><b>".round($EVCount,4)."</b></font> 天";
		              ?>
			          </td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">生日：</td>
			          <td class="h3">
		              <input id="BirthYear" name="BirthYear" type="text" size="4" value="<?php echo $BirthYear;?>" /> 年 
		              <input id="BirthMonth" name="BirthMonth" type="text" size="2" value="<?php echo $BirthMonth;?>" /> 月 
		              <input id="BirthDay" name="BirthDay" type="text" size="2" value="<?php echo $BirthDay;?>" /> 日 
		              <img src="../images/icon.gif" width="16" height="18" style="cursor: hand" onclick="javascript:displayDatePicker('BirthYear','BirthMonth','BirthDay');"/>
			          </td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">連絡地址：</td>
			          <td class="h3"><input type="text" id="Address" name="Address" size="60" value="<?php echo $Address;?>"></td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">戶籍地址：</td>
			          <td class="h3"><input type="text" id="RAddress" name="RAddress" size="60" value="<?php echo $RAddress;?>"></td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">聯絡電話：</td>
			          <td class="h3"><input type="text" id="Tel" name="Tel" size="30" value="<?php echo $Tel;?>"></td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">手機號碼：</td>
			          <td class="h3"><input type="text" id="Mobile" name="Mobile" size="30" value="<?php echo $Mobile;?>"></td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">是否離職：</td>
			          <td class="h3">
			          	<input type="radio" name="IsLeft" value="Y"<?php if (trim($IsLeft) == "Y") echo " checked";?>> 是　
			          	<input type="radio" name="IsLeft" value="N"<?php if (trim($IsLeft) == "N") echo " checked";?>> 否
			          </td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">離職日期	：</td>
			          <td class="h3">
		              <input id="LeftYear" name="LeftYear" type="text" size="4" value="<?php echo $LeftYear;?>" /> 年 
		              <input id="LeftMonth" name="LeftMonth" type="text" size="2" value="<?php echo $LeftMonth;?>" /> 月 
		              <input id="LeftDay" name="LeftDay" type="text" size="2" value="<?php echo $LeftDay;?>" /> 日 
		              <img src="../images/icon.gif" width="16" height="18" style="cursor: hand" onclick="javascript:displayDatePicker('LeftYear','LeftMonth','LeftDay');"/> 
			          </td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">備註：</td>
			          <td class="h3"><input type="text" id="MIntro" name="MIntro" size="60" value="<?php echo $MIntro;?>"></td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td class="c3">相關檔案：</td>
			          <td class="h3"></td>
			        </tr>
			        <tr height="40" align="center">
			          <td colspan="2" class="h3">
			          	<IFRAME marginWidth="0" marginHeight="0" src="ManagerFile.php?MID=<?php echo $MID;?>" frameBorder="1" width="100%" scrolling="yes" height=250></IFRAME> 
			        </tr>
			        <tr height="40" align="center">
			          <td colspan="2" class="h3"><input type="submit" name="submit" class="input_bot" value="送 出"></td>
			        </tr>
				      </form>
			      </table>
    			</td>
    		</tr>
    	</table>
    </td>
	</tr>
</table>
<?php include "down.php";?>
</body>
</html>
<?php
mysqli_close($link);
?>