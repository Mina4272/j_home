<?php
include "CheckPermission.php";
include "../global.php";
include "include/page_function.php";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $PageAdminTitle;?></title>
<link href="../type.css" rel="stylesheet" type="text/css" />
<link href="../script/DatePicker.css" rel="stylesheet" type="text/css" />
<Script LANGUAGE="Javascript" SRC="../script/DatePicker.js"></Script>
<style type="text/css">
<!--
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
}
-->
</style>
<Script type="text/javascript" language="javascript" src="../script/CheckForm.js"></Script>
</head>
<body>
<?php include "top.php";?>
<table width="100%" border="0" cellspacing="0" cellpadding="5">
	<tr>
    <td width="160" height="600" align="left" valign="top">
			<?php include "menu.php";?>
		</td>
    <td valign="top">
    	<table width="100%" border="0" cellpadding="0" cellspacing="0">
    		<tr>
    			<td>
			    	<table width="750" border="0" cellpadding="0" cellspacing="0">
			    		<tr height="30">
			    			<td class="c2">儀器設備管理</td>
			    		</tr>
			    	</table>
			    	<table width="750" border="0" cellpadding="0" cellspacing="0">
			    		<tr>
							<td><input type="button" name="add" value="新 增" class="input_bot" onclick="javascript:location.href='DeviceAdd.php';"></td>
			    		</tr>
			    		
			    	</table>
			    	<?php
						$page = empty($_GET['page'])?"":$_GET['page'];
						if (trim($page) == "") $page = 1;
						$page_rows=15;  //每頁筆數
						$php_Self = "Device.php";  //分頁web檔名
						$button_css = "h4";
						$limit_txt =" limit ".(($page-1) * $page_rows).",".$page_rows;
						$url_str = "";
						$Sql_str="SELECT * FROM device d where d.deltag = 'N' order by d.device_no desc;";
						$SQL_Device="SELECT * FROM device d where d.deltag = 'N' order by d.device_no desc ".$limit_txt.";";
						
						$result_Device=mysqli_query($link,$SQL_Device) or die ("無法執行查詢");
			    	?>
			    	<table width="auto" border="0" cellpadding="5" cellspacing="2" class="s2">
			        <tr align="center">
					  <td width="auto" background="../images/table_bg.gif" class="t21">儀器負責人</td>
			          <td width="auto" background="../images/table_bg.gif" class="t21">儀器名稱(中文)</td>
			          <td width="auto" background="../images/table_bg.gif" class="t21">儀器名稱(英文)</td>
					  <td width="auto" background="../images/table_bg.gif" class="t21">儀器廠牌</td>
					  <td width="auto" background="../images/table_bg.gif" class="t21">儀器型號</td>
					  <td width="auto" background="../images/table_bg.gif" class="t21">儀器序號</td>
					  <td width="auto" background="../images/table_bg.gif" class="t21">儀器規格</td>
					  <td width="auto" background="../images/table_bg.gif" class="t21">儀器購入日期</td>
					  <td width="auto" background="../images/table_bg.gif" class="t21">儀器採購金額</td>
					  <td width="auto" background="../images/table_bg.gif" class="t21">供應商</td>
					  <td width="auto" background="../images/table_bg.gif" class="t21">修改</td>
			        </tr>
		          <?php
		          $tmp = 1;
		          while(list($device_no,$device_people,$device_name_chinese,$device_name_english,$device_label,$device_model,$device_serial,$device_specification,$device_date,$device_money,$supplier)=mysqli_fetch_row($result_Device)){
								//$SQL_Manager="SELECT MName,MEName FROM Manager Where Deltag='N' and MUID='".$PE."'";
								//$result_Manager=mysqli_query($link,$SQL_Manager) or die ("無法執行查詢");
								//list($MName,$MEName)=mysqli_fetch_row($result_Manager);
								//mysqli_free_result($result_Manager);
		        	//if (trim($ExpireDate)=="0000-00-00") $ExpireDate="";
		        	?>
		        	<tr<?php if ($tmp%2 == 0) echo " bgcolor=\"#F6F6F6\"";?>>
					  <td width="auto" class="h3" align="center"><?php echo $device_people;?></td>
					  <td width="auto" class="h3" align="center"><?php echo $device_name_chinese;?></td>
					  <td width="auto" class="h3" align="center"><?php echo $device_name_english;?></td>
					  <td width="auto" class="h3" align="center"><?php echo $device_label;?></td>
					  <td width="auto" class="h3" align="center"><?php echo $device_model;?></td>
					  <td width="auto" class="h3" align="center"><?php echo $device_serial;?></td>
					  <td width="auto" class="h3" align="center"><?php echo $device_specification;?></td>
					  <td width="auto" class="h3" align="center"><?php echo $device_date;?></td>
					  <td width="auto" class="h3" align="center"><?php echo $device_money;?></td>
					  <td width="auto" class="h3" align="center"><?php echo $supplier;?></td>
					  <td align="center">
						<input type="button" name="edit" value="修改" class="input_bot" onclick="javascript:location.href='DeviceEdit.php?device_no=<?php echo $device_no;?>';"><br>
			          	<input type="button" name="edit" value="刪除" class="input_bot" onclick="javascript:if (confirm('您是否確定要刪除？')) location.href='DeviceDelDB.php?device_no=<?php echo $device_no;?>';"<?php if (trim($_SESSION["reg_MUID"]) != "vivi") echo " disabled";?>>
			          </td>
			        </tr>
			        <?php
            			$tmp++;
			      			}
            	mysqli_free_result($result_Device);
			        ?>
			    	</table>
			      <table width="880" border="0" cellpadding="5" cellspacing="2" class="s2">
			        <tr align="center">
			          <td bgcolor="#E8F0C2" class="h4"><?php Page_show($Sql_str,$page_rows,$php_Self,$link,$page,$url_str,$button_css);?></td>
			        </tr>
			      </table>
    			</td>
    		</tr>
    	</table>
    </td>
	</tr>
</table>
<?php include "down.php";?>
</body>
</html>
<?php
mysqli_close($link);
?>