﻿<?php	
include "CheckPermission.php";
include "../global.php";
include "include/utf8.php";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $PageAdminTitle;?></title>
<link href="../type.css" rel="stylesheet" type="text/css" />
<style type="text/css">
<!--
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
}
-->
</style>
<link href="../script/DatePicker.css" rel="stylesheet" type="text/css" />
<Script LANGUAGE="Javascript" SRC="../script/DatePicker.js"></Script>
<Script type="text/javascript" language="javascript" src="../script/CheckForm.js"></Script>
</head>
<body>
<?php include "top.php";?>
<?php
$TID = $_GET['TID'];
$page = $_GET['page'];
$KeyWord = $_GET['KeyWord'];
if (trim($TID) == "")
		{
		mysqli_close($link);
		?>
		<script type="text/JavaScript">
			<!--
			alert ("查無資料，請冾網站管理人員！");
			history.go(-1);
			//-->
		</script>
		<?php
		exit;
		}
$SQL_Training="select TID,TDate,(select TCTTitle from TrainingCamp where Deltag='N' and TCID = Training.TCID) as TCTTitle,TTitle,Lecturer,TLocation,othertext,TTrain,outtext,THour,TExam,othernote,TFile,TContent,TTrainRecord,AddUser,AddDate,ProcUser,ProcDate from Training where Deltag='N' and TID = '".$TID."';";
$result_Training=mysqli_query($link,$SQL_Training) or die ("無法執行查詢");
if (mysqli_num_rows($result_Training) == 0)
		{
		mysqli_free_result($result_Training);
		mysqli_close($link);
		?>
		<SCRIPT language=javascript>
		<!--
		alert ("查無資料，請冾網站管理人員！"); 
		history.go(-1);
		//-->
		</SCRIPT>
		<?php 	
		exit;
		}
list($TID,$TDate,$TCTTitle,$TTitle,$Lecturer,$TLocation,$othertext,$TTrain,$outtext,$THour,$TExam,$othernote,$TFile,$TContent,$TTrainRecord,$AddUser,$AddDate,$ProcUser,$ProcDate)=mysqli_fetch_row($result_Training);
mysqli_free_result($result_Training);
?>
<table width="100%" border="0" cellspacing="0" cellpadding="5">
	<tr>
    <td width="160" height="600" align="left" valign="top">
			<?php include "menu.php";?>
    </td>
    <td valign="top">
    	<table width="100%" border="0" cellpadding="0" cellspacing="0">
    		<tr>
    			<td>
			    	<table width="750" border="0" cellpadding="0" cellspacing="0">
			    		<tr height="30">
			    			<td class="c2">教育訓練資訊</td>
							<td width="80" align="center"><input type="button" name="PCopy" value="複製課程" class="input_bot" onclick="javascript:if (confirm('您是否確定要複製案件？')) window.open ('TrainingCopyDB.php?TID=<?php echo $TID;?>','TrainingCopyDB','height=10,width=10,top=200,left=200,scrollbars=no,status=no');"></td>
			    		</tr>
			    	</table>
			    	<table width="750" border="0" cellpadding="0" cellspacing="0">
			        <tr height="40" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td width="120" align="right" class="c3">日期：</td>
			          <td class="h3"><?php echo $TDate;?></td>
			        </tr>
					<tr height="40" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td width="120" align="right" class="c3">課程主要名稱：</td>
			          <td class="h3"><?php echo $TCTTitle;?></td>
			        </tr>
			        <tr height="40" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td width="120" align="right" class="c3">課程名稱：</td>
			          <td class="h3"><?php echo $TTitle;?></td>
			        </tr>
			        <tr height="40" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td width="120" align="right" class="c3">講師：</td>
			          <td class="h3"><?php echo $Lecturer;?></td>
			        </tr>
					<tr height="40" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td width="120" align="right" class="c3">上課地點:</td>
			          <td class="h3">
						<?php 
							if($TLocation=="meetingroom"){
								echo "會議室";
								
							}else if($TLocation=="other"){
								echo "".$othertext;
							}
									
						;?>
						</td>
			        </tr>
					<tr height="40" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td width="120" align="right" class="c3">內訓/外訓:</td>
			          <td class="h3">
						<?php
							if($TTrain == "in"){
								echo "內訓";
							}else if($TTrain =="out"){
								echo "外訓".$outtext;
							}
						
						
						?>
					  </td>
			        </tr>
					<tr height="40" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td width="120" align="right" class="c3">課程時間：</td>
			          <td class="h3"><?php echo $THour;?></td>
			        </tr>
					<tr height="40" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td width="120" align="right" class="c3">測試方法：</td>
			          <td class="h3">
						<?php 
							if($TExam =="no"){
								echo "無";
							}else if($TExam =="pen"){
								echo "筆試";
							}else if($TExam =="mouth"){
								echo "口試";
							}else if($TExam =="operating"){
								echo "實作";
							}else if($TExam =="other"){
								echo "其他".$othernote;
							}
						
						?>
					  </td>
			        </tr>
			        <tr height="40" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td width="120" align="right" class="c3">課程大綱：</td>
			          <td class="h3"><?php echo $TContent;?>
			          </td>
			        </tr>
			        <tr height="40" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td width="120" align="right" class="c3">課程檔案：</td>
			          <td class="h3">
			          	<?php if (trim($TFile) != "") {?>
			          	<input type="button" name="edit" value="下 載" class="input_bot" onclick="javascript:location.href='getfile.php?FolderName=Admin\\TFile&FileName=<?php echo $TFile;?>';">
			          	<?php }?>
			          </td>
			        </tr>
					<tr height="40" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td width="120" align="right" class="c3">教育訓練紀錄：</td>
			          <td class="h3">
			          	<?php if (trim($TTrainRecord) != "") {?>
			          	<input type="button" name="edit" value="下 載" class="input_bot" onclick="javascript:location.href='getfile.php?FolderName=Admin\\TTFile&FileName=<?php echo $TTrainRecord;?>';">
			          	<?php }?>
			          </td>
					  <td class="h3">
						<input type="button" name="edit" value="下載教育訓練紀錄表" class="input_bot" onclick="javascript:location.href='Training.php?TID=<?php echo $TID;?>'">
					  </td>
			        </tr>
					<tr height="40" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
						<td align="right" class="c3">參與人員：</td>
						<td class="h3">
						<?php 
							$select = "select m.MName,m.MEName from Trainingexam te inner join manager m on te.mid = m.mid and m.deltag='N' where te.deltag='N' and te.TID='".$TID."'";
							$result_select=mysqli_query($link,$select) or die ("無法執行新增");
							while(list($MName,$MEName)=mysqli_fetch_row($result_select)){
								echo $MName.$MEName."<br/>";
							}
						
						?>
						</td>
			        </tr>
			        <tr height="40" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">新增人員：</td>
			          <td class="h3"><?php echo $AddUser;?>　<?php echo $AddDate;?></td>
			        </tr>
			        <?php if (trim($ProcUser) != "") {?>
			        <tr height="40" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">最後更新：</td>
			          <td class="h3"><?php echo $ProcUser;?>　<?php echo $ProcDate;?>
			          </td>
			        </tr>
			        <?php }?>
			        <tr height="40" align="center">
			          <td colspan="2" class="h3"><input type="button" name="button" class="input_bot" value="回列表" onclick="javascript:location.href='TrainingList.php?page=<?php echo $page;?>&KeyWord=<?php echo urlencode($KeyWord);?>';"></td>
			        </tr>
			      </table>
    			</td>
    		</tr>
    	</table>
    </td>
	</tr>
</table>
<?php include "down.php";?>
</body>
</html>
<?php
mysqli_close($link);
?>