﻿<?php
include "CheckPermission.php";
include "CheckEmployeePay.php";
include "../global.php";
include "include/page_function.php";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $PageAdminTitle;?></title>
<link href="../type.css" rel="stylesheet" type="text/css" />
<link href="../script/DatePicker.css" rel="stylesheet" type="text/css" />
<Script LANGUAGE="Javascript" SRC="../script/DatePicker.js"></Script>
<style type="text/css">
<!--
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
}
-->
</style>
<Script type="text/javascript" language="javascript" src="../script/CheckForm.js"></Script>
<script type="text/JavaScript">
<!--
function jsCheck() 
		{
		if (jsTrim(document.form1.SYear.value) != "" || jsTrim(document.form1.SMonth.value) != "" || jsTrim(document.form1.SDay.value) != "") if (ChkDate('SYear',document.form1.SYear.value,document.form1.SMonth.value,document.form1.SDay.value,'使用起始時間') == false) return false;
		if (jsTrim(document.form1.EYear.value) != "" || jsTrim(document.form1.EMonth.value) != "" || jsTrim(document.form1.EDay.value) != "") if (ChkDate('EYear',document.form1.EYear.value,document.form1.EMonth.value,document.form1.EDay.value,'使用結束時間') == false) return false;
		if (jsTrim(document.form1.SYear.value) != "" && jsTrim(document.form1.SMonth.value) != "" && jsTrim(document.form1.SDay.value) != "" && jsTrim(document.form1.EYear.value) != "" && jsTrim(document.form1.EMonth.value) != "" && jsTrim(document.form1.EDay.value) != "") if (CompareDate('SYear',document.form1.SYear.value,document.form1.SMonth.value,document.form1.SDay.value,document.form1.EYear.value,document.form1.EMonth.value,document.form1.EDay.value,'使用起始時間','使用結束時間') == false) return false;
		}

function EmployeeVacationExport() 
		{
		document.form_exp.SYear.value = document.form1.SYear.value;
		document.form_exp.SMonth.value = document.form1.SMonth.value;
		document.form_exp.SDay.value = document.form1.SDay.value;
		document.form_exp.EYear.value = document.form1.EYear.value;
		document.form_exp.EMonth.value = document.form1.EMonth.value;
		document.form_exp.EDay.value = document.form1.EDay.value;
		document.form_exp.QEVType.value = document.form1.QEVType.value;
		document.form_exp.KeyWord.value = document.form1.KeyWord.value;
		document.form_exp.submit();
		}
//-->
</script>
</head>

<body>
<?php include "top.php";?>
<?php
$SqlMID = "";
$SqlTxt ="";
$SDate = empty($_POST['SDate'])?"":$_POST['SDate'];
if (trim($SDate) == "") $SDate = empty($_GET['SDate'])?"":$_GET['SDate'];
$EDate = empty($_POST['EDate'])?"":$_POST['EDate'];
if (trim($EDate) == "") $EDate = empty($_GET['EDate'])?"":$_GET['EDate'];
if (trim($SDate) == "") {
		$SYear = empty($_POST['SYear'])?"":$_POST['SYear'];
		$SMonth = empty($_POST['SMonth'])?"":$_POST['SMonth'];
		$SDay = empty($_POST['SDay'])?"":$_POST['SDay'];
		if (trim($SYear) != "" || trim($SMonth) != "" || trim($SDay) != "") if (checkdate($SMonth,$SDay ,$SYear)) $SDate = $SYear."-".$SMonth."-".$SDay;
		}
if (trim($EDate) == "") {
		$EYear = empty($_POST['EYear'])?"":$_POST['EYear'];
		$EMonth = empty($_POST['EMonth'])?"":$_POST['EMonth'];
		$EDay = empty($_POST['EDay'])?"":$_POST['EDay'];
		if (trim($EYear) != "" || trim($EMonth) != "" || trim($EDay) != "") if (checkdate($EMonth,$EDay ,$EYear)) $EDate = $EYear."-".$EMonth."-".$EDay;
		}
$QEVType = empty($_POST['QEVType'])?"":$_POST['QEVType'];
if (trim($QEVType) == "") $QEVType = empty($_GET['QEVType'])?"":$_GET['QEVType'];
$KeyWord = empty($_POST['KeyWord'])?"":$_POST['KeyWord'];
if (trim($KeyWord) == "") $KeyWord = empty($_GET['KeyWord'])?"":$_GET['KeyWord'];

if (trim($SDate) != "" && trim($EDate) != "") $SqlTxt = $SqlTxt." and (AddDate >= '".$SDate." 00:00:00') and (AddDate <= '".$EDate." 23:59:59') ";
else if (trim($SDate) != "" && trim($EDate) == "") $SqlTxt = $SqlTxt." and (AddDate >= '".$SDate." 00:00:00') ";
else if (trim($SDate) == "" && trim($EDate) != "") $SqlTxt = $SqlTxt." and (AddDate <= '".$EDate." 23:59:59') ";
if (trim($QEVType) != "") $SqlTxt = $SqlTxt." and EVType = '".$QEVType."' ";
if (trim($KeyWord) != "") {
		$SQL_Manager="select MID from Manager where EmployeeNo like '%".$KeyWord."%' or MUID like '%".$KeyWord."%' or MName like '%".$KeyWord."%' order by MID;";
		$result_Manager=mysqli_query($link,$SQL_Manager) or die ("無法執行查詢");
		
		while(list($MMID)=mysqli_fetch_row($result_Manager)){
				if (trim($SqlMID) == "") $SqlMID = $MMID;
				else $SqlMID = $SqlMID.",".$MMID;
				}
		mysqli_free_result($result_Manager);
		}
if (trim($SqlMID) != "") $SqlMID = " MID in (".$SqlMID.")";
if (trim($KeyWord) != "") {
		if (trim($SqlMID) == "") $SqlTxt = $SqlTxt." and EVDesc like '%".$KeyWord."%'";
		else $SqlTxt = $SqlTxt." and (EVDesc like '%".$KeyWord."%' or ".$SqlMID.")";
		}

?>
<table width="100%" border="0" cellspacing="0" cellpadding="5">
	<tr>
    <td width="160" height="600" align="left" valign="top">
			<?php include "menu.php";?>
    </td>
    <td valign="top">
    	<table width="100%" border="0" cellpadding="0" cellspacing="0">
    		<tr>
    			<td>
			    	<table width="750" border="0" cellpadding="0" cellspacing="0">
			    		<form name="form1" method="post" action="EmployeeVacationList.php" onSubmit="return jsCheck();">
			    		<tr height="30">
			    			<td width="120" class="c2">年假使用管理</td>
			    		</tr>
			    		<tr height="30">
			    			<td class="h3"><font color=blue><b>使用時間：</b></font>
			            <input name="SYear" type="text" size="4" value="<?php echo $SYear;?>" />年
			            <input name="SMonth" type="text" size="2" value="<?php echo $SMonth;?>" />月
			            <input name="SDay" type="text" size="2" value="<?php echo $SDay;?>" />日
			            <img src="../images/icon.gif" width="16" height="18" style="cursor: hand" onclick="javascript:displayDatePicker('SYear','SMonth','SDay');"/>～
			            <input name="EYear" type="text" size="4" value="<?php echo $EYear;?>" />年
			            <input name="EMonth" type="text" size="2" value="<?php echo $EMonth;?>" />月
			            <input name="EDay" type="text" size="2" value="<?php echo $EDay;?>" />日
			            <img src="../images/icon.gif" width="16" height="18" style="cursor: hand" onclick="javascript:displayDatePicker('EYear','EMonth','EDay');"/>
			    			</td>
			    		</tr>
			    		<tr height="30">
			    			<td class="h3">
			    				<font color=blue><b>年假類型：</b></font>
			    				<select name="QEVType">
			    					<option value="">不限</option>
			    					<option value="A"<?php if (trim($QEVType) == "A") echo " selected";?>>新增年假</option>
			    					<option value="B"<?php if (trim($QEVType) == "B") echo " selected";?>>使用年假</option>
			    					<option value="C"<?php if (trim($QEVType) == "C") echo " selected";?>>年假折現</option>
			    				</select>　
			    				<font color=blue><b>關鍵字：</b></font><input type="text" name="KeyWord" size="15" value="<?php echo $KeyWord;?>">　
			    				<input type="submit" name="submit" value="查 詢" class="input_bot"> 
			    				<input type="button" name="button" class="input_bot" value="全部列出" onclick="javascript:location.href='EmployeeVacationList.php';"> 
			    				<input type="button" name="add" value="年假折現" class="input_bot" onclick="javascript:location.href='EmployeeVacationDiscount.php';">
			    				<input type="button" name="add" value="新增年假" class="input_bot" onclick="javascript:location.href='EmployeeVacationAdd.php';">
			    				<input type="button" name="report" class="input_bot" value="報表輸出" onclick="javascript:EmployeeVacationExport();">
			    				</td>
			    		</tr>
			    		</form>
			    	</table>
						<?php
						$page = empty($_GET['page'])?"":$_GET['page'];
						if (trim($page) == "") $page = 1;
						$page_rows=15;  //每頁筆數
						$php_Self = "EmployeeVacationList.php";  //分頁web檔名
						$button_css = "h4";
						$limit_txt =" limit ".(($page-1) * $page_rows).",".$page_rows;
						$url_str = "&SDate=".$SDate."&EDate=".$EDate."&QEVType=".$QEVType."&KeyWord=".urlencode($KeyWord);
						$Sql_str="select EVID from EmployeeVacation where Deltag='N' ".$SqlTxt." order by EVID desc;";
						$SQL_EmployeeVacation="select EVID,MID,(select MName from Manager where MID=EmployeeVacation.MID) MName,(select MEName from Manager where MID=EmployeeVacation.MID) MEName,(select EmployeeNo from Manager where MID=EmployeeVacation.MID) EmployeeNo,EVType,MVID,date_format(EPDate,'%Y'),date_format(EPDate,'%m'),EVCount,EVDesc,date_format(AddDate,'%Y'),date_format(AddDate,'%m'),date_format(AddDate,'%d') from EmployeeVacation where Deltag='N' ".$SqlTxt." order by EVID desc ".$limit_txt.";";
						//echo $SQL_EmployeeVacation;
						//exit;
						//$SQL_EmployeeVacation="select * from (select EVID,MID,(select MName from Manager where MID=EmployeeVacation.MID) MName,(select MEName from Manager where MID=EmployeeVacation.MID) MEName,(select EmployeeNo from Manager where MID=EmployeeVacation.MID) EmployeeNo,EVType,MVID,date_format(EPDate,'%Y'),date_format(EPDate,'%m'),EVCount,EVDesc,date_format(AddDate,'%Y'),date_format(AddDate,'%m'),date_format(AddDate,'%d'),Deltag from EmployeeVacation) a where Deltag='N' ".$SqlTxt." order by EVID desc ".$limit_txt.";";
						$result_EmployeeVacation=mysqli_query($link,$SQL_EmployeeVacation) or die ("無法執行查詢");

						$SQL_ECount="select sum(EVCount) from EmployeeVacation where Deltag='N' ".$SqlTxt.";";
						//echo $SQL_ECount;
						$result_ECount=mysqli_query($link,$SQL_ECount) or die ("無法執行查詢");
						list($ECount)=mysqli_fetch_row($result_ECount);
						mysqli_free_result($result_ECount);
						?>
			    	<table width="750" border="0" cellpadding="0" cellspacing="0">
			        <tr height="30">
			        	<td width="50" class="t21" align="right">小計：</td>
			          <td class="h3"><font color=blue><b><?php echo round($ECount,4);?> 天</b></font></td>
			        </tr>
			      </table>
			    	<table width="750" border="0" cellpadding="5" cellspacing="2" class="s2">
			        <tr align="center">
			          <td width="120" background="../images/table_bg.gif" class="t21">使用時間</td>
			          <td width="120" background="../images/table_bg.gif" class="t21">員工編號</td>
			          <td width="120" background="../images/table_bg.gif" class="t21">姓名</td>
			          <td width="60" background="../images/table_bg.gif" class="t21">類型</td>
			          <td width="60" background="../images/table_bg.gif" class="t21">年假<br>天數</td>
			          <td width="180" background="../images/table_bg.gif" class="t21">說明</td>
			          <td width="60" background="../images/table_bg.gif" class="t21">修 改</td>
			        </tr>
		          <?php
		          $tmp = 1;
		          while(list($EVID,$MID,$MName,$MEName,$EmployeeNo,$EVType,$MVID,$EPYear,$EPMonth,$EVCount,$EVDesc,$AddYear,$AddMonth,$AddDay)=mysqli_fetch_row($result_EmployeeVacation)){
		          if (trim($EVType) == "A") $EVTypeTxt="新增<br>年假";
		          else if (trim($EVType) == "B") $EVTypeTxt="使用<br>年假";
		          else if (trim($EVType) == "C") $EVTypeTxt="年假<br>折現";
		          else $EVTypeTxt=$EVType;
		        	?>
		        	<tr<?php if ($tmp%2 == 0) echo " bgcolor=\"#F6F6F6\"";?>>
			          <td class="h3" align="center"><?php echo $AddYear."-".$AddMonth."-".$AddDay;?></td>
			          <td class="h3" align="center"><?php echo $EmployeeNo;?></td>
			          <td class="h3" align="center"><?php echo $MEName.$MName;?></td>
			          <td class="h3" align="center"><?php echo $EVTypeTxt;?></td>
			          <td class="h3" align="center"><?php echo $EVCount;?></td>
			          <td class="h3" align="center"><?php echo $EVDesc;?>
			          	<?php if (trim($MVID)!="") {?>
			          	<input type="button" name="ManagerVac" class="input_bot" value="相關資訊" onclick="javascript:window.open ('MVacList.php?QMVID=<?php echo $MVID;?>','MVacList','');">
			          	<?php }
			          	if (trim($EVType) == "C") echo "折現月份：".$EPYear."-".$EPMonth;
			          	?>
			          	
			          </td>
			          <td align="center"><input type="button" name="edit" value="修 改" class="input_bot" onclick="javascript:location.href='EmployeeVacationEdit.php?EVID=<?php echo $EVID;?>&page=<?php echo $page;?><?php echo $url_str;?>';"></td>
			          <!--<td align="center"><input type="button" name="edit" value="刪 除" class="input_bot" onclick="javascript:if (confirm('您是否確定要刪除？')) location.href='EmployeeVacationDelDB.php?EVID=<?php echo $EVID;?>&page=<?php echo $page;?><?php echo $url_str;?>';"<?php if (trim($EVType) == "B" && trim($MVID) != "") echo " disabled";?>></td>-->
			        </tr>
			        <?php
            			$tmp++;
			      			}
            	mysqli_free_result($result_EmployeeVacation);
			        ?>
			      </table>
			      <table width="750" border="0" cellpadding="5" cellspacing="2" class="s2">
			        <tr align="center">
			          <td bgcolor="#E8F0C2" class="h4"><?php Page_show($Sql_str,$page_rows,$php_Self,$link,$page,$url_str,$button_css);?></td>
			        </tr>
			      </table>
    			</td>
    		</tr>
    	</table>
    </td>
	</tr>
</table>
<form name="form_exp" action="EmployeeVacationExport.php" method="post" target="_EmployeeVacationExport">
	<input type="hidden" name="SYear">
	<input type="hidden" name="SMonth">
	<input type="hidden" name="SDay">
	<input type="hidden" name="EYear">
	<input type="hidden" name="EMonth">
	<input type="hidden" name="EDay">
	<input type="hidden" name="QEVType">
	<input type="hidden" name="KeyWord">
</form>
<?php include "down.php";?>
</body>
</html>
<?php
mysqli_close($link);
?>