﻿<?php
include "CheckPermission.php";
include "CheckProjectAccounting.php";
include "../global.php";
include "include/function.php";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>全威驗證科技內部系統</title>
<style type="text/css">
<!--
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
}
.Q1 {
	font-family: "標楷體", Arial, sans-serif;
	font-size: 18px;
	color: #000000;
	font-weight: bold;
	}
.Q2 {
	font-family: Arial, sans-serif;
	font-size: 18px;
	color: #000000;
	font-weight: bold;
	}
.Q3 {
	font-family: Arial, sans-serif;
	font-size: 18px;
	color: #000000;
	font-weight: bold;
	font-style:italic;
	}
.Q4 {
	font-family: "標楷體", Arial, sans-serif;
	font-size: 12px;
	color: teal;
	font-weight: bold;
	}
.Q5 {
	font-family: "細明體", Arial, sans-serif;
	font-size: 12px;
	color: teal;
	font-weight: bold;
	}
.Q6 {
	font-family: "標楷體", Arial, sans-serif;
	font-size: 12px;
	color: #000000;
	}
.Q7 {
	font-family: "標楷體", Arial, sans-serif;
	font-size: 12px;
	color: #000000;
	font-weight: bold;
	}
.Q8 {
	font-family: Arial, sans-serif;
	font-size: 11px;
	color: #000000;
	font-weight: bold;
	}
.Q9 {
	font-family: "標楷體", Arial, sans-serif;
	font-size: 10px;
	color: #000000;
	font-weight: bold;
	}
.Q10 {
	font-family: Arial, sans-serif;
	font-size: 11px;
	color: #000000;
	}
-->
</style></head>

<body>
<?php
$PID = $_GET['PID'];
$Florin = $_GET['Florin'];
$CheckQuotation = $_GET['CheckQuotation'];
if (trim($Florin) == "") $Florin = "T";
if (trim($PID) == "")
		{
		mysqli_close($link);
		?>
		<script type="text/JavaScript">
			<!--
			alert ("查無資料，請冾網站管理人員！");
			history.go(-1);
			//-->
		</script>
		<?php
		exit;
		}
$SQL_Project="select PUID,PName,ApplyItem,CID,CName,CTel,CFax,Contact,CMobile,CEMail,CAddress,QuoteDate,IFlorin,(select CUID from Customer where Deltag='N' and CID = Project.CID) as CUID,InvoiceCUID,InvoiceTitle,InvoiceAddress,Leadtime,Trademark,PTax,ModelName,SeriesModel,(select TrademarkTxt from Customer where Deltag='N' and CID = Project.CID) as TrademarkTxt from Project where Deltag='N' and PID = '".$PID."';";
$result_Project=mysqli_query($link,$SQL_Project) or die ("無法執行查詢");
if (mysqli_num_rows($result_Project) == 0)
		{
		mysqli_free_result($result_Project);
		mysqli_close($link);
		?>
		<SCRIPT language=javascript>
		<!--
		alert ("查無資料，請冾網站管理人員！"); 
		history.go(-1);
		//-->
		</SCRIPT>
		<?php 	
		exit;
		}
list($PUID,$PName,$ApplyItem,$CID,$CName,$CTel,$CFax,$Contact,$CMobile,$CEMail,$CAddress,$QuoteDate,$IFlorin,$CUID,$InvoiceCUID,$InvoiceTitle,$InvoiceAddress,$Leadtime,$Trademark,$PTax,$ModelName,$SeriesModel,$TrademarkTxt)=mysqli_fetch_row($result_Project);
mysqli_free_result($result_Project);
if (trim($Trademark) != "") $TrademarkTxt = $Trademark;
?>
<table width="720" border="0" cellpadding="0" cellspacing="0">
	<tr>
		<td>
			<table width="720" border="0" cellpadding="0" cellspacing="0">
				<tr>
					<td colspan="3" height="5"></td>
				</tr>
				<tr>
					<td width="170" rowspan="4" align="center"><img src="../images/logo.gif" border="0" width="100" height="96" /></td>
					<td width="350" height="20">&nbsp;</td>
					<td width="200" height="20">&nbsp;</td>
				</tr>
				<tr>
					<td height="20">&nbsp;</td>
					<td height="20">&nbsp;</td>
				</tr>
				<tr>
					<td class="Q1" height="20">全威驗證科技有限公司</td>
					<td class="Q2" height="20">TEL:+886-2-8201-1888</td>
				</tr>
				<tr>
					<td class="Q3" height="20"><font color="red">R</font>ight&nbsp;&nbsp;<font color="red">P</font>ower&nbsp;&nbsp;<font color="red">C</font>ertification&nbsp;&nbsp;Inc.</td>
					<td class="Q2" height="20">FAX:+886-2-8201-8388</td>
				</tr>
				<tr>
					<td colspan="3" height="20">&nbsp;</td>
				</tr>
				<tr>
					<td colspan="3" height="20" align="center" valign="bottom" class="Q2"><font color="purple">服  務  報  價  單 Quotation</font></td>
				</tr>
				<tr>
					<td colspan="3" height="20" align="center" valign="top" class="Q2"><hr width="220" height="25" color="purple"></td>
				</tr>
			</table>
			<table width="680" border="1" cellpadding="0" cellspacing="0" bordercolor="#000000" align="center">
				<tr>
					<td>
						<table width="680" border="0" cellpadding="0" cellspacing="0" align="center">
							<tr height="20">
								<td class="Q4" width="155">公司名稱 company：</td>
								<td class="Q5" width="255"><?php echo $CName;?></td>
								<td class="Q4" width="190">合約編號Contract No.</td>
								<td class="Q5" width="80" align="center"><font color="#000000"><?php echo $PUID;?></font></td>
							</tr>
							<tr height="20">
								<td class="Q4">代表人Representative：</td>
								<td class="Q5"><?php echo $Contact;?></td>
								<td class="Q4">發票抬頭  Title of invoice：</td>
								<td class="Q5" align="center"><font color="#000000"><?php if (trim($InvoiceTitle) != "") echo $InvoiceTitle; else echo "同左";?></font></td>
							</tr>
							<tr height="20">
								<td class="Q4">電話Telephone No.：</td>
								<td class="Q5"><?php echo $CTel;?></td>
								<td class="Q4">統一編號Bul No.</td>
								<td class="Q5" align="center"><font color="#000000"><?php if (trim($InvoiceCUID) != "") echo $InvoiceCUID; else echo $CUID;?></font></td>
							</tr>
							<tr height="20">
								<td class="Q4">地址Address：</td>
								<td class="Q5"><?php echo $CAddress;?></td>
								<td class="Q4">發票寄送地址Address：</td>
								<td class="Q5" align="center"><font color="#000000"><?php if (trim($InvoiceAddress) != "") echo $InvoiceAddress; else echo "同左";?></font></td>
							</tr>
							<tr height="20">
								<td class="Q4">專案名稱Subject：</td>
								<td class="Q5"><?php echo $PName;?>-<?php echo $ApplyItem;?></td>
								<td class="Q4">報價日期 Date：</td>
								<td class="Q5" align="center"><font color="#000000"><?php echo $QuoteDate;?></font></td>
							</tr>
						</table>
						<table width="680" border="0" cellpadding="0" cellspacing="0" align="center" height="1" style="border-style: dashed; border-width: 2px" bordercolor="#000000">
							<tr>
								<td>
									<table width="680" border="0" cellpadding="0" cellspacing="0" align="center">
										<tr height="20">
											<td class="Q4" width="305" align="center"><font color="navy">服務內容 Service Description</font></td>
											<td class="Q4" width="100" align="center"><font color="navy">Amount</font></td>
											<td class="Q4" width="60" align="center"><font color="navy">Tax</font></td>
											<td class="Q4" width="215" align="center"><font color="navy">備 註 Note</font></td>
										</tr>
									</table>
								</td>
							</tr>
						</table>
						<table width="680" border="0" cellpadding="0" cellspacing="0" align="center">
							<?php
							$SQL_ProjectAccounting="select PAID,PAMode,PAItem,Charges,Rate,ChargesOther,PATax,PAStatus,PADate,PANote from ProjectAccounting where Deltag='N' and PAMode='I' and PID = '".$PID."' and (PAStatus = 'W' or PAStatus = 'S') order by PAMode asc,PAID asc;";
							$result_ProjectAccounting=mysqli_query($link,$SQL_ProjectAccounting) or die ("無法執行查詢");
							$ShowLine = 19 - mysqli_num_rows($result_ProjectAccounting);
		          $SumPrice = 0;
		          $PATaxPrice = 0;
		          while(list($PAID,$PAMode,$PAItem,$Charges,$Rate,$ChargesOther,$PATax,$PAStatus,$PADate,$PANote)=mysqli_fetch_row($result_ProjectAccounting)){
								if (trim($Florin) == "O") $Charges = $ChargesOther;
								$SumPrice = $SumPrice + $Charges;
		          	if (trim($PATax) == "") {
				          	if (trim($PTax) == "Y") $PATax = "Y";
				          	else if (trim($PTax) == "N") $PATax = "N";
		          			}
		          	if (trim($PATax) == "Y") $PATaxPrice = $PATaxPrice + round($Charges*0.05);
							?>
							<tr height="15">
								<td class="Q6" width="305" align="center"><?php echo $PAItem;?></td>
								<td class="Q6" width="100" align="center"><?php echo $Charges;?></td>
								<td class="Q6" width="60" align="center">
									<?php
			          	if (trim($PATax) == "Y") echo round($Charges*0.05);
			          	else echo "0";
									?>
								</td>
								<td class="Q6" width="215"><?php echo $PANote;?></td>
							</tr>
			        <?php
			      			}
            	mysqli_free_result($result_ProjectAccounting);
            	for ($tmp=0;$tmp<=$ShowLine-1;$tmp++){
			        ?>
							<tr height="15">
								<td class="Q6" align="center">&nbsp;</td>
								<td class="Q6" align="right">&nbsp;</td>
								<td class="Q6" align="right">&nbsp;</td>
								<td class="Q6" align="right">&nbsp;</td>
								<td class="Q6">&nbsp;</td>
							</tr>
							<?php }?>
							<tr height="15">
								<td class="Q6" align="center" colspan="5">
									Leadtime：<?php echo $Leadtime;?>　
									Trademark：<?php echo $TrademarkTxt;?>　
									Modelname：<?php echo $ModelName;?> / <?php echo $SeriesModel;?>
								</td>
							</tr>
						</table>
						<table width="680" border="0" cellpadding="0" cellspacing="0" align="center" height="1" style="border-style: dashed; border-width: 2px" bordercolor="#000000">
							<tr>
								<td>
									<table width="680" border="0" cellpadding="0" cellspacing="0" align="center">
										<tr height="20">
											<td class="Q4" width="410">&nbsp;<font color="navy">委託費用 Amount</font></td>
											<td class="Q7" width="90" align="center"><?php echo $SumPrice;?></td>
											<td class="Q7" width="180" align="center">&nbsp;</td>
										</tr>
										<tr height="20">
											<td class="Q4">&nbsp;<font color="navy">營業稅 Tax</font></td>
											<td class="Q7" align="center"><?php echo $PATaxPrice;?></td>
											<td class="Q7" align="center">&nbsp;</td>
										</tr>
									</table>
								</td>
							</tr>
						</table>
						<table width="680" border="0" cellpadding="0" cellspacing="0" align="center">
							<tr height="20">
								<td class="Q4" width="410" colspan="3">&nbsp;<font color="navy">總　計 Total (<?php if (trim($Florin) == "T") echo "TWD"; else echo $IFlorin;?>)</font></td>
								<td class="Q7" width="90" align="center"><?php echo ($SumPrice + $PATaxPrice);?></td>
								<td class="Q7" width="180" align="center">&nbsp;</td>
							</tr>
						</table>

					</td>
				</tr>
			</table>
			<table width="690" border="0" cellpadding="0" cellspacing="0" align="center">
				<tr height="20">
					<td></td>
				</tr>
				<tr height="15">
					<td class="Q8">Payment information:</td>
				</tr>
				<tr height="15">
					<td><span class="Q8">Beneficiary Bank Name：</span><span class="Q10">Chinatrust Commercial Bank 電匯 (金融機構:中國信託商業銀行 基隆分行)</span></td>
				</tr>
				<tr height="15">
					<td><span class="Q8">Swift Code：</span><span class="Q10">CTCBTWTPXXX</span></td>
				</tr>
				<tr height="15">
					<td><span class="Q8">Beneficiary Account Name：</span><span class="Q10">Right Power Certification Inc. (全威驗證科技有限公司)</span></td>
				</tr>
				<tr height="15">
					<td><span class="Q8">Beneficiary Account No.：</span><span class="Q10">381-54018788-5</span></td>
				</tr>
				<tr height="15">
					<td class="Q8"></td>
				</tr>
				<tr height="15">
					<td class="Q8">Samples after testing:</td>
				</tr>
				<tr height="15">
					<td><span class="Q10">(Please marked as below. In case of you do not marked, it means you agree that we can help you to junk all samples.)</span></td>
				</tr>
				<tr height="15">
					<td></td>
				</tr>
				<tr height="15">
					<td class="Q8">□ Do not return samples</td>
				</tr>
				<tr height="15">
					<td class="Q8">□ Return all samples after testing. Sending fee will be paid by Client.</td>
				</tr>
				<tr height="30">
					<td></td>
				</tr>
			</table>
			<table width="680" border="0" cellpadding="0" cellspacing="0" align="center">
				<tr height="30">
					<td>
						<table width="300" border="1" cellpadding="4" cellspacing="0" bordercolor="#000000" align="center">
							<tr height="73">
								<td class="Q8" valign="top">客戶簽名 Client Signature/日期 Date：</td>
							</tr>
						</table>
					</td>
					<td>
						<table width="250" border="1" cellpadding="0" cellspacing="0" bordercolor="#000000" align="center">
							<tr>
								<td>
									<table width="300" border="1" cellpadding="4" cellspacing="0" align="center">
										<tr height="50">
											<td class="Q8" width="110" valign="top">承辦業務 Sales：</td>
											<td class="Q8" align="center">王郁齡 Vivi Wang</td>
										</tr>
									</table>
									<table width="300" border="0" cellpadding="4" cellspacing="0" align="center">
										<tr height="15">
											<td class="Q8" align="center">行動電話 Mobile：0933-335-410</td>
										</tr>
									</table>
								</td>
							</tr>
						</table>
					</td>
				</tr>
			</table>
			<table width="700" border="0" cellpadding="0" cellspacing="0" align="center">
				<tr height="30">
					<td></td>
				</tr>
				<tr height="15">
					<td class="Q9">242台北縣新莊市瓊林路11-2號1樓      1F., No. 11-2, Cyonglin Rd., Sinjhuang City, Taipei County 242, Taiwan</td>
				</tr>
			</table>
		</td>
	</tr>
</table>
</body>
</html>
<?php
if (trim($CheckQuotation) == "Y") {
		$QuotationURL="http://".$_SERVER["HTTP_HOST"]."/Admin/ProjectQuotationOutput.php?PID=".$PID."&Florin=".$Florin;
		$fp=fopen($QuotationURL,"r");
		$PQRUContent="";
		while($line=fgets($fp,512)){
			$PQRUContent.=$line;
			}
		fclose($fp);
		
		$PQRUID = "Q".rand_string(10, 'ABCDEFGHIJKLMNPQRSTUVWXYZ23456789abcdefghijklmnopqrstuvwxyz').$PID.$Florin;
		
		$now_time = date("Y-m-d H:i:s",mktime());
		$sql_update = "update ProjectQuotationRecord set Deltag='Y' where Deltag='N' and PID = '".$PID."';";
		$result_update=mysqli_query($link,$sql_update) or die ("無法執行修改");
		$sql_insert = "insert into ProjectQuotationRecord (PID,PQRUID,QuoteDate,PQRUContent,AddUser,AddDate,AddIP) values ('".$PID."','".$PQRUID."','".$QuoteDate."','".$PQRUContent."','".$_SESSION["reg_MUID"]."','".$now_time."','".$_SERVER["REMOTE_ADDR"]."');";
		$result_insert=mysqli_query($link,$sql_insert) or die ("無法執行新增");
		}
mysqli_close($link);
?>