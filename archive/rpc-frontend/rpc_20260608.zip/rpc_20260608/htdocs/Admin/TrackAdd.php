﻿<?php	
include "CheckPermission.php";
//include "CheckAgendum.php";
include "../global.php";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $PageAdminTitle;?></title>
<link href="../type.css" rel="stylesheet" type="text/css" />
<style type="text/css">
<!--
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
}
-->
</style>
<link href="../script/DatePicker.css" rel="stylesheet" type="text/css" />
<Script LANGUAGE="Javascript" SRC="../script/DatePicker.js"></Script>
<Script type="text/javascript" language="javascript" src="../script/CheckForm.js"></Script>
<script type="text/JavaScript">
function jsCheck() 
		{
		if (ChkDate('DYear',document.form1.DYear.value,document.form1.DMonth.value,document.form1.DDay.value,'儀器購入日期') == false) return false;
		if (jsTrim(document.form1.DYear.value) != "" || jsTrim(document.form1.DMonth.value) != "" || jsTrim(document.form1.DDay.value) != "") if (ChkDate('DYear',document.form1.DYear.value,document.form1.DMonth.value,document.form1.DDay.value,'儀器購入日期') == false) return false;
		if (ChkImp('device_name_english',document.form1.device_name_english.value,'儀器名稱(英文)') == false) return false;
		if (ChkImp('device_name_chinese',document.form1.device_name_chinese.value,'儀器名稱(中文)') == false) return false;
		if (ChkImp('device_label',document.form1.device_label.value,'廠牌') == false) return false;
		if (ChkImp('device_model',document.form1.device_model.value,'儀器型號') == false) return false;
		if (ChkImp('device_serial',document.form1.device_serial.value,'儀器序號') == false) return false;
		if (ChkImp('device_specification',document.form1.device_specification.value,'儀器規格') == false) return false;
		if (ChkImp('device_money',document.form1.device_money.value,'儀器採購金額') == false) return false;
		
		}


</script>
</head>
<body>
<?php include "top.php";?>
<table width="100%" border="0" cellspacing="0" cellpadding="5">
	<tr>
    <td width="160" height="600" align="left" valign="top">
			<?php include "menu.php";?>
    </td>
    <td valign="top">
    	<table width="100%" border="0" cellpadding="0" cellspacing="0">
    		<tr>
    			<td>
			    	<table width="750" border="0" cellpadding="0" cellspacing="0">
			    		<tr height="30">
			    			<td class="c2"><b>電子發票字軌</b></td>
			    		</tr>
			    	</table>
			    	<table width="1000" border="0" cellpadding="0" cellspacing="0">
			        <form name="form1" method="post" action="TrackAddDB.php" enctype="multipart/form-data">
						<tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
						  <td align="right" class="c3">請選擇檔案</td>
						  <td class="h3">
							<input type="file" id="file" name="file"></td>
						</tr>
						<tr height="40" align="center">
						  <td colspan="2" class="h3">
							
							<input type="submit" name="submit" class="input_bot" value="送 出">
						  </td>
						</tr>
				    </form>
			      </table>
    			</td>
    		</tr>
    	</table>
    </td>
	</tr>
</table>
<?php include "down.php";?>
</body>
</html>
<?php
mysqli_close($link);
?>