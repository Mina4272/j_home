﻿<?php
include "CheckPermission.php";
include "../global.php";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $PageAdminTitle;?></title>
<link href="../type.css" rel="stylesheet" type="text/css" />

</head>

<body>
<table width="520" border="0" align="center" cellpadding="2" cellspacing="0">
  <tr>
    <td align="center"><span class="c2"><b>祝本月壽星生日快樂</b></span>
    </td>
  </tr>
  <tr>
    <td align="left">
			<?php
			$SQL_Manager="SELECT MUID, MName, MEName, BirthDay FROM Manager WHERE IsLeft = 'N' AND Deltag = 'N' AND RDate IS NOT NULL AND date_format( BirthDay, '%Y' ) <> date_format( now( ) , '%Y' ) AND date_format( BirthDay, '%m' ) = date_format( now( ) , '%m' );";
			$result_Manager=mysqli_query($link,$SQL_Manager) or die ("無法執行查詢");
			?>
    	<table width="100%" border="0" cellpadding="2" cellspacing="2" class="s2">
        <tr align="center">
          <td width="100" background="../images/table_bg.gif" class="t21">帳號</td>
          <td background="../images/table_bg.gif" class="t21">姓名</td>
          <td background="../images/table_bg.gif" class="t21">生日</td>
        </tr>
        <?php
        $tmp = 1;
        while(list($MUID,$MName,$MEName,$BirthDay)=mysqli_fetch_row($result_Manager)){
      	?>
    	  <form name="CForm<?php echo $MID;?>" method="post">
	    	<tr<?php if ($tmp%2 == 0) echo " bgcolor=\"#F6F6F6\"";?>>
          <td align="center" class="h3"><?php echo $MUID;?></td>
          <td align="center" class="h3"><?php echo $MEName.$MName;?></td>
          <td align="center" class="h3"><?php echo $BirthDay;?></td>
        </tr>
    		</form>
        <?php
      			$tmp++;
      			}
      	mysqli_free_result($result_Manager);
        ?>
      </table>
    </td>
  </tr>
</table>
</body>
</html>
<?php
mysqli_close($link);
?>