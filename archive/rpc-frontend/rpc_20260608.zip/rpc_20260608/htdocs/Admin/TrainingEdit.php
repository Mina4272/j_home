﻿<?php	
include "CheckPermission.php";
include "CheckTraining.php";
include "../global.php";
include "include/utf8.php";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $PageAdminTitle;?></title>
<link href="../type.css" rel="stylesheet" type="text/css" />
<style type="text/css">
<!--
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
}
-->
</style>
<link href="../script/DatePicker.css" rel="stylesheet" type="text/css" />
<Script LANGUAGE="Javascript" SRC="../script/DatePicker.js"></Script>
<Script type="text/javascript" language="javascript" src="../script/CheckForm.js"></Script>
<script type="text/JavaScript">
<!--
function jsCheck() 
		{
		if (ChkDate('TYear',document.form1.TYear.value,document.form1.TMonth.value,document.form1.TDay.value,'日期') == false) return false;
		if (ChkImp('TTitle',document.form1.TTitle.value,'課程名稱') == false) return false;
		if (ChkImp('Lecturer',document.form1.Lecturer.value,'講師') == false) return false;
		if(document.form1.TExam.value =="pen"){
			alert("記得要把分數打上去喔");
			
		}
		}
//-->
</script>
</head>
<body>
<?php include "top.php";?>
<?php
$TID = $_GET['TID'];
//$page = $_GET['page'];
$KeyWord = $_GET['KeyWord'];
if (trim($TID) == "")
		{
		mysqli_close($link);
		?>
		<script type="text/JavaScript">
			<!--
			alert ("查無資料，請冾網站管理人員！");
			history.go(-1);
			//-->
		</script>
		<?php
		exit;
		}
$SQL_Training="select date_format(TDate,'%Y'),date_format(TDate,'%m'),date_format(TDate,'%d'),TCID,TTitle,Lecturer,TLocation,othertext,TTrain,outtext,THour,TExam,othernote,TFile,TContent,TTrainRecord,AddUser,AddDate,ProcUser,ProcDate from Training where Deltag='N' and TID = '".$TID."';";
$result_Training=mysqli_query($link,$SQL_Training) or die ("無法執行查詢");
if (mysqli_num_rows($result_Training) == 0)
		{
		mysqli_free_result($result_Training);
		mysqli_close($link);
		?>
		<SCRIPT language=javascript>
		<!--
		alert ("查無資料，請冾網站管理人員！"); 
		history.go(-1);
		//-->
		</SCRIPT>
		<?php 	
		exit;
		}
list($TYear,$TMonth,$TDay,$TCID,$TTitle,$Lecturer,$TLocation,$othertext,$TTrain,$outtext,$THour,$TExam,$othernote,$TFile,$TContent,$TTrainRecord,$AddUser,$AddDate,$ProcUser,$ProcDate)=mysqli_fetch_row($result_Training);
mysqli_free_result($result_Training);
?>
<table width="100%" border="0" cellspacing="0" cellpadding="5">
	<tr>
    <td width="160" height="600" align="left" valign="top">
			<?php include "menu.php";?>
    </td>
    <td valign="top">
    	<table width="100%" border="0" cellpadding="0" cellspacing="0">
    		<tr>
    			<td>
			    	<table width="750" border="0" cellpadding="0" cellspacing="0">
			    		<tr height="30">
			    			<td class="c2">修改教育訓練資訊</td>
			    		</tr>
			    	</table>
			    	<table width="750" border="0" cellpadding="0" cellspacing="0">
			        <form name="form1" method="post" action="TrainingEditDB.php" enctype="multipart/form-data" onSubmit="return jsCheck();">
			        <tr height="40" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td width="120" align="right" class="c3">日期：</td>
			          <td class="h3">
		              <input name="TYear" type="text" size="4" value="<?php echo $TYear;?>" /> 年 
		              <input name="TMonth" type="text" size="2" value="<?php echo $TMonth;?>" /> 月 
		              <input name="TDay" type="text" size="2" value="<?php echo $TDay;?>" /> 日 
		              <img src="../images/icon.gif" width="16" height="18" style="cursor: hand" onclick="javascript:displayDatePicker('TYear','TMonth','TDay');"/>
			          </td>
			        </tr>
					<tr height="40" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td width="120" align="right" class="c3">課程主要名稱:</td>
					  	<td class="h3">
						<select name="TCID">
							<!--<option value=""></option>-->
						<?php
							$SQL="select TCID,TCTTitle from TrainingCamp where Deltag='N' order by TCID;";
							$result=mysqli_query($link,$SQL) or die ("無法執行查詢");
			          		while(list($TCIDs,$TCTTitle)=mysqli_fetch_row($result)){
						?>
							<option value="<?php echo $TCIDs;?>" <?php if ($TCID == $TCIDs) echo " selected";?>><?php echo $TCTTitle;?></option>
					   <?php
							}
					   ?>
					   </select>
					   </td>
			        </tr>
			        <tr height="40" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td width="120" align="right" class="c3">課程名稱：</td>
			          <td class="h3">
			          	<input type="text" name="TTitle" size="80" value="<?php echo $TTitle;?>">
			          	<input type="hidden" name="TID" value="<?php echo $TID;?>">
			          	<input type="hidden" name="page" value="<?php echo $page;?>">
			          	<input type="hidden" name="KeyWord" value="<?php echo $KeyWord;?>">
			          </td>
			        </tr>
			        <tr height="40" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td width="120" align="right" class="c3">講師：</td>
			          <td class="h3">
			          	<input type="text" name="Lecturer" size="40" value="<?php echo $Lecturer;?>">
			          </td>
			        </tr>
					<tr height="40" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td width="120" align="right" class="c3">上課地點：</td>
			          <td class="h3">
			          	<input type="radio" name="TLocation" value="meetingroom" <?php if ($TLocation == "meetingroom") echo " checked";?>>會議室<br>
						<input type="radio" name="TLocation" value="other" <?php if ($TLocation == "other") echo " checked";?>>其他<input type="text" name="othertext" value="<?php echo ($othertext=="NULL")?"":$othertext;?>"><br>
			          </td>
			        </tr>
			        <tr height="40" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td width="120" align="right" class="c3">內訓/外訓：</td>
			          <td class="h3">
			          	<input type="radio" name="TTrain" value="in" <?php if ($TTrain == "in") echo " checked";?>>內訓<br>
						<input type="radio" name="TTrain" value="out" <?php if ($TTrain == "out") echo " checked";?>>外訓<input type="text" name="outtext" value="<?php echo ($outtext=="NULL")?"":$outtext;?>"><br>
			          </td>
			        </tr>
			        <tr height="40" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td width="120" align="right" class="c3">課程時數：</td>
			          <td class="h3">
						<select name="THour">
							<option value="0.5" <?php if ($THour == 0.5) echo " selected";?>>0.5</option>
							<option value="1" <?php if ($THour == 1) echo " selected";?>>1</option>
							<option value="2" <?php if ($THour == 2) echo " selected";?>>2</option>
							<option value="3" <?php if ($THour == 3) echo " selected";?>>3</option>
							<option value="4" <?php if ($THour == 4) echo " selected";?>>4</option>
							<option value="5" <?php if ($THour == 5) echo " selected";?>>5</option>
							<option value="6" <?php if ($THour == 6) echo " selected";?>>6</option>
							<option value="7" <?php if ($THour == 7) echo " selected";?>>7</option>
							<option value="8" <?php if ($THour == 8) echo " selected";?>>8</option>
							<option value="9" <?php if ($THour == 9) echo " selected";?>>9</option>
							<option value="10" <?php if ($THour == 10) echo " selected";?>>10</option>
							<option value="11" <?php if ($THour == 11) echo " selected";?>>11</option>
							<option value="12" <?php if ($THour == 12) echo " selected";?>>12</option>
							<option value="13" <?php if ($THour == 13) echo " selected";?>>13</option>
							<option value="14" <?php if ($THour == 14) echo " selected";?>>14</option>
							<option value="15" <?php if ($THour == 15) echo " selected";?>>15</option>
							<option value="16" <?php if ($THour == 16) echo " selected";?>>16</option>
							<option value="17" <?php if ($THour == 17) echo " selected";?>>17</option>
							<option value="18" <?php if ($THour == 18) echo " selected";?>>18</option>
							<option value="19" <?php if ($THour == 19) echo " selected";?>>19</option>
							<option value="20" <?php if ($THour == 20) echo " selected";?>>20</option>
							<option value="21" <?php if ($THour == 21) echo " selected";?>>21</option>
							<option value="22" <?php if ($THour == 22) echo " selected";?>>22</option>
							<option value="23" <?php if ($THour == 23) echo " selected";?>>23</option>
							<option value="24" <?php if ($THour == 24) echo " selected";?>>24</option>
							<option value="25" <?php if ($THour == 25) echo " selected";?>>25</option>
							<option value="26" <?php if ($THour == 26) echo " selected";?>>26</option>
							<option value="27" <?php if ($THour == 27) echo " selected";?>>27</option>
							<option value="28" <?php if ($THour == 28) echo " selected";?>>28</option>
							<option value="29" <?php if ($THour == 29) echo " selected";?>>29</option>
							<option value="30" <?php if ($THour == 30) echo " selected";?>>30</option>
							<option value="31" <?php if ($THour == 31) echo " selected";?>>31</option>
							<option value="32" <?php if ($THour == 32) echo " selected";?>>32</option>
							<option value="33" <?php if ($THour == 33) echo " selected";?>>33</option>
							<option value="34" <?php if ($THour == 34) echo " selected";?>>34</option>
							<option value="35" <?php if ($THour == 35) echo " selected";?>>35</option>
							<option value="36" <?php if ($THour == 36) echo " selected";?>>36</option>
							<option value="37" <?php if ($THour == 37) echo " selected";?>>37</option>
							<option value="38" <?php if ($THour == 38) echo " selected";?>>38</option>
							<option value="39" <?php if ($THour == 39) echo " selected";?>>39</option>
							<option value="40" <?php if ($THour == 40) echo " selected";?>>40</option>
						</select>
			          </td>
			        </tr>
					<tr height="40" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td width="120" align="right" class="c3">測試方法：</td>
			          <td class="h3">
			          	<input type="radio" name="TExam" value="no" <?php if ($TExam == "no") echo " checked";?>>無<br>
						<input type="radio" name="TExam" value="pen" <?php if ($TExam == "pen") echo " checked";?>>筆試<br>
						<input type="radio" name="TExam" value="mouth" <?php if ($TExam == "mouth") echo " checked";?>>口試<br>
						<input type="radio" name="TExam" value="operating" <?php if ($TExam == "operating") echo " checked";?>>實作<br>
						<input type="radio" name="TExam" value="other" <?php if ($TExam == "other") echo " checked";?>>其他<input type="text" name="othernote" value="<?php echo ($othernote=="NULL")?"":$othernote;?>"><br>
			          </td>
			        </tr>
			        <tr height="40" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td width="120" align="right" class="c3">課程大綱：</td>
			          <td class="h3">
    	          	<textarea name="TContent" cols="70" rows="15" class="h3"><?php echo str_replace("<br>","\r\n",$TContent);?></textarea>
			          </td>
			        </tr>
			        <tr height="40" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td width="120" align="right" class="c3">課程檔案：</td>
			          <td class="h3">
			          	<input type="file" name="TFile" size="60">
			          	<?php if (trim($TFile) != "") {?>
			          	<input type="button" name="edit" value="下 載" class="input_bot" onclick="javascript:location.href='getfile.php?FolderName=Admin\\TFile&FileName=<?php echo $TFile;?>';">
			          	<?php }?>
			          </td>
			        </tr>
					<tr height="40" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td width="120" align="right" class="c3">教育訓練紀錄：</td>
			          <td class="h3">
			          	<input type="file" name="TTrainRecord" size="60">
			          	<?php if (trim($TTrainRecord) != "") {?>
			          	<input type="button" name="edit" value="下 載" class="input_bot" onclick="javascript:location.href='getfile.php?FolderName=Admin\\TTFile&FileName=<?php echo $TTrainRecord;?>';">
			          	<?php }?>
			          </td>
			        </tr>
					<tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td class="c3">參與人員:</td>
			          <td class="h3"></td>
			        </tr>
			        <tr height="40" align="center">
			          <td colspan="2" class="h3">
			          	<IFRAME marginWidth="0" marginHeight="0" src="EmployeeContact.php?TID=<?php echo $TID;?>" frameBorder="1" width="100%" scrolling="yes" height=250></IFRAME> 
			        </tr>
			        <tr height="40" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">新增人員：</td>
			          <td class="h3"><?php echo $AddUser;?>　<?php echo $AddDate;?></td>
			        </tr>
			        <?php if (trim($ProcUser) != "") {?>
			        <tr height="40" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">最後更新：</td>
			          <td class="h3"><?php echo $ProcUser;?>　<?php echo $ProcDate;?>
			          </td>
			        </tr>
			        <?php }?>
			        <tr height="40" align="center">
			          <td colspan="2" class="h3"><input type="submit" name="submit" class="input_bot" value="送 出"></td>
			        </tr>
				      </form>
			      </table>
    			</td>
    		</tr>
    	</table>
    </td>
	</tr>
</table>
<?php include "down.php";?>
</body>
</html>
<?php
mysqli_close($link);
?>