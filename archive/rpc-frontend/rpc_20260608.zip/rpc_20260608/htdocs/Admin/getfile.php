<?php
include "CheckPermission.php";
include "../global.php";
include "include/send_file.php";

$FolderName = $_GET['FolderName'];
$FileName = $_GET['FileName'];
$FileCName = $_GET['FileCName'];
if (trim($FolderName) == "" || trim($FileName) == "")
	{
	?>
	<SCRIPT language=javascript>
	<!--
	alert ("File Error!!"); 
	self.close();
	//-->
	</SCRIPT>
	<?php	
	exit;
	}
mysqli_close($link);
$path = $_SERVER["DOCUMENT_ROOT"]."\\".$FolderName."\\".$FileName;
//echo $path;
//exit;
if (trim($FileCName) != "") {
		@copy($path,$_SERVER["DOCUMENT_ROOT"]."\\Admin\\Temp\\".urlencode($FileCName));
		$path = $_SERVER["DOCUMENT_ROOT"]."\\Admin\\Temp\\".urlencode($FileCName);
		}
if(!send_file($path)) {
       die ("file transfer failed");
   } else {
       //Log the download
   }
?>