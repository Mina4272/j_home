﻿<?php	
include "CheckPermission.php";
include "CheckProject.php";
include "../global.php";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $PageAdminTitle;?></title>
<link href="../type.css" rel="stylesheet" type="text/css" />
<style type="text/css">
<!--
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
}
-->
</style>
<link href="../script/DatePicker.css" rel="stylesheet" type="text/css" />
<Script LANGUAGE="Javascript" SRC="../script/DatePicker.js"></Script>
<Script type="text/javascript" language="javascript" src="../script/CheckForm.js"></Script>
<script type="text/JavaScript">
<!--
function jsCheck() 
		{
		if (jsTrim(document.form1.CName.value) == "")
				{
				alert ('請選擇案件所屬客戶！');
				document.form1.SelCID.focus();
				return false;
				}
		if (ChkImp('PName',document.form1.PName.value,'產品名稱') == false) return false;
		if (ChkImp('PE',document.form1.PE.value,'案件工程師') == false) return false;
		if (ChkImp('ApplyItem',document.form1.ApplyItem.value,'申請項目') == false) return false;
		if (ChkDate('StartYear',document.form1.StartYear.value,document.form1.StartMonth.value,document.form1.StartDay.value,'案件開始日期') == false) return false;
		if (ChkDate('PlanYear',document.form1.PlanYear.value,document.form1.PlanMonth.value,document.form1.PlanDay.value,'預計完成時間') == false) return false;
		if (jsTrim(document.form1.CloseYear.value) != "" || jsTrim(document.form1.CloseYear.value) != "" || jsTrim(document.form1.CloseYear.value) != "") if (ChkDate('CloseYear',document.form1.CloseYear.value,document.form1.CloseMonth.value,document.form1.CloseDay.value,'結案日期') == false) return false;
		if (jsTrim(document.form1.PNoteYear.value) != "" || jsTrim(document.form1.PNoteMonth.value) != "" || jsTrim(document.form1.PNoteDay.value) != "") if (ChkDate('PNoteYear',document.form1.PNoteYear.value,document.form1.PNoteMonth.value,document.form1.PNoteDay.value,'Safety 申請日期') == false) return false;
		if (jsTrim(document.form1.PAYear.value) != "" || jsTrim(document.form1.PAMonth.value) != "" || jsTrim(document.form1.PADay.value) != "") if (ChkDate('PAYear',document.form1.PAYear.value,document.form1.PAMonth.value,document.form1.PADay.value,'EMC 申請日期') == false) return false;
		if (jsTrim(document.form1.PAAYear.value) != "" || jsTrim(document.form1.PAAMonth.value) != "" || jsTrim(document.form1.PAADay.value) != "") if (ChkDate('PAAYear',document.form1.PAAYear.value,document.form1.PAAMonth.value,document.form1.PAADay.value,'加測日期') == false) return false;
		}
//-->
</script>
</head>
<body>
<?php include "top.php";?>
<?php
$PID = empty($_GET['PID'])?"":$_GET['PID'];
$page = empty($_GET['page'])?"":$_GET['page'];
$KeyWord = empty($_GET['KeyWord'])?"":$_GET['KeyWord'];
$QPStatus = empty($_GET['QPStatus'])?"":$_GET['QPStatus'];
$QPE = empty($_GET['QPE'])?"":$_GET['QPE'];
$QBMUID = empty($_GET['QBMUID'])?"":$_GET['QBMUID'];
$ISINo = empty($_GET['ISINo'])?"":$_GET['ISINo'];
$ISAdd = empty($_GET['ISAdd'])?"":$_GET['ISAdd'];
$Source = empty($_GET['Source'])?"":$_GET['Source'];
$PAAReCheck = empty($_GET['PAAReCheck'])?"":$_GET['PAAReCheck'];
if (trim($PID) == "")
		{
		mysqli_close($link);
		?>
		<script type="text/JavaScript">
			<!--
			alert ("查無資料，請冾網站管理人員！");
			history.go(-1);
			//-->
		</script>
		<?php
		exit;
		}
$SQL_Project="select PUID,CID,CName,CTel,CFax,CAddress,Contact,CMobile,CEMail,PStatus,PName,ModelName,SeriesModel,PE,test,Quote,ifnull( BMUID,'vivi') BMUID,ApplyItem,Agent,Canon,CCCCode,SNote,StartDate,date_format(StartDate,'%Y'),date_format(StartDate,'%m'),date_format(StartDate,'%d'),PlanDate,date_format(PlanDate,'%Y'),date_format(PlanDate,'%m'),date_format(PlanDate,'%d'),CloseDate,date_format(CloseDate,'%Y'),date_format(CloseDate,'%m'),date_format(CloseDate,'%d'),PNote,PNoteDate,date_format(PNoteDate,'%Y'),date_format(PNoteDate,'%m'),date_format(PNoteDate,'%d'),EMC,POther,PADate,date_format(PADate,'%Y'),date_format(PADate,'%m'),date_format(PADate,'%d'),PNote1,QuoteDate,ReturnDate,AddUser,AddDate,ProcUser,ProcDate,INo,InvoiceNote,(select CLevel from Customer where CID=Project.CID) CLevel,(select CFees from Customer where CID=Project.CID) CFees,(select CRecord from Customer where CID=Project.CID) CRecord,(select CRecordTxt from Customer where CID=Project.CID) CRecordTxt from Project where Deltag='N' and PID = '".$PID."';";
$result_Project=mysqli_query($link,$SQL_Project) or die ("無法執行查詢");
if (mysqli_num_rows($result_Project) == 0)
		{
		mysqli_free_result($result_Project);
		mysqli_close($link);
		?>
		<SCRIPT language=javascript>
		<!--
		alert ("查無資料，請冾網站管理人員！"); 
		history.go(-1);
		//-->
		</SCRIPT>
		<?php 	
		exit;
		}
list($PUID,$CID,$CName,$CTel,$CFax,$CAddress,$Contact,$CMobile,$CEMail,$PStatus,$PName,$ModelName,$SeriesModel,$PE,$test,$Quote,$BMUID,$ApplyItem,$Agent,$Canon,$CCCCode,$SNote,$StartDate,$StartYear,$StartMonth,$StartDay,$PlanDate,$PlanYear,$PlanMonth,$PlanDay,$CloseDate,$CloseYear,$CloseMonth,$CloseDay,$PNote,$PNoteDate,$PNoteYear,$PNoteMonth,$PNoteDay,$EMC,$POther,$PADate,$PAYear,$PAMonth,$PADay,$PNote1,$QuoteDate,$ReturnDate,$AddUser,$AddDate,$ProcUser,$ProcDate,$INo,$InvoiceNote,$CLevel,$CFees,$CRecord,$CRecordTxt)=mysqli_fetch_row($result_Project);
mysqli_free_result($result_Project);
?>
<table width="100%" border="0" cellspacing="0" cellpadding="5">
	<tr>
    <td width="160" height="600" align="left" valign="top">
			<?php include "menu.php";?>
    </td>
    <td valign="top">
    	<table width="100%" border="0" cellpadding="0" cellspacing="0">
    		<tr>
    			<td>
			    	<table width="750" border="0" cellpadding="0" cellspacing="0">
			    		<tr height="30">
			    			<td class="c2"><b>管理修改案件資料</b></td>
			    		</tr>
			    	</table>
			    	<table width="750" border="0" cellpadding="0" cellspacing="0">
			        <form name="form1" method="post" action="ProjectEditDB.php" onSubmit="return jsCheck();">
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td width="230" align="right" class="c3">案件編號：</td>
			          <td class="h3"><font color=blue><?php echo $PUID;?></font>
			          	<input name="PID" type="hidden" id="PID" value="<?php echo $PID;?>" />
			          	<input name="page" type="hidden" id="page" value="<?php echo $page;?>" />
			          	<input name="KeyWord" type="hidden" id="KeyWord" value="<?php echo $KeyWord;?>" />
			          	<input name="QPStatus" type="hidden" id="QPStatus" value="<?php echo $QPStatus;?>" />
			          	<input name="QPE" type="hidden" id="QPE" value="<?php echo $QPE;?>" />
			          	<input name="QBMUID" type="hidden" id="QBMUID" value="<?php echo $QBMUID;?>" />
			          	<input name="ISINo" type="hidden" id="ISINo" value="<?php echo $ISINo;?>" />
			          	<input name="ISAdd" type="hidden" id="ISAdd" value="<?php echo $ISAdd;?>" />
			         	</td>
			        </tr>
			        <?php
	          	if (trim($CLevel) == "C") $CLevel="B";
	          	if (trim($CLevel) == "A") $CLevelAlt="優(結案後直接給證書)";
	          	else if (trim($CLevel) == "B") $CLevelAlt="良(結案付款後給證書)";
	          	if (trim($CFees) == "A") $CFeesAlt="是(收據抬頭開全威)";
	          	else if (trim($CFees) == "B") $CFeesAlt="是(收據抬頭開申請人)";
	          	else if (trim($CFees) == "C") $CFeesAlt="否(不代送審)";
	          	if (trim($CRecord) == "A") $CRecordAlt="優(結案後月結60天)";
	          	else if (trim($CRecord) == "B") $CRecordAlt="良(月結30天)";
	          	else if (trim($CRecord) == "C") $CRecordAlt="付款開案";
	          	else if (trim($CRecord) == "D") $CRecordAlt="其他(".$CRecordTxt.")";
			        ?>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3"><font color=red><b>*</b></font>客戶名稱：</td>
			          <td class="h3">
			          	<table width="100%" border="0" cellpadding="0" cellspacing="0">
			          		<tr>
			          			<td>
			          				<div id="CNamePreview" style="display:"><?php echo $CName;?>
						          	<img src="../images/<?php echo $CLevel;?>1.gif" alt="<?php echo $CLevelAlt;?>"> 
						          	<img src="../images/<?php echo $CFees;?>1.gif" alt="<?php echo $CFeesAlt;?>"> 
			          				</div>
			          			</td>
			          			<td>
						          	<input type="hidden" id="CID" name="CID" value="<?php echo $CID;?>">
						          	<input type="hidden" id="CName" name="CName" value="<?php echo $CName;?>">
						          	<input type="button" id="SelCID" name="SelCID" class="input_bot" value="選 擇" onclick="javascript:window.open ('SelCustomer.php','SelCustomer','height=300,width=550,top=200,left=200,scrollbars=yes,status=yes');">
			          			</td>
			          		</tr>
			          	</table>
			          	
			          </td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">客戶電話：</td>
			          <td class="h3">
			          	<table width="100%" border="0" cellpadding="0" cellspacing="0">
			          		<tr>
			          			<td width="150">
			          				<div id="CTelPreview" style="display:"><?php echo $CTel;?></div>
						          	<input type="hidden" id="CTel" name="CTel" value="<?php echo $CTel;?>">
			          			</td>
			          			<td width="60" align="right" class="c3">傳真：</td>
			          			<td>
			          				<div id="CFaxPreview" style="display:"><?php echo $CFax;?></div>
			          				<input type="hidden" id="CFax" name="CFax" value="<?php echo $CFax;?>">
			          			</td>
			          		</tr>
			          	</table>
			          </td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">客戶地址：</td>
			          <td class="h3">
			          	<div id="CAddressPreview" style="display:"><?php echo $CAddress;?></div>
			          	<input type="hidden" id="CAddress" name="CAddress" value="<?php echo $CAddress;?>">
			          </td>
			        </tr>
			        <tr height="60" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">連絡人：</td>
			          <td class="h3">
			          	<table width="100%" border="0" cellpadding="0" cellspacing="0">
			          		<tr height="30">
			          			<td width="70" align="right">姓名：</td>
			          			<td width="180"><input type="text" id="Contact" name="Contact" size="20" value="<?php echo $Contact;?>"></td>
			          			<td width="60" align="right">電話：</td>
			          			<td><input type="text" id="CMobile" name="CMobile" size="20" value="<?php echo $CMobile;?>"></td>
			          		</tr>
			          		<tr height="30">
			          			<td width="70" align="right">E-MAil：</td>
			          			<td colspan="3"><input type="text" id="CEMail" name="CEMail" size="60" value="<?php echo $CEMail;?>"></td>
			          		</tr>
			          	</table>
			          </td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3"><font color=red><b>*</b></font>產品名稱：</td>
			          <td class="h3"><input type="text" id="PName" name="PName" size="60" value="<?php echo $PName;?>"></td>
			        </tr>
			        <?php if (trim($ModelName) == "") $ModelName = "NA";?>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">主型式：</td>
			          <td class="h3"><input type="text" id="ModelName" name="ModelName" size="60" value="<?php echo $ModelName;?>"></td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">系列型式：</td>
			          <td class="h3"><input type="text" id="SeriesModel" name="SeriesModel" size="60" value="<?php echo $SeriesModel;?>"></td>
			        </tr>
			        <?php
							$SQL_Manager="select MUID,MName,MEName from Manager where Deltag='N' and ISBusiness = 'Y' and IsLeft='N';";
							$result_Manager=mysqli_query($link,$SQL_Manager) or die ("無法執行查詢");
			        ?>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3"><font color=red><b>*</b></font>承辦客服：</td>
			          <td class="h3">
			          	<select id="BMUID" name="BMUID">
			          		<?php while(list($MUID,$MName,$MEName)=mysqli_fetch_row($result_Manager)){?>
			          		<option value="<?php echo $MUID;?>"<?php if (trim($MUID) == trim($BMUID)) echo " selected";?>><?php echo $MEName.$MName;?></option>
			          		<?php }?>
			          	</select>
			          </td>
			        </tr>
			        <?php
							mysqli_free_result($result_Manager);
							$SQL_Manager="select MUID,MName,MEName from Manager where Deltag='N' and ISEngineer = 'Y' and IsLeft='N';";
							$result_Manager=mysqli_query($link,$SQL_Manager) or die ("無法執行查詢");
			        ?>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3"><font color=red><b>*</b></font>案件工程師：</td>
			          <td class="h3">
			          	<select id="PE" name="PE">
			          		<?php while(list($MUID,$MName,$MEName)=mysqli_fetch_row($result_Manager)){?>
			          		<option value="<?php echo $MUID;?>"<?php if (trim($MUID) == trim($PE)) echo " selected";?>><?php echo $MEName.$MName;?></option>
			          		<?php }?>
			          	</select>
			          </td>
			        </tr>
					<?php
							mysqli_free_result($result_Manager);
							$SQL_Manager="select MUID,MName,MEName from Manager where Deltag='N' and ISEngineer = 'Y' and IsLeft='N';";
							$result_Manager=mysqli_query($link,$SQL_Manager) or die ("無法執行查詢");
			        ?>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">測試工程師：</td>
			          <td class="h3">
			          	<select id="test" name="test">
							<option value=""></option>
			          		<?php while(list($MUID,$MName,$MEName)=mysqli_fetch_row($result_Manager)){?>
			          		<option value="<?php echo $MUID;?>"<?php if (trim($MUID) == trim($test)) echo " selected";?>><?php echo $MEName.$MName;?></option>
			          		<?php }?>
			          	</select>
			          </td>
			        </tr>
			        <?php mysqli_free_result($result_Manager);?>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3"><font color=red><b>*</b></font>申請項目：</td>
			          <td class="h3"><input type="text" id="ApplyItem" name="ApplyItem" size="60" value="<?php echo $ApplyItem;?>"></td>
			        </tr>
					<tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">代理商：</td>
			          <td class="h3">
						<input type="radio" name="Agent" value=""<?php if (trim($Agent) == "") echo " checked";?>>無
						<input type="radio" name="Agent" value="RPC2"<?php if (trim($Agent) == "RPC2") echo " checked";?>>瑞寶
						<input type="radio" name="Agent" value="DIAM"<?php if (trim($Agent) == "DIAM") echo " checked";?>>戴米特
						<input type="radio" name="Agent" value="RPC1"<?php if (trim($Agent) == "RPC1") echo " checked";?>>全威
						<input type="radio" name="Agent" value="FCCL"<?php if (trim($Agent) == "FCCL") echo " checked";?>>富士洲股份有限公司
					  </td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">規範：</td>
			          <td class="h3"><input type="text" id="Canon" name="Canon" size="60" value="<?php echo $Canon;?>"></td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">商品分類號列(C.C.C.Code)：</td>
			          <td class="h3"><input type="text" id="CCCCode" name="CCCCode" size="60" value="<?php echo $CCCCode;?>"></td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3"><font color=red><b>*</b></font>案件開始日期：</td>
			          <td class="h3">
		              <input id="StartYear" name="StartYear" type="text" size="4" value="<?php echo $StartYear;?>" /> 年 
		              <input id="StartMonth" name="StartMonth" type="text" size="2" value="<?php echo $StartMonth;?>" /> 月 
		              <input id="StartDay" name="StartDay" type="text" size="2" value="<?php echo $StartDay;?>" /> 日 
		              <img src="../images/icon.gif" width="16" height="18" style="cursor: hand" onclick="javascript:displayDatePicker('StartYear','StartMonth','StartDay');"/>
			          </td>
			        </tr>
			        <?php
			        if (trim($PlanYear) == "0000") $PlanYear = "";
			        if (trim($PlanMonth) == "00") $PlanMonth = "";
			        if (trim($PlanDay) == "00") $PlanDay = "";
			        ?>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3"><font color=red><b>*</b></font>預計完成時間：</td>
			          <td class="h3">
		              <input id="PlanYear" name="PlanYear" type="text" size="4" value="<?php echo $PlanYear;?>" /> 年 
		              <input id="PlanMonth" name="PlanMonth" type="text" size="2" value="<?php echo $PlanMonth;?>" /> 月 
		              <input id="PlanDay" name="PlanDay" type="text" size="2" value="<?php echo $PlanDay;?>" /> 日 
		              <img src="../images/icon.gif" width="16" height="18" style="cursor: hand" onclick="javascript:displayDatePicker('PlanYear','PlanMonth','PlanDay');"/>
			          </td>
			        </tr>
			        <?php
			        if (trim($CloseYear) == "0000") $CloseYear = "";
			        if (trim($CloseMonth) == "00") $CloseMonth = "";
			        if (trim($CloseDay) == "00") $CloseDay = "";
			        ?>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">結案日期：</td>
			          <td class="h3">
		              <input id="CloseYear" name="CloseYear" type="text" size="4" value="<?php echo $CloseYear;?>" /> 年 
		              <input id="CloseMonth" name="CloseMonth" type="text" size="2" value="<?php echo $CloseMonth;?>" /> 月 
		              <input id="CloseDay" name="CloseDay" type="text" size="2" value="<?php echo $CloseDay;?>" /> 日 
		              <img src="../images/icon.gif" width="16" height="18" style="cursor: hand" onclick="javascript:displayDatePicker('CloseYear','CloseMonth','CloseDay');"/>
			          </td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">案件狀態：</td>
			          <td class="h3">
			          	<select id="PStatus" name="PStatus">
			          		<?php if (trim($PStatus) == "A") {?>
			          		<option value="A"<?php if (trim($PStatus) == "A") echo " selected";?>>新開案</option>
			          		<?php } else if (trim($PStatus) == "B") {?>
			          		<option value="B"<?php if (trim($PStatus) == "B") echo " selected";?>>報價中</option>
			          		<?php } else {?>
			          		<option value="C"<?php if (trim($PStatus) == "C") echo " selected";?>>案件處理中</option>
			          		<option value="D"<?php if (trim($PStatus) == "D") echo " selected";?>>審查中</option>
			          		<option value="E"<?php if (trim($PStatus) == "E") echo " selected";?>>補件中</option>
			          		<option value="F"<?php if (trim($PStatus) == "F") echo " selected";?>>待印證</option>
			          		<option value="G"<?php if (trim($PStatus) == "G") echo " selected";?>>案件取消</option>
			          		<option value="H"<?php if (trim($PStatus) == "H") echo " selected";?>>已結案</option>
			          		<?php }?>
			          	</select>	
			          </td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">本案特別備註：</td>
			          <td class="h3"><input type="text" id="SNote" name="SNote" size="60" value="<?php echo $SNote;?>"></td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">Safety：</td>
			          <td class="h3"><input type="text" id="PNote" name="PNote" size="60" value="<?php echo $PNote;?>"></td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">Safety 申請日期：</td>
			          <td class="h3">
		              <input id="PNoteYear" name="PNoteYear" type="text" size="4" value="<?php echo $PNoteYear;?>" /> 年 
		              <input id="PNoteMonth" name="PNoteMonth" type="text" size="2" value="<?php echo $PNoteMonth;?>" /> 月 
		              <input id="PNoteDay" name="PNoteDay" type="text" size="2" value="<?php echo $PNoteDay;?>" /> 日 
		              <img src="../images/icon.gif" width="16" height="18" style="cursor: hand" onclick="javascript:displayDatePicker('PNoteYear','PNoteMonth','PNoteDay');"/>
			          </td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">EMC：</td>
			          <td class="h3"><input type="text" id="EMC" name="EMC" size="60" value="<?php echo $EMC;?>"></td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">EMC 申請日期：</td>
			          <td class="h3">
		              <input id="PAYear" name="PAYear" type="text" size="4" value="<?php echo $PAYear;?>" /> 年 
		              <input id="PAMonth" name="PAMonth" type="text" size="2" value="<?php echo $PAMonth;?>" /> 月 
		              <input id="PADay" name="PADay" type="text" size="2" value="<?php echo $PADay;?>" /> 日 
		              <img src="../images/icon.gif" width="16" height="18" style="cursor: hand" onclick="javascript:displayDatePicker('PAYear','PAMonth','PADay');"/>
			          </td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">其他：</td>
			          <td class="h3"><input type="text" id="POther" name="POther" size="60" value="<?php echo $POther;?>"></td>
			        </tr>
							<?php
							if (trim($PStatus) == 'B' || trim($PStatus) == 'C' || trim($PStatus) == 'D' || trim($PStatus) == 'E' || trim($PStatus) == 'F') {
								$SQL_ProjectAccountingAdd="select PAADate,date_format(PAADate,'%Y'),date_format(PAADate,'%m'),date_format(PAADate,'%d'),PAAReason,PAACheck from ProjectAccountingAdd where PAACheck='N' and PID = ".$PID.";";
								$result_ProjectAccountingAdd=mysqli_query($link,$SQL_ProjectAccountingAdd) or die ("無法執行查詢");
								list($PAADate,$PAAYear,$PAAMonth,$PAADay,$PAAReason,$PAACheck)=mysqli_fetch_row($result_ProjectAccountingAdd);
								mysqli_free_result($result_ProjectAccountingAdd);
								//if (trim($PAAReCheck) == "N") $PAACheck="N";
							?>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3"><b>加測日期：</b></td>
			          <td class="h3">
			          	<?php
			          	if (trim($PAACheck) == "Y" && trim($PAAReCheck) != "N") {
			          			echo $PAADate;
			          			echo "<input type='hidden' id='PAAYear' name='PAAYear'>";
			          			echo "<input type='hidden' id='PAAMonth' name='PAAMonth'>";
			          			echo "<input type='hidden' id='PAADay' name='PAADay'>";
			          			}
			          	else {
				          	?>
			              <input id="PAAYear" name="PAAYear" type="text" size="4" value="<?php echo $PAAYear;?>" /> 年 
			              <input id="PAAMonth" name="PAAMonth" type="text" size="2" value="<?php echo $PAAMonth;?>" /> 月 
			              <input id="PAADay" name="PAADay" type="text" size="2" value="<?php echo $PAADay;?>" /> 日 
			              <img src="../images/icon.gif" width="16" height="18" style="cursor: hand" onclick="javascript:displayDatePicker('PAAYear','PAAMonth','PAADay');"/>
			          	<?php }?>
			          </td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3"><b>加測原因：</b></td>
			          <td class="h3">
			          	<?php
			          	if (trim($PAACheck) == "Y" && trim($PAAReCheck) != "N") echo $PAAReason;
			          	else {
				          	?>
				          	<textarea rows="3" id="PAAReason" name="PAAReason" cols="60"><?php echo str_replace("<br>","\r\n",$PAAReason);?></textarea>
			          	<?php }?>
			          </td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3"><b>加測狀態：</b></td>
			          <td class="h3"><input type='hidden' id='PAACheck' name='PAACheck' value='<?php if (trim($PAAReCheck) == "N") echo "N"; else echo $PAACheck;?>'>
			          	<?php
			          	if (trim($PAACheck) == "N") {
			          			echo "<font color=red>未完成</font>";
			          			echo " <input type='hidden' id='PAAReCheck' name='PAAReCheck' value='Y'>";
			          			?>
					          	<input type="button" name="button" value="新增加測項目" class="input_bot" onclick="javascript:window.open ('ProjectAccountingList.php?PID=<?php echo $PID;?>','ProjectAccounting','');">
			          			<?php
			          			}
			          	else if (trim($PAACheck) == "Y" && trim($PAAReCheck) != "N") {
			          			echo "<font color=blue>已完成</font> ";
			          			}
			          	else echo " <input type='checkbox' name='PAAReCheck' value='Y'> <font color=blue><b>確認加測</b></font>";
	
			          	if (trim($PAACheck) == "Y" && trim($PAAReCheck) != "N") {
				          	?>
				          	<input type="button" name="PAAReCheck" value="重新加測" class="input_bot" onclick="javascript:if (confirm('您是否確定要加測？')) location.href='ProjectEdit.php?PID=<?php echo $PID;?>&page=<?php echo $page;?>&QPStatus=<?php echo $QPStatus;?>&QPE=<?php echo $QPE;?>&QBMUID=<?php echo $QBMUID;?>&ISINo=<?php echo $ISINo;?>&ISAdd=<?php echo $ISAdd;?>&KeyWord=<?php echo urlencode($KeyWord);?>&PAAReCheck=N';">
			          	<?php }?>
			         		<input type="button" name="button" value="加測記錄" class="input_bot" onclick="javascript:window.open ('ProjectAddHistory.php?PID=<?php echo $PID;?>','ProjectAddHistory','height=400,width=700,top=200,left=200,scrollbars=yes,status=yes');">
			         	</td>
			        </tr>
							<?php }?>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">備 註：</td>
			          <td class="h3"><input type="text" id="PNote1" name="PNote1" size="60" value="<?php echo $PNote1;?>"></td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">請款狀態：</td>
			          <td class="h3"><?php if (trim($INo) == "") echo "未開發票"; else echo "已開發票";?></td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">請款備註：</td>
			          <td class="h3"><?php echo $InvoiceNote;?></td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">新增人員：</td>
			          <td class="h3"><?php echo $AddUser;?>　<?php echo $AddDate;?></td>
			        </tr>
			        <?php if (trim($ProcUser) != "") {?>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">最後更新：</td>
			          <td class="h3"><?php echo $ProcUser;?>　<?php echo $ProcDate;?> 
			          	<input type="button" name="edit" value="歷史記錄" class="input_bot" onclick="javascript:window.open ('ProjectHistory.php?PID=<?php echo $PID;?>','ProjectHistory','height=500,width=750,top=200,left=200,scrollbars=yes,status=yes');">
			         	</td>
			        </tr>
			        <?php }?>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td class="c3">案件記事：</td>
			          <td class="h3"></td>
			        </tr>
			        <tr height="40" align="center">
			          <td colspan="2" class="h3">
			          	<IFRAME marginWidth="0" marginHeight="0" src="ProjectNote.php?PID=<?php echo $PID;?>" frameBorder="1" width="100%" scrolling="yes" height=250></IFRAME> 
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td class="c3">樣品記錄：</td>
			          <td class="h3"></td>
			        </tr>
			        <tr height="40" align="center">
			          <td colspan="2" class="h3">
			          	<IFRAME marginWidth="0" marginHeight="0" src="ProjectSample.php?PID=<?php echo $PID;?>" frameBorder="1" width="100%" scrolling="yes" height=250></IFRAME> 
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td class="c3">案件証書：</td>
			          <td class="h3"></td>
			        </tr>
			        <tr height="40" align="center">
			          <td colspan="2" class="h3">
			          	<IFRAME marginWidth="0" marginHeight="0" src="ProjectCertificate.php?PID=<?php echo $PID;?>" frameBorder="1" width="100%" scrolling="yes" height=250></IFRAME> 
			        </tr>
			        <tr height="40" align="center">
			          <td colspan="2" class="h3">
			          	<input type="button" name="button" class="input_bot" value="回 列 表" onclick="javascript:location.href='<?php if (trim($Source) == "ProjectAccounting") echo "ProjectAccounting"; else echo "ProjectList";?>.php?page=<?php echo $page;?>&QPStatus=<?php echo $QPStatus;?>&QPE=<?php echo $QPE;?>&QBMUID=<?php echo $QBMUID;?>&ISINo=<?php echo $ISINo;?>&ISAdd=<?php echo $ISAdd;?>&KeyWord=<?php echo urlencode($KeyWord);?>';">
			          	<input type="submit" name="submit" class="input_bot" value="送 出">　
			          </td>
			        </tr>
				      </form>
			      </table>
    			</td>
    		</tr>
    	</table>
    </td>
	</tr>
</table>
<?php include "down.php";?>
</body>
</html>
<?php
mysqli_close($link);
?>