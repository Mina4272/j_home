﻿<?php
include "CheckPermission.php";
if (trim(strstr($_SESSION["reg_MPer"],'F')) == "" || trim(strstr($_SESSION["reg_MPer"],'D')) == "" || trim(strstr($_SESSION["reg_MPer"],'I')) == "" || trim(strstr($_SESSION["reg_MPer"],'L')) == "") {}
else exit;
include "../global.php";
include "include/page_function.php";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $PageAdminTitle;?></title>
<link href="../type.css" rel="stylesheet" type="text/css" />
<link href="../script/DatePicker.css" rel="stylesheet" type="text/css" />
<Script LANGUAGE="Javascript" SRC="../script/DatePicker.js"></Script>
<style type="text/css">
<!--
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
}
-->
</style>
<script type="text/JavaScript">
<!--
function jsCheck() 
		{
		if (jsTrim(document.form1.SYear.value) != "" || jsTrim(document.form1.SMonth.value) != "" || jsTrim(document.form1.SDay.value) != "") if (ChkDate('SYear',document.form1.SYear.value,document.form1.SMonth.value,document.form1.SDay.value,'起始時間') == false) return false;
		if (jsTrim(document.form1.EYear.value) != "" || jsTrim(document.form1.EMonth.value) != "" || jsTrim(document.form1.EDay.value) != "") if (ChkDate('EYear',document.form1.EYear.value,document.form1.EMonth.value,document.form1.EDay.value,'結束時間') == false) return false;
		if (jsTrim(document.form1.SYear.value) != "" && jsTrim(document.form1.SMonth.value) != "" && jsTrim(document.form1.SDay.value) != "" && jsTrim(document.form1.EYear.value) != "" && jsTrim(document.form1.EMonth.value) != "" && jsTrim(document.form1.EDay.value) != "") if (CompareDate('ISYear',document.form1.ISYear.value,document.form1.SMonth.value,document.form1.SDay.value,document.form1.EYear.value,document.form1.EMonth.value,document.form1.EDay.value,'起始時間','結束時間') == false) return false;
		if (jsTrim(document.form1.ISYear.value) != "" || jsTrim(document.form1.ISMonth.value) != "" || jsTrim(document.form1.ISDay.value) != "") if (ChkDate('ISYear',document.form1.ISYear.value,document.form1.ISMonth.value,document.form1.ISDay.value,'發票起始時間') == false) return false;
		if (jsTrim(document.form1.IEYear.value) != "" || jsTrim(document.form1.IEMonth.value) != "" || jsTrim(document.form1.IEDay.value) != "") if (ChkDate('IEYear',document.form1.IEYear.value,document.form1.IEMonth.value,document.form1.IEDay.value,'發票結束時間') == false) return false;
		if (jsTrim(document.form1.ISYear.value) != "" && jsTrim(document.form1.ISMonth.value) != "" && jsTrim(document.form1.ISDay.value) != "" && jsTrim(document.form1.IEYear.value) != "" && jsTrim(document.form1.IEMonth.value) != "" && jsTrim(document.form1.IEDay.value) != "") if (CompareDate('ISYear',document.form1.ISYear.value,document.form1.ISMonth.value,document.form1.SDay.value,document.form1.IEYear.value,document.form1.IEMonth.value,document.form1.IEDay.value,'發票起始時間','發票結束時間') == false) return false;
		}

function AccountingExport() 
		{
		document.form_exp.SYear.value = document.form1.SYear.value;
		document.form_exp.SMonth.value = document.form1.SMonth.value;
		document.form_exp.SDay.value = document.form1.SDay.value;
		document.form_exp.EYear.value = document.form1.EYear.value;
		document.form_exp.EMonth.value = document.form1.EMonth.value;
		document.form_exp.EDay.value = document.form1.EDay.value;
		document.form_exp.KeyWord.value = document.form1.KeyWord.value;
		document.form_exp.QPAStatus.value = document.form1.QPAStatus.value;
		document.form_exp.QPAMode.value = document.form1.QPAMode.value;
		document.form_exp.QInvoice.value = document.form1.QInvoice.value;
		document.form_exp.ISYear.value = document.form1.ISYear.value;
		document.form_exp.ISMonth.value = document.form1.ISMonth.value;
		document.form_exp.ISDay.value = document.form1.ISDay.value;
		document.form_exp.IEYear.value = document.form1.IEYear.value;
		document.form_exp.IEMonth.value = document.form1.IEMonth.value;
		document.form_exp.IEDay.value = document.form1.IEDay.value;
		document.form_exp.submit();
		}
//-->
</script>
</head>

<body>
<?php include "top.php";?>
<?php
$SqlTxt ="";
$SDate = empty($_POST['SDate'])?"":$_POST['SDate'];
if (trim($SDate) == "") $SDate = empty($_GET['SDate'])?"":$_GET['SDate'];
$EDate = empty($_POST['EDate'])?"":$_POST['EDate'];
if (trim($EDate) == "") $EDate = empty($_GET['EDate'])?"":$_GET['EDate'];
if (trim($SDate) == "") {
		$SYear = empty($_POST['SYear'])?"":$_POST['SYear'];
		$SMonth = empty($_POST['SMonth'])?"":$_POST['SMonth'];
		$SDay = empty($_POST['SDay'])?"":$_POST['SDay'];
		if (trim($SYear) != "" || trim($SMonth) != "" || trim($SDay) != "") if (checkdate($SMonth,$SDay ,$SYear)) $SDate = $SYear."-".$SMonth."-".$SDay;
		}
if (trim($EDate) == "") {
		$EYear = empty($_POST['EYear'])?"":$_POST['EYear'];
		$EMonth = empty($_POST['EMonth'])?"":$_POST['EMonth'];
		$EDay = empty($_POST['EDay'])?"":$_POST['EDay'];
		if (trim($EYear) != "" || trim($EMonth) != "" || trim($EDay) != "") if (checkdate($EMonth,$EDay ,$EYear)) $EDate = $EYear."-".$EMonth."-".$EDay;
		}
$ISDate = empty($_POST['ISDate'])?"":$_POST['ISDate'];
if (trim($ISDate) == "") $ISDate = empty($_GET['ISDate'])?"":$_GET['ISDate'];
$IEDate = empty($_POST['IEDate'])?"":$_POST['IEDate'];
if (trim($IEDate) == "") $IEDate = empty($_GET['IEDate'])?"":$_GET['IEDate'];
if (trim($ISDate) == "") {
		$ISYear = empty($_POST['ISYear'])?"":$_POST['ISYear'];
		$ISMonth = empty($_POST['ISMonth'])?"":$_POST['ISMonth'];
		$ISDay = empty($_POST['ISDay'])?"":$_POST['ISDay'];
		if (trim($ISYear) != "" || trim($ISMonth) != "" || trim($ISDay) != "") if (checkdate($ISMonth,$ISDay ,$ISYear)) $ISDate = $ISYear."-".$ISMonth."-".$ISDay;
		}
if (trim($IEDate) == "") {
		$IEYear = empty($_POST['IEYear'])?"":$_POST['IEYear'];
		$IEMonth = empty($_POST['IEMonth'])?"":$_POST['IEMonth'];
		$IEDay = empty($_POST['IEDay'])?"":$_POST['IEDay'];
		if (trim($IEYear) != "" || trim($IEMonth) != "" || trim($IEDay) != "") if (checkdate($IEMonth,$IEDay ,$IEYear)) $IEDate = $IEYear."-".$IEMonth."-".$IEDay;
		}
$KeyWord = empty($_POST['KeyWord'])?"":$_POST['KeyWord'];
if (trim($KeyWord) == "") $KeyWord = empty($_GET['KeyWord'])?"":$_GET['KeyWord'];
$QPAStatus = empty($_POST['QPAStatus'])?"":$_POST['QPAStatus'];
if (trim($QPAStatus) == "") $QPAStatus = empty($_GET['QPAStatus'])?"":$_GET['QPAStatus'];
$QPAMode = empty($_POST['QPAMode'])?"":$_POST['QPAMode'];
if (trim($QPAMode) == "") $QPAMode = empty($_GET['QPAMode'])?"":$_GET['QPAMode'];
$QInvoice = empty($_POST['QInvoice'])?"":$_POST['QInvoice'];
if (trim($QInvoice) == "") $QInvoice = empty($_GET['QInvoice'])?"":$_GET['QInvoice'];

if (trim(strstr($_SESSION["reg_MPer"],'D')) == "") {
		if (trim(strstr($_SESSION["reg_MPer"],'I')) != "" && trim(strstr($_SESSION["reg_MPer"],'L')) == "") {
				$QPAMode="I";
				$QPAModeCheck="1";
				}
		else if (trim(strstr($_SESSION["reg_MPer"],'I')) == "" && trim(strstr($_SESSION["reg_MPer"],'L')) != "") {
				$QPAMode="O";
				$QPAModeCheck="1";
				}
		}

//if (trim($SDate) != "" && trim($EDate) != "") $SqlTxt = $SqlTxt." and (a.AddDate >= '".$SDate." 00:00:00') and (a.AddDate <= '".$EDate." 23:59:59') ";
//else if (trim($SDate) != "" && trim($EDate) == "") $SqlTxt = $SqlTxt." and (a.AddDate >= '".$SDate." 00:00:00') ";
//else if (trim($SDate) == "" && trim($EDate) != "") $SqlTxt = $SqlTxt." and (a.AddDate <= '".$EDate." 23:59:59') ";

if (trim($SDate) != "" && trim($EDate) != "") $SqlTxt = $SqlTxt." and (a.StartDate >= '".$SDate."') and (a.StartDate <= '".$EDate."') ";
else if (trim($SDate) != "" && trim($EDate) == "") $SqlTxt = $SqlTxt." and (a.StartDate >= '".$SDate."') ";
else if (trim($SDate) == "" && trim($EDate) != "") $SqlTxt = $SqlTxt." and (a.StartDate <= '".$EDate."') ";

if (trim($QPAStatus) != "") $SqlTxt .= " and b.PAStatus='".$QPAStatus."'";
if (trim($QPAMode) != "") $SqlTxt .= " and b.PAMode='".$QPAMode."' ";
if (trim($KeyWord) != "") $SqlTxt .= " and (a.PUID like '%".$KeyWord."%' or a.CName like '%".$KeyWord."%' or a.CTel like '%".$KeyWord."%' or a.CFax like '%".$KeyWord."%' or a.Contact like '%".$KeyWord."%' or a.CMobile like '%".$KeyWord."%' or a.CEMail like '%".$KeyWord."%' or a.CAddress like '%".$KeyWord."%' or a.PName like '%".$KeyWord."%' or a.ModelName like '%".$KeyWord."%' or a.SeriesModel like '%".$KeyWord."%' or a.PE like '%".$KeyWord."%' or b.PAItem like '%".$KeyWord."%' or b.Invoice like '%".$KeyWord."%' or b.CName like '%".$KeyWord."%' or b.PANote like '%".$KeyWord."%' or b.PANo like '%".$KeyWord."%')";
if (trim($QInvoice) != "") {
		if (trim($QInvoice) == "Y") $SqlTxt .= " and b.Invoice <> ''";
		else if (trim($QInvoice) == "N") $SqlTxt .= " and b.Invoice = ''";
		}
if (trim($ISDate) != "" && trim($IEDate) != "") $SqlTxt = $SqlTxt." and (b.InvoiceDate >= '".$ISDate."') and (b.InvoiceDate <= '".$IEDate."') ";
else if (trim($ISDate) != "" && trim($IEDate) == "") $SqlTxt = $SqlTxt." and (b.InvoiceDate >= '".$ISDate."') ";
else if (trim($ISDate) == "" && trim($IEDate) != "") $SqlTxt = $SqlTxt." and (b.InvoiceDate <= '".$IEDate."') ";
$page = empty($_GET['page'])?"":$_GET['page'];
if (trim($page) == "") $page = 1;
$page_rows=15;  //每頁筆數
$php_Self = "AccountsPayableReport.php";  //分頁web檔名

$button_css = "h4";
$limit_txt =" limit ".(($page-1) * $page_rows).",".$page_rows;
$url_str = "&SDate=".$SDate."&EDate=".$EDate."&QPAStatus=".$QPAStatus."&QPAMode=".$QPAMode."&KeyWord=".urlencode($KeyWord)."&QInvoice=".$QInvoice;
$Sql_str="SELECT a.PID,b.PAID FROM Project a, ProjectAccounting b WHERE a.PID = b.PID AND a.Deltag = 'N' AND b.Deltag = 'N' ".$SqlTxt." order by a.PID desc,b.PAID,b.PAMode";
$SQL_ProjectAccounting="SELECT a.PID,b.PAID,b.PAMode,b.PAItem,b.Charges,b.Rate,b.ChargesOther,b.PAStatus,b.PADate,b.PANote,b.Invoice,b.InvoiceDate,a.PUID,a.PName,a.ModelName,a.QuoteDate,a.IFlorin,a.OFlorin,a.CName,a.PE,a.ApplyItem,a.PStatus,a.PTax,b.PATax FROM Project a, ProjectAccounting b WHERE a.PID = b.PID AND a.Deltag = 'N' AND b.Deltag = 'N' ".$SqlTxt." order by a.PID desc,b.PAID,b.PAMode ".$limit_txt."";
//echo $SQL_ProjectAccounting;
$result_ProjectAccounting=mysqli_query($link,$SQL_ProjectAccounting) or die ("無法執行查詢");
?>
<table width="100%" border="0" cellspacing="0" cellpadding="5">
	<tr>
    <td width="160" height="600" align="left" valign="top">
			<?php include "menu.php";?>
    </td>
    <td valign="top">
    	<table width="100%" border="0" cellpadding="0" cellspacing="0">
    		<tr>
    			<td>
			    	<table width="750" border="0" cellpadding="0" cellspacing="0">
			    		<tr height="30">
			    			<td class="c2" colspan="4">應收應付報表</td>
			    			<td width="20"></td>
			    		</tr>
			    	</table>
			    	<table width="750" border="0" cellpadding="0" cellspacing="0">
			    		<form name="form1" action="AccountsPayableReport.php" method="post">
			    		<tr>
			    			<td align="left" class="h3" colspan="3">案件時間：
			            <input name="SYear" type="text" size="4" value="<?php echo $SYear;?>" />年
			            <input name="SMonth" type="text" size="2" value="<?php echo $SMonth;?>" />月
			            <input name="SDay" type="text" size="2" value="<?php echo $SDay;?>" />日
			            <img src="../images/icon.gif" width="16" height="18" style="cursor: hand" onclick="javascript:displayDatePicker('SYear','SMonth','SDay');"/>～
			            <input name="EYear" type="text" size="4" value="<?php echo $EYear;?>" />年
			            <input name="EMonth" type="text" size="2" value="<?php echo $EMonth;?>" />月
			            <input name="EDay" type="text" size="2" value="<?php echo $EDay;?>" />日
			            <img src="../images/icon.gif" width="16" height="18" style="cursor: hand" onclick="javascript:displayDatePicker('EYear','EMonth','EDay');"/>
			    		<br/>發票日期：<input name="ISYear" type="text" size="4" value="<?php echo $ISYear;?>" />年
										<input name="ISMonth" type="text" size="2" value="<?php echo $ISMonth;?>" />月
										<input name="ISDay" type="text" size="2" value="<?php echo $ISDay;?>" />日
										<img src="../images/icon.gif" width="16" height="18" style="cursor: hand" onclick="javascript:displayDatePicker('ISYear','ISMonth','ISDay');"/>～
										<input name="IEYear" type="text" size="4" value="<?php echo $IEYear;?>" />年
										<input name="IEMonth" type="text" size="2" value="<?php echo $IEMonth;?>" />月
										<input name="IEDay" type="text" size="2" value="<?php echo $IEDay;?>" />日
										<img src="../images/icon.gif" width="16" height="18" style="cursor: hand" onclick="javascript:displayDatePicker('IEYear','IEMonth','IEDay');"/>		
								　<br/>狀　態：
			    				<select name="QPAStatus">
			    					<option value="">不限</option>
			    					<option value="W"<?php if (trim($QPAStatus) == "W") echo " selected";?>>待收/未付</option>
			    					<option value="S"<?php if (trim($QPAStatus) == "S") echo " selected";?>>結清</option>
			    					<option value="C"<?php if (trim($QPAStatus) == "C") echo " selected";?>>取消</option>
			    				</select>　
								收入/支出：
			    				<select name="QPAMode"<?php if (trim($QPAModeCheck) == "1") echo disabled?>>
			    					<option value="">不限</option>
			    					<option value="I"<?php if (trim($QPAMode) == "I") echo " selected";?>>收入</option>
			    					<option value="O"<?php if (trim($QPAMode) == "O") echo " selected";?>>支出</option>
			    				</select>
								是否開立發票：
			    				<select name="QInvoice">
			    					<option value="">不限</option>
			    					<option value="Y"<?php if (trim($QInvoice) == "Y") echo " selected";?>>是</option>
			    					<option value="N"<?php if (trim($QInvoice) == "N") echo " selected";?>>否</option>
			    				</select>
			    			</td>
							<tr>
			    			<td align="left" class="h3">
			    				關鍵字：<input type="text" name="KeyWord" size="10" value="<?php echo $KeyWord;?>">
			    				<input type="submit" name="search" class="input_bot" value="查詢"> 
			    				<input type="button" name="button" class="input_bot" value="全部列出" onclick="javascript:location.href='AccountsPayableReport.php';"> 
			    				<input type="button" name="report" class="input_bot" value="報表輸出" onclick="javascript:AccountingExport();">
			    			</td>
							<td align="left" class="h3">
			    			
			    			</td>
							</tr>
			    		</form>
			    	</table>
			    	<table width="750" border="0" cellpadding="5" cellspacing="2" class="s2">
			        <tr align="center">
			          <td width="140" background="../images/table_bg.gif" class="t21">案件編號<br>產品名稱</td>
			          <td width="180" background="../images/table_bg.gif" class="t21">客戶名稱</td>
			          <td width="70" align="center" background="../images/table_bg.gif" class="t21">收入/支出</td>
			          <td width="180" background="../images/table_bg.gif" class="t21">項 目</td>
			          <td width="40" background="../images/table_bg.gif" class="t21">費 用<br>稅 金</td>
			          <td width="70" background="../images/table_bg.gif" class="t21">狀 態<br>發票號碼</td>
			          <td width="60" background="../images/table_bg.gif" class="t21">備 註</td>
			        </tr>
		          <?php
		          $tmp = 1;
		          while(list($PID,$PAID,$PAMode,$PAItem,$Charges,$Rate,$ChargesOther,$PAStatus,$PADate,$PANote,$Invoice,$InvoiceDate,$PUID,$PName,$ModelName,$QuoteDate,$IFlorin,$OFlorin,$CName,$PE,$ApplyItem,$PStatus,$PTax,$PATax)=mysqli_fetch_row($result_ProjectAccounting)){
								if (trim($QuoteDate) == "0000-00-00") $QuoteDate = "";
								if (trim($QuoteDate) != "") $QuoteCheck = "True";
								if (trim($IFlorin) == "") $IFlorin = "新台幣";
								if (trim($OFlorin) == "") $OFlorin = "新台幣";
		        	?>
		        	<tr<?php if ($tmp%2 == 0) echo " bgcolor=\"#F6F6F6\"";?>>
			          <!--<td align="center" class="h3<?php if (trim($PStatus) == "H" && $PACount > 0) echo "r";?>"><a href="ProjectEdit.php?PID=<?php echo $PID;?>&page=<?php echo $page;?><?php echo $url_str;?>"><?php echo $PUID;?></a><br><?php echo $PName;?><br><?php echo $ModelName;?></td>-->
			          <td align="center" class="h3<?php if (trim($PStatus) == "H" && $PACount > 0) echo "r";?>"><a href="ProjectAccountingList.php?PID=<?php echo $PID;?>&PA_Mode=<?php echo $PAMode;?>"><?php echo $PUID;?></a><br><?php echo $PName;?><br><?php echo $ModelName;?></td>
			          <td class="h3<?php if (trim($PStatus) == "H" && $PACount > 0) echo "r";?>" align="center"><?php echo $CName;?></td>
			          <td align="center" class="h3">
			          	<?php
			          	if (trim($PAMode) == "I") echo "<font color=blue>收入</font>";
			          	else if (trim($PAMode) == "O") echo "<font color=red>支出</font>";
			          	?>
			          </td>
			          <td class="h3"><?php echo $PAItem;?></td>
			          <td class="h3" align="center"><?php echo number_format($Charges);?><br>
			          	<?php
					      	if (trim($PATax) == "") $PATax = $PTax;
			          	if (trim($PATax) == "Y") echo round($Charges * 0.05);
			          	else echo "0";
			          	if (trim($Rate) != "0") {
			          			echo "<br><font color=blue>匯率：".$Rate."</font>";
			          			if (trim($PAMode) == "I") echo "<br><font color=blue>".$IFlorin."：".$ChargesOther."</font>";
			          			else if (trim($PAMode) == "O") echo "<br><font color=blue>".$OFlorin."：".$ChargesOther."</font>";
			          			}
			          	?>
			          </td>
			          <td align="center" class="h3">
			          	<?php
			          	if (trim($PAStatus) == "W") {
			          			if (trim($PAMode) == "I") echo "待收"; else if (trim($PAMode) == "O") echo "未付";
			          			}
			          	else if (trim($PAStatus) == "S") echo "<font color=blue>結清</font><br>".$PADate;
			          	else if (trim($PAStatus) == "C") echo "<font color=red>取消</font>";
			          	if (trim($Invoice) != "") echo "<br><font color=blue>".$Invoice."</font>";
			          	if (trim($InvoiceDate) != "") echo "<br><font color=blue>".$InvoiceDate."</font>";
			          	?>
			          </td>
			          <td class="h3"><?php echo $PANote;?></td>
			        </tr>
			        <?php
            			$tmp++;
			      			}
            	mysqli_free_result($result_ProjectAccounting);
			        ?>
			      </table>
			      <table width="750" border="0" cellpadding="5" cellspacing="2" class="s2">
			        <tr align="center">
			          <td bgcolor="#E8F0C2" class="h4"><?php Page_show($Sql_str,$page_rows,$php_Self,$link,$page,$url_str,$button_css);?></td>
			        </tr>
			      </table>
    			</td>
    		</tr>
    	</table>
    </td>
	</tr>
</table>
<form name="form_exp" action="AccountsPayableReportExport.php" method="post" target="_PayableReportExport">
	<input type="hidden" name="SYear">
	<input type="hidden" name="SMonth">
	<input type="hidden" name="SDay">
	<input type="hidden" name="EYear">
	<input type="hidden" name="EMonth">
	<input type="hidden" name="EDay">
	<input type="hidden" name="KeyWord">
	<input type="hidden" name="QPAStatus">
	<input type="hidden" name="QPAMode">
	<input type="hidden" name="QInvoice">
	<input type="hidden" name="ISYear">
	<input type="hidden" name="ISMonth">
	<input type="hidden" name="ISDay">
	<input type="hidden" name="IEYear">
	<input type="hidden" name="IEMonth">
	<input type="hidden" name="IEDay">
</form>
<?php include "down.php";?>
</body>
</html>
<?php
mysqli_close($link);
?>