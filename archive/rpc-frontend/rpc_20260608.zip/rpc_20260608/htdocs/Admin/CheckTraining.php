<?php
if (trim(strstr($_SESSION["reg_MPer"],'N')) == "") exit;
?>