<?php
if (trim(strstr($_SESSION["reg_MPer"],'A')) == "") exit;
?>