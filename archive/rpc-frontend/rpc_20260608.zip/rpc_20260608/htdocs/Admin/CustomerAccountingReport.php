﻿<?php
include "CheckPermission.php";
include "CheckCustomer.php";
include "../global.php";
include "include/page_function.php";
$CAR = empty($_POST['CAR'])?"":$_POST['CAR'];
if (trim($CAR) == "") $CAR = empty($_GET['CAR'])?"":$_GET['CAR'];
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $PageAdminTitle;?></title>
<link href="../type.css" rel="stylesheet" type="text/css" />
<style type="text/css">
<!--
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
}
-->
</style>
<script type="text/JavaScript">
<!--
function CustomerAccountingExport() 
		{
		document.form_exp.KeyWord.value = document.form1.KeyWord.value;
		document.form_exp.QCType.value = document.form1.QCType.value;
		document.form_exp.CAR.value = '<?php echo $CAR;?>';
		document.form_exp.submit();
		}
//-->
</script>
</head>

<body>
<?php include "top.php";?>
<table width="100%" border="0" cellspacing="0" cellpadding="5">
	<tr>
    <td width="160" height="600" align="left" valign="top">
			<?php include "menu.php";?>
    </td>
    <td valign="top">
    	<table width="100%" border="0" cellpadding="0" cellspacing="0">
    		<tr>
    			<td>
			    	<table width="750" border="0" cellpadding="0" cellspacing="0">
			    		<tr height="30">
			    			<td class="c2"> 客戶帳務統計報表</td>
			    			<td class="c2" align="right">
			    				<input type="button" name="button" value="供應商欠款資料" class="input_bot" onclick="javascript:location.href='CustomerAccountingReport.php?CAR=C';">　
			    			</td>
			    		</tr>
			    	</table>
			    	<table width="750" border="0" cellpadding="0" cellspacing="0">
			    		<form name="form1" action="CustomerAccountingReport.php" method="post">
			    		<tr>
			    			<td width="200" align="left" class="h3">客戶種類：
			    				<select name="QCType">
			    					<option value="">不限</option>
			    					<option value="N"<?php if (trim(empty($_POST['QCType'])?"":$_POST['QCType']) == "N") echo " selected";?>>一般客戶</option>
			    					<option value="P"<?php if (trim(empty($_POST['QCType'])?"":$_POST['QCType']) == "P") echo " selected";?>>供應商</option>
			    				</select>
			    			</td>
			    			<td align="left" class="h3">關鍵字：<input type="text" name="KeyWord" size="20" value="<?php echo empty($_POST['KeyWord'])?"":$_POST['KeyWord'];?>"> <input type="submit" name="search" class="input_bot" value="查詢">　<input type="button" name="button" class="input_bot" value="全部列出" onclick="javascript:location.href='CustomerAccountingReport.php';"></td>
			    			<td align="right" class="h3"><input type="button" name="report" class="input_bot" value="報 表 輸 出" onclick="javascript:CustomerAccountingExport();"></td>
			    			<td width="20"></td>
			    		</tr>
			    		</form>
			    	</table>
						<?php
					$Sql_CID = "";
					$SqlTxt = "";
			    	$QCType = empty($_POST['QCType'])?"":$_POST['QCType'];
			    	if (trim($QCType) == "") $QCType = empty($_GET['QCType'])?"":$_GET['QCType'];
			    	$KeyWord = empty($_POST['KeyWord'])?"":$_POST['KeyWord'];
			    	if (trim($KeyWord) == "") $KeyWord = empty($_GET['KeyWord'])?"":$_GET['KeyWord'];
						if (trim($QCType) != "") $SqlTxt = $SqlTxt." and CType like '%".$QCType."%' ";
			    	if (trim($KeyWord) != "") $SqlTxt = $SqlTxt." and (CUID like '%".$KeyWord."%' or CName like '%".$KeyWord."%' or EName like '%".$KeyWord."%' or Contact like '%".$KeyWord."%' or CAddress like '%".$KeyWord."%' or CTel like '%".$KeyWord."%' or CFax like '%".$KeyWord."%' or CMobile like '%".$KeyWord."%' or CEMail like '%".$KeyWord."%')";

						if (trim($CAR) != "") {
								$SQL_CAR="SELECT DISTINCT a.CID FROM Project a, ProjectAccounting b WHERE a.PID = b.PID AND a.Deltag = 'N' AND b.Deltag = 'N' AND b.PAStatus = 'W' ORDER BY a.CID";
								$result_CAR=mysqli_query($link,$SQL_CAR) or die ("無法執行查詢");
								
								while(list($PQ_CID)=mysqli_fetch_row($result_CAR)){
										if (trim($Sql_CID) == "") $Sql_CID = $PQ_CID;
										else $Sql_CID = $Sql_CID.",".$PQ_CID;
										}
								mysqli_free_result($result_CAR);
								}
						if (trim($Sql_CID) != "") $SqlTxt = $SqlTxt . " and CID in (".$Sql_CID.")";
						$page = empty($_GET['page'])?"":$_GET['page'];
						if (trim($page) == "") $page = 1;
						$page_rows=15;  //每頁筆數
						$php_Self = "CustomerAccountingReport.php";  //分頁web檔名

						$button_css = "h4";
						$limit_txt =" limit ".(($page-1) * $page_rows).",".$page_rows;
						$url_str = "&QCType=".$QCType."&CAR=".$CAR."&KeyWord=".urlencode($KeyWord);
						$Sql_str="select CID,CUID,CPWD,CName,CTel,Contact,CMobile,CEMail,CAddress,CNote,CLevel,CRecord from Customer where Deltag='N' ".$SqlTxt." order by CID desc;";
						$SQL_Customer="select CID,CUID,CPWD,CName,CTel,Contact,CMobile,CEMail,CAddress,CNote,CLevel,CRecord from Customer where Deltag='N' ".$SqlTxt." order by CID desc ".$limit_txt.";";
						$result_Customer=mysqli_query($link,$SQL_Customer) or die ("無法執行查詢");
						?>
			    	<table width="750" border="0" cellpadding="5" cellspacing="2" class="s2">
			        <tr align="center">
			          <td width="50" align="center" background="../images/table_bg.gif" class="t2">序</td>
			          <td width="320" background="../images/table_bg.gif" class="t2">公司名稱</td>
			          <td width="180" background="../images/table_bg.gif" class="t2">電 話</td>
			          <td width="200" background="../images/table_bg.gif" class="t2">備 註</td>
			        </tr>
		          <?php
		          $tmp = 1;
		          while(list($CID,$CUID,$CPWD,$CName,$CTel,$Contact,$CMobile,$CEMail,$CAddress,$CNote,$CLevel,$CRecord)=mysqli_fetch_row($result_Customer)){
		        	?>
		        	<tr<?php if ($tmp%2 == 0) echo " bgcolor=\"#F6F6F6\"";?>>
			          <td align="center" class="h3"><?php echo $CID;?></td>
			          <td class="h3"><?php echo $CName;?> 
			          	<?php
			          	if (trim($CLevel) == "A") $CLevelAlt="客戶等級(好)";
			          	else if (trim($CLevel) == "B") $CLevelAlt="客戶等級(中)";
			          	else if (trim($CLevel) == "C") $CLevelAlt="客戶等級(差)";
			          	if (trim($CRecord) == "A") $CRecordAlt="付款記錄(優良)";
			          	else if (trim($CRecord) == "B") $CRecordAlt="付款記錄(尚可)";
			          	else if (trim($CRecord) == "C") $CRecordAlt="付款記錄(不好)";
			          	?>
			          	<img src="../images/<?php echo $CLevel;?>1.gif" alt="<?php echo $CLevelAlt;?>"> 
			          	<img src="../images/<?php echo $CRecord;?>2.gif" alt="<?php echo $CRecordAlt;?>">
			          </td>
			          <td align="center" class="h3"><?php echo $CTel;?></td>
			          <td class="h4"><?php echo $CNote;?></td>
			        </tr>
			        <?php
            			$tmp++;
			      			}
            	mysqli_free_result($result_Customer);
			        ?>
			      </table>
			      <table width="750" border="0" cellpadding="5" cellspacing="2" class="s2">
			        <tr align="center">
			          <td bgcolor="#E8F0C2" class="h4"><?php Page_show($Sql_str,$page_rows,$php_Self,$link,$page,$url_str,$button_css);?></td>
			        </tr>
			      </table>
    			</td>
    		</tr>
    	</table>
    </td>
	</tr>
</table>
<form name="form_exp" action="CustomerAccountingExport.php" method="post" target="_CustomerAccountingExport">
	<input type="hidden" name="KeyWord">
	<input type="hidden" name="QCType">
	<input type="hidden" name="CAR">
</form>
<?php include "down.php";?>
</body>
</html>
<?php
mysqli_close($link);
?>