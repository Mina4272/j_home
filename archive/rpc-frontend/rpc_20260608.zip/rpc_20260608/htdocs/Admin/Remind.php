﻿<?php
include "CheckPermission.php";
include "../global.php";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $PageAdminTitle;?></title>
<link href="../type.css" rel="stylesheet" type="text/css" />

</head>

<body>
<table width="520" border="0" align="center" cellpadding="2" cellspacing="0">
  <tr>
    <td align="left"><span class="c2"><b>本月到職滿周年</b></span></td>
  </tr>
  <tr>
    <td align="left">
	<table width="100%" border="0" cellpadding="2" cellspacing="2" class="s2">
        <tr align="center">
          <td width="100" background="../images/table_bg.gif" class="t21">帳號</td>
          <td background="../images/table_bg.gif" class="t21">姓名</td>
          <td background="../images/table_bg.gif" class="t21">到職日</td>
        </tr>

	<?php
		$SQL_Manager="SELECT MUID, MName, MEName, RDate FROM Manager WHERE IsLeft = 'N' AND Deltag = 'N' AND RDate IS NOT NULL AND date_format( RDate, '%Y' ) <> date_format( now( ) , '%Y' ) AND date_format( RDate, '%m' ) = date_format( now( ) , '%m' );";
		$result_Manager=mysqli_query($link,$SQL_Manager) or die ("無法執行查詢1");
		$tmp = 1;
       		while(list($MUID,$MName,$MEName,$RDate)=mysqli_fetch_row($result_Manager)){
      	?>
    	
	<form name="CForm<?php echo $MID;?>" method="post">
	    	<tr<?php if ($tmp%2 == 0) echo " bgcolor=\"#F6F6F6\"";?>>
          <td align="center" class="h3"><?php echo $MUID;?></td>
          <td align="center" class="h3"><?php echo $MEName.$MName;?></td>
          <td align="center" class="h3"><?php echo $RDate;?></td>
        </tr>
    		</form>
        <?php
      			$tmp++;
      			}
      	mysqli_free_result($result_Manager);
        ?>

	<tr>
          <td align="left"><span class="c2"><b>本月到職滿六個月</b></span></td>
	</tr>

	<?php
		$SQL_Manager="SELECT MUID, MName, MEName, RDate FROM Manager WHERE IsLeft = 'N' AND Deltag = 'N' AND RDate IS NOT NULL AND date_format(DATE_ADD(RDate,INTERVAL 6 MONTH), '%Y' ) = date_format( now( ) , '%Y' ) AND date_format(DATE_ADD(RDate,INTERVAL 6 MONTH), '%m' ) = date_format( now( ) , '%m' );";
		$result_Manager=mysqli_query($link,$SQL_Manager) or die ("無法執行查詢2");
		//$tmp = 1;
       		while(list($MUID,$MName,$MEName,$RDate)=mysqli_fetch_row($result_Manager)){
      	?>
	
	<form name="CForm<?php echo $MID;?>" method="post">
	    	<tr<?php if ($tmp%2 == 0) echo " bgcolor=\"#F6F6F6\"";?>>
          <td align="center" class="h5"><?php echo $MUID;?></td>
          <td align="center" class="h5"><?php echo $MEName.$MName;?></td>
          <td align="center" class="h5"><?php echo $RDate;?></td>
        </tr>
    		</form>
        <?php
      			$tmp++;
      			}
      	mysqli_free_result($result_Manager);
        ?>

      </table>
    </td>
  </tr>
</table>
</body>
</html>
<?php
mysqli_close($link);
?>