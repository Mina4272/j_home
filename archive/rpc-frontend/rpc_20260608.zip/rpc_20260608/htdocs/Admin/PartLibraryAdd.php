﻿<?php	
include "CheckPermission.php";
include "CheckPartLibrary.php";
include "../global.php";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $PageAdminTitle;?></title>
<link href="../type.css" rel="stylesheet" type="text/css" />
<style type="text/css">
<!--
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
}
-->
</style>
<Script type="text/javascript" language="javascript" src="../script/rpc.js"></Script>
<Script type="text/javascript" language="javascript" src="../script/CheckForm.js"></Script>
<script type="text/JavaScript">
<!--
function jsCheck() 
		{
		if (jsTrim(document.form1.PLCID.value) == "")
				{
				alert ('請選擇所屬類別名稱！');
				document.form1.PLCID.focus();
				return false;
				}
		if (ChkImp('PartName',document.form1.PartName.value,'零件名稱') == false) return false;
		}
function DelPartCertification() {
		if (confirm('您確定要刪除此圖像嗎？')) {
				document.form1.PartCertification.value='';
				document.getElementById('PartCertificationPreview').style.display = 'none';
				document.getElementById('PartCertificationPreview').innerHTML = '';
				document.getElementById('PartCertificationDel').style.display = 'none';
				document.getElementById('PartCertificationDel').innerHTML = '';
				}
		}
//-->
</script>
</head>
<body>
<?php include "top.php";?>
<table width="100%" border="0" cellspacing="0" cellpadding="5">
	<tr>
    <td width="160" height="600" align="left" valign="top">
			<?php include "menu.php";?>
    </td>
    <td valign="top">
    	<table width="100%" border="0" cellpadding="0" cellspacing="0">
    		<tr>
    			<td>
			    	<table width="750" border="0" cellpadding="0" cellspacing="0">
			    		<tr height="30">
			    			<td class="c2"><b>新增零組件/檔案資料</b></td>
			    		</tr>
			    	</table>
			    	<table width="750" border="0" cellpadding="0" cellspacing="0">
			        <form name="form1" method="post" action="PartLibraryAddDB.php" onSubmit="return jsCheck();">
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td width="150" align="right" class="c3">類別名稱：</td>
			          <td class="h3">
			          	<?php
									$SQL_PartLibraryClass="select PLCID,PLCName from PartLibraryClass where Deltag='N' order by PLCID;";
									$result_PartLibraryClass=mysqli_query($link,$SQL_PartLibraryClass) or die ("無法執行查詢");
			          	?>
			    				<select name="PLCID">
			    					<?php while(list($PLCIDTmp,$PLCNameTmp)=mysqli_fetch_row($result_PartLibraryClass)){?>
			    					<option value="<?php echo $PLCIDTmp;?>"><?php echo $PLCNameTmp;?></option>
			    					<?php }?>
			    				</select>
									<?php
									mysqli_free_result($result_PartLibraryClass);
			          	?>
			          </td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">零件名稱：</td>
			          <td class="h3"><input type="text" name="PartName" size="40"></td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">廠家/檔案種類：</td>
			          <td class="h3"><input type="text" name="Firm" size="40"></td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">型號/檔案內容：</td>
			          <td class="h3"><input type="text" name="Model" size="40"></td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">規格：</td>
			          <td class="h3"><input type="text" name="Spec" size="60"></td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">標準：</td>
			          <td class="h3"><input type="text" name="Standard" size="60"></td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">認證符號：</td>
			          <td class="h3"><input type="text" name="Mark" size="40"></td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">證書檔案：</td>
			          <td class="h3">
	              	<table width="150" border="0" cellpadding="0" cellspacing="0">
	              		<tr class="h3">
	              			<td width="50" align="center"><div id="PartCertificationPreview" style="display:none"></div></td>
	              			<td width="50" align="center" valign="bottom"><div id="PartCertificationDel" style="display:none"></div></td>
	              			<td width="50" align="center">
				              	<input name="PartCertification" type="hidden" id="PartCertification" />
				              	<input name="PartCertificationUpload" type="button" class="input_bot" value="上傳" onclick="MM_openBrWindow('PartCertificationUpload.php','_PartCertificationUpload','scrollbars=no,resizable=no,width=450,height=150,top=200,left=200');" /> 
	              			</td>
	              		</tr>
	              	</table>
			          </td>
			        </tr>
			        <tr height="40" align="center">
			          <td colspan="2" class="h3"><input type="submit" name="submit" class="input_bot" value="送 出"></td>
			        </tr>
				      </form>
			      </table>
    			</td>
    		</tr>
    	</table>
    </td>
	</tr>
</table>
<?php include "down.php";?>
</body>
</html>
<?php
mysqli_close($link);
?>