﻿<?php
include "CheckPermission.php";
include "CheckEmployeePay.php";
include "../global.php";
require_once 'PHPExcel.php';

$QEEPDate="";
$SqlTxt="";
$SqlMID = "";
$limit_txt = "";
$QSEPYear = $_POST['QSEPYear'];
$QSEPMonth = $_POST['QSEPMonth'];
$QSEPDay = $_POST['QSEPDay'];
if (trim($QSEPYear) != "" || trim($QSEPMonth) != "") if (checkdate($QSEPMonth,$QSEPDay ,$QSEPYear)) $QSEPDate = $QSEPYear."-".$QSEPMonth."-".$QSEPDay;
$QEEPYear = $_POST['QEEPYear'];
$QEEPMonth = $_POST['QEEPMonth'];
$QEEPDay = $_POST['QEEPDay'];
if (trim($QEEPYear) != "" || trim($QEEPMonth) != "") if (checkdate($QEEPMonth,$QEEPDay ,$QEEPYear)) $QEEPDate = $QEEPYear."-".$QEEPMonth."-".$QEEPDay;
$KeyWord = $_POST['KeyWord'];
if (trim($KeyWord) == "") $KeyWord = empty($_GET['KeyWord'])?"":$_GET['KeyWord'];
$IsLeft = $_POST['IsLeft'];
if (trim($IsLeft) == "") $IsLeft = empty($_GET['IsLeft'])?"":$_GET['IsLeft'];

if (trim($QSEPDate) != "" && trim($QEEPDate) != "") $SqlTxt = $SqlTxt." and (EPDate >= '".$QSEPDate."') and (EPDate <= '".$QEEPDate."') ";
else if (trim($QSEPDate) != "" && trim($QEEPDate) == "") $SqlTxt = $SqlTxt." and (EPDate >= '".$QSEPDate."') ";
else if (trim($QSEPDate) == "" && trim($QEEPDate) != "") $SqlTxt = $SqlTxt." and (EPDate <= '".$QEEPDate."') ";

if (trim($KeyWord) != "") {
		$SQL_Manager="select MID from Manager where EmployeeNo like '%".$KeyWord."%' or MName like '%".$KeyWord."%' order by MID;";
		$result_Manager=mysqli_query($link,$SQL_Manager) or die ("無法執行查詢");
		
		while(list($MMID)=mysqli_fetch_row($result_Manager)){
				if (trim($SqlMID) == "") $SqlMID = $MMID;
				else $SqlMID = $SqlMID.",".$MMID;
				}
		mysqli_free_result($result_Manager);
		}
if (trim($SqlMID) != "") $SqlMID = " a.MID in (".$SqlMID.")";
if (trim($KeyWord) != "") {
		if (trim($SqlMID) == "") $SqlTxt = $SqlTxt." and (a.EPay like '%".$KeyWord."%' or a.Salary like '%".$KeyWord."%' or a.Allowance like '%".$KeyWord."%' or a.Other like '%".$KeyWord."%')";
		else $SqlTxt = $SqlTxt." and (a.EPay like '%".$KeyWord."%' or a.Salary like '%".$KeyWord."%' or a.Allowance like '%".$KeyWord."%' or a.Other like '%".$KeyWord."%' or ".$SqlMID.")";
		}

if (trim($SqlTxt) == "") $SqlTxt = " and (EPDate = '".date("Y-m",mktime())."-1') ";
if (trim($IsLeft) != "") $SqlTxt .= " and b.IsLeft = '".$IsLeft."'";
$SQL_EmployeePay="select a.EPID,a.MID,
									(select MPID from Manager where Deltag='N' and MID=a.MID) MPID,
									(select BAccount from Manager where  Deltag='N' and MID=a.MID) BAccount,
									(select MName from Manager where  Deltag='N' and MID=a.MID) MName,
									(select EmployeeNo from Manager where Deltag='N' and MID=a.MID) EmployeeNo,
									(select MPID from Manager where  Deltag='N' and MID=a.MID) MPID,
									(select EMail from Manager where Deltag='N' and MID=a.MID) EMail,
									(select Departments from Manager where Deltag='N' and MID=a.MID) Departments,
									a.EPDate,date_format(a.EPDate,'%Y'),date_format(a.EPDate,'%m'),a.EPay,a.Salary,a.Allowance,a.Overtime,a.Transportation1,a.Transportation2,a.FullAttendance,a.Bonus,a.Signing,a.NewBonus,a.YearEnd,a.MidYear,a.Disbursement,a.Travel,a.Physiological,a.SigningReturn,a.NotWorking,a.IncomeTax,a.CRetirement,(select CRetirementEmployee from Manager where Deltag='N' and MID=a.MID) CRetirementEmployee,a.CLabor,a.CHealth,a.ELabor,a.EHealth,a.PLeave,a.SickLeave,a.EVAmount,a.Other,a.OtherDesc 
									from EmployeePay a,Manager b where a.MID=b.MID and a.Deltag='N' and b.Deltag='N'
									".$SqlTxt." order by a.MID,a.EPID asc ".$limit_txt.";";
//echo $SQL_EmployeePay;
//exit;
$result_EmployeePay=mysqli_query($link,$SQL_EmployeePay) or die ("無法執行查詢");

$objPHPExcel = new PHPExcel();
$objPHPExcel->setActiveSheetIndex(0);

$objPHPExcel->getActiveSheet()->setCellValue('A1',"入帳帳號");
$objPHPExcel->getActiveSheet()->setCellValue('B1',"入帳金額");
$objPHPExcel->getActiveSheet()->setCellValue('C1',"身份證號");
$objPHPExcel->getActiveSheet()->setCellValue('D1',"受款人email");
$objPHPExcel->getActiveSheet()->setCellValue('E1',"員工編號");
$objPHPExcel->getActiveSheet()->setCellValue('F1',"姓名");
$objPHPExcel->getActiveSheet()->setCellValue('G1',"部門");
$objPHPExcel->getActiveSheet()->setCellValue('H1',"本薪");
$objPHPExcel->getActiveSheet()->setCellValue('I1',"職務加給");
$objPHPExcel->getActiveSheet()->setCellValue('J1',"加班費");
$objPHPExcel->getActiveSheet()->setCellValue('K1',"交通費-公里數計算");
$objPHPExcel->getActiveSheet()->setCellValue('L1',"交通費-實報實銷");
$objPHPExcel->getActiveSheet()->setCellValue('M1',"全勤獎金");
$objPHPExcel->getActiveSheet()->setCellValue('N1',"勞退公司提撥");
$objPHPExcel->getActiveSheet()->setCellValue('O1',"勞退公司提撥-員工負擔");
$objPHPExcel->getActiveSheet()->setCellValue('P1',"勞保費-公司負擔");
$objPHPExcel->getActiveSheet()->setCellValue('Q1',"健保費-公司負擔");
$objPHPExcel->getActiveSheet()->setCellValue('R1',"其他");
$objPHPExcel->getActiveSheet()->setCellValue('S1',"簽約獎金");
$objPHPExcel->getActiveSheet()->setCellValue('T1',"績效獎金");
$objPHPExcel->getActiveSheet()->setCellValue('U1',"獎金");
$objPHPExcel->getActiveSheet()->setCellValue('V1',"年終獎金");
$objPHPExcel->getActiveSheet()->setCellValue('W1',"年中獎金");
$objPHPExcel->getActiveSheet()->setCellValue('X1',"年假折現");
$objPHPExcel->getActiveSheet()->setCellValue('Y1',"資遣費");
$objPHPExcel->getActiveSheet()->setCellValue('Z1',"差旅津貼");
$objPHPExcel->getActiveSheet()->setCellValue('AA1',"其他");
$objPHPExcel->getActiveSheet()->setCellValue('AB1',"勞保費-員工負擔");
$objPHPExcel->getActiveSheet()->setCellValue('AC1',"健保費-員工負擔");
$objPHPExcel->getActiveSheet()->setCellValue('AD1',"事假");
$objPHPExcel->getActiveSheet()->setCellValue('AE1',"病假");
$objPHPExcel->getActiveSheet()->setCellValue('AF1',"勞退公司提撥");
$objPHPExcel->getActiveSheet()->setCellValue('AG1',"勞保費-公司負擔");
$objPHPExcel->getActiveSheet()->setCellValue('AH1',"健保費-公司負擔");
$objPHPExcel->getActiveSheet()->setCellValue('AI1',"生理假");
$objPHPExcel->getActiveSheet()->setCellValue('AJ1',"簽約獎金返還");
$objPHPExcel->getActiveSheet()->setCellValue('AK1',"未上班天數");
$objPHPExcel->getActiveSheet()->setCellValue('AL1',"代扣所得稅");
$objPHPExcel->getActiveSheet()->setCellValue('AM1',"其他");

$objPHPExcel->getActiveSheet()->getStyle("A1")->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("B1")->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("C1")->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("D1")->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("E1")->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("F1")->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("G1")->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("H1")->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("I1")->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("J1")->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("K1")->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("L1")->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("M1")->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("N1")->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("O1")->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("P1")->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("Q1")->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("R1")->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("S1")->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("T1")->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("U1")->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("V1")->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("W1")->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("X1")->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("Y1")->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("Z1")->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("AA1")->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("AB1")->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("AC1")->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("AD1")->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("AE1")->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("AF1")->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("AG1")->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("AH1")->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("AI1")->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("AJ1")->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("AK1")->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("AL1")->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("AM1")->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("AN1")->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$Ecount=2;
while(list($EPID,$MID,$MPID,$BAccount,$MName,$EmployeeNo,$MPID,$EMail,$Departments,$EPDate,$EPYear,$EPDay,$EPay,$Salary,$Allowance,$Overtime,$Transportation1,$Transportation2,$FullAttendance,$Bonus,$Signing,$NewBonus,$YearEnd,$MidYear,$Disbursement,$Travel,$Physiological,$SigningReturn,$NotWorking,$IncomeTax,$CRetirement,$CRetirementEmployee,$CLabor,$CHealth,$ELabor,$EHealth,$PLeave,$SickLeave,$EVAmount,$Other,$OtherDesc)=mysqli_fetch_row($result_EmployeePay)){
  	if (trim($Departments) == "A") $Departments="工程部";
  	else if (trim($Departments) == "B") $Departments="行政品質部";
  	else if (trim($Departments) == "C") $Departments="客服部";
	
	$objPHPExcel->getActiveSheet()->setCellValue('A'.$Ecount,$BAccount);
	$objPHPExcel->getActiveSheet()->setCellValue('B'.$Ecount,$EPay);
	$objPHPExcel->getActiveSheet()->setCellValue('C'.$Ecount,$MPID);
	$objPHPExcel->getActiveSheet()->setCellValue('D'.$Ecount,$EMail);
	$objPHPExcel->getActiveSheet()->setCellValue('E'.$Ecount,$EmployeeNo);
	$objPHPExcel->getActiveSheet()->setCellValue('F'.$Ecount,$MName);
	$objPHPExcel->getActiveSheet()->setCellValue('G'.$Ecount,$Departments);
	$objPHPExcel->getActiveSheet()->setCellValue('H'.$Ecount,$Salary);
	$objPHPExcel->getActiveSheet()->setCellValue('I'.$Ecount,$Allowance);
	$objPHPExcel->getActiveSheet()->setCellValue('J'.$Ecount,$Overtime);
	$objPHPExcel->getActiveSheet()->setCellValue('K'.$Ecount,$Transportation1);
	$objPHPExcel->getActiveSheet()->setCellValue('L'.$Ecount,$Transportation2);
	$objPHPExcel->getActiveSheet()->setCellValue('M'.$Ecount,$FullAttendance);
	$objPHPExcel->getActiveSheet()->setCellValue('N'.$Ecount,$CRetirement);
	$objPHPExcel->getActiveSheet()->setCellValue('O'.$Ecount,$CRetirementEmployee);
	$objPHPExcel->getActiveSheet()->setCellValue('P'.$Ecount,$CLabor);
	$objPHPExcel->getActiveSheet()->setCellValue('Q'.$Ecount,$CHealth);
	$objPHPExcel->getActiveSheet()->setCellValue('R'.$Ecount,$Other);
	$objPHPExcel->getActiveSheet()->setCellValue('S'.$Ecount,$Signing);
	$objPHPExcel->getActiveSheet()->setCellValue('T'.$Ecount,$Bonus);
	$objPHPExcel->getActiveSheet()->setCellValue('U'.$Ecount,$NewBonus);
	$objPHPExcel->getActiveSheet()->setCellValue('V'.$Ecount,$YearEnd);
	$objPHPExcel->getActiveSheet()->setCellValue('W'.$Ecount,$MidYear);
	$objPHPExcel->getActiveSheet()->setCellValue('X'.$Ecount,$EVAmount);
	$objPHPExcel->getActiveSheet()->setCellValue('Y'.$Ecount,$Disbursement);
	$objPHPExcel->getActiveSheet()->setCellValue('Z'.$Ecount,$Travel);
	$objPHPExcel->getActiveSheet()->setCellValue('AA'.$Ecount,"");
	$objPHPExcel->getActiveSheet()->setCellValue('AB'.$Ecount,$ELabor);
	$objPHPExcel->getActiveSheet()->setCellValue('AC'.$Ecount,$EHealth);
	$objPHPExcel->getActiveSheet()->setCellValue('AD'.$Ecount,$PLeave);
	$objPHPExcel->getActiveSheet()->setCellValue('AE'.$Ecount,$SickLeave);
	$objPHPExcel->getActiveSheet()->setCellValue('AF'.$Ecount,$CRetirement);
	$objPHPExcel->getActiveSheet()->setCellValue('AG'.$Ecount,$CLabor);
	$objPHPExcel->getActiveSheet()->setCellValue('AH'.$Ecount,$CHealth);
	$objPHPExcel->getActiveSheet()->setCellValue('AI'.$Ecount,$Physiological);
	$objPHPExcel->getActiveSheet()->setCellValue('AJ'.$Ecount,$SigningReturn);
	$objPHPExcel->getActiveSheet()->setCellValue('AK'.$Ecount,$NotWorking);
	$objPHPExcel->getActiveSheet()->setCellValue('AL'.$Ecount,$IncomeTax);
	$objPHPExcel->getActiveSheet()->setCellValue('AM'.$Ecount,"");
	
		
	$objPHPExcel->getActiveSheet()->getStyle('A'.$Ecount)->getFont()->setSize(12);
	$objPHPExcel->getActiveSheet()->getStyle('B'.$Ecount)->getFont()->setSize(12);
	$objPHPExcel->getActiveSheet()->getStyle('C'.$Ecount)->getFont()->setSize(12);
	$objPHPExcel->getActiveSheet()->getStyle('D'.$Ecount)->getFont()->setSize(12);
	$objPHPExcel->getActiveSheet()->getStyle('E'.$Ecount)->getFont()->setSize(12);
	$objPHPExcel->getActiveSheet()->getStyle('F'.$Ecount)->getFont()->setSize(12);
	$objPHPExcel->getActiveSheet()->getStyle('G'.$Ecount)->getFont()->setSize(12);
	$objPHPExcel->getActiveSheet()->getStyle('H'.$Ecount)->getFont()->setSize(12);
	$objPHPExcel->getActiveSheet()->getStyle('I'.$Ecount)->getFont()->setSize(12);
	$objPHPExcel->getActiveSheet()->getStyle('J'.$Ecount)->getFont()->setSize(12);
	$objPHPExcel->getActiveSheet()->getStyle('K'.$Ecount)->getFont()->setSize(12);
	$objPHPExcel->getActiveSheet()->getStyle('L'.$Ecount)->getFont()->setSize(12);
	$objPHPExcel->getActiveSheet()->getStyle('M'.$Ecount)->getFont()->setSize(12);
	$objPHPExcel->getActiveSheet()->getStyle('N'.$Ecount)->getFont()->setSize(12);
	$objPHPExcel->getActiveSheet()->getStyle('O'.$Ecount)->getFont()->setSize(12);
	$objPHPExcel->getActiveSheet()->getStyle('P'.$Ecount)->getFont()->setSize(12);
	$objPHPExcel->getActiveSheet()->getStyle('Q'.$Ecount)->getFont()->setSize(12);
	$objPHPExcel->getActiveSheet()->getStyle('R'.$Ecount)->getFont()->setSize(12);
	$objPHPExcel->getActiveSheet()->getStyle('S'.$Ecount)->getFont()->setSize(12);
	$objPHPExcel->getActiveSheet()->getStyle('T'.$Ecount)->getFont()->setSize(12);
	$objPHPExcel->getActiveSheet()->getStyle('U'.$Ecount)->getFont()->setSize(12);
	$objPHPExcel->getActiveSheet()->getStyle('V'.$Ecount)->getFont()->setSize(12);
	$objPHPExcel->getActiveSheet()->getStyle('W'.$Ecount)->getFont()->setSize(12);
	$objPHPExcel->getActiveSheet()->getStyle('X'.$Ecount)->getFont()->setSize(12);
	$objPHPExcel->getActiveSheet()->getStyle('Y'.$Ecount)->getFont()->setSize(12);
	$objPHPExcel->getActiveSheet()->getStyle('Z'.$Ecount)->getFont()->setSize(12);
	$objPHPExcel->getActiveSheet()->getStyle('AA'.$Ecount)->getFont()->setSize(12);
	$objPHPExcel->getActiveSheet()->getStyle('AB'.$Ecount)->getFont()->setSize(12);
	$objPHPExcel->getActiveSheet()->getStyle('AC'.$Ecount)->getFont()->setSize(12);
	$objPHPExcel->getActiveSheet()->getStyle('AD'.$Ecount)->getFont()->setSize(12);
	$objPHPExcel->getActiveSheet()->getStyle('AE'.$Ecount)->getFont()->setSize(12);
	$objPHPExcel->getActiveSheet()->getStyle('AF'.$Ecount)->getFont()->setSize(12);
	$objPHPExcel->getActiveSheet()->getStyle('AG'.$Ecount)->getFont()->setSize(12);
	$objPHPExcel->getActiveSheet()->getStyle('AH'.$Ecount)->getFont()->setSize(12);
	$objPHPExcel->getActiveSheet()->getStyle('AI'.$Ecount)->getFont()->setSize(12);
	$objPHPExcel->getActiveSheet()->getStyle('AJ'.$Ecount)->getFont()->setSize(12);
	$objPHPExcel->getActiveSheet()->getStyle('AK'.$Ecount)->getFont()->setSize(12);
	$objPHPExcel->getActiveSheet()->getStyle('AL'.$Ecount)->getFont()->setSize(12);
	$objPHPExcel->getActiveSheet()->getStyle('AM'.$Ecount)->getFont()->setSize(12);
	$objPHPExcel->getActiveSheet()->getStyle('AN'.$Ecount)->getFont()->setSize(12);
	
	$Ecount++;
}
mysqli_free_result($result_EmployeePay);
mysqli_close($link);

$objPHPExcel->getActiveSheet()->setTitle('EmployeePayExport');

ob_end_clean();

header('Content-Type: application/vnd.ms-excel');
header('Content-Disposition: attachment;filename="EmployeePayExport.xls"');
header('Cache-Control: max-age=0');
$objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel5');
$objWriter->save('php://output');
exit;

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $PageAdminTitle;?></title>
<link href="style.css" rel="stylesheet" type="text/css" />
<body>
<table winth="1000" border="0">
	<tr>
		<td colspan="2"><font color=blue>若您無法正常觀看此報表！請下載此 <a href="owc11.zip" target="_File"><font color=red><b>元件</b></font></a> <font color=blue>安裝至您的電腦。</font></td>
	</tr>
</table>
<object id=EmployeePay classid=CLSID:0002E559-0000-0000-C000-000000000046 style="width:100%;height:90%"></object>
<script language=vbscript>
	Sub Window_OnLoad()
	Set chConstants = EmployeePay.Constants
	EmployeePay.ActiveSheet.Cells.Clear
	EmployeePay.Worksheets(1).Select
	EmployeePay.ActiveSheet.Name ="EmployeePay"

	EmployeePay.ActiveSheet.Cells(1,1).Value ="帳號"
	EmployeePay.ActiveSheet.Cells(1,2).Value ="交易金額"
	EmployeePay.ActiveSheet.Cells(1,3).Value ="行庫代號"
	EmployeePay.ActiveSheet.Cells(1,4).Value ="身份證號"
	EmployeePay.ActiveSheet.Cells(1,5).Value ="email帳號"
	EmployeePay.ActiveSheet.Cells(1,6).Value ="受扣款用戶編號"
	EmployeePay.ActiveSheet.Cells(1,7).Value ="全威驗證科技有限公司"
	EmployeePay.ActiveSheet.Cells(1,8).Value ="部門別"
	EmployeePay.ActiveSheet.Cells(1,9).Value ="本薪"
	EmployeePay.ActiveSheet.Cells(1,10).Value ="職務加給"
	EmployeePay.ActiveSheet.Cells(1,11).Value ="加班費"
	EmployeePay.ActiveSheet.Cells(1,12).Value ="交通費-公里數計算"
	EmployeePay.ActiveSheet.Cells(1,13).Value ="交通費-實報實銷"
	EmployeePay.ActiveSheet.Cells(1,14).Value ="績效獎金"
	EmployeePay.ActiveSheet.Cells(1,15).Value ="勞退公司提撥"
	EmployeePay.ActiveSheet.Cells(1,16).Value ="勞保費-公司負擔"
	EmployeePay.ActiveSheet.Cells(1,17).Value ="健保費-公司負擔"
	EmployeePay.ActiveSheet.Cells(1,18).Value ="受款名目(金額10)"
	EmployeePay.ActiveSheet.Cells(1,19).Value ="勞保費-員工負擔"
	EmployeePay.ActiveSheet.Cells(1,20).Value ="健保費-員工負擔"
	EmployeePay.ActiveSheet.Cells(1,21).Value ="事假"
	EmployeePay.ActiveSheet.Cells(1,22).Value ="病假"
	EmployeePay.ActiveSheet.Cells(1,23).Value ="勞退公司提撥"
	EmployeePay.ActiveSheet.Cells(1,24).Value ="勞保費-公司負擔 "
	EmployeePay.ActiveSheet.Cells(1,25).Value ="健保費-公司負擔 "
	EmployeePay.ActiveSheet.Cells(1,26).Value ="受款名目(金額18)"
	EmployeePay.ActiveSheet.Cells(1,27).Value ="受款名目(金額19)"
	EmployeePay.ActiveSheet.Cells(1,28).Value ="受款名目(金額20)"
	EmployeePay.ActiveSheet.Cells(1,29).Value ="應稅金額"
	EmployeePay.ActiveSheet.Cells(1,30).Value ="勞退新制雇主提撥金"
	EmployeePay.ActiveSheet.Cells(1,31).Value ="備註"
<?php  
$ECount=2;
while(list($EPID,$MID,$BCode,$BAccount,$MName,$EmployeeNo,$MPID,$EMail,$Departments,$EPDate,$EPYear,$EPDay,$EPay,$Salary,$Allowance,$Overtime,$Transportation1,$Transportation2,$Bonus,$CRetirement,$CLabor,$CHealth,$ELabor,$EHealth,$PLeave,$SickLeave,$EVAmount,$Other,$OtherDesc)=mysqli_fetch_row($result_EmployeePay)){
  	if (trim($Departments) == "A") $Departments="工程部";
  	else if (trim($Departments) == "B") $Departments="國際認證部";
  	else if (trim($Departments) == "C") $Departments="業務部";
		?>
		EmployeePay.ActiveSheet.Cells(<?php echo $ECount;?>,1).Value ="'<?php echo $BAccount;?>"
		EmployeePay.ActiveSheet.Cells(<?php echo $ECount;?>,2).Value ="<?php echo $EPay;?>"
		EmployeePay.ActiveSheet.Cells(<?php echo $ECount;?>,3).Value ="<?php echo $BCode;?>"
		EmployeePay.ActiveSheet.Cells(<?php echo $ECount;?>,4).Value ="<?php echo $MPID;?>"
		EmployeePay.ActiveSheet.Cells(<?php echo $ECount;?>,5).Value ="<?php echo $EMail;?>"
		EmployeePay.ActiveSheet.Cells(<?php echo $ECount;?>,6).Value ="<?php echo $EmployeeNo;?>"
		EmployeePay.ActiveSheet.Cells(<?php echo $ECount;?>,7).Value ="全威驗證科技有限公司"
		EmployeePay.ActiveSheet.Cells(<?php echo $ECount;?>,8).Value ="<?php echo $Departments;?>"
		EmployeePay.ActiveSheet.Cells(<?php echo $ECount;?>,9).Value ="<?php echo $Salary;?>"
		EmployeePay.ActiveSheet.Cells(<?php echo $ECount;?>,10).Value ="<?php echo $Allowance;?>"
		EmployeePay.ActiveSheet.Cells(<?php echo $ECount;?>,11).Value ="'<?php echo $Overtime;?>"
		EmployeePay.ActiveSheet.Cells(<?php echo $ECount;?>,12).Value ="<?php echo $Transportation1;?>"
		EmployeePay.ActiveSheet.Cells(<?php echo $ECount;?>,13).Value ="<?php echo $Transportation2;?>"
		EmployeePay.ActiveSheet.Cells(<?php echo $ECount;?>,14).Value ="<?php echo $Bonus;?>"
		EmployeePay.ActiveSheet.Cells(<?php echo $ECount;?>,15).Value ="<?php echo $CRetirement;?>"
		EmployeePay.ActiveSheet.Cells(<?php echo $ECount;?>,16).Value ="<?php echo $CLabor;?>"
		EmployeePay.ActiveSheet.Cells(<?php echo $ECount;?>,17).Value ="<?php echo $CHealth;?>"
		EmployeePay.ActiveSheet.Cells(<?php echo $ECount;?>,18).Value ="<?php echo ($EVAmount+$Other);?>"
		EmployeePay.ActiveSheet.Cells(<?php echo $ECount;?>,19).Value ="<?php echo $ELabor;?>"
		EmployeePay.ActiveSheet.Cells(<?php echo $ECount;?>,20).Value ="<?php echo $EHealth;?>"
		EmployeePay.ActiveSheet.Cells(<?php echo $ECount;?>,21).Value ="<?php echo $PLeave;?>"
		EmployeePay.ActiveSheet.Cells(<?php echo $ECount;?>,22).Value ="<?php echo $SickLeave;?>"
		EmployeePay.ActiveSheet.Cells(<?php echo $ECount;?>,23).Value ="<?php echo $CRetirement;?>"
		EmployeePay.ActiveSheet.Cells(<?php echo $ECount;?>,24).Value ="<?php echo $CLabor;?>"
		EmployeePay.ActiveSheet.Cells(<?php echo $ECount;?>,25).Value ="<?php echo $CHealth;?>"
		EmployeePay.ActiveSheet.Cells(<?php echo $ECount;?>,26).Value =""
		EmployeePay.ActiveSheet.Cells(<?php echo $ECount;?>,27).Value =""
		EmployeePay.ActiveSheet.Cells(<?php echo $ECount;?>,28).Value =""
		EmployeePay.ActiveSheet.Cells(<?php echo $ECount;?>,29).Value =""
		EmployeePay.ActiveSheet.Cells(<?php echo $ECount;?>,30).Value ="<?php echo $CRetirement;?>"
		EmployeePay.ActiveSheet.Cells(<?php echo $ECount;?>,31).Value =""
		<?php
		$ECount++;
		}
mysqli_free_result($result_EmployeePay);
mysqli_close($link);
?>

		EmployeePay.ActiveSheet.Range("A1:AE<?php echo $ECount;?>").Font.Color="blue"
		EmployeePay.ActiveSheet.Range("A1:AE<?php echo $ECount;?>").Font.Name="Courier New"
		EmployeePay.ActiveSheet.Range("A1:AE<?php echo $ECount;?>").Font.Size="11"
		EmployeePay.ActiveSheet.Range("A1:AE<?php echo $ECount;?>").Columns.AutoFit
		EmployeePay.ActiveSheet.Range("A1:AE<?php echo $ECount;?>").NumberFormat ="General"

		EmployeePay.ActiveSheet.Range("A1:AE1").Font.Bold=true
		EmployeePay.ActiveSheet.Range("A1:AE1").Font.Color="#000000"
		EmployeePay.ActiveSheet.Range("A1:AE1").Font.Bold=true
		EmployeePay.ActiveSheet.Range("A1:AE1").Font.Bold=true
		EmployeePay.ActiveSheet.Range("A1:AE1").Font.Bold=true

	End Sub
	</script>
</body>
</html>
