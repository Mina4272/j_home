﻿<?php
include "CheckPermission.php";
include "CheckCustomer.php";
include "../global.php";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $PageAdminTitle;?></title>
</head>
<body>
<?php
$CUID = $_POST['CUID'];
$CPWD = $_POST['CPWD'];
$CName = $_POST['CName'];
$EName = $_POST['EName'];
$TrademarkTxt = $_POST['TrademarkTxt'];
$TrademarkImg = $_POST['TrademarkImg'];
$CTel = $_POST['CTel'];
$CFax = $_POST['CFax'];
$Contact = $_POST['Contact'];
$CMobile = $_POST['CMobile'];
$CEMail = $_POST['CEMail'];
$CAddress = $_POST['CAddress'];
$CNote = $_POST['CNote'];

$CType = $_POST['CType'];
$CTypeTxt = join(",", $CType);
$CLevel = $_POST['CLevel'];
$CFees = $_POST['CFees'];
$CRecord = $_POST['CRecord'];
$CRecordTxt = $_POST['CRecordTxt'];
$BSMI = $_POST['BSMI'];

$Principal = $_POST['Principal'];
$TAddress = $_POST['TAddress'];
$LAddress = $_POST['LAddress'];
$GUI = $_POST['GUI'];
if (trim($GUI) == "") $GUI = $CUID;

if (trim($CUID) == "" || trim($CName) == "")
		{
		mysqli_close($link);
		?>
		<script type="text/JavaScript">
			<!--
			alert ("您輸入的資料不足，請重新輸入！");
			history.go(-1);
			//-->
		</script>
		<?php
		exit;
		}

$now_time = date("Y-m-d H:i:s",mktime());
$SQL_select="select CUID from Customer where DelTag = 'N' and CUID = '".$CUID."';";
$result_select=mysqli_query($link,$SQL_select) or die ("無法執行查詢");

if (mysqli_num_rows($result_select) != 0)
		{
		mysqli_free_result($result_select);
		mysqli_close($link);
		?>
		<script type="text/JavaScript">
			<!--
			alert ("您輸入的統一編號已使用中，請確認此客戶資料是否已存在！");
			history.go(-1);
			//-->
		</script>
		<?php
		exit;
		}
mysqli_free_result($result_select);

$sql_insert = "insert into Customer (CUID,CPWD,CName,EName,TrademarkTxt,TrademarkImg,CTel,CFax,CAddress,CNote,CType,CLevel,CFees,CRecord,CRecordTxt,BSMI,Principal,TAddress,LAddress,GUI,AddUser,AddDate,AddIP) values ('".$CUID."','".$CPWD."','".$CName."','".$EName."','".$TrademarkTxt."','".$TrademarkImg."','".$CTel."','".$CFax."','".$CAddress."','".$CNote."','".$CTypeTxt."','".$CLevel."','".$CFees."','".$CRecord."','".$CRecordTxt."','".$BSMI."','".$Principal."','".$TAddress."','".$LAddress."','".$GUI."','".$_SESSION["reg_MUID"]."','".$now_time."','".$_SERVER["REMOTE_ADDR"]."');";
$result_insert=mysqli_query($link,$sql_insert) or die ("無法執行新增");

mysqli_close($link);
?>
<script type="text/JavaScript">
	<!--
	alert ("新增成功！");
	location.href='CustomerList.php';
	//-->
</script>

</body>
</html>
