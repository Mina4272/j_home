﻿<?php
include "CheckPermission.php";
include "CheckEmployeePay.php";
include "../global.php";
include "include/page_function.php";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $PageAdminTitle;?></title>
<link href="../type.css" rel="stylesheet" type="text/css" />
<style type="text/css">
<!--
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
}
-->
</style>
<Script type="text/javascript" language="javascript" src="../script/CheckForm.js"></Script>
<script type="text/JavaScript">
<!--
function jsCheck() 
		{
		if (jsTrim(document.form1.QSEPYear.value) != "" || jsTrim(document.form1.QSEPMonth.value) != "") if (ChkDate('QSEPYear',document.form1.QSEPYear.value,document.form1.QSEPMonth.value,document.form1.QSEPDay.value,'查詢起始月份') == false) return false;
		if (jsTrim(document.form1.QEEPYear.value) != "" || jsTrim(document.form1.QEEPMonth.value) != "") if (ChkDate('QEEPYear',document.form1.QEEPYear.value,document.form1.QEEPMonth.value,document.form1.QEEPDay.value,'查詢結束月份') == false) return false;
		if (jsTrim(document.form1.QSEPYear.value) != "" && jsTrim(document.form1.QSEPMonth.value) != "" && jsTrim(document.form1.QSEPDay.value) != "" && jsTrim(document.form1.QEEPYear.value) != "" && jsTrim(document.form1.QEEPMonth.value) != "" && jsTrim(document.form1.QEEPDay.value) != "") if (CompareDate('QSEPYear',document.form1.QSEPYear.value,document.form1.QSEPMonth.value,document.form1.QSEPDay.value,document.form1.QEEPYear.value,document.form1.QEEPMonth.value,document.form1.QEEPDay.value,'查詢啟始月份','查詢結束月份') == false) return false;
		}

function EmployeePayExport() 
		{
		document.form_exp.QSEPYear.value = document.form1.QSEPYear.value;
		document.form_exp.QSEPMonth.value = document.form1.QSEPMonth.value;
		document.form_exp.QSEPDay.value = document.form1.QSEPDay.value;
		document.form_exp.QEEPYear.value = document.form1.QEEPYear.value;
		document.form_exp.QEEPMonth.value = document.form1.QEEPMonth.value;
		document.form_exp.QEEPDay.value = document.form1.QEEPDay.value;
		document.form_exp.KeyWord.value = document.form1.KeyWord.value;
		document.form_exp.IsLeft.value = document.form1.IsLeft.value;
		document.form_exp.submit();
		}
//-->
</script>
</head>

<body>
<?php include "top.php";?>
<?php
$SqlMID = "";
$SqlTxt = "";

$QSEPDate = empty($_POST['QSEPDate'])?"":$_POST['QSEPDate'];
if (trim($QSEPDate) == "") $QSEPDate = empty($_GET['QSEPDate'])?"":$_GET['QSEPDate'];
$QEEPDate = empty($_POST['QEEPDate'])?"":$_POST['QEEPDate'];
if (trim($QEEPDate) == "") $QEEPDate = empty($_GET['QEEPDate'])?"":$_GET['QEEPDate'];
if (trim($QSEPDate) == "") {
		$QSEPYear = empty($_POST['QSEPYear'])?"":$_POST['QSEPYear'];
		$QSEPMonth = empty($_POST['QSEPMonth'])?"":$_POST['QSEPMonth'];
		$QSEPDay = empty($_POST['QSEPDay'])?"":$_POST['QSEPDay'];
		if (trim($QSEPYear) != "" || trim($QSEPMonth) != "") if (checkdate($QSEPMonth,$QSEPDay ,$QSEPYear)) $QSEPDate = $QSEPYear."-".$QSEPMonth."-".$QSEPDay;
		}
else if (trim($QSEPDate) != "" && (trim($QSEPYear) == "" || trim($QSEPMonth) == "" || trim($QSEPDay) == "")) {
		$QSEPDateArr = explode("-", $QSEPDate);
		$QSEPYear = $QSEPDateArr[0];
		$QSEPMonth = $QSEPDateArr[1];
		$QSEPDay = $QSEPDateArr[2];
		}
if (trim($QEEPDate) == "") {
		$QEEPYear = empty($_POST['QEEPYear'])?"":$_POST['QEEPYear'];
		$QEEPMonth = empty($_POST['QEEPMonth'])?"":$_POST['QEEPMonth'];
		$QEEPDay = empty($_POST['QEEPDay'])?"":$_POST['QEEPDay'];
		if (trim($QEEPYear) != "" || trim($QEEPMonth) != "") if (checkdate($QEEPMonth,$QEEPDay ,$QEEPYear)) $QEEPDate = $QEEPYear."-".$QEEPMonth."-".$QEEPDay;
		}
else if (trim($QEEPDate) != "" && (trim($QEEPYear) == "" || trim($QEEPMonth) == "" || trim($QEEPDay) == "")) {
		$QEEPDateArr = explode("-", $QEEPDate);
		$QEEPYear = $QEEPDateArr[0];
		$QEEPMonth = $QEEPDateArr[1];
		$QEEPDay = $QEEPDateArr[2];
		}
$KeyWord = empty($_POST['KeyWord'])?"":$_POST['KeyWord'];
if (trim($KeyWord) == "") $KeyWord = empty($_GET['KeyWord'])?"":$_GET['KeyWord'];
$IsLeft = empty($_POST['IsLeft'])?"":$_POST['IsLeft'];
if (trim($IsLeft) == "") $IsLeft = empty($_GET['IsLeft'])?"":$_GET['IsLeft'];

if (trim($QSEPDate) != "" && trim($QEEPDate) != "") $SqlTxt = $SqlTxt." and (a.EPDate >= '".$QSEPDate."') and (a.EPDate <= '".$QEEPDate."') ";
else if (trim($QSEPDate) != "" && trim($QEEPDate) == "") $SqlTxt = $SqlTxt." and (a.EPDate >= '".$QSEPDate."') ";
else if (trim($QSEPDate) == "" && trim($QEEPDate) != "") $SqlTxt = $SqlTxt." and (a.EPDate <= '".$QEEPDate."') ";
//if (trim($KeyWord) != "") $SqlTxt = $SqlTxt." and (EPay like '%".$KeyWord."%' or Salary like '%".$KeyWord."%' or Allowance like '%".$KeyWord."%' or Other like '%".$KeyWord."%')";


if (trim($KeyWord) != "") {
		$SQL_Manager="select MID from Manager where EmployeeNo like '%".$KeyWord."%' or MName like '%".$KeyWord."%' order by MID;";
		$result_Manager=mysqli_query($link,$SQL_Manager) or die ("無法執行查詢");
		
		while(list($MMID)=mysqli_fetch_row($result_Manager)){
				if (trim($SqlMID) == "") $SqlMID = $MMID;
				else $SqlMID = $SqlMID.",".$MMID;
				}
		mysqli_free_result($result_Manager);
		}
if (trim($SqlMID) != "") $SqlMID = " a.MID in (".$SqlMID.")";
if (trim($KeyWord) != "") {
		if (trim($SqlMID) == "") $SqlTxt = $SqlTxt." and (a.EPay like '%".$KeyWord."%' or a.Salary like '%".$KeyWord."%' or a.Allowance like '%".$KeyWord."%' or a.Other like '%".$KeyWord."%')";
		else $SqlTxt = $SqlTxt." and (a.EPay like '%".$KeyWord."%' or a.Salary like '%".$KeyWord."%' or a.Allowance like '%".$KeyWord."%' or a.Other like '%".$KeyWord."%' or ".$SqlMID.")";
		}
if (trim($SqlTxt) == "") {
		$SqlTxt = " and (a.EPDate = '".date("Y-m",mktime())."-1') ";
		$QSEPYear=date("Y",mktime());
		$QSEPMonth=date("m",mktime());
		}
if (trim($IsLeft) != "") $SqlTxt .= " and b.IsLeft = '".$IsLeft."'";

?>
<table width="100%" border="0" cellspacing="0" cellpadding="5">
	<tr>
    <td width="160" height="600" align="left" valign="top">
			<?php include "menu.php";?>
    </td>
    <td valign="top">
    	<table width="100%" border="0" cellpadding="0" cellspacing="0">
    		<tr>
    			<td>
			    	<table width="750" border="0" cellpadding="0" cellspacing="0">
			    		<form name="form1" method="post" action="EmployeePayList.php" onSubmit="return jsCheck();">
			    		<tr height="30">
			    			<td width="120" class="c2" colspan="2">薪資管理</td>
			    		</tr>
			    		<tr height="30">
			    			<td class="h3" colspan="2"><font color=blue><b>所屬月份：</b></font>
			    				<select name="QSEPYear">
			    					<option value=""></option>
			    					<option value="2008"<?php if (trim($QSEPYear) == "2008") echo " selected";?>>2008</option>
			    					<option value="2009"<?php if (trim($QSEPYear) == "2009") echo " selected";?>>2009</option>
			    					<option value="2010"<?php if (trim($QSEPYear) == "2010") echo " selected";?>>2010</option>
			    					<option value="2011"<?php if (trim($QSEPYear) == "2011") echo " selected";?>>2011</option>
			    					<option value="2012"<?php if (trim($QSEPYear) == "2012") echo " selected";?>>2012</option>
			    					<option value="2013"<?php if (trim($QSEPYear) == "2013") echo " selected";?>>2013</option>
			    					<option value="2014"<?php if (trim($QSEPYear) == "2014") echo " selected";?>>2014</option>
			    					<option value="2015"<?php if (trim($QSEPYear) == "2015") echo " selected";?>>2015</option>
			    					<option value="2016"<?php if (trim($QSEPYear) == "2016") echo " selected";?>>2016</option>
			    					<option value="2017"<?php if (trim($QSEPYear) == "2017") echo " selected";?>>2017</option>
									<option value="2018"<?php if (trim($QSEPYear) == "2018") echo " selected";?>>2018</option>
			    					<option value="2019"<?php if (trim($QSEPYear) == "2019") echo " selected";?>>2019</option>
			    					<option value="2020"<?php if (trim($QSEPYear) == "2020") echo " selected";?>>2020</option>
			    					<option value="2021"<?php if (trim($QSEPYear) == "2021") echo " selected";?>>2021</option>
			    					<option value="2022"<?php if (trim($QSEPYear) == "2022") echo " selected";?>>2022</option>
			    					<option value="2023"<?php if (trim($QSEPYear) == "2023") echo " selected";?>>2023</option>
			    					<option value="2024"<?php if (trim($QSEPYear) == "2024") echo " selected";?>>2024</option>
			    					<option value="2025"<?php if (trim($QSEPYear) == "2025") echo " selected";?>>2025</option>
									<option value="2026"<?php if (trim($QSEPYear) == "2026") echo " selected";?>>2026</option>
									<option value="2027"<?php if (trim($QSEPYear) == "2027") echo " selected";?>>2027</option>
									<option value="2028"<?php if (trim($QSEPYear) == "2028") echo " selected";?>>2028</option>
									<option value="2029"<?php if (trim($QSEPYear) == "2029") echo " selected";?>>2029</option>
									<option value="2030"<?php if (trim($QSEPYear) == "2030") echo " selected";?>>2030</option>
									<option value="2031"<?php if (trim($QSEPYear) == "2031") echo " selected";?>>2031</option>
									<option value="2032"<?php if (trim($QSEPYear) == "2032") echo " selected";?>>2032</option>
									<option value="2033"<?php if (trim($QSEPYear) == "2033") echo " selected";?>>2033</option>
									<option value="2034"<?php if (trim($QSEPYear) == "2034") echo " selected";?>>2034</option>
									<option value="2035"<?php if (trim($QSEPYear) == "2035") echo " selected";?>>2035</option>
			    				</select> <font color=blue><b>年</b></font> 
			    				<select name="QSEPMonth">
			    					<option value=""></option>
			    					<option value="01"<?php if (trim($QSEPMonth) == "01") echo " selected";?>>01</option>
			    					<option value="02"<?php if (trim($QSEPMonth) == "02") echo " selected";?>>02</option>
			    					<option value="03"<?php if (trim($QSEPMonth) == "03") echo " selected";?>>03</option>
			    					<option value="04"<?php if (trim($QSEPMonth) == "04") echo " selected";?>>04</option>
			    					<option value="05"<?php if (trim($QSEPMonth) == "05") echo " selected";?>>05</option>
			    					<option value="06"<?php if (trim($QSEPMonth) == "06") echo " selected";?>>06</option>
			    					<option value="07"<?php if (trim($QSEPMonth) == "07") echo " selected";?>>07</option>
			    					<option value="08"<?php if (trim($QSEPMonth) == "08") echo " selected";?>>08</option>
			    					<option value="09"<?php if (trim($QSEPMonth) == "09") echo " selected";?>>09</option>
			    					<option value="10"<?php if (trim($QSEPMonth) == "10") echo " selected";?>>10</option>
			    					<option value="11"<?php if (trim($QSEPMonth) == "11") echo " selected";?>>11</option>
			    					<option value="12"<?php if (trim($QSEPMonth) == "12") echo " selected";?>>12</option>
			    				</select> <font color=blue><b>月</b></font><input type="hidden" name="QSEPDay" value="01">  
			    				<select name="QEEPYear">
			    					<option value=""></option>
			    					<option value="2008"<?php if (trim($QEEPYear) == "2008") echo " selected";?>>2008</option>
			    					<option value="2009"<?php if (trim($QEEPYear) == "2009") echo " selected";?>>2009</option>
			    					<option value="2010"<?php if (trim($QEEPYear) == "2010") echo " selected";?>>2010</option>
			    					<option value="2011"<?php if (trim($QEEPYear) == "2011") echo " selected";?>>2011</option>
			    					<option value="2012"<?php if (trim($QEEPYear) == "2012") echo " selected";?>>2012</option>
			    					<option value="2013"<?php if (trim($QEEPYear) == "2013") echo " selected";?>>2013</option>
			    					<option value="2014"<?php if (trim($QEEPYear) == "2014") echo " selected";?>>2014</option>
			    					<option value="2015"<?php if (trim($QEEPYear) == "2015") echo " selected";?>>2015</option>
			    					<option value="2016"<?php if (trim($QEEPYear) == "2016") echo " selected";?>>2016</option>
			    					<option value="2017"<?php if (trim($QEEPYear) == "2017") echo " selected";?>>2017</option>
			    					<option value="2018"<?php if (trim($QEEPYear) == "2018") echo " selected";?>>2018</option>
			    					<option value="2019"<?php if (trim($QEEPYear) == "2019") echo " selected";?>>2019</option>
			    					<option value="2020"<?php if (trim($QEEPYear) == "2020") echo " selected";?>>2020</option>
			    					<option value="2021"<?php if (trim($QEEPYear) == "2021") echo " selected";?>>2021</option>
			    					<option value="2022"<?php if (trim($QEEPYear) == "2022") echo " selected";?>>2022</option>
			    					<option value="2023"<?php if (trim($QEEPYear) == "2023") echo " selected";?>>2023</option>
			    					<option value="2024"<?php if (trim($QEEPYear) == "2024") echo " selected";?>>2024</option>
			    					<option value="2025"<?php if (trim($QEEPYear) == "2025") echo " selected";?>>2025</option>
									<option value="2026"<?php if (trim($QEEPYear) == "2026") echo " selected";?>>2026</option>
									<option value="2027"<?php if (trim($QEEPYear) == "2027") echo " selected";?>>2027</option>
									<option value="2028"<?php if (trim($QEEPYear) == "2028") echo " selected";?>>2028</option>
									<option value="2029"<?php if (trim($QEEPYear) == "2029") echo " selected";?>>2029</option>
									<option value="2030"<?php if (trim($QEEPYear) == "2030") echo " selected";?>>2030</option>
									<option value="2031"<?php if (trim($QEEPYear) == "2031") echo " selected";?>>2031</option>
									<option value="2032"<?php if (trim($QEEPYear) == "2032") echo " selected";?>>2032</option>
									<option value="2033"<?php if (trim($QEEPYear) == "2033") echo " selected";?>>2033</option>
									<option value="2034"<?php if (trim($QEEPYear) == "2034") echo " selected";?>>2034</option>
									<option value="2035"<?php if (trim($QEEPYear) == "2035") echo " selected";?>>2035</option>
			    				</select> <font color=blue><b>年</b></font> 
			    				<select name="QEEPMonth">
			    					<option value=""></option>
			    					<option value="01"<?php if (trim($QEEPMonth) == "01") echo " selected";?>>01</option>
			    					<option value="02"<?php if (trim($QEEPMonth) == "02") echo " selected";?>>02</option>
			    					<option value="03"<?php if (trim($QEEPMonth) == "03") echo " selected";?>>03</option>
			    					<option value="04"<?php if (trim($QEEPMonth) == "04") echo " selected";?>>04</option>
			    					<option value="05"<?php if (trim($QEEPMonth) == "05") echo " selected";?>>05</option>
			    					<option value="06"<?php if (trim($QEEPMonth) == "06") echo " selected";?>>06</option>
			    					<option value="07"<?php if (trim($QEEPMonth) == "07") echo " selected";?>>07</option>
			    					<option value="08"<?php if (trim($QEEPMonth) == "08") echo " selected";?>>08</option>
			    					<option value="09"<?php if (trim($QEEPMonth) == "09") echo " selected";?>>09</option>
			    					<option value="10"<?php if (trim($QEEPMonth) == "10") echo " selected";?>>10</option>
			    					<option value="11"<?php if (trim($QEEPMonth) == "11") echo " selected";?>>11</option>
			    					<option value="12"<?php if (trim($QEEPMonth) == "12") echo " selected";?>>12</option>
			    				</select> <font color=blue><b>月</b></font><input type="hidden" name="QEEPDay" value="01">
			    			</td>
			    		</tr>
			    		<tr height="30">
			    			<td class="h3">
			    				<font color=blue><b>關鍵字：</b></font><input type="text" name="KeyWord" size="15" value="<?php echo $KeyWord;?>"> 
			    				<font color=blue><b>是否離職：</b></font>
			    				<select id="IsLeft" name="IsLeft">
			    					<option value="">不限</option>
			    					<option value="Y"<?php if (trim($IsLeft) == "Y") echo " selected";?>>是</option>
			    					<option value="N"<?php if (trim($IsLeft) == "N") echo " selected";?>>否</option>
			    				</select> 
			    				<input type="submit" name="submit" value="查 詢" class="input_bot"> 
			    				<!--<input type="button" name="button" class="input_bot" value="全部列出" onclick="javascript:location.href='EmployeePayList.php';"> -->
			    				<input type="button" name="report" class="input_bot" value="報表輸出" onclick="javascript:EmployeePayExport();">
			    			<td width="60" align="right" class="h3"><input type="button" name="add" value="批次產出資料" class="input_bot" onclick="javascript:location.href='EmployeePayAdd.php';"></td>
			    		</tr>
			    		</form>
			    	</table>
						<?php
						$page = empty($_GET['page'])?"":$_GET['page'];
						if (trim($page) == "") $page = 1;
						$page_rows=15;  //每頁筆數
						$php_Self = "EmployeePayList.php";  //分頁web檔名
						$button_css = "h4";
						$limit_txt =" limit ".(($page-1) * $page_rows).",".$page_rows;
						$url_str = "&QSEPDate=".$QSEPDate."&QEEPDate=".$QEEPDate."&IsLeft=".$IsLeft."&KeyWord=".urlencode($KeyWord);
						//$Sql_str="select EPID,MID,(select MName from Manager where MID=EmployeePay.MID) MName,(select MEName from Manager where MID=EmployeePay.MID) MEName,(select EmployeeNo from Manager where MID=EmployeePay.MID) EmployeeNo,EPDate,date_format(EPDate,'%Y'),date_format(EPDate,'%m'),EPay,Overtime,Transportation1,Transportation2,Bonus,CRetirement,CLabor,CHealth,ELabor,EHealth,PLeave,SickLeave from EmployeePay where Deltag='N' ".$SqlTxt." order by MID,EPID asc;";
						$Sql_str="select a.EPID,a.MID,b.MName,b.MEName,b.EmployeeNo,a.EPDate,date_format(a.EPDate,'%Y'),date_format(a.EPDate,'%m'),a.EPay,a.Overtime,a.Transportation1,a.Transportation2,a.Bonus,a.CRetirement,a.CLabor,a.CHealth,a.ELabor,a.EHealth,a.PLeave,a.SickLeave from EmployeePay a,Manager b where a.MID=b.MID and a.Deltag='N' and b.Deltag='N' ".$SqlTxt." order by a.MID,a.EPID asc;";
						//$SQL_EmployeePay="select EPID,MID,(select MName from Manager where MID=EmployeePay.MID) MName,(select MEName from Manager where MID=EmployeePay.MID) MEName,(select EmployeeNo from Manager where MID=EmployeePay.MID) EmployeeNo,EPDate,date_format(EPDate,'%Y'),date_format(EPDate,'%m'),EPay,Overtime,Transportation1,Transportation2,Bonus,CRetirement,CLabor,CHealth,ELabor,EHealth,PLeave,SickLeave from EmployeePay where Deltag='N' ".$SqlTxt." order by MID,EPID asc ".$limit_txt.";";
						$SQL_EmployeePay="select a.EPID,a.MID,b.MName,b.MEName,b.EmployeeNo,a.EPDate,date_format(a.EPDate,'%Y'),date_format(a.EPDate,'%m'),a.EPay,a.Overtime,a.Transportation1,a.Transportation2,a.Bonus,a.CRetirement,a.CLabor,a.CHealth,a.ELabor,a.EHealth,a.PLeave,a.SickLeave from EmployeePay a,Manager b where a.MID=b.MID and a.Deltag='N' and b.Deltag='N' ".$SqlTxt." order by a.MID,a.EPID asc ".$limit_txt.";";
						//echo $SQL_EmployeePay;
						$result_EmployeePay=mysqli_query($link,$SQL_EmployeePay) or die ("無法執行查詢");
						?>
			    	<table width="750" border="0" cellpadding="5" cellspacing="2" class="s2">
			        <tr align="center">
			          <td width="120" background="../images/table_bg.gif" class="t21">所屬年月</td>
			          <td width="120" background="../images/table_bg.gif" class="t21">員工編號</td>
			          <td width="120" background="../images/table_bg.gif" class="t21">姓名</td>
			          <td width="120" background="../images/table_bg.gif" class="t21">當月薪資</td>
			          <td width="120" background="../images/table_bg.gif" class="t21">修 改</td>
			          <td width="120" background="../images/table_bg.gif" class="t21">刪 除</td>
			        </tr>
		          <?php
		          $tmp = 1;
		          while(list($EPID,$MID,$MName,$MEName,$EmployeeNo,$EPDate,$EPYear,$EPDay,$EPay,$Overtime,$Transportation1,$Transportation2,$Bonus,$CRetirement,$CLabor,$CHealth,$ELabor,$EHealth,$PLeave,$SickLeave)=mysqli_fetch_row($result_EmployeePay)){
		        	?>
		        	<tr<?php if ($tmp%2 == 0) echo " bgcolor=\"#F6F6F6\"";?>>
			          <td class="h3" align="center"><?php echo $EPYear."/".$EPDay;?></td>
			          <td class="h3" align="center"><?php echo $EmployeeNo;?></td>
			          <td class="h3" align="center"><?php echo $MEName.$MName;?></td>
			          <td class="h3" align="center"><?php echo $EPay;?></td>
			          <td align="center"><input type="button" name="edit" value="修 改" class="input_bot" onclick="javascript:location.href='EmployeePayEdit.php?EPID=<?php echo $EPID;?>&page=<?php echo $page;?><?php echo $url_str;?>';"></td>
			          <td align="center"><input type="button" name="edit" value="刪 除" class="input_bot" onclick="javascript:if (confirm('您是否確定要刪除？')) location.href='EmployeePayDelDB.php?EPID=<?php echo $EPID;?>&page=<?php echo $page;?><?php echo $url_str;?>';"></td>
			        </tr>
			        <?php
            			$tmp++;
			      			}
            	mysqli_free_result($result_EmployeePay);
			        ?>
			      </table>
			      <table width="750" border="0" cellpadding="5" cellspacing="2" class="s2">
			        <tr align="center">
			          <td bgcolor="#E8F0C2" class="h4"><?php Page_show($Sql_str,$page_rows,$php_Self,$link,$page,$url_str,$button_css);?></td>
			        </tr>
			      </table>
    			</td>
    		</tr>
    	</table>
    </td>
	</tr>
</table>
<form name="form_exp" action="EmployeePayExport.php" method="post" target="_EmployeePayExport">
	<input type="hidden" name="QSEPYear">
	<input type="hidden" name="QSEPMonth">
	<input type="hidden" name="QSEPDay">
	<input type="hidden" name="QEEPYear">
	<input type="hidden" name="QEEPMonth">
	<input type="hidden" name="QEEPDay">
	<input type="hidden" name="KeyWord">
	<input type="hidden" name="IsLeft">
</form>
<?php include "down.php";?>
</body>
</html>
<?php
mysqli_close($link);
?>