﻿<?php
include "CheckPermission.php";
include "CheckMVac.php";
include "../global.php";
$SqlTxt="";
$QPCSDate = empty($_POST['QPCSDate'])?"":$_POST['QPCSDate'];
if (trim($QPCSDate) == "") $QPCSDate = empty($_GET['QPCSDate'])?"":$_GET['QPCSDate'];
$QPCEDate = empty($_POST['QPCEDate'])?"":$_POST['QPCEDate'];
if (trim($QPCEDate) == "") $QPCEDate = empty($_GET['QPCEDate'])?"":$_GET['QPCEDate'];
if (trim($QPCSDate) == "") {
		$QPCSYear = $_POST['QPCSYear'];
		$QPCSMonth = $_POST['QPCSMonth'];
		$QPCSDay = $_POST['QPCSDay'];
		if (trim($QPCSYear) != "" || trim($QPCSMonth) != "" || trim($QPCSDay) != "") if (checkdate($QPCSMonth,$QPCSDay ,$QPCSYear)) $QPCSDate = $QPCSYear."-".$QPCSMonth."-".$QPCSDay;
		}
if (trim($QPCEDate) == "") {
		$QPCEYear = $_POST['QPCEYear'];
		$QPCEMonth = $_POST['QPCEMonth'];
		$QPCEDay = $_POST['QPCEDay'];
		if (trim($QPCEYear) != "" || trim($QPCEMonth) != "" || trim($QPCEDay) != "") if (checkdate($QPCEMonth,$QPCEDay ,$QPCEYear)) $QPCEDate = $QPCEYear."-".$QPCEMonth."-".$QPCEDay;
		}
$QPCType = empty($_POST['QPCType'])?"":$_POST['QPCType'];
if (trim($QPCType) == "") $QPCType = empty($_GET['QPCType'])?"":$_GET['QPCType'];
$QPCStatus = empty($_POST['QPCStatus'])?"":$_POST['QPCStatus'];
if (trim($QPCStatus) == "") $QPCStatus = empty($_GET['QPCStatus'])?"":$_GET['QPCStatus'];
$KeyWord = empty($_POST['KeyWord'])?"":$_POST['KeyWord'];
if (trim($KeyWord) == "") $KeyWord = empty($_GET['KeyWord'])?"":$_GET['KeyWord'];
$PCEnd = empty($_POST['PCEnd'])?"":$_POST['PCEnd'];
if (trim($PCEnd) == "") $PCEnd = empty($_GET['PCEnd'])?"":$_GET['PCEnd'];
if (trim($PCEnd) == "1") {
		$QPCSDate="";
		$QPCEDate="";
		$SqlTxt = $SqlTxt." and b.PCEDate='0000-00-00' ";
		}
if (trim($QPCSDate) != "" && trim($QPCEDate) != "") $SqlTxt = $SqlTxt." and (b.PCEDate >= '".$QPCSDate."') and (b.PCEDate <= '".$QPCEDate."') ";
else if (trim($QPCSDate) != "" && trim($QPCEDate) == "") $SqlTxt = $SqlTxt." and (b.PCEDate >= '".$QPCSDate."') ";
else if (trim($QPCSDate) == "" && trim($QPCEDate) != "") $SqlTxt = $SqlTxt." and (b.PCEDate <= '".$QPCEDate."') ";
if (trim($QPCType) != "") $SqlTxt = $SqlTxt." and b.PCType='".$QPCType."' ";
if (trim($QPCStatus) == "A") $SqlTxt = $SqlTxt." and PCEDate >= now( ) AND ISRemind = 'N'";
else if (trim($QPCStatus) == "B") $SqlTxt = $SqlTxt." and PCEDate >= now( ) AND ISRemind = 'Y'";
else if (trim($QPCStatus) == "C") $SqlTxt = $SqlTxt." AND ISRemind = 'Y'";
if (trim($KeyWord) != "") $SqlTxt = $SqlTxt." and (b.PCNo like '%".$KeyWord."%' or b.PCName like '%".$KeyWord."%' or a.CName like '%".$KeyWord."%' or b.RemindNote like '%".$KeyWord."%' or b.PCNote like '%".$KeyWord."%')";

$SQL_ProjectCertificate="select b.PCID,a.PID,b.PCNo,b.PCName,b.PCType,b.PCTypeName,b.PCFile,b.PCSDate,b.PCEDate,b.PCNote,a.PName,a.PE,a.CName,a.PName,a.ModelName,a.SeriesModel,b.ExpireDate,b.ISRemind,b.RemindNote,b.Reminder,b.RemindDate,b.RemindIP from Project a,ProjectCertificate b where a.PID=b.PID and a.Deltag='N' and b.Deltag='N' ".$SqlTxt." order by b.ExpireDate desc;";
$result_ProjectCertificate=mysqli_query($link,$SQL_ProjectCertificate) or die ("無法執行查詢");
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $PageAdminTitle;?></title>
<link href="style.css" rel="stylesheet" type="text/css" />
<body>
<table winth="1000" border="0">
	<tr>
		<td colspan="2"><font color=blue>若您無法正常觀看此報表！請下載此 <a href="owc11.zip" target="_File"><font color=red><b>元件</b></font></a> <font color=blue>安裝至您的電腦。</font></td>
	</tr>
</table>
<object id=Project classid=CLSID:0002E559-0000-0000-C000-000000000046 style="width:100%;height:90%"></object>
<script language=vbscript>
	Sub Window_OnLoad()
	Set chConstants = Project.Constants
	Project.ActiveSheet.Cells.Clear
	Project.Worksheets(1).Select
	Project.ActiveSheet.Name ="Project"

	Project.ActiveSheet.Cells(1,1).Value ="編號"
	Project.ActiveSheet.Cells(1,2).Value ="種類"
	Project.ActiveSheet.Cells(1,3).Value ="名稱"
	Project.ActiveSheet.Cells(1,4).Value ="客戶名稱"
	Project.ActiveSheet.Cells(1,5).Value ="型號"
	Project.ActiveSheet.Cells(1,6).Value ="相關案件"
	Project.ActiveSheet.Cells(1,7).Value ="案件工程師"
	Project.ActiveSheet.Cells(1,8).Value ="有效日期"
	Project.ActiveSheet.Cells(1,9).Value ="備註"
	Project.ActiveSheet.Cells(1,10).Value ="是否已提醒"
	Project.ActiveSheet.Cells(1,11).Value ="提醒備註"
<?php  
$ECount=2;
while(list($PCID,$PID,$PCNo,$PCName,$PCType,$PCTypeName,$PCFile,$PCSDate,$PCEDate,$PCNote,$PName,$PE,$CName,$PName,$ModelName,$SeriesModel,$ExpireDate,$ISRemind,$RemindNote,$Reminder,$RemindDate,$RemindIP)=mysqli_fetch_row($result_ProjectCertificate)){
		$SQL_Manager="SELECT MName,MEName FROM Manager Where Deltag='N' and MUID='".$PE."'";
		$result_Manager=mysqli_query($link,$SQL_Manager) or die ("無法執行查詢");
		list($MName,$MEName)=mysqli_fetch_row($result_Manager);
		mysqli_free_result($result_Manager);
  	if (trim($PCType) == "A") $PCType = "環保標章";
  	else if (trim($PCType) == "B") $PCType = "BSMI證書";
  	else if (trim($PCType) == "C") $PCType = "消防證書";
  	else if (trim($PCType) == "D") $PCType = $PCTypeName;
		?>
		Project.ActiveSheet.Cells(<?php echo $ECount;?>,1).Value ="<?php echo $PCNo;?>"
		Project.ActiveSheet.Cells(<?php echo $ECount;?>,2).Value ="<?php echo $PCType;?>"
		Project.ActiveSheet.Cells(<?php echo $ECount;?>,3).Value ="<?php echo $PCName;?>"
		Project.ActiveSheet.Cells(<?php echo $ECount;?>,4).Value ="<?php echo $CName;?>"
		Project.ActiveSheet.Cells(<?php echo $ECount;?>,5).Value ="<?php echo $ModelName;?>"
		Project.ActiveSheet.Cells(<?php echo $ECount;?>,6).Value ="<?php echo $PName;?>"
		Project.ActiveSheet.Cells(<?php echo $ECount;?>,7).Value ="<?php echo $MEName.$MName;?>"
		Project.ActiveSheet.Cells(<?php echo $ECount;?>,8).Value ="<?php echo $PCSDate."~".$PCEDate;?>"
		Project.ActiveSheet.Cells(<?php echo $ECount;?>,9).Value ="<?php echo $PCNote;?>"
		Project.ActiveSheet.Cells(<?php echo $ECount;?>,10).Value ="<?php echo $ISRemind;?>"
		Project.ActiveSheet.Cells(<?php echo $ECount;?>,11).Value ="<?php echo $RemindNote;?>"
		<?php
		$ECount++;
		}
mysqli_free_result($result_ProjectCertificate);
mysqli_close($link);
?>

		Project.ActiveSheet.Range("A1:R<?php echo $ECount;?>").Font.Color="blue"
		Project.ActiveSheet.Range("A1:R<?php echo $ECount;?>").Font.Name="Courier New"
		Project.ActiveSheet.Range("A1:R<?php echo $ECount;?>").Font.Size="11"
		Project.ActiveSheet.Range("A1:R<?php echo $ECount;?>").Columns.AutoFit
		Project.ActiveSheet.Range("A1:R<?php echo $ECount;?>").NumberFormat ="General"

		Project.ActiveSheet.Range("A1:R1").Font.Bold=true
		Project.ActiveSheet.Range("A1:R1").Font.Color="#000000"
		Project.ActiveSheet.Range("A1:R1").Font.Bold=true
		Project.ActiveSheet.Range("A1:R1").Font.Bold=true
		Project.ActiveSheet.Range("A1:R1").Font.Bold=true

	End Sub
	</script>
</body>
</html>
