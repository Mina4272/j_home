﻿<?php	
include "CheckPermission.php";
include "CheckProjectAccounting.php";
include "../global.php";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $PageAdminTitle;?></title>
<link href="../type.css" rel="stylesheet" type="text/css" />
<style type="text/css">
<!--
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
}
-->
</style>
<link href="../script/DatePicker.css" rel="stylesheet" type="text/css" />
<Script LANGUAGE="Javascript" SRC="../script/DatePicker.js"></Script>
<Script type="text/javascript" language="javascript" src="../script/CheckForm.js"></Script>
<script type="text/JavaScript">
<!--
function jsCheck() 
		{
		if (ChkImp('PQName',document.form1.PQName.value,'報價單名稱') == false) return false;
		if (ChkImp('PQFile',document.form1.PQFile.value,'報價單檔案') == false) return false;
		}
//-->
</script>
</head>
<body>
<?php
$PID = $_GET['PID'];
if (trim($PID) == "")
		{
		mysqli_close($link);
		?>
		<script type="text/JavaScript">
			<!--
			alert ("查無資料，請冾網站管理人員！");
			self.close();
			//-->
		</script>
		<?php
		exit;
		}
?>
<table width="100%" border="0" cellpadding="0" cellspacing="0">
	<tr>
		<td>
    	<table width="100%" border="0" cellpadding="0" cellspacing="0">
    		<tr height="30">
					<td width="15" background="../images/table_bg.gif"></td>
    			<td class="c3" background="../images/table_bg.gif"><b>新增報價單資料</b></td>
    		</tr>
    	</table>
    	<table width="100%" border="0" cellpadding="0" cellspacing="0">
        <form name="form1" method="post" action="ProjectQuotationAddDB.php" enctype="multipart/form-data" onSubmit="return jsCheck();">
        <tr height="40" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
					<td width="30"></td>
          <td class="c3" align="right" width="110">報價單名稱：</td>
          <td class="c3">
          	<input name="PQName" type="text" size="40" />
          </td>
        </tr>
        <tr height="40" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
					<td></td>
          <td class="c3" align="right">報價單檔案：</td>
          <td class="c3">
          	<input name="PQFile" type="file" size="40" />
          </td>
        </tr>
        <tr height="40" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
					<td></td>
          <td class="c3" align="right">報價單類別：</td>
          <td class="c3">
          	<input name="PQType" type="radio" value="A" checked /> 收入簽回　
          	<input name="PQType" type="radio" value="B" /> 支出簽出
          </td>
        </tr>
        <tr height="40" align="center">
					<td></td>
          <td colspan="2" class="h3">
          	<input type="submit" name="submit" class="input_bot" value="送 出">
          	<input name="PID" type="hidden" id="PID" value="<?php echo $PID;?>" />
          </td>
        </tr>
	      </form>
      </table>
		</td>
	</tr>
</table>
</body>
</html>
<?php
mysqli_close($link);
?>