﻿<?php
include "CheckPermission.php";
//include "CheckManager.php";
include "../global.php";
include "include/function.php";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $PageAdminTitle;?></title>
</head>
<body>
<?php
$MJID = $_POST['MJID'];
$MJPeriod = $_POST['MJPeriod'];
$MJTitle = $_POST['MJTitle'];
$MJDescription = $_POST['MJDescription'];
$MJDeputyID = $_POST['MJDeputyID'];
$MJNote = $_POST['MJNote'];

if (trim($MJID) == "" || trim($MJPeriod) == "" || trim($MJTitle) == "")
		{
		mysqli_close($link);
		?>
		<script type="text/JavaScript">
			<!--
			alert ("您輸入的資料不足，請重新輸入！");
			self.close();
			//-->
		</script>
		<?php
		exit;
		}

$SQL_ManagerJob="select MID from ManagerJob where Deltag='N' and MJID = '".$MJID."';";
$result_ManagerJob=mysqli_query($link,$SQL_ManagerJob) or die ("無法執行查詢");
list($MID)=mysqli_fetch_row($result_ManagerJob);

if (mysqli_num_rows($result_ManagerJob) == 0)
		{
		mysqli_free_result($result_ManagerJob);
		mysqli_close($link);
		?>
		<SCRIPT language=javascript>
		<!--
		alert ("查無資料，請冾網站管理人員！"); 
		self.close();
		//-->
		</SCRIPT>
		<?php 	
		exit;
		}

mysqli_free_result($result_ManagerJob);

$now_time = date("Y-m-d H:i:s",mktime());
//$sql_insert = "INSERT INTO ManagerFileHistory(MFID,MID,MTitle,MFile,AddUser,AddDate,AddIP,Deltag,ProcUser,ProcDate,ProcIP,UpdateUser,UpdateDate,UpdateIP) SELECT MFID,MID,MTitle,MFile,AddUser,AddDate,AddIP,Deltag,ProcUser,ProcDate,ProcIP,'".$_SESSION["reg_MUID"]."','".$now_time."','".$_SERVER["REMOTE_ADDR"]."' FROM ManagerFile where Deltag='N' and MID = '".$MID."' and MFID = '".$MFID."';";
//$result_insert=mysqli_query($link,$sql_insert) or die ("無法執行新增");

//if (trim($MFile) != "") $SqlTxt = ",MFile='".$MFile."'";

$sql_update = "update ManagerJob set MJPeriod = '".$MJPeriod."', MJTitle = '".htmlspecialchars($MJTitle,ENT_QUOTES)."', MJDescription = '".$MJDescription."', MJDeputyID = '".$MJDeputyID."', MJNote = '".$MJNote."', ProcUser = '".$_SESSION["reg_MUID"]."',ProcDate = '".$now_time."',ProcIP = '".$_SERVER["REMOTE_ADDR"]."' where Deltag='N' and MJID = '".$MJID."';";
//echo $sql_update;
$result_update=mysqli_query($link,$sql_update) or die ("無法執行修改");

mysqli_close($link);
?>
<script type="text/JavaScript">
	<!--
	alert ("修改成功！");
	location.href='ManagerJob.php?MID=<?php echo $MID;?>';
	//-->
</script>

</body>
</html>
