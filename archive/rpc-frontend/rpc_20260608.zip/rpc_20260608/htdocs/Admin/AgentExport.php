﻿<?php
include "CheckPermission.php";
//include "CheckMVac.php";
include "../global.php";
require_once 'PHPExcel.php';

$SqlTxt="";
$QPCSDate = empty($_POST['QPCSDate'])?"":$_POST['QPCSDate'];
if (trim($QPCSDate) == "") $QPCSDate = empty($_GET['QPCSDate'])?"":$_GET['QPCSDate'];
$QPCEDate = empty($_POST['QPCEDate'])?"":$_POST['QPCEDate'];
if (trim($QPCEDate) == "") $QPCEDate = empty($_GET['QPCEDate'])?"":$_GET['QPCEDate'];
if (trim($QPCSDate) == "") {
		$QPCSYear = $_POST['QPCSYear'];
		$QPCSMonth = $_POST['QPCSMonth'];
		$QPCSDay = $_POST['QPCSDay'];
		if (trim($QPCSYear) != "" || trim($QPCSMonth) != "" || trim($QPCSDay) != "") if (checkdate($QPCSMonth,$QPCSDay ,$QPCSYear)) $QPCSDate = $QPCSYear."-".$QPCSMonth."-".$QPCSDay;
		}
if (trim($QPCEDate) == "") {
		$QPCEYear = $_POST['QPCEYear'];
		$QPCEMonth = $_POST['QPCEMonth'];
		$QPCEDay = $_POST['QPCEDay'];
		if (trim($QPCEYear) != "" || trim($QPCEMonth) != "" || trim($QPCEDay) != "") if (checkdate($QPCEMonth,$QPCEDay ,$QPCEYear)) $QPCEDate = $QPCEYear."-".$QPCEMonth."-".$QPCEDay;
		}
$QPCType = empty($_POST['QPCType'])?"":$_POST['QPCType'];
if (trim($QPCType) == "") $QPCType = empty($_GET['QPCType'])?"":$_GET['QPCType'];
$QPCStatus = empty($_POST['QPCStatus'])?"":$_POST['QPCStatus'];
if (trim($QPCStatus) == "") $QPCStatus = empty($_GET['QPCStatus'])?"":$_GET['QPCStatus'];
$KeyWord = empty($_POST['KeyWord'])?"":$_POST['KeyWord'];
if (trim($KeyWord) == "") $KeyWord = empty($_GET['KeyWord'])?"":$_GET['KeyWord'];
$PCEnd = empty($_POST['PCEnd'])?"":$_POST['PCEnd'];
//if (trim($PCEnd) == "") $PCEnd = empty($_GET['PCEnd'])?"":$_GET['PCEnd'];
//if (trim($PCEnd) == "1") {
//		$QPCSDate="";
//		$QPCEDate="";
//		$SqlTxt = $SqlTxt." and b.PCEDate='0000-00-00' ";
//		}
if (trim($QPCSDate) != "" && trim($QPCEDate) != "") $SqlTxt = $SqlTxt." and (b.PCEDate >= '".$QPCSDate."') and (b.PCEDate <= '".$QPCEDate."') ";
else if (trim($QPCSDate) != "" && trim($QPCEDate) == "") $SqlTxt = $SqlTxt." and (b.PCEDate >= '".$QPCSDate."') ";
else if (trim($QPCSDate) == "" && trim($QPCEDate) != "") $SqlTxt = $SqlTxt." and (b.PCEDate <= '".$QPCEDate."') ";
if (trim($QPCType) != "") $SqlTxt = $SqlTxt." and b.PCType='".$QPCType."' ";
if (trim($QPCStatus) == "A") $SqlTxt = $SqlTxt."and PCSDate <= now() and PCEDate >= now( )";
else if (trim($QPCStatus) == "B") $SqlTxt = $SqlTxt." and PCSDate !='0000-00-00' and PCEDate !='0000-00-00' and PCEDate < now( )";
else if (trim($QPCStatus) == "C") $SqlTxt = $SqlTxt." and (PCSDate ='0000-00-00' or PCEDate ='0000-00-00')";
/**if (trim($QPCStatus) == "A") $SqlTxt = $SqlTxt." and PCEDate >= now( ) AND ISRemind = 'N'";
else if (trim($QPCStatus) == "B") $SqlTxt = $SqlTxt." and PCEDate >= now( ) AND ISRemind = 'Y'";
else if (trim($QPCStatus) == "C") $SqlTxt = $SqlTxt." AND ISRemind = 'Y'";
else if (trim($QPCStatus) == "D") $SqlTxt = $SqlTxt." and PCEDate >= now( ) AND ISNotice = 'N'";
else if (trim($QPCStatus) == "E") $SqlTxt = $SqlTxt." and PCEDate >= now( ) AND ISNotice = 'Y'";
else if (trim($QPCStatus) == "F") $SqlTxt = $SqlTxt." AND ISNotice = 'Y'";
**/
if (trim($KeyWord) != "") $SqlTxt = $SqlTxt." and (b.PCNo like '%".$KeyWord."%' or b.PCName like '%".$KeyWord."%' or a.CName like '%".$KeyWord."%' or b.RemindNote like '%".$KeyWord."%' or b.PCNote like '%".$KeyWord."%')";

$SQL_Agent="select b.PCID,a.PUID,a.PID,b.PCNo,b.PCName,b.PCType,b.PCTypeName,b.PCFile,b.PCSDate,b.PCEDate,b.PCNote,a.PName,a.PE,a.CName,a.PName,a.ModelName,a.SeriesModel,a.CloseDate,b.ExpireDate,DATE_ADD( b.ExpireDate, INTERVAL -3 MONTH ) AS EpDate,b.ISRemind,b.RemindNote,b.Reminder,b.RemindDate,b.RemindIP from Project a,ProjectCertificate b where a.PID=b.PID and a.Deltag='N' and b.Deltag='N' and a.Agent IN('RPC1','RPC2','DIAM') ".$SqlTxt." order by b.PCID desc;";
$result_Agent=mysqli_query($link,$SQL_Agent) or die ("無法執行查詢");

$objPHPExcel = new PHPExcel();
$objPHPExcel->setActiveSheetIndex(0);
//$objPHPExcel->getActiveSheet()->setCellValue('A1',"編號");
$objPHPExcel->getActiveSheet()->setCellValue('A1',"全威案件編號");
$objPHPExcel->getActiveSheet()->setCellValue('B1',"證書號碼");
$objPHPExcel->getActiveSheet()->setCellValue('C1',"廠商公司名稱");
$objPHPExcel->getActiveSheet()->setCellValue('D1',"證書種類");
$objPHPExcel->getActiveSheet()->setCellValue('E1',"證書狀態");
$objPHPExcel->getActiveSheet()->setCellValue('F1',"產品名稱");
$objPHPExcel->getActiveSheet()->setCellValue('G1',"主型號");
$objPHPExcel->getActiveSheet()->setCellValue('H1',"系列型號");
$objPHPExcel->getActiveSheet()->setCellValue('I1',"登錄日期(更新日期)");
$objPHPExcel->getActiveSheet()->setCellValue('J1',"到期日期(代理商)");
$objPHPExcel->getActiveSheet()->setCellValue('K1',"全額結清日期(給全威)");
$objPHPExcel->getActiveSheet()->setCellValue('L1',"通知狀態");
$objPHPExcel->getActiveSheet()->setCellValue('M1',"備註");
$objPHPExcel->getActiveSheet()->getStyle("A1")->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("B1")->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("C1")->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("D1")->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("E1")->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("F1")->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("G1")->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("H1")->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("I1")->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("J1")->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("K1")->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("L1")->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("M1")->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("N1")->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);

$objPHPExcel->getActiveSheet()->getColumnDimension('A')->setWidth(15);
$objPHPExcel->getActiveSheet()->getColumnDimension('B')->setWidth(15);
$objPHPExcel->getActiveSheet()->getColumnDimension('C')->setWidth(15);
$objPHPExcel->getActiveSheet()->getColumnDimension('D')->setWidth(15);
$objPHPExcel->getActiveSheet()->getColumnDimension('E')->setWidth(15);
$objPHPExcel->getActiveSheet()->getColumnDimension('F')->setWidth(15);
$objPHPExcel->getActiveSheet()->getColumnDimension('G')->setWidth(15);
$objPHPExcel->getActiveSheet()->getColumnDimension('H')->setWidth(15);
$objPHPExcel->getActiveSheet()->getColumnDimension('I')->setWidth(15);
$objPHPExcel->getActiveSheet()->getColumnDimension('J')->setWidth(15);
$objPHPExcel->getActiveSheet()->getColumnDimension('K')->setWidth(15);
$objPHPExcel->getActiveSheet()->getColumnDimension('L')->setWidth(15);
$objPHPExcel->getActiveSheet()->getColumnDimension('M')->setWidth(15);
$objPHPExcel->getActiveSheet()->getColumnDimension('N')->setWidth(15);

$Ecount=2;
while(list($PCID,$PUID,$PID,$PCNo,$PCName,$PCType,$PCTypeName,$PCFile,$PCSDate,$PCEDate,$PCNote,$PName,$PE,$CName,$PName,$ModelName,$SeriesModel,$CloseDate,$ExpireDate,$EpDate,$ISRemind,$RemindNote,$Reminder,$RemindDate,$RemindIP)=mysqli_fetch_row($result_Agent)){
		//$SQL_Manager="SELECT MName,MEName FROM Manager Where Deltag='N' and MUID='".$PE."'";
		//$result_Manager=mysqli_query($link,$SQL_Manager) or die ("無法執行查詢");
		//list($MName,$MEName)=mysqli_fetch_row($result_Manager);
		//mysqli_free_result($result_Manager);
  	if (trim($PCType) == "A") $PCType = "環保標章";
  	else if (trim($PCType) == "B") $PCType = "BSMI證書";
  	else if (trim($PCType) == "C") $PCType = "消防證書";
  	else if (trim($PCType) == "D") $PCType = $PCTypeName;
	else if (trim($PCType) == "E") $PCType = "NCC";
	else if (trim($PCType) == "F") $PCType = "BSMI DOC";
	
	$checkDayStr = date('Y-m-d'); if(($checkDayStr>= $PCSDate)&&($checkDayStr<=$PCEDate)){ $txt="認證";}elseif($PCSDate !="0000-00-00" && $PCEDate !="0000-00-00" && $checkDayStr>$PCEDate){ $txt="證書到期";}elseif($PCSDate=="0000-00-00" || $PCEDate=="0000-00-00"){ $txt="未認證";}

		
	//$objPHPExcel->getActiveSheet()->setCellValue('A'.$Ecount,$PID);
	$objPHPExcel->getActiveSheet()->setCellValue('A'.$Ecount,$PUID);
	//$objPHPExcel->getActiveSheet()->getCell('B'.$Ecount)->getHyperlink($PUID)->setUrl( 'http://127.0.0.1/admin/ProjectDetail.php?PID='.$PID);
	$objPHPExcel->getActiveSheet()->setCellValue('B'.$Ecount,$PCNo);
	$objPHPExcel->getActiveSheet()->setCellValue('C'.$Ecount,$CName);
	$objPHPExcel->getActiveSheet()->setCellValue('D'.$Ecount,$PCType);
	$objPHPExcel->getActiveSheet()->setCellValue('E'.$Ecount,$txt);
	$objPHPExcel->getActiveSheet()->setCellValue('F'.$Ecount,$PName);
	$objPHPExcel->getActiveSheet()->setCellValue('G'.$Ecount,$ModelName);
	$objPHPExcel->getActiveSheet()->setCellValue('H'.$Ecount,$SeriesModel);
	$objPHPExcel->getActiveSheet()->setCellValue('I'.$Ecount,$PCSDate);
	$objPHPExcel->getActiveSheet()->setCellValue('J'.$Ecount,$PCEDate);
	$PADateTxt;
	$SQL="SELECT PADate FROM projectaccounting where PID = '".$PID."' and PAMode = 'I' and (PAItem like '%代理商%' or PAItem like '%BSMI%')";
						//echo $SQL;
						//exit;
	$result=mysqli_query($link,$SQL) or die ("無法執行查詢");
	while(list($PADate)=mysqli_fetch_row($result)){

		$PADateTxt.=$PADate."\n";
					  

	}
	$objPHPExcel->getActiveSheet()->getCell('K'.$Ecount)->setValue($PADateTxt);
	$PADateTxt="";
	$objPHPExcel->getActiveSheet()->setCellValue('L'.$Ecount,$EpDate);
	$objPHPExcel->getActiveSheet()->setCellValue('M'.$Ecount,$PCNote);
	$objPHPExcel->getActiveSheet()->getStyle('A'.$Ecount)->getFont()->setSize(12);
	$objPHPExcel->getActiveSheet()->getStyle('B'.$Ecount)->getFont()->setSize(12);
	$objPHPExcel->getActiveSheet()->getStyle('C'.$Ecount)->getFont()->setSize(12);
	$objPHPExcel->getActiveSheet()->getStyle('D'.$Ecount)->getFont()->setSize(12);
	$objPHPExcel->getActiveSheet()->getStyle('E'.$Ecount)->getFont()->setSize(12);
	$objPHPExcel->getActiveSheet()->getStyle('F'.$Ecount)->getFont()->setSize(12);
	$objPHPExcel->getActiveSheet()->getStyle('G'.$Ecount)->getFont()->setSize(12);
	$objPHPExcel->getActiveSheet()->getStyle('H'.$Ecount)->getFont()->setSize(12);
	$objPHPExcel->getActiveSheet()->getStyle('I'.$Ecount)->getFont()->setSize(12);
	$objPHPExcel->getActiveSheet()->getStyle('J'.$Ecount)->getFont()->setSize(12);
	$objPHPExcel->getActiveSheet()->getStyle('K'.$Ecount)->getFont()->setSize(12);
	$objPHPExcel->getActiveSheet()->getStyle('K'.$Ecount)->getAlignment()->setWrapText(true);
	$objPHPExcel->getActiveSheet()->getStyle('L'.$Ecount)->getFont()->setSize(12);
	//$objPHPExcel->getActiveSheet()->getStyle('L'.$Ecount)->getAlignment()->setWrapText(true); 
	$objPHPExcel->getActiveSheet()->getStyle('M'.$Ecount)->getFont()->setSize(12);
	$objPHPExcel->getActiveSheet()->getStyle('N'.$Ecount)->getFont()->setSize(12);
	
	$objPHPExcel->getActiveSheet()->getRowDimension($Ecount)->setRowHeight(100);
	$Ecount++;
}
mysqli_free_result($result_Agent);
mysqli_close($link);

$objPHPExcel->getActiveSheet()->setTitle('Agent');

ob_end_clean();

header('Content-Type: application/vnd.ms-excel');
header('Content-Disposition: attachment;filename="Agent.xls"');
header('Cache-Control: max-age=0');
$objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel5');
$objWriter->save('php://output');
exit;



?>
