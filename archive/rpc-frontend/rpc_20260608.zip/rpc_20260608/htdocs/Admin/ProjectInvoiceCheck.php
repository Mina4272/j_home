﻿<?php	
include "CheckPermission.php";
include "CheckProjectAccounting.php";
include "../global.php";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $PageAdminTitle;?></title>
<link href="../type.css" rel="stylesheet" type="text/css" />
<style type="text/css">
<!--
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
}
-->
</style>
<link href="../script/DatePicker.css" rel="stylesheet" type="text/css" />
<Script LANGUAGE="Javascript" SRC="../script/DatePicker.js"></Script>
<Script type="text/javascript" language="javascript" src="../script/CheckForm.js"></Script>
<script type="text/JavaScript">
<!--
function jsCheck() 
		{
		if (ChkDate('InvoiceYear',document.form1.InvoiceYear.value,document.form1.InvoiceMonth.value,document.form1.InvoiceDay.value,'列印日期') == false) return false;
		if (ChkImp('INo',document.form1.INo.value,'發票號碼') == false) return false;
		if (ChkDate('IYear',document.form1.IYear.value,document.form1.IMonth.value,document.form1.IDay.value,'發票日期') == false) return false;
		}
//-->
</script>
</head>
<body>
<?php
$PID = $_GET['PID'];
if (trim($PID) == "")
		{
		mysqli_close($link);
		?>
		<script type="text/JavaScript">
			<!--
			alert ("查無資料，請冾網站管理人員！");
			history.go(-1);
			//-->
		</script>
		<?php
		exit;
		}
$SQL_Project="select InvoiceDate,date_format(InvoiceDate,'%Y'),date_format(InvoiceDate,'%m'),date_format(InvoiceDate,'%d'),IFlorin,INo,IDate,date_format(IDate,'%Y'),date_format(IDate,'%m'),date_format(IDate,'%d'),InvoiceNote from Project where Deltag='N' and PID = '".$PID."';";

$result_Project=mysqli_query($link,$SQL_Project) or die ("無法執行查詢");
if (mysqli_num_rows($result_Project) == 0)
		{
		mysqli_free_result($result_Project);
		mysqli_close($link);
		?>
		<SCRIPT language=javascript>
		<!--
		alert ("查無資料，請冾網站管理人員！"); 
		history.go(-1);
		//-->
		</SCRIPT>
		<?php 	
		exit;
		}
list($InvoiceDate,$InvoiceYear,$InvoiceMonth,$InvoiceDay,$IFlorin,$INo,$IDate,$IYear,$IMonth,$IDay,$InvoiceNote)=mysqli_fetch_row($result_Project);
mysqli_free_result($result_Project);
//if (trim($InvoiceDate) == "0000-00-00") $InvoiceDate = "";
//if (trim($InvoiceDate) != "") {
//		mysqli_close($link);
		?>
		<script type="text/JavaScript">
			<!--
			//location.href='ProjectQuotation.php?PID=<?php echo $PID;?>';
			//-->
		</script>
		<?php
//		exit;
//		}
$SQL_ProjectAccounting="select PAID,PAMode,PAItem,Charges,Rate,PAStatus,PADate,PANote from ProjectAccounting where Deltag='N' and PAMode='I' and PID = '".$PID."' and (PAStatus = 'W' or PAStatus = 'S') order by PAMode asc,PAID asc;";
$result_ProjectAccounting=mysqli_query($link,$SQL_ProjectAccounting) or die ("無法執行查詢");
if (mysqli_num_rows($result_ProjectAccounting) == 0)
		{
		mysqli_free_result($result_ProjectAccounting);
		mysqli_close($link);
		?>
		<SCRIPT language=javascript>
		<!--
		alert ("您未新增報價資料！"); 
		self.close();
		//-->
		</SCRIPT>
		<?php 	
		exit;
		}
mysqli_free_result($result_ProjectAccounting);

?>
<center>
<table width="100%" border="0" cellpadding="0" cellspacing="0">
	<tr>
		<td>
    	<table width="500" border="0" cellpadding="0" cellspacing="0">
    		<tr height="40" align="center">
    			<td></td>
    		</tr>
    		<tr height="30" align="center">
    			<td class="c2" background="../images/table_bg.gif"><b>請選擇使用幣別</b></td>
    		</tr>
    	</table>
    	<?php
    	if (trim($InvoiceYear) == "") $InvoiceYear = date("Y",mktime());
    	if (trim($InvoiceMonth) == "") $InvoiceMonth = date("m",mktime());
    	if (trim($InvoiceDay) == "") $InvoiceDay = date("d",mktime());
		if (trim($IYear) == "" || trim($IYear) == "0000" ) $IYear = date("Y",mktime());
    	if (trim($IMonth) == "" || trim($IMonth) == "00") $IMonth = date("m",mktime());
    	if (trim($IDay) == "" || trim($IDay) == "00") $IDay = date("d",mktime());
    	?>
    	<table width="500" border="0" cellpadding="0" cellspacing="0">
        <form name="form1" method="post" action="ProjectInvoiceCheckDB.php" onSubmit="return jsCheck();">
        <tr height="40" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
          <td width="120" align="right" class="c3">列印日期：</td>
          <td class="h3" align="left">
            <input name="InvoiceYear" type="text" size="4" value="<?php echo $InvoiceYear;?>" /> 年 
            <input name="InvoiceMonth" type="text" size="2" value="<?php echo $InvoiceMonth;?>" /> 月 
            <input name="InvoiceDay" type="text" size="2" value="<?php echo $InvoiceDay;?>" /> 日 
            <img src="../images/icon.gif" width="16" height="18" style="cursor: hand" onclick="javascript:displayDatePicker('InvoiceYear','InvoiceMonth','InvoiceDay');"/>
            <input name="PID" type="hidden" value="<?php echo $PID;?>" />
          </td>
        </tr>
		<tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
          <td align="right" class="c3">電子發票或紙本發票：</td>
          <td class="h3" align="left">
            <input name="Invoice" type="radio" value="P" checked /> 紙本發票 
            <input name="Invoice" type="radio" value="E" /> 電子發票
            <!--<input name="IVersion" type="radio" value="OBU" disabled/> OBU-->
          </td>
        </tr>
        <tr height="40" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
          <td width="120" align="right" class="c3">使用幣別：</td>
          <td class="h3" align="left">
            <input name="PID" type="hidden" value="<?php echo $PID;?>" />
            <input name="Florin" type="radio" value="T" checked /> 新台幣　
            <?php if (trim($IFlorin) != "") {?>
            <input name="Florin" type="radio" value="O" /> <?php echo $IFlorin;?>
            <?php }?>
          </td>
        </tr>
        <tr height="40" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
          <td width="120" align="right" class="c3">發票號碼：</td>
          <td class="h3" align="left">
            <input <?php if(!empty($INo) && (!($_SESSION["reg_MUID"] == 'amanda')) ){ echo "readonly";} ?> name="INo" type="text" size="10" value="<?php echo $INo;?>" />
          </td>
        </tr>
        <tr height="40" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
          <td width="120" align="right" class="c3">發票日期：</td>
          <td class="h3" align="left">
            <input name="IYear" type="text" size="4" value="<?php echo $IYear;?>" /> 年 
            <input name="IMonth" type="text" size="2"  value="<?php echo $IMonth;?>"/> 月 
            <input name="IDay" type="text" size="2" value="<?php echo $IDay;?>"/> 日 
            <img src="../images/icon.gif" width="16" height="18" style="cursor: hand" onclick="javascript:displayDatePicker('IYear','IMonth','IDay');"/>
          </td>
        </tr>
        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
          <td align="right" class="c3">付款帳戶：</td>
          <td class="h3" align="left">
            <input name="IAccount" type="radio" value="R" checked /> 全威驗證科技股份有限公司 
			<br/>
            <!--<input name="IAccount" type="radio" value="V" disabled/> 瑞寶國際科技有限公司-->
          </td>
        </tr>
        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
          <td align="right" class="c3">發票版本：</td>
          <td class="h3" align="left">
            <input name="IVersion" type="radio" value="Cht" checked /> 中文版 
            <input name="IVersion" type="radio" value="Eng" /> 英文版
            <!--<input name="IVersion" type="radio" value="OBU" disabled/> OBU-->
          </td>
        </tr>
        <tr height="40" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
          <td width="120" align="right" class="c3">備註：</td>
          <td class="h3" align="left">
            <input name="InvoiceNote" type="text" size="30" value="<?php echo $InvoiceNote;?>" />
          </td>
        </tr>
        <tr height="40" align="center" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
          <td colspan="2" class="h3"><input type="submit" name="submit" class="input_bot" value="送 出"></td>
        </tr>
	      </form>
      </table>
		</td>
	</tr>
</table>
</center>
</body>
</html>
<?php
mysqli_close($link);
?>