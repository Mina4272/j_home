﻿<?php
include "CheckPermission.php";
include "CheckCustomer.php";
if (trim(strstr($_SESSION["reg_MPer"],'P')) == "" && trim(strstr($_SESSION["reg_MPer"],'Q')) == "") exit;
include "../global.php";
include "include/function.php";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $PageAdminTitle;?></title>
</head>
<body>
<?php
$CSID = $_POST['CSID'];
$CID = $_POST['CID'];
$CSMode = $_POST['CSMode'];
$CSContent = $_POST['CSContent'];
$SqlTxt="";
if(trim($_FILES['CSFile']['tmp_name']) != "")
		{
		if($_FILES['CSFile']['size'] > 20971520)
				{
				?>
				<script type="text/JavaScript">
					<!--
					alert ("您上傳的檔案 Size 超過 20 M，請重新上傳！");
					history.go(-1);
					//-->
				</script>
				<?php
				exit();
				}
		$CSFile = "CSFile_".$CID.date("ymdHis",mktime()).rand_string(5, 'ABCDEFGHIJKLMNPQRSTUVWXYZ23456789abcdefghijklmnopqrstuvwxyz').".".strtolower(substr($_FILES['CSFile']['name'],strrpos($_FILES['CSFile']['name'],".")+1,strlen($_FILES['CSFile']['name'])+1));
		@copy($_FILES['CSFile']['tmp_name'],$_SERVER["DOCUMENT_ROOT"]."\\Admin\\CFile\\".$CSFile);
		}

if (trim($CSID) == "" || trim($CID) == "" || trim($CSContent) == "")
		{
		mysqli_close($link);
		?>
		<script type="text/JavaScript">
			<!--
			alert ("您輸入的資料不足，請重新輸入！");
			self.close();
			//-->
		</script>
		<?php
		exit;
		}

$SQL_CustomerSecret="select CSContent,AddUser,AddDate,ProcUser,ProcDate from CustomerSecret where Deltag='N' and CID = '".$CID."' and CSID = '".$CSID."';";
$result_CustomerSecret=mysqli_query($link,$SQL_CustomerSecret) or die ("無法執行查詢");
if (mysqli_num_rows($result_CustomerSecret) == 0)
		{
		mysqli_free_result($result_CustomerSecret);
		mysqli_close($link);
		?>
		<SCRIPT language=javascript>
		<!--
		alert ("查無資料，請冾網站管理人員！"); 
		self.close();
		//-->
		</SCRIPT>
		<?php 	
		exit;
		}
mysqli_free_result($result_CustomerSecret);

$now_time = date("Y-m-d H:i:s",mktime());

$sql_insert = "INSERT INTO CustomerSecretHistory(CSID,CID,CSMode,CSContent,CSFile,AddUser,AddDate,AddIP,Deltag,ProcUser,ProcDate,ProcIP,UpdateUser,UpdateDate,UpdateIP) SELECT CSID,CID,CSMode,CSContent,CSFile,AddUser,AddDate,AddIP,Deltag,ProcUser,ProcDate,ProcIP,'".$_SESSION["reg_MUID"]."','".$now_time."','".$_SERVER["REMOTE_ADDR"]."' FROM CustomerSecret where Deltag='N' and CID = '".$CID."' and CSID = '".$CSID."';";
$result_insert=mysqli_query($link,$sql_insert) or die ("無法執行新增");

if (trim($CSFile) != "") $SqlTxt = ",CSFile='".$CSFile."'";

$sql_update = "update CustomerSecret set CSMode = '".$CSMode."',CSContent = '".$CSContent."' ".$SqlTxt." ,ProcUser = '".$_SESSION["reg_MUID"]."',ProcDate = '".$now_time."',ProcIP = '".$_SERVER["REMOTE_ADDR"]."' where Deltag='N' and CID = '".$CID."' and CSID = '".$CSID."';";
$result_update=mysqli_query($link,$sql_update) or die ("無法執行修改");

mysqli_close($link);
?>
<script type="text/JavaScript">
	<!--
	alert ("修改成功！");
	opener.location.reload();
	self.close();
	//-->
</script>

</body>
</html>
