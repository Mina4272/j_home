﻿<?php
include "CheckPermission.php";
include "../global.php";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $PageAdminTitle;?></title>
</head>
<body>
<?php
$MVID = $_GET['MVID'];
$page = $_GET['page'];
$QMVSDate = $_GET['QMVSDate'];
$QMVEDate = $_GET['QMVEDate'];
$QMVType = $_GET['QMVType'];
$QMUID = $_GET['QMUID'];
$KeyWord = $_GET['KeyWord'];
$QAgent = $_GET['QAgent'];
$QMVCheck = $_GET['QMVCheck'];

if (trim($MVID) == "")
		{
		mysqli_close($link);
		?>
		<script type="text/JavaScript">
			<!--
			alert ("您輸入的資料不足，請重新輸入！");
			history.go(-1);
			//-->
		</script>
		<?php
		exit;
		}
$SQL_ManagerVac="select MUID,MVCheck,MVType from ManagerVac where Deltag='N' and MVID=".$MVID.";";
$result_ManagerVac=mysqli_query($link,$SQL_ManagerVac) or die ("無法執行查詢");
if (mysqli_num_rows($result_ManagerVac) == 0)
		{
		mysqli_free_result($result_Manager);
		mysqli_close($link);
		?>
		<SCRIPT language=javascript>
		<!--
		alert ("查無資料，請冾網站管理人員！"); 
		history.go(-1);
		//-->
		</SCRIPT>
		<?php 	
		exit;
		}
list($MUID,$MVCheck,$MVType)=mysqli_fetch_row($result_ManagerVac);
mysqli_free_result($result_ManagerVac);

if (trim($_SESSION["reg_MUID"]) == "Tony" || trim($_SESSION["reg_MUID"]) == "amanda" || trim($_SESSION["reg_MUID"]) == "jacky") {}
else {
		if (trim($MVCheck) != "W")
				{
				mysqli_close($link);
				?>
				<script type="text/JavaScript">
					<!--
					alert ("此請假單已簽核，不得刪除！");
					history.go(-1);
					//-->
				</script>
				<?php
				exit;
				}
		if (trim($MUID) != trim($_SESSION["reg_MUID"]))
				{
				mysqli_close($link);
				?>
				<script type="text/JavaScript">
					<!--
					alert ("此請假單非本人，不得刪除！");
					history.go(-1);
					//-->
				</script>
				<?php
				exit;
				}
		}

$now_time = date("Y-m-d H:i:s",mktime());
$sql_insert = "INSERT INTO ManagerVacHistory(MVID,MUID,MVType,MVSDate,MVEDate,Hourage,Agent,MVNote,MVSend,MVCheck,MVCNote,MVCheckID,MVCheckDate,MVCheckIP,AddUser,AddDate,AddIP,Deltag,ProcUser,ProcDate,ProcIP,UpdateUser,UpdateDate,UpdateIP) SELECT MVID,MUID,MVType,MVSDate,MVEDate,Hourage,Agent,MVNote,MVSend,MVCheck,MVCNote,MVCheckID,MVCheckDate,MVCheckIP,AddUser,AddDate,AddIP,Deltag,ProcUser,ProcDate,ProcIP,'".$_SESSION["reg_MUID"]."','".$now_time."','".$_SERVER["REMOTE_ADDR"]."' from ManagerVac where Deltag='N' and MVID=".$MVID.";";
$result_insert=mysqli_query($link,$sql_insert) or die ("無法執行新增");
$sql_update = "update ManagerVac set Deltag = 'Y',ProcUser = '".$_SESSION["reg_MUID"]."',ProcDate = '".$now_time."',ProcIP = '".$_SERVER["REMOTE_ADDR"]."' where Deltag='N' and MVID=".$MVID.";";
$result_update=mysqli_query($link,$sql_update) or die ("無法執行修改");
if (trim($MVType) == "G") {
		$sql_update = "update EmployeeVacation set Deltag = 'Y',ProcUser = '".$_SESSION["reg_MUID"]."',ProcDate = '".$now_time."',ProcIP = '".$_SERVER["REMOTE_ADDR"]."' where Deltag='N' and MVID=".$MVID.";";
		$result_update=mysqli_query($link,$sql_update) or die ("無法執行修改");
		}
mysqli_close($link);
?>
<script type="text/JavaScript">
	<!--
	alert ("刪除成功！");
	location.href='MVacList.php?page=<?php echo $page;?>&QMVSDate=<?php echo $QMVSDate;?>&QMVEDate=<?php echo $QMVEDate;?>&QMVType=<?php echo $QMVType;?>&QMUID=<?php echo $QMUID;?>&QAgent=<?php echo $QAgent;?>&QMVCheck=<?php echo $QMVCheck;?>&KeyWord=<?php echo urlencode($KeyWord);?>';
	//-->
</script>

</body>
</html>
