﻿<?php
include "CheckPermission.php";
include "CheckCommonAccounting.php";
include "../global.php";
include "include/function.php";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $PageAdminTitle;?></title>
</head>
<body>
<?php
$PayDate = "";
$QCAYear = $_POST['QCAYear'];
$QCAMonth = $_POST['QCAMonth'];
$CAYear = $_POST['CAYear'];
$CAMonth = $_POST['CAMonth'];
$CADate = $CAYear."-".$CAMonth."-01";
$CAItem = $_POST['CAItem'];
$Amount = $_POST['Amount'];
$Invoice = $_POST['Invoice'];
$InvoiceYear = $_POST['InvoiceYear'];
$InvoiceMonth = $_POST['InvoiceMonth'];
$InvoiceDay = $_POST['InvoiceDay'];
if (trim($InvoiceYear) != "" || trim($InvoiceMonth) != "" || trim($InvoiceDay) != "") if (checkdate($InvoiceMonth,$InvoiceDay ,$InvoiceYear)) $InvoiceDate = $InvoiceYear."-".$InvoiceMonth."-".$InvoiceDay;
$CAStatus = $_POST['CAStatus'];
$CANote = $_POST['CANote'];
$PayYear = $_POST['PayYear'];
$PayMonth = $_POST['PayMonth'];
$PayDay = $_POST['PayDay'];
if (trim($PayYear) != "" || trim($PayMonth) != "" || trim($PayDay) != "") if (checkdate($PayMonth,$PayDay ,$PayYear)) $PayDate = $PayYear."-".$PayMonth."-".$PayDay;
$CAType = $_POST['CAType'];

if (trim($CAYear) == "" || trim($CAMonth) == "" || trim($CAItem) == "" || trim($Amount) == "" || trim($CAStatus) == "")
		{
		mysqli_close($link);
		?>
		<script type="text/JavaScript">
			<!--
			alert ("您輸入的資料不足，請重新輸入！");
			history.go(-1);
			//-->
		</script>
		<?php
		exit;
		}

$CACDate = date("ymd");
//echo "CACDate=$CACDate<br>";
$now_time = date("Y-m-d H:i:s",mktime());
if(trim($_FILES['CAFile']['tmp_name']) != "")
		{
		if($_FILES['CAFile']['size'] > 20971520)
				{
				?>
				<script type="text/JavaScript">
					<!--
					alert ("您上傳的檔案 Size 超過 20 M，請重新上傳！");
					history.go(-1);
					//-->
				</script>
				<?php
				exit();
				}
		$CAFile = "CAFile_".date("ymdHis",mktime()).rand_string(5, 'ABCDEFGHIJKLMNPQRSTUVWXYZ23456789abcdefghijklmnopqrstuvwxyz').".".strtolower(substr($_FILES['CAFile']['name'],strrpos($_FILES['CAFile']['name'],".")+1,strlen($_FILES['CAFile']['name'])+1));
		@copy($_FILES['CAFile']['tmp_name'],$_SERVER["DOCUMENT_ROOT"]."\\Admin\\CAFile\\".$CAFile);
		}
$SQL_select="select CACount from CommonAccountingCount where CACDate = '".$CACDate."';";
$result_select=mysqli_query($link,$SQL_select) or die ("無法執行查詢");
if (mysqli_num_rows($result_select) == 0)
		{
		$sql_insert = "insert into CommonAccountingCount (CACDate,CACount) values ('".$CACDate."','2');";
		$result_insert=mysqli_query($link,$sql_insert) or die ("無法執行新增");
		$CACount = "1";
		}
else
		{
		$sql_update = "update CommonAccountingCount set CACount = CACount + 1 where CACDate = '".$CACDate."';";
		$result_update=mysqli_query($link,$sql_update) or die ("無法執行新增");
		list($CACount)=mysqli_fetch_row($result_select);
		}
mysqli_free_result($result_select);
		
//echo "CACount=$CACount<br>";
if (strlen($CACount) < 2)
	{
	for ($i=1;$i=2-strlen($CACount);$i++)
		{
		$CACount = "0" . $CACount;
		}
	}
$CAUID = "Q".$CACDate.$CACount;

$now_time = date("Y-m-d H:i:s",mktime());

if (trim($PayDate) == "") $PayDate = "0000-00-00";
if (trim($InvoiceDate) == "") $InvoiceDate = "0000-00-00";
if (trim($CAStatus) == "S") $sql_insert = "insert into CommonAccounting (CAUID,CADate,CAItem,CAType,Amount,InvoiceDate,Invoice,CAStatus,CARecord,CARecordDate,CARecordIP,PayDate,CANote,CAFile,AddUser,AddDate,AddIP) values ('".$CAUID."','".$CADate."','".$CAItem."','".$CAType."','".$Amount."','".$InvoiceDate."','".$Invoice."','".$CAStatus."','".$_SESSION["reg_MUID"]."','".$now_time."','".$_SERVER["REMOTE_ADDR"]."','".$PayDate."','".$CANote."','".$CAFile."','".$_SESSION["reg_MUID"]."','".$now_time."','".$_SERVER["REMOTE_ADDR"]."');";
else  $sql_insert = "insert into CommonAccounting (CAUID,CADate,CAItem,CAType,Amount,InvoiceDate,Invoice,CAStatus,PayDate,CANote,CAFile,AddUser,AddDate,AddIP) values ('".$CAUID."','".$CADate."','".$CAItem."','".$CAType."','".$Amount."','".$InvoiceDate."','".$Invoice."','".$CAStatus."','".$PayDate."','".$CANote."','".$CAFile."','".$_SESSION["reg_MUID"]."','".$now_time."','".$_SERVER["REMOTE_ADDR"]."');";
$result_insert=mysqli_query($link,$sql_insert) or die ("無法執行新增");

mysqli_close($link);
?>
<script type="text/JavaScript">
	<!--
	alert ("新增成功！");
	location.href='CommonAccounting.php?QCAYear=<?php echo $CAYear;?>&QCAMonth=<?php echo $CAMonth;?>';
	//-->
</script>

</body>
</html>
