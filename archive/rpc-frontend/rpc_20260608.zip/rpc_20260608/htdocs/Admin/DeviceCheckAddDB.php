<?php
include "CheckPermission.php";
//include "CheckAgendum.php";
include "../global.php";
include "include/page_function.php";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $PageAdminTitle;?></title>
<link href="../type.css" rel="stylesheet" type="text/css" />
<style type="text/css">
<!--
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
}
-->
</style></head>

<body>
<?php
$device_no = $_POST['device_no'];
$DC_cycle = $_POST['DC_cycle'];
$DCYear = $_POST['DCYear'];
$DCMonth = $_POST['DCMonth'];
$DCDay = $_POST['DCDay'];
if (trim($DCYear) != "" || trim($DCMonth) != "" || trim($DCDay) != "") if (checkdate($DCMonth,$DCDay ,$DCYear)) $DC_date = $DCYear."-".$DCMonth."-".$DCDay;
$DC_result = $_POST['DC_result'];
$D_status = $_POST['D_status'];
$DC_Note = $_POST['DC_Note'];

if (trim($DC_cycle) == "" || trim($DC_date) == "" || trim($DC_result) == "" || trim($D_status) == "" || trim($DC_Note) == "" )
{
	mysqli_close($link);
		
?>
<script type="text/JavaScript">
<!--
	alert ("您輸入的資料不足，請重新輸入！");
	history.go(-1);
	//-->
</script>
<?php
	exit;
}


$sql_insert = "insert into devicecheck (D_no,DC_cycle,DC_date,DC_result,D_status,DC_Note) values ('".$device_no."','".$DC_cycle."','".$DC_date."','".$DC_result."','".$D_status."','".$DC_Note."');";
//echo $sql_insert;
$result_insert=mysqli_query($link,$sql_insert) or die ("無法執行新增");
mysqli_close($link);
	
?>
<script type="text/JavaScript">
	
	alert("新增成功！");
	opener.location.reload();
	self.close();
	
</script>
</body>
</html>
<?php
mysqli_close($link);
?>