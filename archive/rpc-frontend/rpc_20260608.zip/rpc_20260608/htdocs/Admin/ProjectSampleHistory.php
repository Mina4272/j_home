﻿<?php
include "CheckPermission.php";
include "CheckProject.php";
include "../global.php";
include "include/page_function.php";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $PageAdminTitle;?></title>
<link href="../type.css" rel="stylesheet" type="text/css" />
<style type="text/css">
<!--
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
}
-->
</style></head>

<body>
<?php
$PSID = $_GET['PSID'];
$PID = $_GET['PID'];
if (trim($PID) == "" || trim($PSID) == "")
		{
		mysqli_close($link);
		?>
		<script type="text/JavaScript">
			<!--
			alert ("查無資料，請冾網站管理人員！");
			self.close();
			//-->
		</script>
		<?php
		exit;
		}
$SQL_ProjectSample="select PSType,PSDate,date_format(PSDate,'%Y'),date_format(PSDate,'%m'),date_format(PSDate,'%d'),PSCount,PSMode,PSPersonnel,SPlace,IPlace,PSNote,AddUser,AddDate,ProcUser,ProcDate from ProjectSample where Deltag='N' and PID = '".$PID."' and PSID = '".$PSID."';";
$result_ProjectSample=mysqli_query($link,$SQL_ProjectSample) or die ("無法執行查詢");
if (mysqli_num_rows($result_ProjectSample) == 0)
		{
		mysqli_free_result($result_ProjectSample);
		mysqli_close($link);
		?>
		<SCRIPT language=javascript>
		<!--
		alert ("查無資料，請冾網站管理人員！"); 
		self.close();
		//-->
		</SCRIPT>
		<?php 	
		exit;
		}
mysqli_free_result($result_ProjectSample);
?>
<table width="100%" border="0" cellpadding="0" cellspacing="0">
	<tr>
		<td>
			<?php
			$page = $_GET['page'];
			if (trim($page) == "") $page = 1;
			$page_rows=15;  //每頁筆數
			$php_Self = "ProjectSampleHistory.php";  //分頁web檔名

			$button_css = "h4";
			$limit_txt =" limit ".(($page-1) * $page_rows).",".$page_rows;
			$url_str = "&PID=".$PID."&PSID=".$PSID;
			$Sql_str="select PSType,PSDate,PSCount,PSMode,PSPersonnel,SPlace,IPlace,PSend,PSNote,PSFile,AddUser,AddDate,ProcUser,ProcDate from ProjectSampleHistory where Deltag='N' and PID = '".$PID."' and PSID = '".$PSID."' order by PSHID desc;";
			$SQL_ProjectSample="select PSType,PSDate,PSCount,PSMode,PSPersonnel,SPlace,IPlace,PSend,PSNote,PSFile,AddUser,AddDate,ProcUser,ProcDate from ProjectSampleHistory where Deltag='N' and PID = '".$PID."' and PSID = '".$PSID."' order by PSHID desc ".$limit_txt.";";
			$result_ProjectSample=mysqli_query($link,$SQL_ProjectSample) or die ("無法執行查詢");
			?>
    	<table width="100%" border="0" cellpadding="5" cellspacing="2" class="s2">
        <tr align="center">
          <td align="center" background="../images/table_bg.gif" class="t21">收樣 / 送樣</td>
          <td align="center" background="../images/table_bg.gif" class="t21">日期</td>
          <td align="center" background="../images/table_bg.gif" class="t21">數量</td>
          <td align="center" background="../images/table_bg.gif" class="t21">方式</td>
          <td align="center" background="../images/table_bg.gif" class="t21">收入人<br>收入地</td>
          <td align="center" background="../images/table_bg.gif" class="t21">送出人<br>送出地</td>
          <td align="center" background="../images/table_bg.gif" class="t21">相關檔案</td>
          <td align="center" background="../images/table_bg.gif" class="t21">備註</td>
          <td width="20%" background="../images/table_bg.gif" class="t21">最後更新</td>
        </tr>
        <?php
        $tmp = 1;
        while(list($PSType,$PSDate,$PSCount,$PSMode,$PSPersonnel,$SPlace,$IPlace,$PSend,$PSNote,$PSFile,$AddUser,$AddDate,$ProcUser,$ProcDate)=mysqli_fetch_row($result_ProjectSample)){
      	?>
      	<tr<?php if ($tmp%2 == 0) echo " bgcolor=\"#F6F6F6\"";?>>
          <td align="center" class="h3"><?php if (trim($PSType) == "I") echo "收入樣品"; else if (trim($PSType) == "O") echo "送出樣品";?></td>
          <td align="center" class="h3"><?php echo $PSDate;?></td>
          <td align="center" class="h3"><?php echo $PSCount;?></td>
          <td align="center" class="h3"><?php echo $PSMode;?></td>
          <td align="center" class="h3"><?php echo $PSPersonnel."<br>".$SPlace;?></td>
          <td align="center" class="h3"><?php echo $PSend."<br>".$IPlace;?></td>
				  <td class="h3" align="center">
			    	<?php if (trim($PSFile) != "") {?>
			    		<input type="button" name="edit" value="下 載" class="input_bot" onclick="javascript:location.href='getfile.php?FolderName=Admin\\PSFile&FileName=<?php echo $PSFile;?>';">
			    	<?php }?>
			    </td>
          <td align="center" class="h3"><?php echo $PSNote;?></td>
          <td align="center" class="h3">
          	<?php
          	if (trim($ProcUser) == "") echo $AddUser."<br>".$AddDate;
          	else echo $ProcUser."<br>".$ProcDate;
          	?>
          </td>
        </tr>
        <?php
      			$tmp++;
      			}
      	mysqli_free_result($result_ProjectSample);
        ?>
      </table>
      <table width="100%" border="0" cellpadding="5" cellspacing="2" class="s2">
        <tr align="center">
          <td bgcolor="#E8F0C2" class="h4"><?php Page_show($Sql_str,$page_rows,$php_Self,$link,$page,$url_str,$button_css);?></td>
        </tr>
      </table>
		</td>
	</tr>
</table>
</body>
</html>
<?php
mysqli_close($link);
?>