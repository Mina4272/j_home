﻿<?php
include "CheckPermission.php";
include "CheckProjectAccounting.php";
include "../global.php";
include "include/page_function.php";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $PageAdminTitle;?></title>
<link href="../type.css" rel="stylesheet" type="text/css" />
<style type="text/css">
<!--
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
}
-->
</style></head>

<body>
<?php
$PA_Mode = empty($_GET['PA_Mode'])?"":$_GET['PA_Mode'];
if (trim($PA_Mode) == "") $PA_Mode="I";

if (trim(strstr($_SESSION["reg_MPer"],'D')) == "") {
		if (trim($PA_Mode) == "I"){
				if (trim(strstr($_SESSION["reg_MPer"],'I')) == "") {
						mysqli_close($link);
						exit;
						}
				}
		if (trim($PA_Mode) == "O"){
				if (trim(strstr($_SESSION["reg_MPer"],'L')) == "") {
						mysqli_close($link);
						exit;
						}
				}
		}

if (trim($PA_Mode) == "I") $PQTypeMode="A";
else if (trim($PA_Mode) == "O") $PQTypeMode="B";
$PID = $_GET['PID'];
if (trim(strstr($_SESSION["reg_MPer"],'D')) != "")
		$SQL_ProjectQuotationList="select PQID,PQFile,PQName,PQType,AddUser,AddDate,ProcUser,ProcDate from ProjectQuotationList where Deltag='N' and PID = '".$PID."' order by PQID desc;";
else 
		$SQL_ProjectQuotationList="select PQID,PQFile,PQName,PQType,AddUser,AddDate,ProcUser,ProcDate from ProjectQuotationList where Deltag='N' and PQType='".$PQTypeMode."' and PID = '".$PID."' order by PQID desc;";
$result_ProjectQuotationList=mysqli_query($link,$SQL_ProjectQuotationList) or die ("無法執行查詢");
?>
<table width="100%" border="0" cellpadding="0" cellspacing="0">
	<tr height="30">
		<td width="10"></td>
		<td width="200" class="c2">報價記錄列表</td>
		<td align="right"><input type="button" name="add" value="新 增" class="input_bot" onclick="javascript:location.href='ProjectQuotationAdd.php?PID=<?php echo $PID;?>';"></td>
		<td width="20"></td>
	</tr>
</table>
<table width="100%" border="0" cellpadding="5" cellspacing="2" class="s2">
  <tr>
    <td width="200" align="center" background="../images/table_bg.gif" class="t21">日 期</td>
    <td width="230" align="center" background="../images/table_bg.gif" class="t21">名稱</td>
    <td width="80" align="center" background="../images/table_bg.gif" class="t21">種類</td>
    <td width="120" align="center" background="../images/table_bg.gif" class="t21">報價單</td>
    <td width="50" align="center" background="../images/table_bg.gif" class="t21">修 改</td>
    <td width="50" align="center" background="../images/table_bg.gif" class="t21">刪 除</td>
  </tr>
  <?php
  $tmp = 1;
  while(list($PQID,$PQFile,$PQName,$PQType,$AddUser,$AddDate,$ProcUser,$ProcDate)=mysqli_fetch_row($result_ProjectQuotationList)){
	?>
	<tr<?php if ($tmp%2 == 0) echo " bgcolor=\"#F6F6F6\"";?>>
    <td class="h3" align="center"><?php if (trim($ProcDate) == "" || trim($ProcDate) == "0000-00-00") echo $AddDate; else echo $ProcDate;?></td>
    <td class="h3" align="center"><?php echo $PQName;?></td>
    <td class="h3" align="center">
    	<?php
    	if (trim($PQType)=="A") echo "收入簽回";
    	else if (trim($PQType)=="B") echo "支出簽出";
    	?>
    </td>
    <td class="h3" align="center"><a href="getfile.php?FolderName=Admin\\PQFile&FileName=<?php echo $PQFile;?>">下載</a></td>
    <td align="center"><input type="button" name="edit" value="修 改" class="input_bot" onclick="javascript:location.href='ProjectQuotationEdit.php?PID=<?php echo $PID;?>&PQID=<?php echo $PQID;?>';"></td>
    <td align="center"><input type="button" name="edit" value="刪 除" class="input_bot" onclick="javascript:if (confirm('您是否確定要刪除？')) location.href='ProjectQuotationDelDB.php?PID=<?php echo $PID;?>&PQID=<?php echo $PQID;?>';"></td>
  </tr>
  <?php
			$tmp++;
			}
	mysqli_free_result($result_ProjectQuotationList);
  ?>
</table>
</body>
</html>
<?php
mysqli_close($link);
?>