﻿<?php
include "CheckPermission.php";
include "../global.php";
include "include/page_function.php";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $PageAdminTitle;?></title>
<link href="../type.css" rel="stylesheet" type="text/css" />
<link href="../script/DatePicker.css" rel="stylesheet" type="text/css" />
<Script LANGUAGE="Javascript" SRC="../script/DatePicker.js"></Script>
<style type="text/css">
<!--
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
}
-->
</style>
<Script type="text/javascript" language="javascript" src="../script/CheckForm.js"></Script>
<script type="text/JavaScript">
<!--
function jsCheck() 
		{
		if (jsTrim(document.form1.QPCSYear.value) != "" || jsTrim(document.form1.QPCSMonth.value) != "" || jsTrim(document.form1.QPCSDay.value) != "") if (ChkDate('QPCSYear',document.form1.QPCSYear.value,document.form1.QPCSMonth.value,document.form1.QPCSDay.value,'証書有效起始日期') == false) return false;
		if (jsTrim(document.form1.QPCEYear.value) != "" || jsTrim(document.form1.QPCEMonth.value) != "" || jsTrim(document.form1.QPCEDay.value) != "") if (ChkDate('QPCEYear',document.form1.QPCEYear.value,document.form1.QPCEMonth.value,document.form1.QPCEDay.value,'証書有效結束日期') == false) return false;
		if (jsTrim(document.form1.QPCSYear.value) != "" && jsTrim(document.form1.QPCSMonth.value) != "" && jsTrim(document.form1.QPCSDay.value) != "" && jsTrim(document.form1.QPCEYear.value) != "" && jsTrim(document.form1.QPCEMonth.value) != "" && jsTrim(document.form1.QPCEDay.value) != "") if (CompareDate('QPCSYear',document.form1.QPCSYear.value,document.form1.QPCSMonth.value,document.form1.QPCSDay.value,document.form1.QPCEYear.value,document.form1.QPCEMonth.value,document.form1.QPCEDay.value,'查詢啟始日期','查詢結束日期') == false) return false;
		}
function ProjectCertificateExport() 
		{
		document.form_exp.QPCSYear.value = document.form1.QPCSYear.value;
		document.form_exp.QPCSMonth.value = document.form1.QPCSMonth.value;
		document.form_exp.QPCSDay.value = document.form1.QPCSDay.value;
		document.form_exp.QPCEYear.value = document.form1.QPCEYear.value;
		document.form_exp.QPCEMonth.value = document.form1.QPCEMonth.value;
		document.form_exp.QPCEDay.value = document.form1.QPCEDay.value;
		document.form_exp.QPCType.value = document.form1.QPCType.value;
		document.form_exp.QPCStatus.value = document.form1.QPCStatus.value;
		document.form_exp.KeyWord.value = document.form1.KeyWord.value;
		document.form_exp.submit();
		}
//-->
</script>
</head>
<body>
<?php include "top.php";?>
<table width="100%" border="0" cellspacing="0" cellpadding="5">
	<tr>
    <td width="160" height="600" align="left" valign="top">
			<?php include "menu.php";?>
		</td>
    <td valign="top">
    	<table width="100%" border="0" cellpadding="0" cellspacing="0">
    		<tr>
    			<td>
			    	<table width="750" border="0" cellpadding="0" cellspacing="0">
			    		<tr height="30">
			    			<td class="c2">證書管理</td>
			    		</tr>
			    	</table>
			    	<table width="750" border="0" cellpadding="0" cellspacing="0">
			    		<form name="form1" action="ProjectCertificateList.php" method="post" onSubmit="return jsCheck();">
			    		<tr>
			    			<td align="left" class="h3">證書有效期限：
			            <input name="QPCSYear" type="text" size="4" value="<?php echo empty($_POST['QPCSYear'])?"":$_POST['QPCSYear'] ;?>" />年
			            <input name="QPCSMonth" type="text" size="2" value="<?php echo empty($_POST['QPCSMonth'])?"":$_POST['QPCSMonth'];?>" />月
			            <input name="QPCSDay" type="text" size="2" value="<?php echo empty($_POST['QPCSDay'])?"":$_POST['QPCSDay'];?>" />日
			            <img src="../images/icon.gif" width="16" height="18" style="cursor: hand" onclick="javascript:displayDatePicker('QPCSYear','QPCSMonth','QPCSDay');"/>～
			            <input name="QPCEYear" type="text" size="4" value="<?php echo empty($_POST['QPCEYear'])?"":$_POST['QPCEYear'];?>" />年
			            <input name="QPCEMonth" type="text" size="2" value="<?php echo empty($_POST['QPCEMonth'])?"":$_POST['QPCEMonth'];?>" />月
			            <input name="QPCEDay" type="text" size="2" value="<?php echo empty($_POST['QPCEDay'])?"":$_POST['QPCEDay'];?>" />日
			            <img src="../images/icon.gif" width="16" height="18" style="cursor: hand" onclick="javascript:displayDatePicker('QPCEYear','QPCEMonth','QPCEDay');"/> 
			            <input type="checkbox" name="PCEnd" value="1"<?php if (trim(empty($_POST['PCEnd'])?"":$_POST['PCEnd']) == "1") echo " checked";?>> 無到期日
			    			</td>
			    		</tr>
			    		<tr>
			    			<td width="200" align="left" class="h3">
			    				證書種類：
			          	<select name="QPCType">
			          		<option value="">不限</option>
			          		<option value="A"<?php if (trim(empty($_POST['QPCType'])?"":$_POST['QPCType']) == "A") echo " selected";?>>環保標章</option>
			          		<option value="B"<?php if (trim(empty($_POST['QPCType'])?"":$_POST['QPCType']) == "B") echo " selected";?>>BSMI證書</option>
			          		<option value="C"<?php if (trim(empty($_POST['QPCType'])?"":$_POST['QPCType']) == "C") echo " selected";?>>消防證書</option>
			          		<option value="E"<?php if (trim(empty($_POST['QPCType'])?"":$_POST['QPCType']) == "E") echo " selected";?>>NCC</option>
							<option value="F"<?php if (trim(empty($_POST['QPCType'])?"":$_POST['QPCType']) == "F") echo " selected";?>>BSMI DOC</option>
							<option value="D"<?php if (trim(empty($_POST['QPCType'])?"":$_POST['QPCType']) == "D") echo " selected";?>>其他</option>
			          	</select> 
			    				狀態：
			          	<select name="QPCStatus">
			          		<option value="">不限</option>
			          		<option value="A"<?php if (trim(empty($_POST['QPCStatus'])?"":$_POST['QPCStatus']) == "A") echo " selected";?>>到期未取消</option>
			          		<option value="B"<?php if (trim(empty($_POST['QPCStatus'])?"":$_POST['QPCStatus']) == "B") echo " selected";?>>到期已取消</option>
			          		<option value="C"<?php if (trim(empty($_POST['QPCStatus'])?"":$_POST['QPCStatus']) == "C") echo " selected";?>>已回覆結果</option>
			          		<option value="D"<?php if (trim(empty($_POST['QPCStatus'])?"":$_POST['QPCStatus']) == "D") echo " selected";?>>到期未通知</option>
			          		<option value="E"<?php if (trim(empty($_POST['QPCStatus'])?"":$_POST['QPCStatus']) == "E") echo " selected";?>>到期已通知</option>
			          		<option value="F"<?php if (trim(empty($_POST['QPCStatus'])?"":$_POST['QPCStatus']) == "F") echo " selected";?>>已通知</option>
			          	</select> 
			    				關鍵字：<input type="text" name="KeyWord" size="15" value="<?php echo empty($_POST['KeyWord'])?"":$_POST['KeyWord'];?>"> 
			    				<input type="submit" class="input_bot" name="search" value="查詢"> <input type="button" name="button" class="input_bot" value="全部列出" onclick="javascript:location.href='ProjectCertificateList.php';"> 
			    				<input type="button" name="report" class="input_bot" value="資料匯出" onclick="javascript:ProjectCertificateExport();">
			    			</td>
			    		</tr>
			    		</form>
			    	</table>
			    	<?php
					$SqlTxt="";
			    	$QPCSDate = empty($_POST['QPCSDate'])?"":$_POST['QPCSDate'];
			    	if (trim($QPCSDate) == "") $QPCSDate = empty($_GET['QPCSDate'])?"":$_GET['QPCSDate'];
			    	$QPCEDate = empty($_POST['QPCEDate'])?"":$_POST['QPCEDate'];
			    	if (trim($QPCEDate) == "") $QPCEDate = empty($_GET['QPCEDate'])?"":$_GET['QPCEDate'];
						if (trim($QPCSDate) == "") {
								$QPCSYear = empty($_POST['QPCSYear'])?"":$_POST['QPCSYear'];
								$QPCSMonth = empty($_POST['QPCSMonth'])?"":$_POST['QPCSMonth'];
								$QPCSDay = empty($_POST['QPCSDay'])?"":$_POST['QPCSDay'];
								if (trim($QPCSYear) != "" || trim($QPCSMonth) != "" || trim($QPCSDay) != "") if (checkdate($QPCSMonth,$QPCSDay ,$QPCSYear)) $QPCSDate = $QPCSYear."-".$QPCSMonth."-".$QPCSDay;
								}
						if (trim($QPCEDate) == "") {
								$QPCEYear = empty($_POST['QPCEYear'])?"":$_POST['QPCEYear'];
								$QPCEMonth = empty($_POST['QPCEMonth'])?"":$_POST['QPCEMonth'];
								$QPCEDay = empty($_POST['QPCEDay'])?"":$_POST['QPCEDay'];
								if (trim($QPCEYear) != "" || trim($QPCEMonth) != "" || trim($QPCEDay) != "") if (checkdate($QPCEMonth,$QPCEDay ,$QPCEYear)) $QPCEDate = $QPCEYear."-".$QPCEMonth."-".$QPCEDay;
								}
			    	$QPCType = empty($_POST['QPCType'])?"":$_POST['QPCType'];
			    	if (trim($QPCType) == "") $QPCType = empty($_GET['QPCType'])?"":$_GET['QPCType'];
			    	$QPCStatus = empty($_POST['QPCStatus'])?"":$_POST['QPCStatus'];
			    	if (trim($QPCStatus) == "") $QPCStatus = empty($_GET['QPCStatus'])?"":$_GET['QPCStatus'];
			    	$KeyWord = empty($_POST['KeyWord'])?"":$_POST['KeyWord'];
			    	if (trim($KeyWord) == "") $KeyWord = empty($_GET['KeyWord'])?"":$_GET['KeyWord'];
			    	$PCEnd = empty($_POST['PCEnd'])?"":$_POST['PCEnd'];
			    	if (trim($PCEnd) == "") $PCEnd = empty($_GET['PCEnd'])?"":$_GET['PCEnd'];
			    	if (trim($PCEnd) == "1") {
			    			$QPCSDate="";
			    			$QPCEDate="";
			    			$SqlTxt = $SqlTxt." and b.PCEDate='0000-00-00' ";
			    			}
						if (trim($QPCSDate) != "" && trim($QPCEDate) != "") $SqlTxt = $SqlTxt." and (b.PCEDate >= '".$QPCSDate."') and (b.PCEDate <= '".$QPCEDate."') ";
						else if (trim($QPCSDate) != "" && trim($QPCEDate) == "") $SqlTxt = $SqlTxt." and (b.PCEDate >= '".$QPCSDate."') ";
						else if (trim($QPCSDate) == "" && trim($QPCEDate) != "") $SqlTxt = $SqlTxt." and (b.PCEDate <= '".$QPCEDate."') ";
						if (trim($QPCType) != "") $SqlTxt = $SqlTxt." and b.PCType='".$QPCType."' ";
						if (trim($QPCStatus) == "A") $SqlTxt = $SqlTxt." and PCEDate >= now( ) AND ISRemind = 'N'";
						else if (trim($QPCStatus) == "B") $SqlTxt = $SqlTxt." and PCEDate >= now( ) AND ISRemind = 'Y'";
						else if (trim($QPCStatus) == "C") $SqlTxt = $SqlTxt." AND ISRemind = 'Y'";
						else if (trim($QPCStatus) == "D") $SqlTxt = $SqlTxt." and PCEDate >= now( ) AND ISNotice = 'N'";
						else if (trim($QPCStatus) == "E") $SqlTxt = $SqlTxt." and PCEDate >= now( ) AND ISNotice = 'Y'";
						else if (trim($QPCStatus) == "F") $SqlTxt = $SqlTxt." AND ISNotice = 'Y'";

						if (trim($KeyWord) != "") $SqlTxt = $SqlTxt." and (b.PCNo like '%".$KeyWord."%' or b.PCName like '%".$KeyWord."%' or a.CName like '%".$KeyWord."%' or b.RemindNote like '%".$KeyWord."%' or b.PCNote like '%".$KeyWord."%')";
						$page = empty($_GET['page'])?"":$_GET['page'];
						if (trim($page) == "") $page = 1;
						$page_rows=15;  //每頁筆數
						$php_Self = "ProjectCertificateList.php";  //分頁web檔名
						$button_css = "h4";
						$limit_txt =" limit ".(($page-1) * $page_rows).",".$page_rows;
						$url_str = "&QPCSDate=".$QPCSDate."&QPCEDate=".$QPCEDate."&PCEnd=".$PCEnd."&QPCType=".$QPCType."&QPCStatus=".$QPCStatus."&KeyWord=".urlencode($KeyWord);
						$Sql_str="select b.PCID from Project a,ProjectCertificate b where a.PID=b.PID and a.Deltag='N' and b.Deltag='N' ".$SqlTxt." order by b.PCID desc;";
						$SQL_ProjectCertificate="select b.PCID,a.PID,b.PCNo,b.PCName,b.PCType,b.PCTypeName,b.PCFile,b.PCSDate,b.PCEDate,b.PCNote,a.PName,a.PE,a.CName,a.PName,a.ModelName,a.SeriesModel,b.ExpireDate,b.ISRemind,b.RemindNote,b.Reminder,b.RemindDate,b.RemindIP,b.ISNotice,b.NoticeNote,b.Notifier,b.NoticeDate,b.NoticeIP from Project a,ProjectCertificate b where a.PID=b.PID and a.Deltag='N' and b.Deltag='N' and b.PCEDate <='".date('Y-m-d')."'".$SqlTxt." order by b.PCID desc ".$limit_txt.";";
						//echo $SQL_ProjectCertificate;
						$result_ProjectCertificate=mysqli_query($link,$SQL_ProjectCertificate) or die ("無法執行查詢");
			    	?>
			    	<table width="750" border="0" cellpadding="5" cellspacing="2" class="s2">
			        <tr align="center">
			          <td width="150" align="center" background="../images/table_bg.gif" class="t21">編號<br>種類<br>名稱</td>
			          <td width="150" background="../images/table_bg.gif" class="t21">客戶名稱<br>型號</td>
			          <td width="150" background="../images/table_bg.gif" class="t21">相關案件<br>案件工程師</td>
			          <td width="100" background="../images/table_bg.gif" class="t21">有效日期</td>
			          <td width="100" background="../images/table_bg.gif" class="t21">備註</td>
			          <td width="100" background="../images/table_bg.gif" class="t21">詳細<br>取消提醒<br>通知客戶</td>
			        </tr>
		          <?php
		          $tmp = 1;
		          while(list($PCID,$PID,$PCNo,$PCName,$PCType,$PCTypeName,$PCFile,$PCSDate,$PCEDate,$PCNote,$PName,$PE,$CName,$PName,$ModelName,$SeriesModel,$ExpireDate,$ISRemind,$RemindNote,$Reminder,$RemindDate,$RemindIP,$ISNotice,$NoticeNote,$Notifier,$NoticeDate,$NoticeIP)=mysqli_fetch_row($result_ProjectCertificate)){
								$SQL_Manager="SELECT MName,MEName FROM Manager Where Deltag='N' and MUID='".$PE."'";
								$result_Manager=mysqli_query($link,$SQL_Manager) or die ("無法執行查詢");
								list($MName,$MEName)=mysqli_fetch_row($result_Manager);
								mysqli_free_result($result_Manager);
		        	if (trim($ExpireDate)=="0000-00-00") $ExpireDate="";
		        	?>
		        	<tr<?php if ($tmp%2 == 0) echo " bgcolor=\"#F6F6F6\"";?>>
			          <td width="150" class="h3" align="center">
									<?php
									echo $PCNo."<br>";
			          	if (trim($PCType) == "A") echo "環保標章";
			          	else if (trim($PCType) == "B") echo "BSMI證書";
			          	else if (trim($PCType) == "C") echo "消防證書";
			          	else if (trim($PCType) == "D") echo $PCTypeName;
									?><br>
			          	<a href="getfile.php?FolderName=Admin\\PCFile&FileName=<?php echo $PCFile;?>"><?php echo $PCName;?></a>
			          </td>
			          <td width="150" class="h3">
			          	<?php
			          	echo $CName."<br>".$ModelName;
			          	?>
			          </td>
			          <td width="150" class="h3"><?php echo $PName;?><br><?php echo $MEName.$MName;?></td>
			          <?php if (trim($PCEDate) == "0000-00-00") echo $PCEDate="";?>
			          <td width="100" class="h3" align="center"><?php echo $PCSDate;?><br> ~ <br><?php echo $PCEDate;?></td>
			          <td width="100" class="h3"><?php echo $PCNote;?></td>
						    <td width="100" align="center">
						    	<input type="button" name="edit" value="詳細" class="input_bot" onclick="javascript:location.href='ProjectDetail.php?PID=<?php echo $PID;?>';"><br>
						    	<?php if (trim($ISRemind) == "N"){?>
						    		<input type="button" name="Remind" value="取消" class="input_bot" onclick="javascript:window.open ('ProjectCertificateRemind.php?PID=<?php echo $PID;?>&PCID=<?php echo $PCID;?>','SelCustomer','height=340,width=700,top=200,left=200,scrollbars=yes,status=yes');">
						    	<?php } else {
						    			if (trim($RemindNote) != "") echo "<font color=blue>".$RemindNote."</font><br>";
						    			echo $Reminder."<br>".$RemindDate;
						    			}	
									echo "<br>";
									if (trim($ISNotice) == "N"){?>
						    		<input type="button" name="Notice" value="通知" class="input_bot" onclick="javascript:window.open ('ProjectCertificateNotice.php?PID=<?php echo $PID;?>&PCID=<?php echo $PCID;?>','SelCustomer','height=340,width=700,top=200,left=200,scrollbars=yes,status=yes');">
						    	<?php } else {
						    			if (trim($NoticeNote) != "") echo "<font color=blue>".$NoticeNote."</font><br>";
						    			echo $Notifier."<br>".$NoticeDate;
						    			}	
						    	?>
						    </td>
			        </tr>
			        <?php
            			$tmp++;
			      			}
            	mysqli_free_result($result_ProjectCertificate);
			        ?>
			    	</table>
			      <table width="750" border="0" cellpadding="5" cellspacing="2" class="s2">
			        <tr align="center">
			          <td bgcolor="#E8F0C2" class="h4"><?php Page_show($Sql_str,$page_rows,$php_Self,$link,$page,$url_str,$button_css);?></td>
			        </tr>
			      </table>
    			</td>
    		</tr>
    	</table>
    </td>
	</tr>
</table>
<form name="form_exp" action="ProjectCertificateExport.php" method="post" target="_ProjectCertificateExport">
	<input type="hidden" name="QPCSYear">
	<input type="hidden" name="QPCSMonth">
	<input type="hidden" name="QPCSDay">
	<input type="hidden" name="QPCEYear">
	<input type="hidden" name="QPCEMonth">
	<input type="hidden" name="QPCEDay">
	<input type="hidden" name="QPCType">
	<input type="hidden" name="QPCStatus">
	<input type="hidden" name="KeyWord">
</form>
<?php include "down.php";?>
</body>
</html>
<?php
mysqli_close($link);
?>