﻿<?php
include "CheckPermission.php";
include "CheckProject.php";
include "../global.php";
require_once("../include/chinese_party.class.php");
require("class.phpmailer.php");
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $PageAdminTitle;?></title>
</head>
<body>
<table width="100%" border="0" cellspacing="0" cellpadding="5">
	<tr>
    <td width="160" height="600" align="left" valign="top">
    </td>
    <td valign="top">
    	<table width="100%" border="0" cellpadding="0" cellspacing="0">
    		<tr>
    			<td>
			    	<table width="750" border="0" cellpadding="0" cellspacing="0">
			    		<tr height="30">
			    			<td class="c2">新增</td>
			    		</tr>
			    	</table>
			    	<table width="750" border="0" cellpadding="0" cellspacing="0">
			        <form name="form1" method="post" action="ProjectCopyAllDB.php">
			        <tr height="40" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td width="120" align="right" class="c3">課程主要名稱:</td>
					  	<td class="h3">
						<select name="TCID">
						<?php
							$SQL="select TCID,TCTTitle from TrainingCamp where Deltag='N' order by TCID;";
							$result=mysqli_query($link,$SQL) or die ("無法執行查詢");
			          		while(list($TCID,$TCTTitle)=mysqli_fetch_row($result)){
						?>
							<option value="<?php echo $TCID;?>"><?php echo $TCTTitle;?></option>
					   <?php
							}
					   ?>
					   </select>
					   </td>
			        </tr>
			        <tr height="40" align="center">
			          <td colspan="2" class="h3"><input type="submit" name="submit" class="input_bot" value="送 出"></td>
			        </tr>
				      </form>
			      </table>
    			</td>
    		</tr>
    	</table>
    </td>
	</tr>
</table>

</body>
</html>
