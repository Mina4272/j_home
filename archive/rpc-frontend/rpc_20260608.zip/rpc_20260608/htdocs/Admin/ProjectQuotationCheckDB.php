﻿<?php	
include "CheckPermission.php";
include "CheckProjectAccounting.php";
include "../global.php";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $PageAdminTitle;?></title>
<link href="../type.css" rel="stylesheet" type="text/css" />
<style type="text/css">
<!--
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
}
-->
</style>
</head>
<body>
<?php
$PID = $_POST['PID'];
$QuoteYear = $_POST['QuoteYear'];
$QuoteMonth = $_POST['QuoteMonth'];
$QuoteDay = $_POST['QuoteDay'];
$Florin = $_POST['Florin'];
if (trim($QuoteYear) != "" || trim($QuoteMonth) != "" || trim($QuoteDay) != "") if (checkdate($QuoteMonth,$QuoteDay ,$QuoteYear)) $QuoteDate = $QuoteYear."-".$QuoteMonth."-".$QuoteDay;
$InvoiceCUID = $_POST['InvoiceCUID'];
$InvoiceTitle = $_POST['InvoiceTitle'];
$InvoiceAddress = $_POST['InvoiceAddress'];
$Leadtime = $_POST['Leadtime'];
//$Trademark = $_POST['Trademark'];
$PTax = $_POST['PTax'];
$CheckQuotation = $_POST['CheckQuotation'];
$CheckQuotation2 = $_POST['CheckQuotation2'];
$Company = $_POST['Company'];
$QVersion = $_POST['QVersion'];
$BMUID = $_POST['BMUID'];

if (trim($PID) == "" || trim($QuoteDate) == "")
		{
		mysqli_close($link);
		?>
		<script type="text/JavaScript">
			<!--
			alert ("您輸入的資料不足，請重新輸入！");
			history.go(-1);
			//-->
		</script>
		<?php
		exit;
		}
$now_time = date("Y-m-d H:i:s",mktime());
if (trim($CheckQuotation) == "Y") $SqlTxt = ",PStatus='B',QuoteDate = '".$QuoteDate."',QRecord = '".$_SESSION["reg_MUID"]."',QRecordDate = '".$now_time."',QRecordIP = '".$_SERVER["REMOTE_ADDR"]."'";
if (trim($CheckQuotation2) == "Y") $SqlTxt = $SqlTxt.",PStatus='C'";
$sql_update = "update Project set InvoiceCUID = '".$InvoiceCUID."',InvoiceTitle = '".$InvoiceTitle."',InvoiceAddress = '".$InvoiceAddress."',Leadtime = '".$Leadtime."',PTax = '".$PTax."',BMUID = '".$BMUID."'".$SqlTxt.",ProcUser = '".$_SESSION["reg_MUID"]."',ProcDate = '".$now_time."',ProcIP = '".$_SERVER["REMOTE_ADDR"]."' where Deltag='N' and PID = '".$PID."';";
$result_update=mysqli_query($link,$sql_update) or die ("無法執行修改");

if (trim($CheckQuotation) == "Y") {
		$sql_insert = "INSERT INTO ProjectAccountingAddHistory(PAAID,PID,PAADate,PAAReason,PAACheck,AddUser,AddDate,AddIP,ProcUser,ProcDate,ProcIP,UpdateUser,UpdateDate,UpdateIP) SELECT PAAID,PID,PAADate,PAAReason,PAACheck,AddUser,AddDate,AddIP,ProcUser,ProcDate,ProcIP,'".$_SESSION["reg_MUID"]."','".$now_time."','".$_SERVER["REMOTE_ADDR"]."' FROM ProjectAccountingAdd where PID = ".$PID.";";
		$result_insert=mysqli_query($link,$sql_insert) or die ("無法執行新增");
		$sql_update = "update ProjectAccountingAdd set PAACheck = 'Y',ProcUser = '".$_SESSION["reg_MUID"]."',ProcDate = '".$now_time."',ProcIP = '".$_SERVER["REMOTE_ADDR"]."' where PID = ".$PID.";";
		$result_update=mysqli_query($link,$sql_update) or die ("無法執行修改");
		}
mysqli_close($link);
?>
<script type="text/JavaScript">
	<!--
	location.href='ProjectQuotation<?php if (trim($QVersion) == "Eng") echo "Eng";?>.php?PID=<?php echo $PID;?>&Florin=<?php echo $Florin;?>&CheckQuotation=<?php echo $CheckQuotation;?>&Company=<?php echo $Company;?>';
	//-->
</script>
</body>
</html>
