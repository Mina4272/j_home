﻿<?php
include "CheckPermission.php";
include "../global.php";
require_once("../include/chinese_party.class.php");
require("class.phpmailer.php");
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $PageAdminTitle;?></title>
</head>
<body>
<?php
$MFType = $_POST['MFType'];
$MFYear = $_POST['MFYear'];
$MFMonth = $_POST['MFMonth'];
$MFDay = $_POST['MFDay'];
if (trim($MFYear) != "" || trim($MFMonth) != "" || trim($MFDay) != "") if (checkdate($MFMonth,$MFDay ,$MFYear)) $MFDate = $MFYear."-".$MFMonth."-".$MFDay;
$MFCause = $_POST['MFCause'];
$MFComment = $_POST['MFComment'];
$Quantity = $_POST['Quantity'];
$MFNote = $_POST['MFNote'];
$MFSend = $_POST['MFSend'];

if (trim($MFType) == "" || trim($MFDate) == "" || trim($MFCause) == "" || trim($MFComment) == "" || trim($Quantity) == "" || trim($MFSend) == "")
		{
		mysqli_close($link);
		?>
		<script type="text/JavaScript">
			<!--
			alert ("您輸入的資料不足，請重新輸入！");
			history.go(-1);
			//-->
		</script>
		<?php
		exit;
		}
$sql="SELECT * FROM ManagerFees WHERE MUID = '".$_SESSION["reg_MUID"]."' and MFType='".$MFType."' and MFDate='".$MFDate."' and MFCheck in ('W','Y') and Deltag = 'N'";
$result=mysqli_query($link,$sql) or die ("無法執行查詢");
if (mysqli_num_rows($result) > 0)
		{
		mysqli_free_result($result);
		mysqli_close($link);
		?>
		<SCRIPT language=javascript>
		<!--
		alert ("您申請的日期：<?php echo $MFDate?> 已申請過了，一天只能申請一次，請勿重覆申請！"); 
		history.go(-1);
		//-->
		</SCRIPT>
		<?php 	
		exit;
		}
mysqli_free_result($result);

$now_time = date("Y-m-d H:i:s",mktime());
$sql_insert = "insert into ManagerFees (MUID,MFType,MFDate,MFCause,MFComment,Quantity,MFNote,MFSend,AddUser,AddDate,AddIP) values ('".$_SESSION["reg_MUID"]."','".$MFType."','".$MFDate."','".$MFCause."','".$MFComment."','".$Quantity."','".$MFNote."','".$MFSend."','".$_SESSION["reg_MUID"]."','".$now_time."','".$_SERVER["REMOTE_ADDR"]."');";
$result_insert=mysqli_query($link,$sql_insert) or die ("無法執行新增");

if (trim($MFSend) == "Y") {
		if (trim($MFType) == "A") $MFType="加班費";
		else if (trim($MFType) == "B") $MFType="交通費-公里";
		else if (trim($MFType) == "C") $MFType="交通費-實報實銷";
		
		$EMAILFN = "MFees.htm";
		$subject="費用申請通知 ！！";
		$fp=fopen($EMAILFN,"r");
		$content="";
		while($line=fgets($fp,512)){
			$content.=$line;
			}
		fclose($fp);
		
		$content = str_replace("{MName}",$_SESSION["reg_MName"].$_SESSION["reg_MUID"],$content);
		$content = str_replace("{MFType}",$MFType,$content);
		$content = str_replace("{MFDate}",$MFDate,$content);
		$content = str_replace("{MFCause}",$MFCause,$content);
		$content = str_replace("{MFComment}",$MFComment,$content);
		$content = str_replace("{Quantity}",$Quantity,$content);
		$content = str_replace("{MFNote}",$MFNote,$content);
		
		//$cconv = new chinese_party();
		//$content = $cconv->u82tchi($content);
		//$subject = $cconv->u82tchi($subject);
    
		$SQL_Manager="SELECT EMail FROM Manager WHERE MPer LIKE '%K%' AND Deltag = 'N';";
		$result_Manager=mysqli_query($link,$SQL_Manager) or die ("無法執行查詢");
		$temp_mail="";
    while(list($EMail)=mysqli_fetch_row($result_Manager)){
			if(empty($temp_mail)==" "){
				$temp_mail .=$EMail;
			}else{
				$temp_mail .= ','.$EMail;
			}	
	}
		$mail = new PHPMailer();
		$mail->IsSMTP();
		$mail->SMTPAuth = true; //設定SMTP需要驗證
		$mail->SMTPSecure = "ssl"; // Gmail的SMTP主機需要使用SSL連線
		$mail->Host = "smtp.gmail.com"; //Gamil的SMTP主機
		$mail->Port = 465; //Gamil的SMTP主機的埠號(Gmail為465)。
		$mail->CharSet = "utf-8"; //郵件編碼
		$mail->Username = "Benson@rpclab.com"; //Gamil帳號
		$mail->Password = "76197619"; //Gmail密碼
		$mail->From     = "Benson@rpclab.com";
		$mail->FromName = $subject;
		$mail->WordWrap = 50;
		$mail->IsHTML(true);                               // send as HTML
		//$mail->CharSet = "big5";
		$mail->Subject  = $subject;
		$mail->Body     =  $content;
		$mail->AddAddress($temp_mail,"");
		$mail->AddReplyTo("Benson@rpclab.com");
		if(!$mail->Send())
		{
				    //echo "There has been a mail error sending to " . $SendEMail . "<br>";
				    //echo "Mailer Error: " . $mail->ErrorInfo . "<br>";
		}
		else
		{
						//echo $SendEMail . " sending !!<br>";
		}
						
		$mail->ClearAddresses();
		$mail->ClearReplyTos();
		$mail->SmtpClose();
		mysqli_free_result($result_Manager);
}
mysqli_close($link);
?>
<script type="text/JavaScript">
	
	alert ("新增成功！");
	location.href='MFeesList.php';
	
</script>
</body>
</html>
