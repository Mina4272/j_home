﻿<?php
include "CheckPermission.php";
include "CheckProjectAccounting.php";
include "../global.php";
include "include/page_function.php";
$xmlFile = 'C:\xampp\htdocs\Admin';
$copyFile= 'C:\EINVTurnkey\UpCast\B2SSTORAGE\F0501\SRC'; 
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>全威驗證科技內部系統</title>
<style type="text/css">
<!--
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
}
.Q1 {
	font-family: "標楷體", Arial, sans-serif;
	font-size: 18px;
	color: #000000;
	font-weight: bold;
	}
.Q2 {
	font-family: Arial, sans-serif;
	font-size: 18px;
	color: #000000;
	font-weight: bold;
	}
.Q3 {
	font-family: Arial, sans-serif;
	font-size: 18px;
	color: #000000;
	font-weight: bold;
	font-style:italic;
	}
.Q4 {
	font-family: "標楷體", Arial, sans-serif;
	font-size: 12px;
	color: #000000;
	font-weight: bold;
	}
.Q5 {
	font-family: "細明體", Arial, sans-serif;
	font-size: 12px;
	color: #000000;
	font-weight: bold;
	}
.Q6 {
	font-family: "標楷體", Arial, sans-serif;
	font-size: 12px;
	color: #000000;
	}
.Q7 {
	font-family: "標楷體", Arial, sans-serif;
	font-size: 12px;
	color: #000000;
	font-weight: bold;
	}
.Q8 {
	font-family: "標楷體", Arial, sans-serif;
	font-size: 11px;
	color: #000000;
	font-weight: bold;
	}
.Q9 {
	font-family: "標楷體", Arial, sans-serif;
	font-size: 10px;
	color: #000000;
	font-weight: bold;
	}
-->
</style></head>

<body>
<?php
$PID = $_GET['PID'];
//$Florin = $_GET['Florin'];
//if (trim($Florin) == "") $Florin = "T";
//$IAccount = $_GET['IAccount'];
//if (trim($IAccount) == "") $IAccount = "R";

if (trim($PID) == "")
		{
		mysqli_close($link);
		?>
		<script type="text/JavaScript">
			<!--
			alert ("查無資料，請冾網站管理人員！");
			history.go(-1);
			//-->
		</script>
		<?php
		exit;
		}
$SQL_Project="select PUID,PName,ApplyItem,CID,CName,CTel,CFax,Contact,CMobile,CEMail,CAddress,InvoiceDate,IFlorin,(select GUI from Customer where Deltag='N' and CID = Project.CID) as GUI,(select CUID from Customer where Deltag='N' and CID = Project.CID) as CUID,InvoiceCUID,InvoiceTitle,InvoiceAddress,Leadtime,Trademark,PTax,ModelName,(select TrademarkTxt from Customer where Deltag='N' and CID = Project.CID) as TrademarkTxt,INo,IDate from Project where Deltag='N' and PID = '".$PID."';";
$result_Project=mysqli_query($link,$SQL_Project) or die ("無法執行查詢");
if (mysqli_num_rows($result_Project) == 0)
		{
		mysqli_free_result($result_Project);
		mysqli_close($link);
		?>
		<SCRIPT language=javascript>
		<!--
		alert ("查無資料，請冾網站管理人員！"); 
		history.go(-1);
		//-->
		</SCRIPT>
		<?php 	
		exit;
		}
list($PUID,$PName,$ApplyItem,$CID,$CName,$CTel,$CFax,$Contact,$CMobile,$CEMail,$CAddress,$InvoiceDate,$IFlorin,$GUI,$CUID,$InvoiceCUID,$InvoiceTitle,$InvoiceAddress,$Leadtime,$Trademark,$PTax,$ModelName,$TrademarkTxt,$INo,$IDate)=mysqli_fetch_row($result_Project);
mysqli_free_result($result_Project);
if (trim($Trademark) != "") $TrademarkTxt = $Trademark;
if (trim($GUI) == "") $GUI=$CUID;

$CUID = (trim($InvoiceCUID) != "") ? $InvoiceCUID : $GUI;

$date = new DateTime($IDate);
$result = $date->format('Ymd');

$str = '<?xml version="1.0" encoding="UTF-8"?>
<CancelInvoice xsi:schemaLocation="urn:GEINV:eInvoiceMessage:F0501:4.0 F0501.xsd" xmlns="urn:GEINV:eInvoiceMessage:F0501:4.0" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
	<CancelInvoiceNumber>'.$INo.'</CancelInvoiceNumber>
	<InvoiceDate>'.$result.'</InvoiceDate>
	<BuyerId>'.$CUID.'</BuyerId>
	<SellerId>28083754</SellerId>
	<CancelDate>'.date("Ymd").'</CancelDate>
	<CancelTime>'.date("H:i:s").'</CancelTime>
	<CancelReason>無</CancelReason>
</CancelInvoice>	
';
						//echo $str;
$xml = new SimpleXMLElement($str); 
  
$File = 'F0501.xml';  
// Printing as XML  
$xml->saveXML($File);

if(!empty($INo)){
	if(file_exists($copyFile)){
		$File1 = 'F0501.xml';
		$File2 = 'F0501'.date('YmdHis').'.xml';
		//echo $xmlFile;
		rename($xmlFile.'\\'.$File1,$xmlFile.'\\'.$File2);
		if (copy($xmlFile.'\\'.$File2,$copyFile.'\\'.$File2)) {
			echo "成功";
		} else {
			echo "失敗";
		}
	}else{
		$File = 'F0501.xml'; 
		if (copy($xmlFile.'\\'.$File,$copyFile.'\\'.$File)) {
			echo "成功";
		} else {
			echo "失敗";
		}
	}
}

mysqli_close($link);
?>