﻿<?php
include "CheckPermission.php";
include "CheckProjectAccounting.php";
include "../global.php";
include "include/function.php";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>全威驗證科技內部系統</title>
<style type="text/css">
<!--
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
}
.Q1 {
	font-family: "標楷體", Arial, sans-serif;
	font-size: 18px;
	color: #000000;
	font-weight: bold;
	}
.Q2 {
	font-family: Arial, sans-serif;
	font-size: 18px;
	color: #000000;
	font-weight: bold;
	}
.Q3 {
	font-family: Arial, sans-serif;
	font-size: 18px;
	color: #000000;
	font-weight: bold;
	font-style:italic;
	}
.Q4 {
	font-family: "標楷體", Arial, sans-serif;
	font-size: 12px;
	color: #000000;
	font-weight: bold;
	}
.Q5 {
	font-family: "細明體", Arial, sans-serif;
	font-size: 12px;
	color: #000000;
	font-weight: bold;
	}
.Q6 {
	font-family: "標楷體", Arial, sans-serif;
	font-size: 12px;
	color: #000000;
	}
.Q7 {
	font-family: "標楷體", Arial, sans-serif;
	font-size: 12px;
	color: #000000;
	font-weight: bold;
	}
.Q8 {
	font-family: Arial, sans-serif;
	font-size: 11px;
	color: #000000;
	font-weight: bold;
	}
.Q9 {
	font-family: "標楷體", Arial, sans-serif;
	font-size: 10px;
	color: #000000;
	font-weight: bold;
	}
.Q10 {
	font-family: Arial, sans-serif;
	font-size: 11px;
	color: #000000;
	}
-->
</style></head>

<body>
<?php
$PID = $_GET['PID'];
$Florin = $_GET['Florin'];
$CheckQuotation = $_GET['CheckQuotation'];
$Company = $_GET['Company'];
if (trim($Florin) == "") $Florin = "T";
if (trim($PID) == "")
		{
		mysqli_close($link);
		?>
		<script type="text/JavaScript">
			<!--
			alert ("查無資料，請冾網站管理人員！");
			history.go(-1);
			//-->
		</script>
		<?php
		exit;
		}
$SQL_Project="select PUID,PName,ApplyItem,CID,CName,CTel,CFax,Contact,CMobile,CEMail,CAddress,QuoteDate,IFlorin,(select CUID from Customer where Deltag='N' and CID = Project.CID) as CUID,InvoiceCUID,InvoiceTitle,InvoiceAddress,Leadtime,Trademark,PTax,ModelName,SeriesModel,(select TrademarkTxt from Customer where Deltag='N' and CID = Project.CID) as TrademarkTxt,(select MName from Manager where Deltag='N' and MUID=Project.BMUID) MName,(select MEName from Manager where Deltag='N' and MUID=Project.BMUID) MEName,(select Mobile from Manager where Deltag='N' and MUID=Project.BMUID) Mobile from Project where Deltag='N' and PID = '".$PID."';";
$result_Project=mysqli_query($link,$SQL_Project) or die ("無法執行查詢");
if (mysqli_num_rows($result_Project) == 0)
		{
		mysqli_free_result($result_Project);
		mysqli_close($link);
		?>
		<SCRIPT language=javascript>
		<!--
		alert ("查無資料，請冾網站管理人員！"); 
		history.go(-1);
		//-->
		</SCRIPT>
		<?php 	
		exit;
		}
list($PUID,$PName,$ApplyItem,$CID,$CName,$CTel,$CFax,$Contact,$CMobile,$CEMail,$CAddress,$QuoteDate,$IFlorin,$CUID,$InvoiceCUID,$InvoiceTitle,$InvoiceAddress,$Leadtime,$Trademark,$PTax,$ModelName,$SeriesModel,$TrademarkTxt,$MName,$MEName,$Mobile)=mysqli_fetch_row($result_Project);
mysqli_free_result($result_Project);
if (trim($Trademark) != "") $TrademarkTxt = $Trademark;
if (trim($MName) == "" && trim($Mobile) == "" && trim($MEName) == "") {
		$MName="王郁齡";
		$MEName="Vivi Wang";
		$Mobile="0933-335-410";
		}
?>
<?php
//============================================================+
// File name   : example_006.php
// Begin       : 2008-03-04
// Last Update : 2013-05-14
//
// Description : Example 006 for TCPDF class
//               WriteHTML and RTL support
//
// Author: Nicola Asuni
//
// (c) Copyright:
//               Nicola Asuni
//               Tecnick.com LTD
//               www.tecnick.com
//               info@tecnick.com
//============================================================+

/**
 * Creates an example PDF TEST document using TCPDF
 * @package com.tecnick.tcpdf
 * @abstract TCPDF - Example: WriteHTML and RTL support
 * @author Nicola Asuni
 * @since 2008-03-04
 */

// Include the main TCPDF library (search for installation path).
require_once('TCPDF/tcpdf.php');
//$font = new TCPDF_FONTS();
//$fontname = $font->addTTFfont('TCPDF/fonts/kaiu.ttf');
// create new PDF document
$pdf = new TCPDF(PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);
// set document information
$pdf->SetCreator(PDF_CREATOR);
$pdf->SetAuthor('Nicola Asuni');
$pdf->SetTitle('TCPDF');
$pdf->SetSubject('TCPDF Tutorial');
$pdf->SetKeywords('TCPDF, PDF, example, test, guide');

// set default header data
//$pdf->SetHeaderData(PDF_HEADER_LOGO, PDF_HEADER_LOGO_WIDTH, PDF_HEADER_TITLE.' 006', PDF_HEADER_STRING);

// set header and footer fonts
$pdf->setPrintHeader(false); //不要頁首
$pdf->setPrintFooter(false); //不要頁尾
//$pdf->setHeaderFont(Array(PDF_FONT_NAME_MAIN, '', PDF_FONT_SIZE_MAIN));
//$pdf->setFooterFont(Array(PDF_FONT_NAME_DATA, '', PDF_FONT_SIZE_DATA));

// set default monospaced font
$pdf->SetDefaultMonospacedFont(PDF_FONT_MONOSPACED);

// set margins
//$pdf->SetMargins(PDF_MARGIN_LEFT, PDF_MARGIN_TOP, PDF_MARGIN_RIGHT);
//$pdf->SetHeaderMargin(PDF_MARGIN_HEADER);
//$pdf->SetFooterMargin(PDF_MARGIN_FOOTER);

// set auto page breaks
$pdf->SetAutoPageBreak(TRUE, PDF_MARGIN_BOTTOM);

// set image scale factor
$pdf->setImageScale(PDF_IMAGE_SCALE_RATIO);

// set some language-dependent strings (optional)
if (@file_exists(dirname(__FILE__).'/lang/eng.php')) {
    require_once(dirname(__FILE__).'/lang/eng.php');
    $pdf->setLanguageArray($l);
}

// ---------------------------------------------------------

// set font
$pdf->SetFont('msungstdlight', '',7.2, '', false);

// add a page
$pdf->AddPage();

// writeHTML($html, $ln=true, $fill=false, $reseth=false, $cell=false, $align='')
// writeHTMLCell($w, $h, $x, $y, $html='', $border=0, $ln=0, $fill=0, $reseth=true, $align='', $autopadding=true)

// create some HTML content

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
// Print a table

// create some HTML content

$i = 0;							
$SQL_ProjectAccounting="select PAID,PAMode,PAItem,Charges,Rate,ChargesOther,PATax,PAStatus,PADate,PANote from ProjectAccounting where Deltag='N' and PAMode='I' and PID = '".$PID."' and (PAStatus = 'W' or PAStatus = 'S') order by PAMode asc,PAID asc;";
$result_ProjectAccounting=mysqli_query($link,$SQL_ProjectAccounting) or die ("無法執行查詢");
$ShowLine = 17 - mysqli_num_rows($result_ProjectAccounting);
$SumPrice = 0;
$PATaxPrice = 0;
while(list($PAID,$PAMode,$PAItem,$Charges,$Rate,$ChargesOther,$PATax,$PAStatus,$PADate,$PANote)=mysqli_fetch_row($result_ProjectAccounting)){
	if (trim($Florin) == "O") $Charges = $ChargesOther;
	$SumPrice = $SumPrice + $Charges;
	if (trim($PATax) == "") {
	if (trim($PTax) == "Y") $PATax = "Y";
	else if (trim($PTax) == "N") $PATax = "N";
	}
	if (trim($PATax) == "Y") $PATaxPrice = $PATaxPrice + round($Charges*0.05);
	
	$P = 0;
	if (trim($PATax) == "Y") $P = number_format(round($Charges*0.05));
	else if (trim($PATax) == "N") $P = 0;
	
	$sum = 0;	
		
	if (trim($PATax) == "Y") $sum = number_format((round($Charges*0.05))+$Charges);
	else if (trim($PATax) == "N") $sum = number_format($Charges);
	
	$contents[$i]['ChargesOther'] = $ChargesOther;
	$contents[$i]['PAItem'] = $PAItem;
	$contents[$i]['Charges'] = $Charges;
	$contents[$i]['P'] = $P;
	$contents[$i]['sum'] = $sum;
	$contents[$i]['PANote'] = $PANote;
	$contents[$i]['PATax'] = $PATax;
	$i++;

}
mysqli_free_result($result_ProjectAccounting);

$tmps = array_chunk($contents,8);


$html = '';
$sHtml = '';
$sum = 0;
$s1 = 0;
for ($c = 0; $c < count($tmps); $c++) {
	$SumPrice = 0;
	$PATaxPrice = 0;
	//echo $subHtml;
	$subHtml = '';
	$PATax = '';
	for ($z = 0; $z < count($tmps[$c]); $z++) {
		
		if (trim($Florin) == "O") $Charges = $tmps[$c][$z]['ChargesOther'];
		$SumPrice = $SumPrice + $tmps[$c][$z]['Charges'];
		if (trim($tmps[$c][$z]['PATax']) != "") {
			if (trim($tmps[$c][$z]['PATax']) == "Y") $PATax = "Y";
			else if (trim($tmps[$c][$z]['PATax']) == "N") $PATax = "N";
		}
		if (trim($PATax) == "Y") $PATaxPrice = $PATaxPrice + round($tmps[$c][$z]['Charges']*0.05);
		
		//$SumPrice = $SumPrice + $tmps[$c][$z]['Charges'];
		//$PATaxPrice = $PATaxPrice + round($tmps[$c][$z]['Charges']*0.05);
		$subHtml .= '<tr height="15">
			<td class="Q6" width="260" align="center">'.$tmps[$c][$z]['PAItem'].'</td>
			<td class="Q6" width="85" align="center">'.number_format($tmps[$c][$z]['Charges']).'</td>
			<td class="Q6" width="60" align="center">'.$tmps[$c][$z]['P'].'</td>
			<td class="Q6" width="85" align="center">'.$tmps[$c][$z]['sum'].'</td>
			<td class="Q6" width="180">'.$tmps[$c][$z]['PANote'].'</td>
		</tr>';
		$sum = $SumPrice + $PATaxPrice;
	}
	$s1 = $sum+$s1;
	
	$F = '';	
	if (trim($Florin) == "T") $F = "TWD"; else $F = $IFlorin;
	
	if($c == count($tmps)-1){
		$sHtml = '<table border="0" cellpadding="0" cellspacing="0" align="center">
							<tr height="20">
								<td class="Q4">&nbsp;總　計 ('.$F.')</td>
								<td class="Q7" align="center">&nbsp;</td>
								<td class="Q7" align="center">&nbsp;</td>
								<td class="Q7" align="center">&nbsp;</td>
								<td class="Q7" align="center">'.number_format($s1).'</td>
								<td class="Q7" align="center">&nbsp;</td>
							</tr>
						</table>';
	}
	
	
	
	$IT = '';
	if (trim($InvoiceTitle) != "") $IT = $InvoiceTitle; else $IT = "同左";
	$IC = '';
	if (trim($InvoiceCUID) != "") $IC = $InvoiceCUID; else $IC = $GUI;
	$IA = '';
	if (trim($InvoiceAddress) != "") $IA = $InvoiceAddress; else $IA = "同左";

						
	$html .= '<table border="0" cellpadding="0" cellspacing="0">
	<tr>
		<td>
			<table border="0" cellpadding="0" cellspacing="0">
				<tr>
					<td colspan="3" height="5"></td>
				</tr>
				<tr>
					<td width="150" rowspan="4" align="center"><img src="../images/logo.gif" border="0" width="100" height="96" /></td>
					<td width="350" height="20">&nbsp;</td>
					<td width="200" height="20">&nbsp;</td>
				</tr>				
				<tr>
					<td class="Q1" height="20"><font size="14">全威驗證科技股份有限公司</font></td>
					<td class="Q2" height="20"><font size="14">TEL:+886-2-8201-1888</font></td>
				</tr>
				<tr>
					<td class="Q3" height="20"><font  size="14" color="red">R</font><font size="14">ight </font><font size="14" color="red">P</font><font size="14">ower </font><font size="14" color="red">C</font><font size="14">ertification Co., Ltd.</font></td>
					<td class="Q2" height="20"><font size="14">FAX:+886-2-8201-8388</font></td>
				</tr>
				<tr>
					<td colspan="3" height="20">&nbsp;</td>
				</tr>
				<tr>
					<td height="20">&nbsp;</td>
					<td height="20" align="center" class="Q2"><font color="purple" size="14">服  務  報  價  單 Quotation</font></td>
					<td height="20">&nbsp;</td>
				</tr>
				<tr>
					<td height="20">&nbsp;</td>
					<td width="70" height="20">&nbsp;</td>
					<td height="20" align="center" class="Q2"><hr width="210" height="1" color="purple"></td>
					<td height="20">&nbsp;</td>
				</tr>
			</table>
			<table border="1" cellpadding="0" cellspacing="0" bordercolor="#000000">
				<tr>
					<td>
						<table  border="0" cellpadding="0" cellspacing="0" >
							<tr height="20">
								<td class="Q4" width="155">公司名稱 Company：</td>
								<td class="Q5" width="255">'.$CName.'</td>
								<td class="Q4" width="190">合約編號Contract No.</td>
								<td class="Q5" width="80"><font color="#000000">'.$PUID.'</font></td>
							</tr>
							<tr height="20">
								<td class="Q4">聯絡人Contact Person：</td>
								<td class="Q5">'.$Contact.'</td>
								<td class="Q4">發票抬頭  Title of invoice：</td>
								<td class="Q5"><font color="#000000">'.$IT.'</font></td>
							</tr>
							<tr height="20">
								<td class="Q4">電話Telephone No.：</td>
								<td class="Q5">'.$CTel.'</td>
								<td class="Q4">統一編號 Tax ID:</td>
								<td class="Q5"><font color="#000000">'.$IC.'</font></td>
							</tr>
							<tr height="20">
								<td class="Q4">公司地址<br/>Company Address：</td>
								<td class="Q5">'.$CAddress.'</td>
								<td class="Q4">發票寄送地址<br/>Invoice Address：</td>
								<td class="Q5"><font color="#000000">'.$IA.'</font></td>
							</tr>
							<tr height="20">
								<td class="Q4">專案名稱Project:</td>
								<td class="Q5">'.$PName.'-'.$ApplyItem.'</td>
								<td class="Q4">報價日期 Date：</td>
								<td class="Q5"><font color="#000000">'.$QuoteDate.'</font></td>
							</tr>
						</table>
						<table border="0" cellpadding="0" cellspacing="0" align="center" style="border: 1px solid black;">
							<tr>
								<td>
									<table  border="0" cellpadding="0" cellspacing="0" align="center">
										<tr height="20">
											<td class="Q4" width="305" align="center">服務內容 Service Description</td>
											<td class="Q4" width="60" align="center">Tax</td>
											<td class="Q4" width="100" align="center">Amount</td>
											<td class="Q4" width="215" align="center">備 註 Note</td>
										</tr>
									</table>
								</td>
							</tr>
						</table>
						<table width="720" border="0" cellpadding="0" cellspacing="0">
						'.$subHtml.'<tr height="15">
									<td class="Q6" width="260" align="center"></td>
									<td class="Q6" width="85" align="center"></td>
									<td class="Q6" width="60" align="center"></td>
									<td class="Q6" width="85" align="center"></td>
									<td class="Q6" width="180"></td>
								</tr><tr height="15">
								<td class="Q6" align="center" colspan="5">
								Lead-time：'.$Leadtime.'
								Model name：'.$ModelName.' / '.$SeriesModel.'
								</td>
							</tr>
						</table>
						<table border="0" cellpadding="0" cellspacing="0" align="center" height="1" style="border: 1px solid black;">
								<tr>
									<td>
										<table width="680" border="0" cellpadding="0" cellspacing="0" align="center">
											<tr height="20">
												<td class="Q4" width="410">&nbsp;委託費用 Amount</td>
												<td class="Q7" width="90" align="center">'.number_format($SumPrice).'</td>
												<td class="Q7" width="180" align="center">&nbsp;</td>
											</tr>
											<tr height="20">
												<td class="Q4">&nbsp;營業稅 Tax</td>
												<td class="Q7" align="center">'.number_format($PATaxPrice).'</td>
												<td class="Q7" align="center">&nbsp;</td>
											</tr>
										</table>
									</td>
								</tr>
						</table>
						<table border="0" cellpadding="0" cellspacing="0" align="center">
							<tr height="20">
								<td class="Q4">&nbsp;小　計 ('.$F.')</td>
								<td class="Q7" align="center">&nbsp;</td>
								<td class="Q7" align="center">&nbsp;</td>
								<td class="Q7" align="center">&nbsp;</td>
								<td class="Q7" align="center">'.number_format($SumPrice + $PATaxPrice).'</td>
								<td class="Q7" align="center">&nbsp;</td>
							</tr>
						</table>
						'.$sHtml.'
					</td>
				</tr>
			</table>
			<table border="0" cellpadding="0" cellspacing="0">
				<tr height="15">
					<td class="Q8">Precautions</td>
				</tr>
				<tr height="15">
					<td class="Q8">1.The above quotes are valid for 30 days. Please sign and then email back or fax to 886-2-8201-8388.</td>
				</tr>
				<tr height="15">
					<td class="Q8">2.The application fees and test fees will be varied by the product structure and the second source while we receive samples.</td>
				</tr>
				<tr height="15">
					<td class="Q8">3.The products function must be normal operating. During the application period, it shall not to do any added items on changing the content of the test or safety critical components. Otherwise, the progress will be slowed down and the cost will be increased. During the test period, the applicant needs to do the full cooperation for confirming the feasibility of the strategy. If the test is fail and the additional test fee will be added in the quotation.</td>
				</tr>
				<tr height="15">
					<td class="Q8">4.The lead-time is based on the complete samples, components, required documents, and the test are carried out without fail. If the application process is test fail or document shortage and the lead-time will be counted from scratch.</td>
				</tr>
				<tr height="15">
					<td class="Q8">5.The service content of Right Power Certification Inc. (excluding the factory inspection part), and reserves the right to change the service content for any reason.</td>
				</tr>
				<tr height="15">
					<td class="Q8">6.The applicant must pay the remittance or cash check in accordance with the INVOICE payment terms issued by Right Power Certification Inc. related expenses. (Please inform the bank when the wire transfer must included the bank handling fee to avoid unbalanced.)</td>
				</tr>
				<tr height="15">
					<td class="Q8">7.After the payment balance is settled, the original certificate will be sent by registered or email. If the product must be returned after the product test is completed, please make a statement in advance and we will charge the additional cost by applicant.</td>
				</tr>
				<tr height="15">
					<td class="Q8">8.The contents of this quotation are agreed to be confidential and may not be used outside the scope of the agreed purpose or for the benefit of others without the consent of the laboratory.</td>
				</tr>
				<tr height="15">
					<td class="Q8">9.Right Power Certification Inc. keeps all information obtained during the testing activities of this report confidential, except as required by law.Right Power Certification Inc. keeps all information confidential obtained in the testing activities of this report, except for the certification requirements of the laboratory.</td>
				</tr>
				<tr height="15">
					<td class="Q8">10.The compliance judgment rule of this test report is based on the requirements of regulations and standards, and the measurement uncertainty is not considered.</td>
				</tr>
				<tr height="15">
					<td class="Q8">11.If the sample does not needed to be returned, it will be destroyed by our company. If the sample is needed to be returned, the freight will be paid by applicant.</td>
				</tr>
				<tr height="15">
					<td class="Q8">12.The customer agrees to appoint the relevant external laboratory activities necessary by Right Power Certification Inc. and provide relevant information to the external experimental unit</td>
				</tr>
				<tr height="15">
					<td></td>
				</tr>
				<tr height="10">
					<td class="Q8">Payment information:</td>
				</tr>
				<tr height="10">
					<td class="Q8">1. ACCOUNT WITH BANK：CTBC Bank Co., Ltd. / SWIFT Code：CTCBTWTP761
<br/>Address：2F., No. 115, Xingde Rd., Sanchong Dist., New Taipei City 241 , Taiwan (R.O.C.) </td>
				</tr>
				<tr height="10">
					<td class="Q8">2. IN FAVOR OF Account Name : RIGHT POWER CERTIFICATION Co., Ltd. / Account Number : 761131010088</td>
				</tr>
				<tr height="15">
					<td class="Q8"></td>
				</tr>
				<tr height="30">
					<td></td>
				</tr>
			</table>
			<table width="720" border="0" cellpadding="0" cellspacing="0" align="center">
				<tr height="400">
					<td>
						<table width="250" border="0" cellpadding="0" cellspacing="0" bordercolor="#000000" align="center">
							<tr>
								<td>
									<table width="250" border="0" cellpadding="4" cellspacing="0" align="center">
										<tr height="50">
											<td class="Q8" width="120" valign="top">實驗室主管<br/>Laboratory Head：</td>
											<td class="Q8" align="center"></td>
										</tr>
									</table>
									<table width="250" border="0" cellpadding="4" cellspacing="0" align="center">
										<tr height="15">
											<td class="Q8" width="120" align="center"></td>
											<td class="Q8" align="center" style="border-bottom-style: solid;"></td>
										</tr>
									</table>
								</td>
							</tr>
						</table>
						
					</td>
					<td>
						<table width="250" border="0" cellpadding="0" cellspacing="0" bordercolor="#000000" align="center" >
							<tr>
								<td>
									<table width="250" border="0" cellpadding="4" cellspacing="0" align="center">
										<tr height="50">
											<td class="Q8" width="120" valign="top">顧客簽名 Customer Signature<br/>/日期 Date：</td>
											<td class="Q8" align="center"></td>
										</tr>
									</table>
									<table width="250" border="0" cellpadding="4" cellspacing="0" align="center">
										<tr height="15">
											<td class="Q8" width="120" align="center"></td>
											<td class="Q8" align="center" style="border-bottom-style: solid;"></td>
										</tr>
									</table>
								</td>
							</tr>
						</table>
						
					</td>
				</tr>
			</table>
			<table width="250" border="0" cellpadding="0" cellspacing="0" align="center">
				<tr height="30">
					<td>
					</td>
				</tr>
			</table>
			<table width="720" border="0" cellpadding="0" cellspacing="0" align="center">
				<tr height="30">
					<td>
						<table width="250" border="0" cellpadding="0" cellspacing="0" bordercolor="#000000" align="center">
							<tr>
								<td>
									<table width="250" border="0" cellpadding="4" cellspacing="0" align="center">
										<tr height="50">
											<td class="Q8" width="120" valign="top">承辦客服<br/>Customer service：</td>
											<td class="Q8" align="center">'.$MEName.$MName.'</td>
										</tr>
									</table>
									<table width="250" border="0" cellpadding="4" cellspacing="0" align="center">
										<tr height="15">
											<td class="Q8" width="120" align="center"></td>
											<td class="Q8" align="center" style="border-bottom-style: solid;">行動電話<br/>Mobile：'.$Mobile.'</td>
										</tr>
									</table>
								</td>
							</tr>
						</table>
					</td>
					<td>
						<table width="250" border="0" cellpadding="0" cellspacing="0" bordercolor="#000000" align="center">
							<tr height="73">
								<td class="Q8" valign="top"></td>
							</tr>
						</table>
					</td>
				</tr>
			</table>
			<table width="800" border="0" cellpadding="0" cellspacing="0">
				<tr height="10">
					<td></td>
				</tr>
				<tr height="15">
					<td class="Q9">241新北市三重興德路115號2樓2F., No. 115, Xingde Rd., Sanchong Dist., New Taipei City 241 , Taiwan (R.O.C.)</td>
				</tr>
				<tr height="15">
					<td class="Q9">文件編號: RPC-OD-201</td> <td class="Q9" align="right">版次: Version 1.7(20230304)</td>
				</tr>
			</table>

					
		</td>
	</tr>
</table>';
	
	//$subHtml = '';
}



// output the HTML content
$pdf->writeHTML($html, true, false, true, false, '');

// reset pointer to the last page
$pdf->lastPage();

// ---------------------------------------------------------
ob_clean();
//Close and output PDF document
$pdf->Output('quote.pdf', 'I');

//============================================================+
// END OF FILE
//============================================================+




/*


for ($tmp=0;$tmp<=$ShowLine-1;$tmp++){

}

$sub1 .= '<tr height="15">
	<td class="Q6" width="260" align="center"></td>
	<td class="Q6" width="85" align="center"></td>
	<td class="Q6" width="60" align="center"></td>
	<td class="Q6" width="85" align="center"></td>
	<td class="Q6" width="180"></td>
</tr>';

$sub1 .='<tr height="15">
			<td class="Q6" align="center" colspan="5">
			Lead-time：'.$Leadtime.'
			Model name：'.$ModelName.' / '.$SeriesModel.'
			</td>
		</tr>
	</table>';

$F = '';	
if (trim($Florin) == "T") $F = "TWD"; else $F = $IFlorin;

$sub1 .= '<table border="0" cellpadding="0" cellspacing="0" align="center" height="1" style="border: 1px solid black;">
							<tr>
								<td>
									<table width="680" border="0" cellpadding="0" cellspacing="0" align="center">
										<tr height="20">
											<td class="Q4" width="410">&nbsp;委託費用 Amount</td>
											<td class="Q7" width="90" align="center">'.number_format($SumPrice).'</td>
											<td class="Q7" width="180" align="center">&nbsp;</td>
										</tr>
										<tr height="20">
											<td class="Q4">&nbsp;營業稅 Tax</td>
											<td class="Q7" align="center">'.number_format($PATaxPrice).'</td>
											<td class="Q7" align="center">&nbsp;</td>
										</tr>
									</table>
								</td>
							</tr>
						</table>
						<table border="0" cellpadding="0" cellspacing="0" align="center">
							<tr height="20">
								<td class="Q4">&nbsp;總　計 Total('.$F.')</td>
								<td class="Q7" align="center">&nbsp;</td>
								<td class="Q7" align="center">&nbsp;</td>
								<td class="Q7" align="center">&nbsp;</td>
								<td class="Q7" align="center">'.number_format($SumPrice + $PATaxPrice).'</td>
								<td class="Q7" align="center">&nbsp;</td>
							</tr>
						</table>
					</td>
				</tr>
			</table>
';
$subHtml .= $sub1;	

$IT = '';
if (trim($InvoiceTitle) != "") $IT = $InvoiceTitle; else $IT = "同左";
$IC = '';
if (trim($InvoiceCUID) != "") $IC = $InvoiceCUID; else $IC = $GUI;
$IA = '';
if (trim($InvoiceAddress) != "") $IA = $InvoiceAddress; else $IA = "同左";

					
$html = '';

// output the HTML content
$pdf->writeHTML($html, true, false, true, false, '');

// reset pointer to the last page
$pdf->lastPage();

// ---------------------------------------------------------
ob_clean();
//Close and output PDF document
$pdf->Output('quote.pdf', 'I');
*/
//============================================================+
// END OF FILE
//============================================================+
?>
</body>
</html>
<?php
if (trim($CheckQuotation) == "Y") {
		$QuotationURL="https://".$_SERVER["HTTP_HOST"]."/Admin/ProjectQuotationOutput.php?PID=".$PID."&Florin=".$Florin;
		$fp=fopen($QuotationURL,"r");
		$PQRUContent="";
		while($line=fgets($fp,512)){
			$PQRUContent.=$line;
			}
		fclose($fp);
		
		$PQRUID = "Q".rand_string(10, 'ABCDEFGHIJKLMNPQRSTUVWXYZ23456789abcdefghijklmnopqrstuvwxyz').$PID.$Florin;
		
		$now_time = date("Y-m-d H:i:s",mktime());
		$sql_update = "update ProjectQuotationRecord set Deltag='Y' where Deltag='N' and PID = '".$PID."';";
		$result_update=mysqli_query($link,$sql_update) or die ("無法執行修改");
		$sql_insert = "insert into ProjectQuotationRecord (PID,PQRUID,QuoteDate,PQRUContent,AddUser,AddDate,AddIP) values ('".$PID."','".$PQRUID."','".$QuoteDate."','".$PQRUContent."','".$_SESSION["reg_MUID"]."','".$now_time."','".$_SERVER["REMOTE_ADDR"]."');";
		$result_insert=mysqli_query($link,$sql_insert) or die ("無法執行新增");
		}
mysqli_close($link);
?>