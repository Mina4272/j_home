﻿<?php	
include "CheckPermission.php";
include "../global.php";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $PageAdminTitle;?></title>
<link href="../type.css" rel="stylesheet" type="text/css" />
<style type="text/css">
<!--
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
}
-->
</style>
<link href="../script/DatePicker.css" rel="stylesheet" type="text/css" />
<Script LANGUAGE="Javascript" SRC="../script/DatePicker.js"></Script>
<Script type="text/javascript" language="javascript" src="../script/CheckForm.js"></Script>
<script type="text/JavaScript">
<!--
function jsCheck() 
		{
		if (ChkDate('MVSYear',document.form1.MVSYear.value,document.form1.MVSMonth.value,document.form1.MVSDay.value,'請假起始時間') == false) return false;
		if (ChkDate('MVEYear',document.form1.MVEYear.value,document.form1.MVEMonth.value,document.form1.MVEDay.value,'請假結束時間') == false) return false;
		if (CompareDate('MVSYear',document.form1.MVSYear.value,document.form1.MVSMonth.value,document.form1.MVSDay.value,document.form1.MVEYear.value,document.form1.MVEMonth.value,document.form1.MVEDay.value,'請假起始時間','請假結束時間') == false) return false;
		if (ChkNaN('Hourage',document.form1.Hourage.value,'時數','') == false) return false;
		}
//-->
</script>
</head>
<body>
<?php include "top.php";?>
<?php
$MVID = $_GET['MVID'];
$page = $_GET['page'];
$QMVSDate = $_GET['QMVSDate'];
$QMVEDate = $_GET['QMVEDate'];
$QMVType = $_GET['QMVType'];
$QMUID = $_GET['QMUID'];
$KeyWord = $_GET['KeyWord'];
$QAgent = $_GET['QAgent'];
$QMVCheck = $_GET['QMVCheck'];

if (trim($MVID) == "")
		{
		mysqli_close($link);
		?>
		<script type="text/JavaScript">
			<!--
			alert ("查無資料，請冾網站管理人員！");
			history.go(-1);
			//-->
		</script>
		<?php
		exit;
		}
$SQL_ManagerVac="select MUID,MVType,MVSDate,date_format(MVSDate,'%Y'),date_format(MVSDate,'%m'),date_format(MVSDate,'%d'),date_format(MVSDate,'%H'),date_format(MVSDate,'%i'),MVEDate,date_format(MVEDate,'%Y'),date_format(MVEDate,'%m'),date_format(MVEDate,'%d'),date_format(MVEDate,'%H'),date_format(MVEDate,'%i'),Hourage,Agent,MVNote,MVSend,MVCheck,(select MName from Manager where MUID=ManagerVac.MUID) MName,(select MEName from Manager where MUID=ManagerVac.MUID) MEName from ManagerVac where Deltag='N' and MVID=".$MVID.";";
$result_ManagerVac=mysqli_query($link,$SQL_ManagerVac) or die ("無法執行查詢");
if (mysqli_num_rows($result_ManagerVac) == 0)
		{
		mysqli_free_result($result_Manager);
		mysqli_close($link);
		?>
		<SCRIPT language=javascript>
		<!--
		alert ("查無資料，請冾網站管理人員！"); 
		history.go(-1);
		//-->
		</SCRIPT>
		<?php 	
		exit;
		}
list($MUID,$MVType,$MVSDate,$MVSYear,$MVSMonth,$MVSDay,$MVSHouse,$MVSMin,$MVEDate,$MVEYear,$MVEMonth,$MVEDay,$MVEHouse,$MVEMin,$Hourage,$Agent,$MVNote,$MVSend,$MVCheck,$MName,$MEName)=mysqli_fetch_row($result_ManagerVac);
mysqli_free_result($result_ManagerVac);

if (trim($MVCheck) != "W")
		{
		mysqli_close($link);
		?>
		<script type="text/JavaScript">
			<!--
			alert ("此請假單已簽核，不得修改！");
			history.go(-1);
			//-->
		</script>
		<?php
		exit;
		}

if (trim($MUID) != trim($_SESSION["reg_MUID"]))
		{
		mysqli_close($link);
		?>
		<script type="text/JavaScript">
			<!--
			alert ("此請假單非本人，不得修改！");
			history.go(-1);
			//-->
		</script>
		<?php
		exit;
		}
?>
<table width="100%" border="0" cellspacing="0" cellpadding="5">
	<tr>
    <td width="160" height="600" align="left" valign="top">
			<?php include "menu.php";?>
    </td>
    <td valign="top">
    	<table width="100%" border="0" cellpadding="0" cellspacing="0">
    		<tr>
    			<td>
			    	<table width="750" border="0" cellpadding="0" cellspacing="0">
			    		<tr height="30">
			    			<td class="c2"><b>修改請假資料</b></td>
			    		</tr>
			    	</table>
			    	<table width="750" border="0" cellpadding="0" cellspacing="0">
			        <form name="form1" method="post" action="MVacEditDB.php" onSubmit="return jsCheck();">
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td width="160" align="right" class="c3">申請人：</td>
			          <td class="h3"><?php echo $MEName.$MName;?>
			          	<input type="hidden" name="MVID" value="<?php echo $MVID;?>">
			          	<input type="hidden" name="page" value="<?php echo $page;?>">
			          	<input type="hidden" name="QMVSDate" value="<?php echo $QMVSDate;?>">
			          	<input type="hidden" name="QMVEDate" value="<?php echo $QMVEDate;?>">
			          	<input type="hidden" name="QMVType" value="<?php echo $QMVType;?>">
			          	<input type="hidden" name="QMUID" value="<?php echo $QMUID;?>">
			          	<input type="hidden" name="KeyWord" value="<?php echo $KeyWord;?>">
			          	<input type="hidden" name="QAgent" value="<?php echo $QAgent;?>">
			          	<input type="hidden" name="QMVCheck" value="<?php echo $QMVCheck;?>">
			          </td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">假別：</td>
			          <td class="h3">
			          	<select name="MVType">
			          		<option value="A"<?php if (trim($MVType) == "A") echo " selected";?>>事假</option>
			          		<option value="B"<?php if (trim($MVType) == "B") echo " selected";?>>病假</option>
			          		<option value="C"<?php if (trim($MVType) == "C") echo " selected";?>>公假</option>
			          		<option value="D"<?php if (trim($MVType) == "D") echo " selected";?>>喪假</option>
			          		<option value="E"<?php if (trim($MVType) == "E") echo " selected";?>>婚假</option>
			          		<option value="F"<?php if (trim($MVType) == "F") echo " selected";?>>產假</option>
			          		<option value="G"<?php if (trim($MVType) == "G") echo " selected";?>>特休</option>
			          		<option value="H"<?php if (trim($MVType) == "H") echo " selected";?>>其他</option>
			          	</select>
			          </td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">請假起始時間：</td>
			          <td class="h3">
			            <input name="MVSYear" type="text" size="4" value="<?php echo $MVSYear;?>" />年
			            <input name="MVSMonth" type="text" size="2" value="<?php echo $MVSMonth;?>" />月
			            <input name="MVSDay" type="text" size="2" value="<?php echo $MVSDay;?>" />日
			            <img src="../images/icon.gif" width="16" height="18" style="cursor: hand" onclick="javascript:displayDatePicker('MVSYear','MVSMonth','MVSDay');"/> 
			          	<select name="MVSHouse">
			          		<option value="00"<?php if (trim($MVSHouse) == "00") echo " selected";?>>00</option>
			          		<option value="01"<?php if (trim($MVSHouse) == "01") echo " selected";?>>01</option>
			          		<option value="02"<?php if (trim($MVSHouse) == "02") echo " selected";?>>02</option>
			          		<option value="03"<?php if (trim($MVSHouse) == "03") echo " selected";?>>03</option>
			          		<option value="04"<?php if (trim($MVSHouse) == "04") echo " selected";?>>04</option>
			          		<option value="05"<?php if (trim($MVSHouse) == "05") echo " selected";?>>05</option>
			          		<option value="06"<?php if (trim($MVSHouse) == "06") echo " selected";?>>06</option>
			          		<option value="07"<?php if (trim($MVSHouse) == "07") echo " selected";?>>07</option>
			          		<option value="08"<?php if (trim($MVSHouse) == "08") echo " selected";?>>08</option>
			          		<option value="09"<?php if (trim($MVSHouse) == "09") echo " selected";?>>09</option>
			          		<option value="10"<?php if (trim($MVSHouse) == "10") echo " selected";?>>10</option>
			          		<option value="11"<?php if (trim($MVSHouse) == "11") echo " selected";?>>11</option>
			          		<option value="12"<?php if (trim($MVSHouse) == "12") echo " selected";?>>12</option>
			          		<option value="13"<?php if (trim($MVSHouse) == "13") echo " selected";?>>13</option>
			          		<option value="14"<?php if (trim($MVSHouse) == "14") echo " selected";?>>14</option>
			          		<option value="15"<?php if (trim($MVSHouse) == "15") echo " selected";?>>15</option>
			          		<option value="16"<?php if (trim($MVSHouse) == "16") echo " selected";?>>16</option>
			          		<option value="17"<?php if (trim($MVSHouse) == "17") echo " selected";?>>17</option>
			          		<option value="18"<?php if (trim($MVSHouse) == "18") echo " selected";?>>18</option>
			          		<option value="19"<?php if (trim($MVSHouse) == "19") echo " selected";?>>19</option>
			          		<option value="20"<?php if (trim($MVSHouse) == "20") echo " selected";?>>20</option>
			          		<option value="21"<?php if (trim($MVSHouse) == "21") echo " selected";?>>21</option>
			          		<option value="22"<?php if (trim($MVSHouse) == "22") echo " selected";?>>22</option>
			          		<option value="23"<?php if (trim($MVSHouse) == "23") echo " selected";?>>23</option>
			          	</select> 時 
			          	<select name="MVSMin">
			          		<option value="00"<?php if (trim($MVSMin) == "00") echo " selected";?>>00</option>
			          		<option value="01"<?php if (trim($MVSMin) == "01") echo " selected";?>>01</option>
			          		<option value="02"<?php if (trim($MVSMin) == "02") echo " selected";?>>02</option>
			          		<option value="03"<?php if (trim($MVSMin) == "03") echo " selected";?>>03</option>
			          		<option value="04"<?php if (trim($MVSMin) == "04") echo " selected";?>>04</option>
			          		<option value="05"<?php if (trim($MVSMin) == "05") echo " selected";?>>05</option>
			          		<option value="06"<?php if (trim($MVSMin) == "06") echo " selected";?>>06</option>
			          		<option value="07"<?php if (trim($MVSMin) == "07") echo " selected";?>>07</option>
			          		<option value="08"<?php if (trim($MVSMin) == "08") echo " selected";?>>08</option>
			          		<option value="09"<?php if (trim($MVSMin) == "09") echo " selected";?>>09</option>
			          		<option value="10"<?php if (trim($MVSMin) == "10") echo " selected";?>>10</option>
			          		<option value="11"<?php if (trim($MVSMin) == "11") echo " selected";?>>11</option>
			          		<option value="12"<?php if (trim($MVSMin) == "12") echo " selected";?>>12</option>
			          		<option value="13"<?php if (trim($MVSMin) == "13") echo " selected";?>>13</option>
			          		<option value="14"<?php if (trim($MVSMin) == "14") echo " selected";?>>14</option>
			          		<option value="15"<?php if (trim($MVSMin) == "15") echo " selected";?>>15</option>
			          		<option value="16"<?php if (trim($MVSMin) == "16") echo " selected";?>>16</option>
			          		<option value="17"<?php if (trim($MVSMin) == "17") echo " selected";?>>17</option>
			          		<option value="18"<?php if (trim($MVSMin) == "18") echo " selected";?>>18</option>
			          		<option value="19"<?php if (trim($MVSMin) == "19") echo " selected";?>>19</option>
			          		<option value="20"<?php if (trim($MVSMin) == "20") echo " selected";?>>20</option>
			          		<option value="21"<?php if (trim($MVSMin) == "21") echo " selected";?>>21</option>
			          		<option value="22"<?php if (trim($MVSMin) == "22") echo " selected";?>>22</option>
			          		<option value="23"<?php if (trim($MVSMin) == "23") echo " selected";?>>23</option>
			          		<option value="24"<?php if (trim($MVSMin) == "24") echo " selected";?>>24</option>
			          		<option value="25"<?php if (trim($MVSMin) == "25") echo " selected";?>>25</option>
			          		<option value="26"<?php if (trim($MVSMin) == "26") echo " selected";?>>26</option>
			          		<option value="27"<?php if (trim($MVSMin) == "27") echo " selected";?>>27</option>
			          		<option value="28"<?php if (trim($MVSMin) == "28") echo " selected";?>>28</option>
			          		<option value="29"<?php if (trim($MVSMin) == "29") echo " selected";?>>29</option>
			          		<option value="30"<?php if (trim($MVSMin) == "30") echo " selected";?>>30</option>
			          		<option value="31"<?php if (trim($MVSMin) == "31") echo " selected";?>>31</option>
			          		<option value="32"<?php if (trim($MVSMin) == "32") echo " selected";?>>32</option>
			          		<option value="33"<?php if (trim($MVSMin) == "33") echo " selected";?>>33</option>
			          		<option value="34"<?php if (trim($MVSMin) == "34") echo " selected";?>>34</option>
			          		<option value="35"<?php if (trim($MVSMin) == "35") echo " selected";?>>35</option>
			          		<option value="36"<?php if (trim($MVSMin) == "36") echo " selected";?>>36</option>
			          		<option value="37"<?php if (trim($MVSMin) == "37") echo " selected";?>>37</option>
			          		<option value="38"<?php if (trim($MVSMin) == "38") echo " selected";?>>38</option>
			          		<option value="39"<?php if (trim($MVSMin) == "39") echo " selected";?>>39</option>
			          		<option value="40"<?php if (trim($MVSMin) == "40") echo " selected";?>>40</option>
			          		<option value="41"<?php if (trim($MVSMin) == "41") echo " selected";?>>41</option>
			          		<option value="42"<?php if (trim($MVSMin) == "42") echo " selected";?>>42</option>
			          		<option value="43"<?php if (trim($MVSMin) == "43") echo " selected";?>>43</option>
			          		<option value="44"<?php if (trim($MVSMin) == "44") echo " selected";?>>44</option>
			          		<option value="45"<?php if (trim($MVSMin) == "45") echo " selected";?>>45</option>
			          		<option value="46"<?php if (trim($MVSMin) == "46") echo " selected";?>>46</option>
			          		<option value="47"<?php if (trim($MVSMin) == "47") echo " selected";?>>47</option>
			          		<option value="48"<?php if (trim($MVSMin) == "48") echo " selected";?>>48</option>
			          		<option value="49"<?php if (trim($MVSMin) == "49") echo " selected";?>>49</option>
			          		<option value="50"<?php if (trim($MVSMin) == "50") echo " selected";?>>50</option>
			          		<option value="51"<?php if (trim($MVSMin) == "51") echo " selected";?>>51</option>
			          		<option value="52"<?php if (trim($MVSMin) == "52") echo " selected";?>>52</option>
			          		<option value="53"<?php if (trim($MVSMin) == "53") echo " selected";?>>53</option>
			          		<option value="54"<?php if (trim($MVSMin) == "54") echo " selected";?>>54</option>
			          		<option value="55"<?php if (trim($MVSMin) == "55") echo " selected";?>>55</option>
			          		<option value="56"<?php if (trim($MVSMin) == "56") echo " selected";?>>56</option>
			          		<option value="57"<?php if (trim($MVSMin) == "57") echo " selected";?>>57</option>
			          		<option value="58"<?php if (trim($MVSMin) == "58") echo " selected";?>>58</option>
			          		<option value="59"<?php if (trim($MVSMin) == "59") echo " selected";?>>59</option>
			          	</select> 分
			          </td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">請假結束時間：</td>
			          <td class="h3">
			            <input name="MVEYear" type="text" size="4" value="<?php echo $MVEYear;?>" />年
			            <input name="MVEMonth" type="text" size="2" value="<?php echo $MVEMonth;?>" />月
			            <input name="MVEDay" type="text" size="2" value="<?php echo $MVEDay;?>" />日
			            <img src="../images/icon.gif" width="16" height="18" style="cursor: hand" onclick="javascript:displayDatePicker('MVEYear','MVEMonth','MVEDay');"/> 
			          	<select name="MVEHouse">
			          		<option value="00"<?php if (trim($MVEHouse) == "00") echo " selected";?>>00</option>
			          		<option value="01"<?php if (trim($MVEHouse) == "01") echo " selected";?>>01</option>
			          		<option value="02"<?php if (trim($MVEHouse) == "02") echo " selected";?>>02</option>
			          		<option value="03"<?php if (trim($MVEHouse) == "03") echo " selected";?>>03</option>
			          		<option value="04"<?php if (trim($MVEHouse) == "04") echo " selected";?>>04</option>
			          		<option value="05"<?php if (trim($MVEHouse) == "05") echo " selected";?>>05</option>
			          		<option value="06"<?php if (trim($MVEHouse) == "06") echo " selected";?>>06</option>
			          		<option value="07"<?php if (trim($MVEHouse) == "07") echo " selected";?>>07</option>
			          		<option value="08"<?php if (trim($MVEHouse) == "08") echo " selected";?>>08</option>
			          		<option value="09"<?php if (trim($MVEHouse) == "09") echo " selected";?>>09</option>
			          		<option value="10"<?php if (trim($MVEHouse) == "10") echo " selected";?>>10</option>
			          		<option value="11"<?php if (trim($MVEHouse) == "11") echo " selected";?>>11</option>
			          		<option value="12"<?php if (trim($MVEHouse) == "12") echo " selected";?>>12</option>
			          		<option value="13"<?php if (trim($MVEHouse) == "13") echo " selected";?>>13</option>
			          		<option value="14"<?php if (trim($MVEHouse) == "14") echo " selected";?>>14</option>
			          		<option value="15"<?php if (trim($MVEHouse) == "15") echo " selected";?>>15</option>
			          		<option value="16"<?php if (trim($MVEHouse) == "16") echo " selected";?>>16</option>
			          		<option value="17"<?php if (trim($MVEHouse) == "17") echo " selected";?>>17</option>
			          		<option value="18"<?php if (trim($MVEHouse) == "18") echo " selected";?>>18</option>
			          		<option value="19"<?php if (trim($MVEHouse) == "19") echo " selected";?>>19</option>
			          		<option value="20"<?php if (trim($MVEHouse) == "20") echo " selected";?>>20</option>
			          		<option value="21"<?php if (trim($MVEHouse) == "21") echo " selected";?>>21</option>
			          		<option value="22"<?php if (trim($MVEHouse) == "22") echo " selected";?>>22</option>
			          		<option value="23"<?php if (trim($MVEHouse) == "23") echo " selected";?>>23</option>
			          	</select> 時 
			          	<select name="MVEMin">
			          		<option value="00"<?php if (trim($MVEMin) == "00") echo " selected";?>>00</option>
			          		<option value="01"<?php if (trim($MVEMin) == "01") echo " selected";?>>01</option>
			          		<option value="02"<?php if (trim($MVEMin) == "02") echo " selected";?>>02</option>
			          		<option value="03"<?php if (trim($MVEMin) == "03") echo " selected";?>>03</option>
			          		<option value="04"<?php if (trim($MVEMin) == "04") echo " selected";?>>04</option>
			          		<option value="05"<?php if (trim($MVEMin) == "05") echo " selected";?>>05</option>
			          		<option value="06"<?php if (trim($MVEMin) == "06") echo " selected";?>>06</option>
			          		<option value="07"<?php if (trim($MVEMin) == "07") echo " selected";?>>07</option>
			          		<option value="08"<?php if (trim($MVEMin) == "08") echo " selected";?>>08</option>
			          		<option value="09"<?php if (trim($MVEMin) == "09") echo " selected";?>>09</option>
			          		<option value="10"<?php if (trim($MVEMin) == "10") echo " selected";?>>10</option>
			          		<option value="11"<?php if (trim($MVEMin) == "11") echo " selected";?>>11</option>
			          		<option value="12"<?php if (trim($MVEMin) == "12") echo " selected";?>>12</option>
			          		<option value="13"<?php if (trim($MVEMin) == "13") echo " selected";?>>13</option>
			          		<option value="14"<?php if (trim($MVEMin) == "14") echo " selected";?>>14</option>
			          		<option value="15"<?php if (trim($MVEMin) == "15") echo " selected";?>>15</option>
			          		<option value="16"<?php if (trim($MVEMin) == "16") echo " selected";?>>16</option>
			          		<option value="17"<?php if (trim($MVEMin) == "17") echo " selected";?>>17</option>
			          		<option value="18"<?php if (trim($MVEMin) == "18") echo " selected";?>>18</option>
			          		<option value="19"<?php if (trim($MVEMin) == "19") echo " selected";?>>19</option>
			          		<option value="20"<?php if (trim($MVEMin) == "20") echo " selected";?>>20</option>
			          		<option value="21"<?php if (trim($MVEMin) == "21") echo " selected";?>>21</option>
			          		<option value="22"<?php if (trim($MVEMin) == "22") echo " selected";?>>22</option>
			          		<option value="23"<?php if (trim($MVEMin) == "23") echo " selected";?>>23</option>
			          		<option value="24"<?php if (trim($MVEMin) == "24") echo " selected";?>>24</option>
			          		<option value="25"<?php if (trim($MVEMin) == "25") echo " selected";?>>25</option>
			          		<option value="26"<?php if (trim($MVEMin) == "26") echo " selected";?>>26</option>
			          		<option value="27"<?php if (trim($MVEMin) == "27") echo " selected";?>>27</option>
			          		<option value="28"<?php if (trim($MVEMin) == "28") echo " selected";?>>28</option>
			          		<option value="29"<?php if (trim($MVEMin) == "29") echo " selected";?>>29</option>
			          		<option value="30"<?php if (trim($MVEMin) == "30") echo " selected";?>>30</option>
			          		<option value="31"<?php if (trim($MVEMin) == "31") echo " selected";?>>31</option>
			          		<option value="32"<?php if (trim($MVEMin) == "32") echo " selected";?>>32</option>
			          		<option value="33"<?php if (trim($MVEMin) == "33") echo " selected";?>>33</option>
			          		<option value="34"<?php if (trim($MVEMin) == "34") echo " selected";?>>34</option>
			          		<option value="35"<?php if (trim($MVEMin) == "35") echo " selected";?>>35</option>
			          		<option value="36"<?php if (trim($MVEMin) == "36") echo " selected";?>>36</option>
			          		<option value="37"<?php if (trim($MVEMin) == "37") echo " selected";?>>37</option>
			          		<option value="38"<?php if (trim($MVEMin) == "38") echo " selected";?>>38</option>
			          		<option value="39"<?php if (trim($MVEMin) == "39") echo " selected";?>>39</option>
			          		<option value="40"<?php if (trim($MVEMin) == "40") echo " selected";?>>40</option>
			          		<option value="41"<?php if (trim($MVEMin) == "41") echo " selected";?>>41</option>
			          		<option value="42"<?php if (trim($MVEMin) == "42") echo " selected";?>>42</option>
			          		<option value="43"<?php if (trim($MVEMin) == "43") echo " selected";?>>43</option>
			          		<option value="44"<?php if (trim($MVEMin) == "44") echo " selected";?>>44</option>
			          		<option value="45"<?php if (trim($MVEMin) == "45") echo " selected";?>>45</option>
			          		<option value="46"<?php if (trim($MVEMin) == "46") echo " selected";?>>46</option>
			          		<option value="47"<?php if (trim($MVEMin) == "47") echo " selected";?>>47</option>
			          		<option value="48"<?php if (trim($MVEMin) == "48") echo " selected";?>>48</option>
			          		<option value="49"<?php if (trim($MVEMin) == "49") echo " selected";?>>49</option>
			          		<option value="50"<?php if (trim($MVEMin) == "50") echo " selected";?>>50</option>
			          		<option value="51"<?php if (trim($MVEMin) == "51") echo " selected";?>>51</option>
			          		<option value="52"<?php if (trim($MVEMin) == "52") echo " selected";?>>52</option>
			          		<option value="53"<?php if (trim($MVEMin) == "53") echo " selected";?>>53</option>
			          		<option value="54"<?php if (trim($MVEMin) == "54") echo " selected";?>>54</option>
			          		<option value="55"<?php if (trim($MVEMin) == "55") echo " selected";?>>55</option>
			          		<option value="56"<?php if (trim($MVEMin) == "56") echo " selected";?>>56</option>
			          		<option value="57"<?php if (trim($MVEMin) == "57") echo " selected";?>>57</option>
			          		<option value="58"<?php if (trim($MVEMin) == "58") echo " selected";?>>58</option>
			          		<option value="59"<?php if (trim($MVEMin) == "59") echo " selected";?>>59</option>
			          	</select> 分
			          </td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">時數：</td>
			          <td class="h3"><input type="text" name="Hourage" size="10" value="<?php echo $Hourage;?>"></td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">代理人：</td>
			          <td class="h3">
			          	<select name="Agent">
			          		<?php
										$SQL_Manager="select MUID,MName,MEName from Manager where MUID not in ('".$_SESSION["reg_MUID"]."') and Deltag='N' and IsLeft='N' order by MID;";
										$result_Manager=mysqli_query($link,$SQL_Manager) or die ("無法執行查詢");
			          		while(list($MUID,$MName,$MEName)=mysqli_fetch_row($result_Manager)){
					          		?>
					          		<option value="<?php echo $MUID;?>"<?php if (trim($MUID) == trim($Agent)) echo " selected";?>><?php echo $MEName.$MName;?></option>
					          		<?php
						      			}
			            	mysqli_free_result($result_Manager);
			          		?>
			          	</select>
			          </td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">備註：</td>
			          <td class="h3"><input type="text" name="MVNote" size="60" value="<?php echo $MVNote;?>"></td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">是否送審：</td>
			          <td class="h3">
			          	<input type="radio" name="MVSend" value="N"<?php if (trim($MVSend) == "N") echo " checked";?>> 否 
			          	<input type="radio" name="MVSend" value="Y"<?php if (trim($MVSend) == "Y") echo " checked";?>> 是
			          </td>
			        </tr>
			        <tr height="40" align="center">
			          <td colspan="2" class="h3">
			          	<?php if (trim($MVSend) == "Y") {?>
			          	<input type="button" name="button" class="input_bot" value="回列表" onclick="javascript:location.href='MVacList.php?page=<?php echo $page;?>&QMVSDate=<?php echo $QMVSDate;?>&QMVEDate=<?php echo $QMVEDate;?>&QMVType=<?php echo $QMVType;?>&QMUID=<?php echo $QMUID;?>&QAgent=<?php echo $QAgent;?>&QMVCheck=<?php echo $QMVCheck;?>&KeyWord=<?php echo urlencode($KeyWord);?>';";> <font color=blue>已送審不得再修改</font>
			          	<?php } else {?>
			          	<input type="submit" name="submit" class="input_bot" value="送 出">
			          	<?php }?>
			          </td>
			        </tr>
				      </form>
			      </table>
    			</td>
    		</tr>
    	</table>
    </td>
	</tr>
</table>
<?php include "down.php";?>
</body>
</html>
<?php
mysqli_close($link);
?>