﻿<?php	
include "CheckPermission.php";
include "CheckProject.php";
include "../global.php";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $PageAdminTitle;?></title>
<link href="../type.css" rel="stylesheet" type="text/css" />
<style type="text/css">
<!--
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
}
-->
</style>
<link href="../script/DatePicker.css" rel="stylesheet" type="text/css" />
<Script LANGUAGE="Javascript" SRC="../script/DatePicker.js"></Script>
<Script type="text/javascript" language="javascript" src="../script/CheckForm.js"></Script>
</head>
<body>
<?php include "top.php";?>
<?php
$PID = empty($_GET['PID'])?"":$_GET['PID'];
$page = empty($_GET['page'])?"":$_GET['page'];
$KeyWord = empty($_GET['KeyWord'])?"":$_GET['KeyWord'];
$QPStatus = empty($_GET['QPStatus'])?"":$_GET['QPStatus'];
$QPE = empty($_GET['QPE'])?"":$_GET['QPE'];
$QBMUID = empty($_GET['QBMUID'])?"":$_GET['QBMUID'];
$ISINo = empty($_GET['ISINo'])?"":$_GET['ISINo'];
$ISAdd = empty($_GET['ISAdd'])?"":$_GET['ISAdd'];
$url_str = "&QPStatus=".$QPStatus."&QPE=".$QPE."&QBMUID=".$QBMUID."&ISINo=".$ISINo."&ISAdd=".$ISAdd."&KeyWord=".urlencode($KeyWord);

if (trim($PID) == "")
		{
		mysqli_close($link);
		?>
		<script type="text/JavaScript">
			<!--
			alert ("查無資料，請冾網站管理人員！");
			history.go(-1);
			//-->
		</script>
		<?php
		exit;
		}
$SQL_Project="select PUID,CID,CName,CTel,CFax,CAddress,Contact,CMobile,CEMail,PStatus,PName,ModelName,SeriesModel,PE,test,Quote,ifnull( BMUID,'vivi') BMUID,ApplyItem,Agent,Canon,CCCCode,SNote,StartDate,date_format(StartDate,'%Y'),date_format(StartDate,'%m'),date_format(StartDate,'%d'),PlanDate,date_format(PlanDate,'%Y'),date_format(PlanDate,'%m'),date_format(PlanDate,'%d'),CloseDate,date_format(CloseDate,'%Y'),date_format(CloseDate,'%m'),date_format(CloseDate,'%d'),PNote,PNoteDate,EMC,POther,PADate,date_format(PADate,'%Y'),date_format(PADate,'%m'),date_format(PADate,'%d'),PNote1,QuoteDate,ReturnDate,AddUser,AddDate,ProcUser,ProcDate,INo,InvoiceNote,(select CLevel from Customer where CID=Project.CID) CLevel,(select CFees from Customer where CID=Project.CID) CFees,(select CRecord from Customer where CID=Project.CID) CRecord,(select CRecordTxt from Customer where CID=Project.CID) CRecordTxt from Project where Deltag='N' and PID = '".$PID."';";
$result_Project=mysqli_query($link,$SQL_Project) or die ("無法執行查詢");
if (mysqli_num_rows($result_Project) == 0)
		{
		mysqli_free_result($result_Project);
		mysqli_close($link);
		?>
		<SCRIPT language=javascript>
		<!--
		alert ("查無資料，請冾網站管理人員！"); 
		history.go(-1);
		//-->
		</SCRIPT>
		<?php 	
		exit;
		}
list($PUID,$CID,$CName,$CTel,$CFax,$CAddress,$Contact,$CMobile,$CEMail,$PStatus,$PName,$ModelName,$SeriesModel,$PE,$test,$Quote,$BMUID,$ApplyItem,$Agent,$Canon,$CCCCode,$SNote,$StartDate,$StartYear,$StartMonth,$StartDay,$PlanDate,$PlanYear,$PlanMonth,$PlanDay,$CloseDate,$CloseYear,$CloseMonth,$CloseDay,$PNote,$PNoteDate,$EMC,$POther,$PADate,$PAYear,$PAMonth,$PADay,$PNote1,$QuoteDate,$ReturnDate,$AddUser,$AddDate,$ProcUser,$ProcDate,$INo,$InvoiceNote,$CLevel,$CFees,$CRecord,$CRecordTxt)=mysqli_fetch_row($result_Project);
mysqli_free_result($result_Project);
?>
<table width="100%" border="0" cellspacing="0" cellpadding="5">
	<tr>
    <td width="160" height="600" align="left" valign="top">
			<?php include "menu.php";?>
    </td>
    <td valign="top">
    	<table width="100%" border="0" cellpadding="0" cellspacing="0">
    		<tr>
    			<td>
			    	<table width="750" border="0" cellpadding="0" cellspacing="0">
			    		<tr height="30">
			    			<td class="c2"><b>管理修改案件資料</b></td>
			          <td width="80" align="center"><input type="button" name="edit" value="檔案管理" class="input_bot" onclick="javascript:location.href='ProjectFileClassList.php?PID=<?php echo $PID;?>&page=<?php echo $page;?><?php echo $url_str;?>';"></td>
			          <td width="80" align="center"><input type="button" name="edit" value="修 改" class="input_bot" onclick="javascript:location.href='ProjectEdit.php?PID=<?php echo $PID;?>&page=<?php echo $page;?><?php echo $url_str;?>';"></td>
			          <td width="80" align="center"><input type="button" name="edit" value="刪 除" class="input_bot" onclick="javascript:if (confirm('您是否確定要刪除？')) location.href='ProjectDelDB.php?PID=<?php echo $PID;?>&page=<?php echo $page;?><?php echo $url_str;?>';"></td>
			          <td width="80" align="center"><input type="button" name="PCopy" value="複製案件" class="input_bot" onclick="javascript:if (confirm('您是否確定要複製案件？')) window.open ('ProjectCopyDB.php?PID=<?php echo $PID;?>','ProjectCopyDB','height=10,width=10,top=200,left=200,scrollbars=no,status=no');"></td>
			    		</tr>
			    	</table>
			    	<table width="750" border="0" cellpadding="0" cellspacing="0">
			        <form name="form1" method="post" action="ProjectEditDB.php" onSubmit="return jsCheck();">
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td width="230" align="right" class="c3">案件編號：</td>
			          <td class="h3"><font color=blue><?php echo $PUID;?></font>
			          	<input name="PID" type="hidden" id="PID" value="<?php echo $PID;?>" />
			          	<input name="page" type="hidden" id="page" value="<?php echo $page;?>" />
			          	<input name="KeyWord" type="hidden" id="KeyWord" value="<?php echo $KeyWord;?>" />
			          	<input name="QPStatus" type="hidden" id="QPStatus" value="<?php echo $QPStatus;?>" />
			          	<input name="QPE" type="hidden" id="QPE" value="<?php echo $QPE;?>" />
			          	<input name="QBMUID" type="hidden" id="QBMUID" value="<?php echo $QBMUID;?>" />
			          	<input name="ISINo" type="hidden" id="ISINo" value="<?php echo $ISINo;?>" />
			          	<input name="ISAdd" type="hidden" id="ISAdd" value="<?php echo $ISAdd;?>" />
			         	</td>
			        </tr>
			        <?php
	          	if (trim($CLevel) == "C") $CLevel="B";
	          	if (trim($CLevel) == "A") $CLevelAlt="優(結案後直接給證書)";
	          	else if (trim($CLevel) == "B") $CLevelAlt="良(結案付款後給證書)";
	          	if (trim($CFees) == "A") $CFeesAlt="是(收據抬頭開全威)";
	          	else if (trim($CFees) == "B") $CFeesAlt="是(收據抬頭開申請人)";
	          	else if (trim($CFees) == "C") $CFeesAlt="否(不代送審)";
	          	if (trim($CRecord) == "A") $CRecordAlt="優(結案後月結60天)";
	          	else if (trim($CRecord) == "B") $CRecordAlt="良(月結30天)";
	          	else if (trim($CRecord) == "C") $CRecordAlt="付款開案";
	          	else if (trim($CRecord) == "D") $CRecordAlt="其他(".$CRecordTxt.")";
			        ?>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">客戶名稱：</td>
			          <td class="h3">
			          	<table width="100%" border="0" cellpadding="0" cellspacing="0">
			          		<tr>
			          			<td>
			          				<div id="CNamePreview" style="display:"><?php echo $CName;?>
						          	<img src="../images/<?php echo $CLevel;?>1.gif" alt="<?php echo $CLevelAlt;?>"> 
						          	<img src="../images/<?php echo $CFees;?>1.gif" alt="<?php echo $CFeesAlt;?>"> 
			          				</div></td>
			          			<td>
						          	<input type="hidden" name="CID" value="<?php echo $CID;?>">
						          	<input type="hidden" name="CName" value="<?php echo $CName;?>">
			          			</td>
			          		</tr>
			          	</table>
			          	
			          </td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">客戶電話：</td>
			          <td class="h3">
			          	<table width="100%" border="0" cellpadding="0" cellspacing="0">
			          		<tr>
			          			<td width="150">
			          				<div id="CTelPreview" style="display:"><?php echo $CTel;?></div>
						          	<input type="hidden" name="CTel" value="<?php echo $CTel;?>">
			          			</td>
			          			<td width="60" align="right" class="c3">傳真：</td>
			          			<td>
			          				<div id="CFaxPreview" style="display:"><?php echo $CFax;?></div>
			          				<input type="hidden" name="CFax" value="<?php echo $CFax;?>">
			          			</td>
			          		</tr>
			          	</table>
			          </td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">客戶地址：</td>
			          <td class="h3">
			          	<div id="CAddressPreview" style="display:"><?php echo $CAddress;?></div>
			          	<input type="hidden" name="CAddress" value="<?php echo $CAddress;?>">
			          </td>
			        </tr>
			        <tr height="60" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">連絡人：</td>
			          <td class="h3">
			          	<table width="100%" border="0" cellpadding="0" cellspacing="0">
			          		<tr height="30">
			          			<td width="70" align="right">姓名：</td>
			          			<td width="180"><?php echo $Contact;?></td>
			          			<td width="60" align="right">電話：</td>
			          			<td><?php echo $CMobile;?></td>
			          		</tr>
			          		<tr height="30">
			          			<td width="70" align="right">E-MAil：</td>
			          			<td colspan="3"><?php echo $CEMail;?></td>
			          		</tr>
			          	</table>
			          </td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">產品名稱：</td>
			          <td class="h3"><?php echo $PName;?></td>
			        </tr>
			        <?php if (trim($ModelName) == "") $ModelName = "NA";?>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">主型式：</td>
			          <td class="h3"><?php echo $ModelName;?></td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">系列型式：</td>
			          <td class="h3"><?php echo $SeriesModel;?></td>
			        </tr>
			        <?php
							$SQL_Manager="select MName,MEName from Manager where MUID = '".$BMUID."';";
							$result_Manager=mysqli_query($link,$SQL_Manager) or die ("無法執行查詢");
							list($BMName,$BMEName)=mysqli_fetch_row($result_Manager);
							mysqli_free_result($result_Manager);
			        ?>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">承辦客服：</td>
			          <td class="h3"><?php echo $BMEName.$BMName;?></td>
			        <?php
							//$SQL_Manager="select MName from Manager where Deltag='N' and ISEngineer = 'Y' and MUID = '".$PE."';";
							$SQL_Manager="select MName,MEName from Manager where MUID = '".$PE."';";
							$result_Manager=mysqli_query($link,$SQL_Manager) or die ("無法執行查詢");
							list($MName,$MEName)=mysqli_fetch_row($result_Manager);
							mysqli_free_result($result_Manager);
			        ?>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">案件工程師：</td>
			          <td class="h3"><?php echo $MEName.$MName;?></td>
			        </tr>
					<?php
							//$SQL_Manager="select MName from Manager where Deltag='N' and ISEngineer = 'Y' and MUID = '".$PE."';";
							$SQL_Manager="select MName,MEName from Manager where MUID = '".$test."';";
							$result_Manager=mysqli_query($link,$SQL_Manager) or die ("無法執行查詢");
							list($MName,$MEName)=mysqli_fetch_row($result_Manager);
							mysqli_free_result($result_Manager);
			        ?>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">測試工程師：</td>
			          <td class="h3"><?php echo $MEName.$MName;?></td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">申請項目：</td>
			          <td class="h3"><?php echo $ApplyItem;?></td>
			        </tr>
					<tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">代理商：</td>
			          <td class="h3">
						<?php if($Agent=="RPC1"){echo "全威";}
							  elseif($Agent=="RPC2"){echo "瑞寶";}
							  elseif($Agent=="DIAM"){echo "戴米特";}
							  elseif($Agent=="FCCL"){echo"富士洲股份有限公司";}
						?>
					  </td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">規範：</td>
			          <td class="h3"><?php echo $Canon;?></td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">商品分類號列(C.C.C.Code)：</td>
			          <td class="h3"><?php echo $CCCCode;?></td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">案件開始日期：</td>
			          <td class="h3"><?php echo $StartDate;?></td>
			        </tr>
			        <?php
			        if (trim($PlanDate) == "0000-00-00") $PlanDate = "";
			        ?>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">預計完成時間：</td>
			          <td class="h3"><?php echo $PlanDate;?></td>
			        </tr>
			        <?php
			        if (trim($CloseDate) == "0000-00-00") $CloseDate = "";
			        ?>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">結案日期：</td>
			          <td class="h3"><?php echo $CloseDate;?></td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">案件狀態：</td>
			          <td class="h3">
		          		<?php
		          		if (trim($PStatus) == "A") echo "新開案";
		          		else if (trim($PStatus) == "B") echo "報價中";
		          		else if (trim($PStatus) == "C") echo "案件處理中";
		          		else if (trim($PStatus) == "D") echo "審查中";
		          		else if (trim($PStatus) == "E") echo "補件中";
		          		else if (trim($PStatus) == "F") echo "待印證";
		          		else if (trim($PStatus) == "G") echo "案件取消";
		          		else if (trim($PStatus) == "H") echo "已結案";
		          		?>
			          </td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">本案特別備註：</td>
			          <td class="h3"><?php echo $SNote;?></td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">Safety：</td>
			          <td class="h3"><?php echo $PNote;?></td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">Safety 申請日期：</td>
			          <td class="h3"><?php echo $PNoteDate;?></td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">EMC：</td>
			          <td class="h3"><?php echo $EMC;?></td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">EMC 申請日期：</td>
			          <td class="h3"><?php echo $PADate;?></td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">其他：</td>
			          <td class="h3"><?php echo $POther;?></td>
			        </tr>
							<?php
							if (trim($PStatus) == 'B' || trim($PStatus) == 'C' || trim($PStatus) == 'D' || trim($PStatus) == 'E' || trim($PStatus) == 'F') {
								$SQL_ProjectAccountingAdd="select PAADate,date_format(PAADate,'%Y'),date_format(PAADate,'%m'),date_format(PAADate,'%d'),PAAReason,PAACheck from ProjectAccountingAdd where PID = ".$PID.";";
								$result_ProjectAccountingAdd=mysqli_query($link,$SQL_ProjectAccountingAdd) or die ("無法執行查詢");
								list($PAADate,$PAAYear,$PAAMonth,$PAADay,$PAAReason,$PAACheck)=mysqli_fetch_row($result_ProjectAccountingAdd);
								mysqli_free_result($result_ProjectAccountingAdd);
							?>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3"><b>加測日期：</b></td>
			          <td class="h3"><?php echo $PAADate;?></td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3"><b>加測原因：</b></td>
			          <td class="h3"><?php echo $PAAReason;?></td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3"><b>加測狀態：</b></td>
			          <td class="h3">
			          	<?php
			          	if (trim($PAACheck) == "N") echo "<font color=red>未完成</font>";
			          	else if (trim($PAACheck) == "Y") echo "<font color=blue>已完成</font>";
			          	?>
			         	</td>
			        </tr>
							<?php }?>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">備 註：</td>
			          <td class="h3"><?php echo $PNote1;?></td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">請款狀態：</td>
			          <td class="h3"><?php if (trim($INo) == "") echo "未開發票"; else echo "已開發票";?></td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">請款備註：</td>
			          <td class="h3"><?php echo $InvoiceNote;?></td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">新增人員：</td>
			          <td class="h3"><?php echo $AddUser;?>　<?php echo $AddDate;?></td>
			        </tr>
			        <?php if (trim($ProcUser) != "") {?>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">最後更新：</td>
			          <td class="h3"><?php echo $ProcUser;?>　<?php echo $ProcDate;?></td>
			        </tr>
			        <?php }?>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td class="c3">案件記事：</td>
			          <td class="h3"></td>
			        </tr>
			        <tr height="40" align="center">
			          <td colspan="2" class="h3">
			          	<IFRAME marginWidth="0" marginHeight="0" src="ProjectNote.php?PID=<?php echo $PID;?>" frameBorder="1" width="100%" scrolling="yes" height=250></IFRAME> 
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td class="c3">樣品記錄：</td>
			          <td class="h3"></td>
			        </tr>
			        <tr height="40" align="center">
			          <td colspan="2" class="h3">
			          	<IFRAME marginWidth="0" marginHeight="0" src="ProjectSample.php?PID=<?php echo $PID;?>" frameBorder="1" width="100%" scrolling="yes" height=250></IFRAME> 
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td class="c3">案件証書：</td>
			          <td class="h3"></td>
			        </tr>
			        <tr height="40" align="center">
			          <td colspan="2" class="h3">
			          	<IFRAME marginWidth="0" marginHeight="0" src="ProjectCertificate.php?PID=<?php echo $PID;?>" frameBorder="1" width="100%" scrolling="yes" height=250></IFRAME> 
			        </tr>
			        <tr height="40" align="center">
			          <td colspan="2" class="h3"><input type="button" name="button" class="input_bot" value="回 列 表" onclick="javascript:location.href='ProjectList.php?page=<?php echo $page;?>&QPStatus=<?php echo $QPStatus;?>&QPE=<?php echo $QPE;?>&QBMUID=<?php echo $QBMUID;?>&ISINo=<?php echo $ISINo;?>&ISAdd=<?php echo $ISAdd;?>&KeyWord=<?php echo urlencode($KeyWord);?>';"></td>
			        </tr>
				      </form>
			      </table>
    			</td>
    		</tr>
    	</table>
    </td>
	</tr>
</table>
<?php include "down.php";?>
</body>
</html>
<?php
mysqli_close($link);
?>