﻿<?php
include "CheckPermission.php";
include "CheckMVac.php";
include "../global.php";
require_once 'PHPExcel.php';

$SqlTxt="";
$QPCSDate = empty($_POST['QPCSDate'])?"":$_POST['QPCSDate'];
if (trim($QPCSDate) == "") $QPCSDate = empty($_GET['QPCSDate'])?"":$_GET['QPCSDate'];
$QPCEDate = empty($_POST['QPCEDate'])?"":$_POST['QPCEDate'];
if (trim($QPCEDate) == "") $QPCEDate = empty($_GET['QPCEDate'])?"":$_GET['QPCEDate'];
if (trim($QPCSDate) == "") {
		$QPCSYear = $_POST['QPCSYear'];
		$QPCSMonth = $_POST['QPCSMonth'];
		$QPCSDay = $_POST['QPCSDay'];
		if (trim($QPCSYear) != "" || trim($QPCSMonth) != "" || trim($QPCSDay) != "") if (checkdate($QPCSMonth,$QPCSDay ,$QPCSYear)) $QPCSDate = $QPCSYear."-".$QPCSMonth."-".$QPCSDay;
		}
if (trim($QPCEDate) == "") {
		$QPCEYear = $_POST['QPCEYear'];
		$QPCEMonth = $_POST['QPCEMonth'];
		$QPCEDay = $_POST['QPCEDay'];
		if (trim($QPCEYear) != "" || trim($QPCEMonth) != "" || trim($QPCEDay) != "") if (checkdate($QPCEMonth,$QPCEDay ,$QPCEYear)) $QPCEDate = $QPCEYear."-".$QPCEMonth."-".$QPCEDay;
		}
$QPCType = empty($_POST['QPCType'])?"":$_POST['QPCType'];
if (trim($QPCType) == "") $QPCType = empty($_GET['QPCType'])?"":$_GET['QPCType'];
$QPCStatus = empty($_POST['QPCStatus'])?"":$_POST['QPCStatus'];
if (trim($QPCStatus) == "") $QPCStatus = empty($_GET['QPCStatus'])?"":$_GET['QPCStatus'];
$KeyWord = empty($_POST['KeyWord'])?"":$_POST['KeyWord'];
if (trim($KeyWord) == "") $KeyWord = empty($_GET['KeyWord'])?"":$_GET['KeyWord'];
$PCEnd = empty($_POST['PCEnd'])?"":$_POST['PCEnd'];
if (trim($PCEnd) == "") $PCEnd = empty($_GET['PCEnd'])?"":$_GET['PCEnd'];
if (trim($PCEnd) == "1") {
		$QPCSDate="";
		$QPCEDate="";
		$SqlTxt = $SqlTxt." and b.PCEDate='0000-00-00' ";
		}
if (trim($QPCSDate) != "" && trim($QPCEDate) != "") $SqlTxt = $SqlTxt." and (b.PCEDate >= '".$QPCSDate."') and (b.PCEDate <= '".$QPCEDate."') ";
else if (trim($QPCSDate) != "" && trim($QPCEDate) == "") $SqlTxt = $SqlTxt." and (b.PCEDate >= '".$QPCSDate."') ";
else if (trim($QPCSDate) == "" && trim($QPCEDate) != "") $SqlTxt = $SqlTxt." and (b.PCEDate <= '".$QPCEDate."') ";
if (trim($QPCType) != "") $SqlTxt = $SqlTxt." and b.PCType='".$QPCType."' ";
if (trim($QPCStatus) == "A") $SqlTxt = $SqlTxt." and PCEDate >= now( ) AND ISRemind = 'N'";
else if (trim($QPCStatus) == "B") $SqlTxt = $SqlTxt." and PCEDate >= now( ) AND ISRemind = 'Y'";
else if (trim($QPCStatus) == "C") $SqlTxt = $SqlTxt." AND ISRemind = 'Y'";
if (trim($KeyWord) != "") $SqlTxt = $SqlTxt." and (b.PCNo like '%".$KeyWord."%' or b.PCName like '%".$KeyWord."%' or a.CName like '%".$KeyWord."%' or b.RemindNote like '%".$KeyWord."%' or b.PCNote like '%".$KeyWord."%')";

$SQL_ProjectCertificate="select b.PCID,a.PID,b.PCNo,b.PCName,b.PCType,b.PCTypeName,b.PCFile,b.PCSDate,b.PCEDate,b.PCNote,a.PName,a.PE,a.CName,a.PName,a.ModelName,a.SeriesModel,b.ExpireDate,b.ISRemind,b.RemindNote,b.Reminder,b.RemindDate,b.RemindIP from Project a,ProjectCertificate b where a.PID=b.PID and a.Deltag='N' and b.Deltag='N' ".$SqlTxt." order by b.ExpireDate desc;";
$result_ProjectCertificate=mysqli_query($link,$SQL_ProjectCertificate) or die ("無法執行查詢");

$objPHPExcel = new PHPExcel();
$objPHPExcel->setActiveSheetIndex(0);
$objPHPExcel->getActiveSheet()->setCellValue('A1',"編號");
$objPHPExcel->getActiveSheet()->setCellValue('B1',"種類");
$objPHPExcel->getActiveSheet()->setCellValue('C1',"名稱");
$objPHPExcel->getActiveSheet()->setCellValue('D1',"客戶名稱");
$objPHPExcel->getActiveSheet()->setCellValue('E1',"型號");
$objPHPExcel->getActiveSheet()->setCellValue('F1',"相關案件");
$objPHPExcel->getActiveSheet()->setCellValue('G1',"案件工程師");
$objPHPExcel->getActiveSheet()->setCellValue('H1',"有效日期");
$objPHPExcel->getActiveSheet()->setCellValue('I1',"備註");
$objPHPExcel->getActiveSheet()->setCellValue('J1',"是否已提醒");
$objPHPExcel->getActiveSheet()->setCellValue('K1',"提醒備註");
$objPHPExcel->getActiveSheet()->getStyle("A1")->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("B1")->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("C1")->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("D1")->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("E1")->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("F1")->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("G1")->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("H1")->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("I1")->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("J1")->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("K1")->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$Ecount=2;
while(list($PCID,$PID,$PCNo,$PCName,$PCType,$PCTypeName,$PCFile,$PCSDate,$PCEDate,$PCNote,$PName,$PE,$CName,$PName,$ModelName,$SeriesModel,$ExpireDate,$ISRemind,$RemindNote,$Reminder,$RemindDate,$RemindIP)=mysqli_fetch_row($result_ProjectCertificate)){
		$SQL_Manager="SELECT MName,MEName FROM Manager Where Deltag='N' and MUID='".$PE."'";
		$result_Manager=mysqli_query($link,$SQL_Manager) or die ("無法執行查詢");
		list($MName,$MEName)=mysqli_fetch_row($result_Manager);
		mysqli_free_result($result_Manager);
  	if (trim($PCType) == "A") $PCType = "環保標章";
  	else if (trim($PCType) == "B") $PCType = "BSMI證書";
  	else if (trim($PCType) == "C") $PCType = "消防證書";
  	else if (trim($PCType) == "D") $PCType = $PCTypeName;
	
	$objPHPExcel->getActiveSheet()->setCellValue('A'.$Ecount,$PCNo);
	$objPHPExcel->getActiveSheet()->setCellValue('B'.$Ecount,$PCType);
	$objPHPExcel->getActiveSheet()->setCellValue('C'.$Ecount,$PCName);
	$objPHPExcel->getActiveSheet()->setCellValue('D'.$Ecount,$CName);
	$objPHPExcel->getActiveSheet()->setCellValue('E'.$Ecount,$ModelName);
	$objPHPExcel->getActiveSheet()->setCellValue('F'.$Ecount,$PName);
	$objPHPExcel->getActiveSheet()->setCellValue('G'.$Ecount,$MEName.$MName);
	$objPHPExcel->getActiveSheet()->setCellValue('H'.$Ecount,$PCSDate."~".$PCEDate);
	$objPHPExcel->getActiveSheet()->setCellValue('I'.$Ecount,$PCNote);
	$objPHPExcel->getActiveSheet()->setCellValue('J'.$Ecount,$ISRemind);
	$objPHPExcel->getActiveSheet()->setCellValue('K'.$Ecount,$RemindNote);
	$objPHPExcel->getActiveSheet()->getStyle('A'.$Ecount)->getFont()->setSize(12);
	$objPHPExcel->getActiveSheet()->getStyle('B'.$Ecount)->getFont()->setSize(12);
	$objPHPExcel->getActiveSheet()->getStyle('C'.$Ecount)->getFont()->setSize(12);
	$objPHPExcel->getActiveSheet()->getStyle('D'.$Ecount)->getFont()->setSize(12);
	$objPHPExcel->getActiveSheet()->getStyle('E'.$Ecount)->getFont()->setSize(12);
	$objPHPExcel->getActiveSheet()->getStyle('F'.$Ecount)->getFont()->setSize(12);
	$objPHPExcel->getActiveSheet()->getStyle('G'.$Ecount)->getFont()->setSize(12);
	$objPHPExcel->getActiveSheet()->getStyle('H'.$Ecount)->getFont()->setSize(12);
	$objPHPExcel->getActiveSheet()->getStyle('I'.$Ecount)->getFont()->setSize(12);
	$objPHPExcel->getActiveSheet()->getStyle('J'.$Ecount)->getFont()->setSize(12);
	$objPHPExcel->getActiveSheet()->getStyle('K'.$Ecount)->getFont()->setSize(12);
	$Ecount++;
}
mysqli_free_result($result_ProjectCertificate);
mysqli_close($link);

$objPHPExcel->getActiveSheet()->setTitle('ProjectCertificate');

ob_end_clean();

header('Content-Type: application/vnd.ms-excel');
header('Content-Disposition: attachment;filename="ProjectCertificate.xls"');
header('Cache-Control: max-age=0');
$objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel5');
$objWriter->save('php://output');
exit;



?>
