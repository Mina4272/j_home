﻿<?php
$DBUSER="root";
$DBNAME="rpcdb";
$DBPSWD="";
$PageTitle="全威驗證廠商案件查詢平台";
$PageAdminTitle="全威驗證系統管理平台";
//$CryptKey = "VampCryptKeyPrint";

$link = mysqli_connect ("localhost", $DBUSER, $DBPSWD) or die("無法連接資料庫: " . mysql_error( ));  
mysqli_select_db($link,$DBNAME)or die("無法選擇資料庫");

$SQL_select="SET CHARACTER SET utf8";
$result_select=mysqli_query($link,$SQL_select) or die ("無法執行查詢");

$SQL_select="SET NAMES 'utf8'";
$result_select=mysqli_query($link,$SQL_select) or die ("無法執行查詢");
$SQL_ProjectCertificate="select PCID,PCEDate from ProjectCertificate";
$result_ProjectCertificate=mysqli_query($link,$SQL_ProjectCertificate) or die ("無法執行查詢");

if($result_ProjectCertificate){
	while($row = mysqli_fetch_array($result_ProjectCertificate)){
		$PCEDate=$row['PCEDate'];
		if($PCEDate =="0000-00-00"){
			$PCEDate2 = "0000-00-00";
		}else{
			$PCEDate2=date("Y-m-d",strtotime('-6 month',strtotime($PCEDate)));
		}
		echo $PCEDate2;
		$sql_update = "update ProjectCertificate set PCEDate2 = '".$PCEDate2."' where PCID='".$row['PCID']."'";
		$result_update=mysqli_query($link,$sql_update) or die ("無法執行修改");
	}
}


mysqli_close($link);
?>
