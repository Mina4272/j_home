﻿<?php
include "CheckPermission.php";
include "CheckAccountingReport.php";
include "../global.php";
require_once 'PHPExcel.php';

function chk_str($chkstr) {
	$chkstr = str_replace('"','〞',$chkstr);
	return $chkstr;
}

$SqlTxt1 = "";
$QSCADate = "";
$QECADate = "";

$QSCAYear = empty($_POST['QSCAYear'])?"":$_POST['QSCAYear'];
$QSCAMonth = empty($_POST['QSCAMonth'])?"":$_POST['QSCAMonth'];
$QECAYear = empty($_POST['QECAYear'])?"":$_POST['QECAYear'];
$QECAMonth = empty($_POST['QECAMonth'])?"":$_POST['QECAMonth'];
$QCAType = empty($_POST['QCAType'])?"":$_POST['QCAType'];
$KeyWord = empty($_POST['KeyWord'])?"":$_POST['KeyWord'];

if (trim($QCAType) != "") $QqlType = " and CAType='".$QCAType."' ";

if (trim($QSCAYear) != "" && trim($QSCAMonth) != "") {
		$QSCADate = $QSCAYear."-".$QSCAMonth."-01";
		$QSMonth = $QSCAYear."-".$QSCAMonth;
		}
if (trim($QECAYear) != "" && trim($QECAMonth) != "") {
		$QECADate = $QECAYear."-".$QECAMonth."-31";
		$QEMonth = $QECAYear."-".$QECAMonth;
		}

if (trim($QSCADate) != "" && trim($QECADate) != "") {
		$SqlTxt1 = " AND date_format( a.AddDate, '%Y-%m-%d' ) BETWEEN '".$QSCADate."' AND '".$QECADate."' ";
		$SqlTxt2 = " AND CADate BETWEEN '".$QSCADate."' AND '".$QEMonth."-01' ";
		}
else if (trim($QSCADate) != "" && trim($QECADate) == "") {
		$SqlTxt1 = " AND date_format( a.AddDate, '%Y-%m' ) = '".$QSMonth."' ";
		$SqlTxt2 = " AND CADate = '".$QSCADate."' ";
		}
else if (trim($QSCADate) == "" && trim($QECADate) != "") {
		$SqlTxt1 = " AND date_format( a.AddDate, '%Y-%m' ) = '".$QEMonth."' ";
		$SqlTxt2 = " AND CADate = '".$QEMonth."-01' ";
		}

//echo "QSCADate=$QSCADate<br>";
//echo "QECADate=$QECADate<br>";
//exit;
//if (trim($QCAYear) != "" && trim($QCAMonth) != "") {
//		$QMonth = $QCAYear."-".$QCAMonth;
//		$QCADate = $QCAYear."-".$QCAMonth."-01";
//		}

//echo "QCADate=$QCADate<br>";
//if (trim($QCADate) == "") {
//		$QMonth = date("Y-m",mktime());
//		$QCADate = date("Y-m",mktime())."-01";
//		}
							
$SQL_Project="select a.PID,a.PUID,a.CID,a.CName,a.CTel,a.CFax,a.Contact,a.CMobile,a.CEMail,a.CAddress,a.PStatus,a.PName,a.ModelName,a.SeriesModel,a.PE,a.Quote,a.ApplyItem,a.Canon,a.SNote,a.PlanDate,a.CloseDate,a.PNote,a.QuoteDate,a.ReturnDate,a.IFlorin,a.OFlorin,a.InvoiceDate,a.InvoiceCUID,(select CUID from Customer where Deltag='N' and CID = a.CID) as CUID,date_format( a.AddDate, '%Y-%m' ) date_month,a.PTax from Project a where a.Deltag='N' ".$SqlTxt1." order by a.PID desc;";
//echo $SQL_Project;
//exit;
$result_Project=mysqli_query($link,$SQL_Project) or die ("無法執行查詢");

$objPHPExcel = new PHPExcel();
$objPHPExcel->setActiveSheetIndex(0);

$objPHPExcel->getActiveSheet()->setCellValue('A1',"所屬月份");
$objPHPExcel->getActiveSheet()->setCellValue('B1', $QSMonth."～".$QEMonth);
$objPHPExcel->getActiveSheet()->setCellValue('C1',"");
$objPHPExcel->getActiveSheet()->setCellValue('D1',"");
$objPHPExcel->getActiveSheet()->setCellValue('E1',"");
$objPHPExcel->getActiveSheet()->setCellValue('F1',"");

$objPHPExcel->getActiveSheet()->getStyle("A1")->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("B1")->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("C1")->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("D1")->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("E1")->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("F1")->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);

$Ecount=2;
$TolCharges=0;
$TolInputCharges=0;
$TolInputChargesTax=0;
$TolOutputCharges=0;
$TolOutputChargesTax=0;
$TitleLine=0;
$SumLine=0;

while(list($PID,$PUID,$CID,$CName,$CTel,$CFax,$Contact,$CMobile,$CEMail,$CAddress,$PStatus,$PName,$ModelName,$SeriesModel,$PE,$Quote,$ApplyItem,$Canon,$SNote,$PlanDate,$CloseDate,$PNote,$QuoteDate,$ReturnDate,$IFlorin,$OFlorin,$PInvoiceDate,$InvoiceCUID,$CUID,$date_month,$PTax)=mysqli_fetch_row($result_Project)){
  	if (trim($ModelName) == "") $ModelName = "NA";
  	if (trim($PStatus) == "A") $PStatus="新開案";
  	else if (trim($PStatus) == "B") $PStatus="報價中";
  	else if (trim($PStatus) == "C") $PStatus="案件處理中";
  	else if (trim($PStatus) == "D") $PStatus="審查中";
  	else if (trim($PStatus) == "E") $PStatus="補件中";
  	else if (trim($PStatus) == "F") $PStatus="待印證";
  	else if (trim($PStatus) == "G") $PStatus="案件取消";
  	else if (trim($PStatus) == "H") $PStatus="已結案";
  	$PName = str_replace('"','〞',$PName);
  	$ApplyItem = str_replace('"','〞',$ApplyItem);
	
	$objPHPExcel->getActiveSheet()->setCellValue('A'.$Ecount,$PUID);
	$objPHPExcel->getActiveSheet()->setCellValue('B'.$Ecount,$PName."-".$ApplyItem);
	$objPHPExcel->getActiveSheet()->setCellValue('C'.$Ecount,$CName);
	$objPHPExcel->getActiveSheet()->setCellValue('D'.$Ecount,$PStatus);
	$objPHPExcel->getActiveSheet()->setCellValue('E'.$Ecount,"");
	$objPHPExcel->getActiveSheet()->setCellValue('F'.$Ecount,"");
				
	$objPHPExcel->getActiveSheet()->getStyle('A'.$Ecount)->getFont()->setSize(12);
	$objPHPExcel->getActiveSheet()->getStyle('B'.$Ecount)->getFont()->setSize(12);
	$objPHPExcel->getActiveSheet()->getStyle('C'.$Ecount)->getFont()->setSize(12);
	$objPHPExcel->getActiveSheet()->getStyle('D'.$Ecount)->getFont()->setSize(12);
	$objPHPExcel->getActiveSheet()->getStyle('E'.$Ecount)->getFont()->setSize(12);
	$objPHPExcel->getActiveSheet()->getStyle('F'.$Ecount)->getFont()->setSize(12);
	
	$Ecount++;
		
	$objPHPExcel->getActiveSheet()->setCellValue('A'.$Ecount,"收入/支出");
	$objPHPExcel->getActiveSheet()->setCellValue('B'.$Ecount,"項目");
	$objPHPExcel->getActiveSheet()->setCellValue('C'.$Ecount,"費用");
	$objPHPExcel->getActiveSheet()->setCellValue('D'.$Ecount,"稅金");
	$objPHPExcel->getActiveSheet()->setCellValue('E'.$Ecount,"匯率");
	$objPHPExcel->getActiveSheet()->setCellValue('F'.$Ecount,"外幣別");
	$objPHPExcel->getActiveSheet()->setCellValue('G'.$Ecount,"外幣費用");
	$objPHPExcel->getActiveSheet()->setCellValue('H'.$Ecount,"狀態");
	$objPHPExcel->getActiveSheet()->setCellValue('I'.$Ecount,"時間");
	$objPHPExcel->getActiveSheet()->setCellValue('J'.$Ecount,"發票日期");
	$objPHPExcel->getActiveSheet()->setCellValue('K'.$Ecount,"發票號碼");
	$objPHPExcel->getActiveSheet()->setCellValue('L'.$Ecount,"供應商");
	$objPHPExcel->getActiveSheet()->setCellValue('M'.$Ecount,"備註");
	
	$objPHPExcel->getActiveSheet()->getStyle("A".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
	$objPHPExcel->getActiveSheet()->getStyle("B".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
	$objPHPExcel->getActiveSheet()->getStyle("C".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
	$objPHPExcel->getActiveSheet()->getStyle("D".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
	$objPHPExcel->getActiveSheet()->getStyle("E".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
	$objPHPExcel->getActiveSheet()->getStyle("F".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
	$objPHPExcel->getActiveSheet()->getStyle("G".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
	$objPHPExcel->getActiveSheet()->getStyle("H".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
	$objPHPExcel->getActiveSheet()->getStyle("I".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
	$objPHPExcel->getActiveSheet()->getStyle("J".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
	$objPHPExcel->getActiveSheet()->getStyle("K".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
	$objPHPExcel->getActiveSheet()->getStyle("L".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
	$objPHPExcel->getActiveSheet()->getStyle("M".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
		
	$Ecount++;
	
	$SQL_ProjectAccounting="select PAID,PAMode,PAItem,Charges,Rate,ChargesOther,PATax,PAStatus,PADate,PANote,InvoiceDate,Invoice,CName from ProjectAccounting where Deltag='N' and PID = '".$PID."' and (PAStatus = 'W' or PAStatus = 'S') order by PAMode asc,PAID asc;";
	//echo $SQL_ProjectAccounting;
	//exit;
	$result_ProjectAccounting=mysqli_query($link,$SQL_ProjectAccounting) or die ("無法執行查詢");
	$SumCharges=0;
	$SumInput=0;
	$SumInputTax=0;
	$SumOutput=0;
	$SumOutputTax=0;
  	$PATaxPrice=0;
	$DateMonthI=array();
	$DateMonthITax=array();
	$DateMonthO=array();
	$DateMonthOTax=array();
	while(list($PAID,$PAMode,$PAItem,$Charges,$Rate,$ChargesOther,$PATax,$PAStatus,$PADate,$PANote,$InvoiceDate,$Invoice,$PCName)=mysqli_fetch_row($result_ProjectAccounting)){
	  
		if (trim($PATax) == "") $PATax = $PTax;
			$PATaxPrice=0;
		if (trim($PATax) == "Y") $PATaxPrice = round($Charges*0.05);
		if (trim($PAStatus) == "W") {
			if (trim($PAMode) == "I") $PAStatus="待收"; else if (trim($PAMode) == "O") $PAStatus="未付";
		}
		else if (trim($PAStatus) == "S") $PAStatus="結清";
		else if (trim($PAStatus) == "C") $PAStatus="取消";
		$FlorinTxt="";
		$IFlorin ="";
		$OFlorin ="";
		if (trim($PAMode) == "I") $FlorinTxt=$IFlorin;
		else if (trim($PAMode) == "O") $FlorinTxt=$OFlorin;
				
		if (trim($PAMode) == "I") {
			$SumInput=$SumInput+$Charges;
			if (trim($PATax) == "Y") {
				$SumInputTax = $SumInputTax + round($Charges*0.05);
				$SumCharges=$SumCharges+$Charges;
				$DateMonthI[$date_month]=$DateMonthI[$date_month]+$Charges;
				$DateMonthITax[$date_month]=$DateMonthITax[$date_month]+round($Charges*0.05);
			}
		}
		else if (trim($PAMode) == "O") {
			$SumOutput=$SumOutput+$Charges;
			if (trim($PATax) == "Y") {
				$SumOutputTax = $SumOutputTax + round($Charges*0.05);
				$SumCharges=$SumCharges-$Charges;
				$DateMonthO[$date_month]=$DateMonthO[$date_month]+$Charges;
				$DateMonthOTax[$date_month]=$DateMonthOTax[$date_month]+round($Charges*0.05);
			}
		}
				
		if (trim($PAMode) == "I") $PAMode="收入";
		else if (trim($PAMode) == "O") $PAMode="支出";
			$PAItem = str_replace('"','〞',$PAItem);
		
		$objPHPExcel->getActiveSheet()->setCellValue('A'.$Ecount,$PAMode);
		$objPHPExcel->getActiveSheet()->setCellValue('B'.$Ecount,$PAItem);
		$objPHPExcel->getActiveSheet()->setCellValue('C'.$Ecount,$Charges);
		$objPHPExcel->getActiveSheet()->setCellValue('D'.$Ecount,$PATaxPrice);
		$objPHPExcel->getActiveSheet()->setCellValue('E'.$Ecount,$Rate);
		$objPHPExcel->getActiveSheet()->setCellValue('F'.$Ecount,$FlorinTxt);
		$objPHPExcel->getActiveSheet()->setCellValue('G'.$Ecount,$ChargesOther);
		$objPHPExcel->getActiveSheet()->setCellValue('H'.$Ecount,$PAStatus);
		$objPHPExcel->getActiveSheet()->setCellValue('I'.$Ecount,$PADate);
		$objPHPExcel->getActiveSheet()->setCellValue('J'.$Ecount,$InvoiceDate);
		$objPHPExcel->getActiveSheet()->setCellValue('K'.$Ecount,$Invoice);
		$objPHPExcel->getActiveSheet()->setCellValue('L'.$Ecount,$PCName);;
		$objPHPExcel->getActiveSheet()->setCellValue('M'.$Ecount,chk_str($PANote));
			
		$objPHPExcel->getActiveSheet()->getStyle('A'.$Ecount)->getFont()->setSize(12);
		$objPHPExcel->getActiveSheet()->getStyle('B'.$Ecount)->getFont()->setSize(12);
		$objPHPExcel->getActiveSheet()->getStyle('C'.$Ecount)->getFont()->setSize(12);
		$objPHPExcel->getActiveSheet()->getStyle('D'.$Ecount)->getFont()->setSize(12);
		$objPHPExcel->getActiveSheet()->getStyle('E'.$Ecount)->getFont()->setSize(12);
		$objPHPExcel->getActiveSheet()->getStyle('F'.$Ecount)->getFont()->setSize(12);
		$objPHPExcel->getActiveSheet()->getStyle('G'.$Ecount)->getFont()->setSize(12);
		$objPHPExcel->getActiveSheet()->getStyle('H'.$Ecount)->getFont()->setSize(12);
		$objPHPExcel->getActiveSheet()->getStyle('I'.$Ecount)->getFont()->setSize(12);
		$objPHPExcel->getActiveSheet()->getStyle('J'.$Ecount)->getFont()->setSize(12);
		$objPHPExcel->getActiveSheet()->getStyle('K'.$Ecount)->getFont()->setSize(12);
		$objPHPExcel->getActiveSheet()->getStyle('L'.$Ecount)->getFont()->setSize(12);
		$objPHPExcel->getActiveSheet()->getStyle('M'.$Ecount)->getFont()->setSize(12);
					
		$PATaxPrice=0;
		$Ecount++;	
		
	}
	
mysqli_free_result($result_ProjectAccounting);
		
	$objPHPExcel->getActiveSheet()->setCellValue('A'.$Ecount,"");
	$objPHPExcel->getActiveSheet()->setCellValue('B'.$Ecount,"收入");
	$objPHPExcel->getActiveSheet()->setCellValue('C'.$Ecount,"稅金(收入)");
	$objPHPExcel->getActiveSheet()->setCellValue('D'.$Ecount,"支出");
	$objPHPExcel->getActiveSheet()->setCellValue('E'.$Ecount,"稅金(支出)");
	$objPHPExcel->getActiveSheet()->setCellValue('F'.$Ecount,"小計");
	$objPHPExcel->getActiveSheet()->setCellValue('G'.$Ecount,"");
	$objPHPExcel->getActiveSheet()->setCellValue('H'.$Ecount,"");
	$objPHPExcel->getActiveSheet()->setCellValue('I'.$Ecount,"");
	$objPHPExcel->getActiveSheet()->setCellValue('J'.$Ecount,"");
	$objPHPExcel->getActiveSheet()->setCellValue('K'.$Ecount,"");
	$objPHPExcel->getActiveSheet()->setCellValue('L'.$Ecount,"");
	$objPHPExcel->getActiveSheet()->setCellValue('M'.$Ecount,"");
	
	$objPHPExcel->getActiveSheet()->getStyle("A".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
	$objPHPExcel->getActiveSheet()->getStyle("B".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
	$objPHPExcel->getActiveSheet()->getStyle("C".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
	$objPHPExcel->getActiveSheet()->getStyle("D".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
	$objPHPExcel->getActiveSheet()->getStyle("E".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
	$objPHPExcel->getActiveSheet()->getStyle("F".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
	$objPHPExcel->getActiveSheet()->getStyle("G".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
	$objPHPExcel->getActiveSheet()->getStyle("H".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
	$objPHPExcel->getActiveSheet()->getStyle("I".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
	$objPHPExcel->getActiveSheet()->getStyle("J".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
	$objPHPExcel->getActiveSheet()->getStyle("K".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
	$objPHPExcel->getActiveSheet()->getStyle("L".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
	$objPHPExcel->getActiveSheet()->getStyle("M".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
	
	$Ecount++;
		
	$objPHPExcel->getActiveSheet()->setCellValue('A'.$Ecount,"");
	$objPHPExcel->getActiveSheet()->setCellValue('B'.$Ecount,$SumInput);
	$objPHPExcel->getActiveSheet()->setCellValue('C'.$Ecount,$SumInputTax);
	$objPHPExcel->getActiveSheet()->setCellValue('D'.$Ecount,$SumOutput);
	$objPHPExcel->getActiveSheet()->setCellValue('E'.$Ecount,$SumOutputTax);
	$objPHPExcel->getActiveSheet()->setCellValue('F'.$Ecount,$SumCharges);
	$objPHPExcel->getActiveSheet()->setCellValue('G'.$Ecount,"");
	$objPHPExcel->getActiveSheet()->setCellValue('H'.$Ecount,"");
	$objPHPExcel->getActiveSheet()->setCellValue('I'.$Ecount,"");
	$objPHPExcel->getActiveSheet()->setCellValue('J'.$Ecount,"");
	$objPHPExcel->getActiveSheet()->setCellValue('K'.$Ecount,"");
	$objPHPExcel->getActiveSheet()->setCellValue('L'.$Ecount,"");;
	$objPHPExcel->getActiveSheet()->setCellValue('M'.$Ecount,"");
	
	$objPHPExcel->getActiveSheet()->getStyle('A'.$Ecount)->getFont()->setSize(12);
	$objPHPExcel->getActiveSheet()->getStyle('B'.$Ecount)->getFont()->setSize(12);
	$objPHPExcel->getActiveSheet()->getStyle('C'.$Ecount)->getFont()->setSize(12);
	$objPHPExcel->getActiveSheet()->getStyle('D'.$Ecount)->getFont()->setSize(12);
	$objPHPExcel->getActiveSheet()->getStyle('E'.$Ecount)->getFont()->setSize(12);
	$objPHPExcel->getActiveSheet()->getStyle('F'.$Ecount)->getFont()->setSize(12);
	$objPHPExcel->getActiveSheet()->getStyle('G'.$Ecount)->getFont()->setSize(12);
	$objPHPExcel->getActiveSheet()->getStyle('H'.$Ecount)->getFont()->setSize(12);
	$objPHPExcel->getActiveSheet()->getStyle('I'.$Ecount)->getFont()->setSize(12);
	$objPHPExcel->getActiveSheet()->getStyle('J'.$Ecount)->getFont()->setSize(12);
	$objPHPExcel->getActiveSheet()->getStyle('K'.$Ecount)->getFont()->setSize(12);
	$objPHPExcel->getActiveSheet()->getStyle('L'.$Ecount)->getFont()->setSize(12);
	$objPHPExcel->getActiveSheet()->getStyle('M'.$Ecount)->getFont()->setSize(12);
	
	$TolCharges = $TolCharges + $SumCharges;
	$TolInputCharges = $TolInputCharges + $SumInput;
	$TolInputChargesTax = $TolInputChargesTax + $SumInputTax;
	$TolOutputCharges = $TolOutputCharges + $SumOutput;
	$TolOutputChargesTax = $TolOutputChargesTax + $SumOutputTax;
		
	$Ecount++;
}
mysqli_free_result($result_Project);
		
$objPHPExcel->getActiveSheet()->setCellValue('A'.$Ecount,"一般帳務列表");
$objPHPExcel->getActiveSheet()->setCellValue('B'.$Ecount,"");
$objPHPExcel->getActiveSheet()->setCellValue('C'.$Ecount,"");
$objPHPExcel->getActiveSheet()->setCellValue('D'.$Ecount,"");
$objPHPExcel->getActiveSheet()->setCellValue('E'.$Ecount,"");
$objPHPExcel->getActiveSheet()->setCellValue('F'.$Ecount,"");
$objPHPExcel->getActiveSheet()->setCellValue('G'.$Ecount,"");
$objPHPExcel->getActiveSheet()->setCellValue('H'.$Ecount,"");
$objPHPExcel->getActiveSheet()->setCellValue('I'.$Ecount,"");
$objPHPExcel->getActiveSheet()->setCellValue('J'.$Ecount,"");
$objPHPExcel->getActiveSheet()->setCellValue('K'.$Ecount,"");
$objPHPExcel->getActiveSheet()->setCellValue('L'.$Ecount,"");
$objPHPExcel->getActiveSheet()->setCellValue('M'.$Ecount,"");
	
$objPHPExcel->getActiveSheet()->getStyle("A".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("B".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("C".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("D".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("E".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("F".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("G".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("H".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("I".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("J".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("K".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("L".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("M".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);

$Ecount++;

$objPHPExcel->getActiveSheet()->setCellValue('A'.$Ecount,"項目");
$objPHPExcel->getActiveSheet()->setCellValue('B'.$Ecount,"金額");
$objPHPExcel->getActiveSheet()->setCellValue('C'.$Ecount,"狀態");
$objPHPExcel->getActiveSheet()->setCellValue('D'.$Ecount,"時間");
$objPHPExcel->getActiveSheet()->setCellValue('E'.$Ecount,"備註");
$objPHPExcel->getActiveSheet()->setCellValue('F'.$Ecount,"");
$objPHPExcel->getActiveSheet()->setCellValue('G'.$Ecount,"");
$objPHPExcel->getActiveSheet()->setCellValue('H'.$Ecount,"");
$objPHPExcel->getActiveSheet()->setCellValue('I'.$Ecount,"");
$objPHPExcel->getActiveSheet()->setCellValue('J'.$Ecount,"");
$objPHPExcel->getActiveSheet()->setCellValue('K'.$Ecount,"");
$objPHPExcel->getActiveSheet()->setCellValue('L'.$Ecount,"");
$objPHPExcel->getActiveSheet()->setCellValue('M'.$Ecount,"");
	
$objPHPExcel->getActiveSheet()->getStyle("A".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("B".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("C".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("D".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("E".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("F".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("G".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("H".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("I".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("J".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("K".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("L".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("M".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);

$Ecount++;

$SQL_CommonAccounting="select CAID,CADate,CAItem,Amount,InvoiceDate,Invoice,CAStatus,PayDate,CANote from CommonAccounting where Deltag='N' and (CAStatus = 'W' or CAStatus = 'S') ".$SqlTxt2." order by CAID asc;";
$result_CommonAccounting=mysqli_query($link,$SQL_CommonAccounting) or die ("無法執行查詢");
$SumAmount=0;
while(list($CAID,$CADate,$CAItem,$Amount,$InvoiceDate,$Invoice,$CAStatus,$PayDate,$CANote)=mysqli_fetch_row($result_CommonAccounting)){
	$SumAmount = $SumAmount + $Amount;
	if (trim($PayDate) == "0000-00-00") $PayDate = "";
   	if (trim($CAStatus) == "W") $CAStatus="未付";
   	else if (trim($CAStatus) == "S") $CAStatus="結清";
   	else if (trim($CAStatus) == "C") $CAStatus="取消";
	
	$objPHPExcel->getActiveSheet()->setCellValue('A'.$Ecount,$CAItem);
	$objPHPExcel->getActiveSheet()->setCellValue('B'.$Ecount,$Amount);
	$objPHPExcel->getActiveSheet()->setCellValue('C'.$Ecount,$CAStatus);
	$objPHPExcel->getActiveSheet()->setCellValue('D'.$Ecount,$PayDate);
	$objPHPExcel->getActiveSheet()->setCellValue('E'.$Ecount,$CANote);
	$objPHPExcel->getActiveSheet()->setCellValue('F'.$Ecount,"");
	$objPHPExcel->getActiveSheet()->setCellValue('G'.$Ecount,"");
	$objPHPExcel->getActiveSheet()->setCellValue('H'.$Ecount,"");
	$objPHPExcel->getActiveSheet()->setCellValue('I'.$Ecount,"");
	$objPHPExcel->getActiveSheet()->setCellValue('J'.$Ecount,"");
	$objPHPExcel->getActiveSheet()->setCellValue('K'.$Ecount,"");
	$objPHPExcel->getActiveSheet()->setCellValue('L'.$Ecount,"");;
	$objPHPExcel->getActiveSheet()->setCellValue('M'.$Ecount,"");
	
	$objPHPExcel->getActiveSheet()->getStyle('A'.$Ecount)->getFont()->setSize(12);
	$objPHPExcel->getActiveSheet()->getStyle('B'.$Ecount)->getFont()->setSize(12);
	$objPHPExcel->getActiveSheet()->getStyle('C'.$Ecount)->getFont()->setSize(12);
	$objPHPExcel->getActiveSheet()->getStyle('D'.$Ecount)->getFont()->setSize(12);
	$objPHPExcel->getActiveSheet()->getStyle('E'.$Ecount)->getFont()->setSize(12);
	$objPHPExcel->getActiveSheet()->getStyle('F'.$Ecount)->getFont()->setSize(12);
	$objPHPExcel->getActiveSheet()->getStyle('G'.$Ecount)->getFont()->setSize(12);
	$objPHPExcel->getActiveSheet()->getStyle('H'.$Ecount)->getFont()->setSize(12);
	$objPHPExcel->getActiveSheet()->getStyle('I'.$Ecount)->getFont()->setSize(12);
	$objPHPExcel->getActiveSheet()->getStyle('J'.$Ecount)->getFont()->setSize(12);
	$objPHPExcel->getActiveSheet()->getStyle('K'.$Ecount)->getFont()->setSize(12);
	$objPHPExcel->getActiveSheet()->getStyle('L'.$Ecount)->getFont()->setSize(12);
	$objPHPExcel->getActiveSheet()->getStyle('M'.$Ecount)->getFont()->setSize(12);

$Ecount++;

}
mysqli_free_result($result_CommonAccounting);

$objPHPExcel->getActiveSheet()->setCellValue('A'.$Ecount,"小計");
$objPHPExcel->getActiveSheet()->setCellValue('B'.$Ecount,$SumAmount);
$objPHPExcel->getActiveSheet()->setCellValue('C'.$Ecount,"");
$objPHPExcel->getActiveSheet()->setCellValue('D'.$Ecount,"");
$objPHPExcel->getActiveSheet()->setCellValue('E'.$Ecount,"");
$objPHPExcel->getActiveSheet()->setCellValue('F'.$Ecount,"");
$objPHPExcel->getActiveSheet()->setCellValue('G'.$Ecount,"");
$objPHPExcel->getActiveSheet()->setCellValue('H'.$Ecount,"");
$objPHPExcel->getActiveSheet()->setCellValue('I'.$Ecount,"");
$objPHPExcel->getActiveSheet()->setCellValue('J'.$Ecount,"");
$objPHPExcel->getActiveSheet()->setCellValue('K'.$Ecount,"");
$objPHPExcel->getActiveSheet()->setCellValue('L'.$Ecount,"");
$objPHPExcel->getActiveSheet()->setCellValue('M'.$Ecount,"");
	
$objPHPExcel->getActiveSheet()->getStyle("A".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("B".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("C".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("D".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("E".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("F".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("G".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("H".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("I".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("J".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("K".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("L".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("M".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);

$Ecount++;

foreach($DateMonthI as $key => $value) {

	$objPHPExcel->getActiveSheet()->setCellValue('A'.$Ecount,$key."收入小計");
	$objPHPExcel->getActiveSheet()->setCellValue('B'.$Ecount,$DateMonthI[$key]);
	$objPHPExcel->getActiveSheet()->setCellValue('C'.$Ecount,$DateMonthITax[$key]);
	$objPHPExcel->getActiveSheet()->setCellValue('D'.$Ecount,$DateMonthO[$key]);
	$objPHPExcel->getActiveSheet()->setCellValue('E'.$Ecount,$DateMonthOTax[$key]);
	$objPHPExcel->getActiveSheet()->setCellValue('F'.$Ecount,($DateMonthI[$key]-$DateMonthO[$key]));
	$objPHPExcel->getActiveSheet()->setCellValue('G'.$Ecount,"");
	$objPHPExcel->getActiveSheet()->setCellValue('H'.$Ecount,"");
	$objPHPExcel->getActiveSheet()->setCellValue('I'.$Ecount,"");
	$objPHPExcel->getActiveSheet()->setCellValue('J'.$Ecount,"");
	$objPHPExcel->getActiveSheet()->setCellValue('K'.$Ecount,"");
	$objPHPExcel->getActiveSheet()->setCellValue('L'.$Ecount,"");
	$objPHPExcel->getActiveSheet()->setCellValue('M'.$Ecount,"");
		
	$objPHPExcel->getActiveSheet()->getStyle("A".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
	$objPHPExcel->getActiveSheet()->getStyle("B".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
	$objPHPExcel->getActiveSheet()->getStyle("C".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
	$objPHPExcel->getActiveSheet()->getStyle("D".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
	$objPHPExcel->getActiveSheet()->getStyle("E".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
	$objPHPExcel->getActiveSheet()->getStyle("F".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
	$objPHPExcel->getActiveSheet()->getStyle("G".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
	$objPHPExcel->getActiveSheet()->getStyle("H".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
	$objPHPExcel->getActiveSheet()->getStyle("I".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
	$objPHPExcel->getActiveSheet()->getStyle("J".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
	$objPHPExcel->getActiveSheet()->getStyle("K".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
	$objPHPExcel->getActiveSheet()->getStyle("L".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
	$objPHPExcel->getActiveSheet()->getStyle("M".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);

	$Ecount++;
}
$Ecount++;

$objPHPExcel->getActiveSheet()->setCellValue('A'.$Ecount,"收入小計");
$objPHPExcel->getActiveSheet()->setCellValue('B'.$Ecount,$TolInputCharges);
$objPHPExcel->getActiveSheet()->setCellValue('C'.$Ecount,$TolInputChargesTax);
$objPHPExcel->getActiveSheet()->setCellValue('D'.$Ecount,$TolOutputCharges);
$objPHPExcel->getActiveSheet()->setCellValue('E'.$Ecount,$TolOutputChargesTax);
$objPHPExcel->getActiveSheet()->setCellValue('F'.$Ecount,$TolCharges);
$objPHPExcel->getActiveSheet()->setCellValue('G'.$Ecount,"");
$objPHPExcel->getActiveSheet()->setCellValue('H'.$Ecount,"");
$objPHPExcel->getActiveSheet()->setCellValue('I'.$Ecount,"");
$objPHPExcel->getActiveSheet()->setCellValue('J'.$Ecount,"");
$objPHPExcel->getActiveSheet()->setCellValue('K'.$Ecount,"");
$objPHPExcel->getActiveSheet()->setCellValue('L'.$Ecount,"");
$objPHPExcel->getActiveSheet()->setCellValue('M'.$Ecount,"");
		
$objPHPExcel->getActiveSheet()->getStyle("A".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("B".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("C".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("D".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("E".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("F".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("G".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("H".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("I".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("J".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("K".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("L".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("M".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);

$Ecount++;

$objPHPExcel->getActiveSheet()->setCellValue('A'.$Ecount,"支出小計");
$objPHPExcel->getActiveSheet()->setCellValue('B'.$Ecount,"");
$objPHPExcel->getActiveSheet()->setCellValue('C'.$Ecount,"");
$objPHPExcel->getActiveSheet()->setCellValue('D'.$Ecount,"");
$objPHPExcel->getActiveSheet()->setCellValue('E'.$Ecount,"");
$objPHPExcel->getActiveSheet()->setCellValue('F'.$Ecount,$SumAmount);
$objPHPExcel->getActiveSheet()->setCellValue('G'.$Ecount,"");
$objPHPExcel->getActiveSheet()->setCellValue('H'.$Ecount,"");
$objPHPExcel->getActiveSheet()->setCellValue('I'.$Ecount,"");
$objPHPExcel->getActiveSheet()->setCellValue('J'.$Ecount,"");
$objPHPExcel->getActiveSheet()->setCellValue('K'.$Ecount,"");
$objPHPExcel->getActiveSheet()->setCellValue('L'.$Ecount,"");
$objPHPExcel->getActiveSheet()->setCellValue('M'.$Ecount,"");
		
$objPHPExcel->getActiveSheet()->getStyle("A".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("B".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("C".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("D".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("E".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("F".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("G".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("H".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("I".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("J".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("K".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("L".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("M".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);

$Ecount++;
		
$objPHPExcel->getActiveSheet()->setCellValue('A'.$Ecount,"總計");
$objPHPExcel->getActiveSheet()->setCellValue('B'.$Ecount,"");
$objPHPExcel->getActiveSheet()->setCellValue('C'.$Ecount,"");
$objPHPExcel->getActiveSheet()->setCellValue('D'.$Ecount,"");
$objPHPExcel->getActiveSheet()->setCellValue('E'.$Ecount,"");
$objPHPExcel->getActiveSheet()->setCellValue('F'.$Ecount,$TolCharges-$SumAmount);
$objPHPExcel->getActiveSheet()->setCellValue('G'.$Ecount,"");
$objPHPExcel->getActiveSheet()->setCellValue('H'.$Ecount,"");
$objPHPExcel->getActiveSheet()->setCellValue('I'.$Ecount,"");
$objPHPExcel->getActiveSheet()->setCellValue('J'.$Ecount,"");
$objPHPExcel->getActiveSheet()->setCellValue('K'.$Ecount,"");
$objPHPExcel->getActiveSheet()->setCellValue('L'.$Ecount,"");
$objPHPExcel->getActiveSheet()->setCellValue('M'.$Ecount,"");
		
$objPHPExcel->getActiveSheet()->getStyle("A".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("B".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("C".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("D".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("E".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("F".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("G".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("H".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("I".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("J".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("K".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("L".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("M".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);

$Ecount++;

$objPHPExcel->getActiveSheet()->setCellValue('A'.$Ecount,"客戶收支統計");
$objPHPExcel->getActiveSheet()->setCellValue('B'.$Ecount,"");
$objPHPExcel->getActiveSheet()->setCellValue('C'.$Ecount,"");
$objPHPExcel->getActiveSheet()->setCellValue('D'.$Ecount,"");
$objPHPExcel->getActiveSheet()->setCellValue('E'.$Ecount,"");
$objPHPExcel->getActiveSheet()->setCellValue('F'.$Ecount,"");
$objPHPExcel->getActiveSheet()->setCellValue('G'.$Ecount,"");
$objPHPExcel->getActiveSheet()->setCellValue('H'.$Ecount,"");
$objPHPExcel->getActiveSheet()->setCellValue('I'.$Ecount,"");
$objPHPExcel->getActiveSheet()->setCellValue('J'.$Ecount,"");
$objPHPExcel->getActiveSheet()->setCellValue('K'.$Ecount,"");
$objPHPExcel->getActiveSheet()->setCellValue('L'.$Ecount,"");
$objPHPExcel->getActiveSheet()->setCellValue('M'.$Ecount,"");
		
$objPHPExcel->getActiveSheet()->getStyle("A".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("B".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("C".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("D".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("E".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("F".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("G".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("H".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("I".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("J".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("K".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("L".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("M".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);

$SQL="SELECT a.CID, a.CName, b.PAMode, ifnull( sum( b.Charges ) , 0 ) Charges
									FROM Project a, ProjectAccounting b
									WHERE a.PID = b.PID
									AND a.Deltag = 'N'
									AND b.Deltag = 'N'
									AND (
									b.PAStatus = 'W'
									OR b.PAStatus = 'S'
									)
									$SqlTxt1
									GROUP BY a.CID, a.CName, b.PAMode";
echo $SQL;
//exit;
$result=mysqli_query($link,$SQL) or die ("無法執行查詢");
$PaccArr=array();
while(list($CID,$CName,$PAMode,$Charges)=mysqli_fetch_row($result)){
	$PaccArr['CName']=$CName;
	$PaccArr['Charges'."_".$PAMode]=$PaccArr['Charges'."_".$PAMode]+$Charges;
}
print_r($PaccArr);
exit;
mysqli_free_result($result);

$Ecount++;

$objPHPExcel->getActiveSheet()->setCellValue('A'.$Ecount,"客戶名稱");
$objPHPExcel->getActiveSheet()->setCellValue('B'.$Ecount,"收入");
$objPHPExcel->getActiveSheet()->setCellValue('C'.$Ecount,"所佔收入比例");
$objPHPExcel->getActiveSheet()->setCellValue('D'.$Ecount,"支出");
$objPHPExcel->getActiveSheet()->setCellValue('E'.$Ecount,"所佔支出比例");
$objPHPExcel->getActiveSheet()->setCellValue('F'.$Ecount,"");
$objPHPExcel->getActiveSheet()->setCellValue('G'.$Ecount,"");
$objPHPExcel->getActiveSheet()->setCellValue('H'.$Ecount,"");
$objPHPExcel->getActiveSheet()->setCellValue('I'.$Ecount,"");
$objPHPExcel->getActiveSheet()->setCellValue('J'.$Ecount,"");
$objPHPExcel->getActiveSheet()->setCellValue('K'.$Ecount,"");
$objPHPExcel->getActiveSheet()->setCellValue('L'.$Ecount,"");
$objPHPExcel->getActiveSheet()->setCellValue('M'.$Ecount,"");
		
$objPHPExcel->getActiveSheet()->getStyle("A".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("B".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("C".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("D".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("E".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("F".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("G".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("H".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("I".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("J".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("K".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("L".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("M".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);

$Charges_I_Tol=0;
$Charges_O_Tol=0;
foreach ($PaccArr as $key=>$val) {
	$Charges_I_Tol=$Charges_I_Tol+$PaccArr[$key]['Charges_I'];
	$Charges_O_Tol=$Charges_O_Tol+$PaccArr[$key]['Charges_O'];
}
foreach ($PaccArr as $key=>$val) {
	
	$Ecount++;
				
	$objPHPExcel->getActiveSheet()->setCellValue('A'.$Ecount,$PaccArr[$key]['CName']);
	$objPHPExcel->getActiveSheet()->setCellValue('B'.$Ecount,$PaccArr[$key]['Charges_I']);
	$objPHPExcel->getActiveSheet()->setCellValue('C'.$Ecount,($PaccArr[$key]['Charges_I']/$Charges_I_Tol));
	$objPHPExcel->getActiveSheet()->setCellValue('D'.$Ecount,$PaccArr[$key]['Charges_O']);
	$objPHPExcel->getActiveSheet()->setCellValue('E'.$Ecount,($PaccArr[$key]['Charges_O']/$Charges_O_Tol));
	$objPHPExcel->getActiveSheet()->setCellValue('F'.$Ecount,"");
	$objPHPExcel->getActiveSheet()->setCellValue('G'.$Ecount,"");
	$objPHPExcel->getActiveSheet()->setCellValue('H'.$Ecount,"");
	$objPHPExcel->getActiveSheet()->setCellValue('I'.$Ecount,"");
	$objPHPExcel->getActiveSheet()->setCellValue('J'.$Ecount,"");
	$objPHPExcel->getActiveSheet()->setCellValue('K'.$Ecount,"");
	$objPHPExcel->getActiveSheet()->setCellValue('L'.$Ecount,"");;
	$objPHPExcel->getActiveSheet()->setCellValue('M'.$Ecount,"");
	
	$objPHPExcel->getActiveSheet()->getStyle('A'.$Ecount)->getFont()->setSize(12);
	$objPHPExcel->getActiveSheet()->getStyle('B'.$Ecount)->getFont()->setSize(12);
	$objPHPExcel->getActiveSheet()->getStyle('C'.$Ecount)->getFont()->setSize(12);
	$objPHPExcel->getActiveSheet()->getStyle('D'.$Ecount)->getFont()->setSize(12);
	$objPHPExcel->getActiveSheet()->getStyle('E'.$Ecount)->getFont()->setSize(12);
	$objPHPExcel->getActiveSheet()->getStyle('F'.$Ecount)->getFont()->setSize(12);
	$objPHPExcel->getActiveSheet()->getStyle('G'.$Ecount)->getFont()->setSize(12);
	$objPHPExcel->getActiveSheet()->getStyle('H'.$Ecount)->getFont()->setSize(12);
	$objPHPExcel->getActiveSheet()->getStyle('I'.$Ecount)->getFont()->setSize(12);
	$objPHPExcel->getActiveSheet()->getStyle('J'.$Ecount)->getFont()->setSize(12);
	$objPHPExcel->getActiveSheet()->getStyle('K'.$Ecount)->getFont()->setSize(12);
	$objPHPExcel->getActiveSheet()->getStyle('L'.$Ecount)->getFont()->setSize(12);
	$objPHPExcel->getActiveSheet()->getStyle('M'.$Ecount)->getFont()->setSize(12);
}
$Ecount++;

$objPHPExcel->getActiveSheet()->setTitle('FinancialReportExport');

ob_end_clean();

header('Content-Type: application/vnd.ms-excel');
header('Content-Disposition: attachment;filename="FinancialReportExport.xls"');
header('Cache-Control: max-age=0');
$objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel5');
$objWriter->save('php://output');
exit;


?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $PageAdminTitle;?></title>
<link href="style.css" rel="stylesheet" type="text/css" />
<body>
<table winth="1000" border="0">
	<tr>
		<td colspan="2"><font color=blue>若您無法正常觀看此報表！請下載此 <a href="owc11.zip" target="_File"><font color=red><b>元件</b></font></a> <font color=blue>安裝至您的電腦。</font></td>
	</tr>
</table>
<object id=ProjectAccounting classid=CLSID:0002E559-0000-0000-C000-000000000046 style="width:100%;height:90%"></object>
<script language=vbscript>
	Sub Window_OnLoad()
	Set chConstants = ProjectAccounting.Constants
	ProjectAccounting.ActiveSheet.Cells.Clear
	ProjectAccounting.Worksheets(1).Select
	ProjectAccounting.ActiveSheet.Name ="ProjectAccounting"

	ProjectAccounting.ActiveSheet.Cells(1,1).Value ="所屬月份"
	ProjectAccounting.ActiveSheet.Cells(1,2).Value ="<?php echo $QSMonth;?> ～ <?php echo $QEMonth;?>"
	ProjectAccounting.ActiveSheet.Cells(1,3).Value =""
	ProjectAccounting.ActiveSheet.Cells(1,4).Value =""
	ProjectAccounting.ActiveSheet.Cells(1,5).Value =""
	ProjectAccounting.ActiveSheet.Cells(1,6).Value =""
<?php  
$ECount=2;
$TolCharges=0;
$TolInputCharges=0;
$TolInputChargesTax=0;
$TolOutputCharges=0;
$TolOutputChargesTax=0;
$TitleLine=0;
$SumLine=0;
while(list($PID,$PUID,$CID,$CName,$CTel,$CFax,$Contact,$CMobile,$CEMail,$CAddress,$PStatus,$PName,$ModelName,$SeriesModel,$PE,$Quote,$ApplyItem,$Canon,$SNote,$PlanDate,$CloseDate,$PNote,$QuoteDate,$ReturnDate,$IFlorin,$OFlorin,$PInvoiceDate,$InvoiceCUID,$CUID,$date_month,$PTax)=mysqli_fetch_row($result_Project)){
  	if (trim($ModelName) == "") $ModelName = "NA";
  	if (trim($PStatus) == "A") $PStatus="新開案";
  	else if (trim($PStatus) == "B") $PStatus="報價中";
  	else if (trim($PStatus) == "C") $PStatus="案件處理中";
  	else if (trim($PStatus) == "D") $PStatus="審查中";
  	else if (trim($PStatus) == "E") $PStatus="補件中";
  	else if (trim($PStatus) == "F") $PStatus="待印證";
  	else if (trim($PStatus) == "G") $PStatus="案件取消";
  	else if (trim($PStatus) == "H") $PStatus="已結案";
  	$PName = str_replace('"','〞',$PName);
  	$ApplyItem = str_replace('"','〞',$ApplyItem);
		?>
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,1).Value ="<?php echo $PUID;?>"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,2).Value ="<?php echo $PName;?> - <?php echo $ApplyItem;?>"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,3).Value ="<?php echo $CName;?>"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,4).Value ="<?php echo $PStatus;?>"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,5).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,6).Value =""
		<?php
		if (trim($TitleLine) == "") $TitleLine = $ECount;
		else $TitleLine = $TitleLine.",".$ECount;
		$ECount++;
		?>
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,1).Value ="收入/支出"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,2).Value ="項目"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,3).Value ="費用"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,4).Value ="稅金"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,5).Value ="匯率"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,6).Value ="外幣別"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,7).Value ="外幣費用"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,8).Value ="狀態"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,9).Value ="時間"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,10).Value ="發票日期"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,11).Value ="發票號碼"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,12).Value ="供應商"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,13).Value ="備註"
		<?php
		$ECount++;
		$SQL_ProjectAccounting="select PAID,PAMode,PAItem,Charges,Rate,ChargesOther,PATax,PAStatus,PADate,PANote,InvoiceDate,Invoice,CName from ProjectAccounting where Deltag='N' and PID = '".$PID."' and (PAStatus = 'W' or PAStatus = 'S') order by PAMode asc,PAID asc;";
		$result_ProjectAccounting=mysqli_query($link,$SQL_ProjectAccounting) or die ("無法執行查詢");
		$SumCharges=0;
		$SumInput=0;
		$SumInputTax=0;
		$SumOutput=0;
		$SumOutputTax=0;
  	$PATaxPrice=0;
    while(list($PAID,$PAMode,$PAItem,$Charges,$Rate,$ChargesOther,$PATax,$PAStatus,$PADate,$PANote,$InvoiceDate,$Invoice,$PCName)=mysqli_fetch_row($result_ProjectAccounting)){
      	if (trim($PATax) == "") $PATax = $PTax;
      	$PATaxPrice=0;
      	if (trim($PATax) == "Y") $PATaxPrice = round($Charges*0.05);
      	if (trim($PAStatus) == "W") {
      			if (trim($PAMode) == "I") $PAStatus="待收"; else if (trim($PAMode) == "O") $PAStatus="未付";
      			}
      	else if (trim($PAStatus) == "S") $PAStatus="結清";
      	else if (trim($PAStatus) == "C") $PAStatus="取消";
      	$FlorinTxt="";
      	if (trim($PAMode) == "I") $FlorinTxt=$IFlorin;
      	else if (trim($PAMode) == "O") $FlorinTxt=$OFlorin;
      	
      	if (trim($PAMode) == "I") {
      			$SumInput=$SumInput+$Charges;
		      	if (trim($PATax) == "Y") $SumInputTax = $SumInputTax + round($Charges*0.05);
      			$SumCharges=$SumCharges+$Charges;
		      	$DateMonthI[$date_month]=$DateMonthI[$date_month]+$Charges;
		      	$DateMonthITax[$date_month]=$DateMonthITax[$date_month]+round($Charges*0.05);
      			}
      	else if (trim($PAMode) == "O") {
      			$SumOutput=$SumOutput+$Charges;
		      	if (trim($PATax) == "Y") $SumOutputTax = $SumOutputTax + round($Charges*0.05);
      			$SumCharges=$SumCharges-$Charges;
		      	$DateMonthO[$date_month]=$DateMonthO[$date_month]+$Charges;
		      	$DateMonthOTax[$date_month]=$DateMonthOTax[$date_month]+round($Charges*0.05);
      			}
      	
      	if (trim($PAMode) == "I") $PAMode="收入";
      	else if (trim($PAMode) == "O") $PAMode="支出";
				$PAItem = str_replace('"','〞',$PAItem);
				?>
				ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,1).Value ="<?php echo $PAMode;?>"
				ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,2).Value ="<?php echo $PAItem;?>"
				ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,3).Value ="<?php echo $Charges;?>"
				ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,4).Value ="<?php echo $PATaxPrice;?>"
				ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,5).Value ="<?php echo $Rate;?>"
				ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,6).Value ="<?php echo $FlorinTxt;?>"
				ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,7).Value ="<?php echo $ChargesOther;?>"
				ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,8).Value ="<?php echo $PAStatus;?>"
				ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,9).Value ="'<?php echo $PADate;?>"
				ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,10).Value ="'<?php echo $InvoiceDate;?>"
				ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,11).Value ="<?php echo $Invoice;?>"
				ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,12).Value ="<?php echo $PCName;?>"
				ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,13).Value ="<?php echo chk_str($PANote);?>"
				<?php
				$PATaxPrice=0;
				$ECount++;
				}
		mysqli_free_result($result_ProjectAccounting);
		?>
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,1).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,2).Value ="收入"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,3).Value ="稅金(收入)"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,4).Value ="支出"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,5).Value ="稅金(支出)"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,6).Value ="小計"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,7).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,8).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,9).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,10).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,11).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,12).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,13).Value =""
		<?php
		if (trim($SumLine) == "") $SumLine = $ECount;
		else $SumLine = $SumLine.",".$ECount;
		$ECount++;
		?>
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,1).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,2).Value ="<?php echo $SumInput;?>"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,3).Value ="<?php echo $SumInputTax?>"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,4).Value ="<?php echo $SumOutput;?>"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,5).Value ="<?php echo $SumOutputTax?>"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,6).Value ="<?php echo $SumCharges;?>"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,7).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,8).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,9).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,10).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,11).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,12).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,13).Value =""
		<?php
		$TolCharges = $TolCharges + $SumCharges;
		$TolInputCharges = $TolInputCharges + $SumInput;
		$TolInputChargesTax = $TolInputChargesTax + $SumInputTax;
		$TolOutputCharges = $TolOutputCharges + $SumOutput;
		$TolOutputChargesTax = $TolOutputChargesTax + $SumOutputTax;
		if (trim($SumLine) == "") $SumLine = $ECount;
		else $SumLine = $SumLine.",".$ECount;
		
		$ECount++;
		$ECount++;
		}
mysqli_free_result($result_Project);
?>
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,1).Value ="一般帳務列表"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,2).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,3).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,4).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,5).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,6).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,7).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,8).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,9).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,10).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,11).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,12).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,13).Value =""
		<?php
		if (trim($TitleLine) == "") $TitleLine = $ECount;
		else $TitleLine = $TitleLine.",".$ECount;
		$ECount++;
		?>
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,1).Value ="項目"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,2).Value ="金額"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,3).Value ="狀態"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,4).Value ="時間"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,5).Value ="備註"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,6).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,7).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,8).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,9).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,10).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,11).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,12).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,13).Value =""
		<?php
		$ECount++;
		$SQL_CommonAccounting="select CAID,CADate,CAItem,Amount,InvoiceDate,Invoice,CAStatus,PayDate,CANote from CommonAccounting where Deltag='N' and (CAStatus = 'W' or CAStatus = 'S') ".$SqlTxt2." order by CAID asc;";
		$result_CommonAccounting=mysqli_query($link,$SQL_CommonAccounting) or die ("無法執行查詢");
		$SumAmount=0;
		while(list($CAID,$CADate,$CAItem,$Amount,$InvoiceDate,$Invoice,$CAStatus,$PayDate,$CANote)=mysqli_fetch_row($result_CommonAccounting)){
				$SumAmount = $SumAmount + $Amount;
				if (trim($PayDate) == "0000-00-00") $PayDate = "";
      	if (trim($CAStatus) == "W") $CAStatus="未付";
      	else if (trim($CAStatus) == "S") $CAStatus="結清";
      	else if (trim($CAStatus) == "C") $CAStatus="取消";
				?>
				ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,1).Value ="<?php echo $CAItem;?>"
				ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,2).Value ="<?php echo $Amount;?>"
				ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,3).Value ="<?php echo $CAStatus;?>"
				ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,4).Value ="'<?php echo $PayDate;?>"
				ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,5).Value ="<?php echo $CANote;?>"
				ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,6).Value =""
				ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,7).Value =""
				ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,8).Value =""
				ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,9).Value =""
				ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,10).Value =""
				ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,11).Value =""
				ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,12).Value =""
				ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,13).Value =""
				<?php
				$ECount++;
				}
		mysqli_free_result($result_CommonAccounting);
		?>
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,1).Value ="小計"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,2).Value ="<?php echo $SumAmount;?>"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,3).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,4).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,5).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,6).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,7).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,8).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,9).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,10).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,11).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,12).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,13).Value =""
		<?php
		if (trim($SumLine) == "") $SumLine = $ECount;
		else $SumLine = $SumLine.",".$ECount;
		$ECount++;
		$ECount++;
		$ECount++;
		foreach($DateMonthI as $key => $value) {
				?>
				ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,1).Value ="<?php echo $key;?> 收入小計"
				ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,2).Value ="<?php echo $DateMonthI[$key];?>"
				ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,3).Value ="<?php echo $DateMonthITax[$key];?>"
				ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,4).Value ="<?php echo $DateMonthO[$key];?>"
				ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,5).Value ="<?php echo $DateMonthOTax[$key];?>"
				ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,6).Value ="<?php echo ($DateMonthI[$key]-$DateMonthO[$key]);?>"
				ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,7).Value =""
				ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,8).Value =""
				ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,9).Value =""
				ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,10).Value =""
				ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,11).Value =""
				ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,12).Value =""
				ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,13).Value =""
				<?php
				if (trim($SumLine) == "") $SumLine = $ECount;
				else $SumLine = $SumLine.",".$ECount;
				$ECount++;
				}
		$ECount++;
		?>

		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,1).Value ="收入小計"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,2).Value ="<?php echo $TolInputCharges;?>"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,3).Value ="<?php echo $TolInputChargesTax;?>"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,4).Value ="<?php echo $TolOutputCharges;?>"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,5).Value ="<?php echo $TolOutputChargesTax;?>"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,6).Value ="<?php echo $TolCharges;?>"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,7).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,8).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,9).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,10).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,11).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,12).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,13).Value =""
		<?php
		if (trim($SumLine) == "") $SumLine = $ECount;
		else $SumLine = $SumLine.",".$ECount;
		$ECount++;
		?>
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,1).Value ="支出小計"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,2).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,3).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,4).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,5).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,6).Value ="<?php echo $SumAmount;?>"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,7).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,8).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,9).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,10).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,11).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,12).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,13).Value =""
		<?php
		if (trim($SumLine) == "") $SumLine = $ECount;
		else $SumLine = $SumLine.",".$ECount;
		$ECount++;
		?>
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,1).Value ="總計"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,2).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,3).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,4).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,5).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,6).Value ="<?php echo ($TolCharges-$SumAmount);?>"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,7).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,8).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,9).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,10).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,11).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,12).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,13).Value =""
		<?php
		if (trim($SumLine) == "") $SumLine = $ECount;
		else $SumLine = $SumLine.",".$ECount;
		$ECount++;
		$ECount++;
		if (trim($SumLine) == "") $SumLine = $ECount;
		else $SumLine = $SumLine.",".$ECount;
		?>
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,1).Value ="客戶收支統計"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,2).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,3).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,4).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,5).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,6).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,7).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,8).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,9).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,10).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,11).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,12).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,13).Value =""
		<?php
		$SQL="SELECT a.CID, a.CName, b.PAMode, ifnull( sum( b.Charges ) , 0 ) Charges
									FROM Project a, ProjectAccounting b
									WHERE a.PID = b.PID
									AND a.Deltag = 'N'
									AND b.Deltag = 'N'
									AND (
									b.PAStatus = 'W'
									OR b.PAStatus = 'S'
									)
									$SqlTxt1
									GROUP BY a.CID, a.CName, b.PAMode";
		$result=mysqli_query($link,$SQL) or die ("無法執行查詢");
		$PaccArr=array();
		while(list($CID,$CName,$PAMode,$Charges)=mysqli_fetch_row($result)){
				$PaccArr[$CID]['CName']=$CName;
				$PaccArr[$CID]['Charges'."_".$PAMode]=$PaccArr[$CID]['Charges'."_".$PAMode]+$Charges;
				}
		mysqli_free_result($result);
		$ECount++;
		if (trim($SumLine) == "") $SumLine = $ECount;
		else $SumLine = $SumLine.",".$ECount;
		?>
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,1).Value ="客戶名稱"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,2).Value ="收入"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,3).Value ="所佔收入比例"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,4).Value ="支出"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,5).Value ="所佔支出比例"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,6).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,7).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,8).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,9).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,10).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,11).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,12).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,13).Value =""
		<?php
		$Charges_I_Tol=0;
		$Charges_O_Tol=0;
		foreach ($PaccArr as $key=>$val) {
				$Charges_I_Tol=$Charges_I_Tol+$PaccArr[$key]['Charges_I'];
				$Charges_O_Tol=$Charges_O_Tol+$PaccArr[$key]['Charges_O'];
				}
		foreach ($PaccArr as $key=>$val) {
				$ECount++;
				?>
				ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,1).Value ="<?php echo $PaccArr[$key]['CName'];?>"
				ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,2).Value ="<?php echo $PaccArr[$key]['Charges_I'];?>"
				ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,3).Value ="<?php echo ($PaccArr[$key]['Charges_I']/$Charges_I_Tol)?>"
				ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,4).Value ="<?php echo $PaccArr[$key]['Charges_O'];?>"
				ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,5).Value ="<?php echo ($PaccArr[$key]['Charges_O']/$Charges_O_Tol);?>"
				ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,6).Value =""
				ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,7).Value =""
				ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,8).Value =""
				ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,9).Value =""
				ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,10).Value =""
				ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,11).Value =""
				ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,12).Value =""
				ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,13).Value =""
				<?php
				if (trim($SumLine2) == "") $SumLine2 = $ECount;
				else $SumLine2 = $SumLine2.",".$ECount;
				}
		$ECount++;
		?>
		ProjectAccounting.ActiveSheet.Range("A1:L<?php echo $ECount;?>").Font.Color="blue"
		ProjectAccounting.ActiveSheet.Range("A1:L<?php echo $ECount;?>").Font.Name="Courier New"
		ProjectAccounting.ActiveSheet.Range("A1:L<?php echo $ECount;?>").Font.Size="11"
		ProjectAccounting.ActiveSheet.Range("A1:L<?php echo $ECount;?>").Columns.AutoFit
		ProjectAccounting.ActiveSheet.Range("A1:L<?php echo $ECount;?>").NumberFormat ="General"

		ProjectAccounting.ActiveSheet.Range("A<?php echo $ECount;?>:L<?php echo $ECount;?>").Font.Bold=true

		ProjectAccounting.ActiveSheet.Range("A1:I1").Font.Bold=true
		<?php
		$TitleLineArr = str_split(",",$TitleLine);
		$count_i=count($TitleLineArr);
		for ($tmp=0;$tmp<=$count_i-1;$tmp++){
				?>
				ProjectAccounting.ActiveSheet.Range("A<?php echo $TitleLineArr[$tmp];?>:L<?php echo $TitleLineArr[$tmp];?>").Font.Color="#000000"
				ProjectAccounting.ActiveSheet.Range("A<?php echo $TitleLineArr[$tmp];?>:L<?php echo $TitleLineArr[$tmp];?>").Font.Bold=true
				ProjectAccounting.ActiveSheet.Range("A<?php echo $TitleLineArr[$tmp]+1;?>:L<?php echo $TitleLineArr[$tmp]+1;?>").Font.Bold=true
				<?php
				}

		$SumLineArr = split(",",$SumLine);
		$count_i=count($SumLineArr);
		for ($tmp=0;$tmp<=$count_i-1;$tmp++){
				?>
				ProjectAccounting.ActiveSheet.Range("A<?php echo $SumLineArr[$tmp];?>:J<?php echo $SumLineArr[$tmp];?>").Font.Bold=true
				<?php
				}
		$SumLine2Arr = split(",",$SumLine2);
		$count_i=count($SumLine2Arr);
		for ($tmp=0;$tmp<=$count_i-1;$tmp++){
				?>
				ProjectAccounting.ActiveSheet.Range("C<?php echo $SumLine2Arr[$tmp];?>").NumberFormat="0.00%"
				ProjectAccounting.ActiveSheet.Range("E<?php echo $SumLine2Arr[$tmp];?>").NumberFormat="0.00%"
				<?php
				}
		?>
	End Sub
	</script>
</body>
</html>
<?php
mysqli_close($link);
?>