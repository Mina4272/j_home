﻿<?php
include "CheckPermission.php";
include "CheckEmployeePay.php";
include "../global.php";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $PageAdminTitle;?></title>
</head>
<body>
<?php
$EPID = $_POST['EPID'];
$page = $_POST['page'];
$QSEPDate = $_POST['QSEPDate'];
$QEEPDate = $_POST['QEEPDate'];
$KeyWord = $_POST['KeyWord'];

//$Bonus = $_POST['Bonus'];
$Signing = $_POST['Signing'];
$NewBonus = $_POST['NewBonus'];
$YearEnd = $_POST['YearEnd'];
$MidYear = $_POST['MidYear'];
$Disbursement = $_POST['Disbursement'];
$Travel = $_POST['Travel'];
$SigningReturn = $_POST['SigningReturn'];
$NotWorking = $_POST['NotWorking'];
$IncomeTax = $_POST['IncomeTax'];

$Other = $_POST['Other'];
$OtherDesc = $_POST['OtherDesc'];

if (trim($EPID) == "")
		{
		mysqli_close($link);
		?>
		<script type="text/JavaScript">
			<!--
			alert ("您輸入的資料不足，請重新輸入！");
			history.go(-1);
			//-->
		</script>
		<?php
		exit;
		}

$now_time = date("Y-m-d H:i:s",mktime());
$SQL_select="select Salary,Allowance,ELabor,EHealth,Overtime,Transportation1,Transportation2,FullAttendance,Bonus,Physiological,PLeave,SickLeave,EVAmount from EmployeePay where DelTag = 'N' and EPID = '".$EPID."';";
$result_select=mysqli_query($link,$SQL_select) or die ("無法執行查詢");

if (mysqli_num_rows($result_select) == 0)
		{
		mysqli_free_result($result_select);
		mysqli_close($link);
		?>
		<script type="text/JavaScript">
			<!--
			alert ("查無資料，請冾網站管理人員！");
			history.go(-1);
			//-->
		</script>
		<?php
		exit;
		}
list($Salary,$Allowance,$ELabor,$EHealth,$Overtime,$Transportation1,$Transportation2,$FullAttendance,$Bonus,$Physiological,$PLeave,$SickLeave,$EVAmount)=mysqli_fetch_row($result_select);
mysqli_free_result($result_select);

$EPay = $Salary + $Allowance - $ELabor - $EHealth + $Overtime + $Transportation1 + $Transportation2 + $FullAttendance- $PLeave - $SickLeave -$Physiological + $Bonus + $Signing + $NewBonus + $YearEnd + $MidYear + $Disbursement + $Travel - $SigningReturn - $NotWorking -$IncomeTax + $Other+$EVAmount;
//$sql_insert = "INSERT INTO EmployeePayHistory(EPID,MID,EPDate,EPay,Salary,Allowance,CLabor,CHealth,ELabor,EHealth,CRetirement,Overtime,Transportation1,Transportation2,Bonus,PLeave,SickLeave,EVAmount,Other,OtherDesc,AddUser,AddDate,AddIP,Deltag,ProcUser,ProcDate,ProcIP,UpdateUser,UpdateDate,UpdateIP) SELECT EPID,MID,EPDate,EPay,Salary,Allowance,CLabor,CHealth,ELabor,EHealth,CRetirement,Overtime,Transportation1,Transportation2,Bonus,PLeave,SickLeave,EVAmount,Other,OtherDesc,AddUser,AddDate,AddIP,Deltag,ProcUser,ProcDate,ProcIP,'".$_SESSION["reg_MUID"]."','".$now_time."','".$_SERVER["REMOTE_ADDR"]."' FROM EmployeePay where DelTag = 'N' and EPID = '".$EPID."';";
//$result_insert=mysqli_query($link,$sql_insert) or die ("無法執行新增");
$sql_update = "update EmployeePay set EPay = '".$EPay."',Signing = '".$Signing."' ,NewBonus = '".$NewBonus."' ,YearEnd = '".$YearEnd."' ,MidYear = '".$MidYear."' , Disbursement= '".$Disbursement."' ,Travel = '".$Travel."' ,SigningReturn = '".$SigningReturn."' ,NotWorking = '".$NotWorking."' ,IncomeTax = '".$IncomeTax."',Other = '".$Other."',OtherDesc = '".$OtherDesc."',ProcUser = '".$_SESSION["reg_MUID"]."',ProcDate = '".$now_time."',ProcIP = '".$_SERVER["REMOTE_ADDR"]."' where DelTag = 'N' and EPID = '".$EPID."';";
$result_update=mysqli_query($link,$sql_update) or die ("無法執行修改");

mysqli_close($link);
?>
<script type="text/JavaScript">
	<!--
	alert ("修改成功！");
	location.href='EmployeePayList.php?page=<?php echo $page;?>&QSEPDate=<?php echo $QSEPDate;?>&QEEPDate=<?php echo $QEEPDate;?>&KeyWord=<?php echo urlencode($KeyWord);?>';
	//-->
</script>

</body>
</html>
