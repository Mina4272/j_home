﻿<?php
include "CheckPermission.php";
include "CheckProject.php";
include "../global.php";
require_once("../include/chinese_party.class.php");
require("class.phpmailer.php");
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $PageAdminTitle;?></title>
</head>
<body>
<?php
$TID = $_GET['TID'];

if (trim($TID) == "")
		{
		mysqli_close($link);
		?>
		<script type="text/JavaScript">
			<!--
			alert ("您輸入的資料不足，請重新輸入！");
			self.close();
			//-->
		</script>
		<?php
		exit;
		}
$SQL="select TDate,TCID,TTitle,Lecturer,TLocation,othertext,TTrain,outtext,THour,TExam,othernote,TFile,TContent,TTrainRecord from Training where Deltag='N' and TID = '".$TID."';";
$result=mysqli_query($link,$SQL) or die ("無法執行查詢");
if (mysqli_num_rows($result) == 0)
		{
		mysqli_free_result($result);
		mysqli_close($link);
		?>
		<SCRIPT language=javascript>
		<!--
		alert ("查無資料，請冾網站管理人員！"); 
		self.close();
		//-->
		</SCRIPT>
		<?php 	
		exit;
		}
list($TDate,$TCID,$TTitle,$Lecturer,$TLocation,$othertext,$TTrain,$outtext,$THour,$TExam,$othernote,$TFile,$TContent,$TTrainRecord)=mysqli_fetch_row($result);
mysqli_free_result($result);

$TDate = date("Y-m-d");
$now_time = date("Y-m-d H:i:s",mktime());


$sql_insert = "insert into Training (TDate,TCID,TTitle,Lecturer,TLocation,othertext,TTrain,outtext,THour,TExam,othernote,TFile,TContent,TTrainRecord,AddUser,AddDate,AddIP) values ('".$TDate."','".$TCID."','".$TTitle."','".$Lecturer."','".$TLocation."','".$othertext."','".$TTrain."','".$outtext."','".$THour."','".$TExam."','".$othernote."','".$TFile."','".$TContent."','".$TTrainRecord."','".$_SESSION["reg_MUID"]."','".$now_time."','".$_SERVER["REMOTE_ADDR"]."');";
$result_insert=mysqli_query($link,$sql_insert) or die ("無法執行新增");



$EMAILFN = "notify.htm";
$subject="全威驗證案件新增通知 ！！";
$fp=fopen($EMAILFN,"r");
$content="";
while($line=fgets($fp,512)){
	$content.=$line;
	}
fclose($fp);

$content = str_replace("{PUID}",$PUID,$content);
$content = str_replace("{PName}",$PName,$content);
$content = str_replace("{ModelName}",$ModelName,$content);
$content = str_replace("{CName}",$CName,$content);
$content = str_replace("{PE}",$MName,$content);

$cconv = new chinese_party();
$content = $cconv->u82tchi($content);
$subject = $cconv->u82tchi($subject);

$mail = new PHPMailer();
$mail->IsSMTP();
$mail->Host     = "127.0.0.1";
$mail->SMTPAuth = true;
$mail->From     = "Benson@rpclab.com";
$mail->FromName = $subject;
$mail->WordWrap = 50;
$mail->IsHTML(true);                               // send as HTML
$mail->CharSet = "big5";
$mail->Subject  = $subject;
$mail->Body     =  $content;
$mail->AddAddress("Benson@rpclab.com","");
$mail->AddReplyTo("Benson@rpclab.com");
if(!$mail->Send())
		{
    //echo "There has been a mail error sending to " . $SendEMail . "<br>";
    //echo "Mailer Error: " . $mail->ErrorInfo . "<br>";
  	}
else
		{
		//echo $SendEMail . " sending !!<br>";
		}
		
$mail->ClearAddresses();
$mail->ClearReplyTos();
$mail->SmtpClose();

mysqli_close($link);
?>
<script type="text/JavaScript">
	<!--
	alert ("複製案件新增成功！");
	self.close();
	//-->
</script>

</body>
</html>
