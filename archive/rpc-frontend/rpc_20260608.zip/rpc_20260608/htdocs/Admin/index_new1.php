<html>

<head>
<meta HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=utf-8">
<title>全威驗證系統管理平台</title>
</head>

<frameset framespacing="0" border="0" frameborder="0" rows="140,*">
	<frame name="header" scrolling="no" noresize target="main" src="top1.php">
	<frame name="main" src="index1.php">
	<noframes>
	<body>
	</body>
	</noframes>
</frameset>

</html>
