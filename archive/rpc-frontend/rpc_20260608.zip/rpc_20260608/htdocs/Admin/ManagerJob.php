﻿<?php
include "CheckPermission.php";
include "../global.php";
include "include/page_function.php";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $PageAdminTitle;?></title>
<link href="../type.css" rel="stylesheet" type="text/css" />
<style type="text/css">
<!--
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
}
-->
</style></head>

<body>
<?php include "top.php";?>
<table width="100%" border="0" cellspacing="0" cellpadding="5">
	<tr>
    <td width="160" height="600" align="left" valign="top">
	<?php include "menu.php";?>
    </td>

	<?php 						
		$MID = $_GET['MID'];	
		//$MName = $_GET['MName'];
		
		$SQL_Manager="select MUID,MName from Manager where MID='".$MID."';";
		$result_Manager=mysqli_query($link,$SQL_Manager) or die ("沒有人!");
		list($MUID,$MName)=mysqli_fetch_row($result_Manager);
		mysqli_free_result($result_Manager);

		//echo strtolower($_SESSION["reg_MUID"]);
		//echo strtolower($MUID);
	?>					

    <td valign="top">
    	<table width="100%" border="0" cellpadding="0" cellspacing="0">
    		<tr>
    			<td>
			    	<table width="750" border="0" cellpadding="0" cellspacing="0">
			    		<tr height="30">
			    			<td class="c2"><?php echo $MName;?> 例行工作</td>
			    		</tr>
			    	</table>
			    	<table width="750" border="0" cellpadding="0" cellspacing="0">
			    		<tr>
			    			<td align="right" class="h3">
			    				<?php if ((trim(strstr($_SESSION["reg_MPer"],'G')) != "") || (strtolower($_SESSION["reg_MUID"]) == strtolower($MUID))){?>
			    					<input type="button" name="add" value="新 增" class="input_bot" onclick="javascript:location.href='ManagerJobAdd.php?MID=<?php echo $MID;?>&MName=<?php echo $MName;?>';">
			    				<?php }?>
								<?php if(strtolower($_SESSION["reg_MUID"]) == strtolower($MUID)){?>
			    					<input type="button" name="change" value="工作內容轉移" class="input_bot" onclick="javascript:location.href='ManagerJobChange.php?MID=<?php echo $MID;?>';">
			    				<?php }?>
			    			</td>
			    			<td width="20"></td>
			    		</tr>
			    	</table>
						<?php
						$page = empty($_GET['page'])?"":$_GET['page'];
						if (trim($page) == "") $page = 1;
						$page_rows=150;  //每頁筆數
						$php_Self = "ManagerJob.php";  //分頁web檔名

						$button_css = "h4";
						$limit_txt =" limit ".(($page-1) * $page_rows).",".$page_rows;
						$url_str = "";
						$Sql_str="select MID,MUID,MPassword,MName,MEName,EmployeeNo,EMail,MIntro,MPer from Manager where Deltag='N' order by MID;";
						//$SQL_Manager="select MID,MUID,MPassword,MName,MEName,EmployeeNo,EMail,MIntro,MPer from Manager where Deltag='N' order by MID desc ".$limit_txt.";";
					
						$SQL_ManagerJob="select a.MJID, a.MJPeriod, a.MJTitle, a.MJDescription, a.MJDeputyID, a.MJNote, b.MName as MJDeputy from ManagerJob as a, Manager as b where a.MJDeputyID=b.MID and a.MID='".$MID."' and a.Deltag='N' order by a.MJID ".$limit_txt.";";						
						//echo $SQL_NamagerJob;
						$result_Manager=mysqli_query($link,$SQL_ManagerJob) or die ("沒有例行工作項目!");
						?>
			    	<table width="750" border="0" cellpadding="5" cellspacing="2" class="s2">
			        <tr align="center">
			          <td width="80" align="center" background="../images/table_bg.gif" class="t21">工作週期</td>
			          <td width="80" align="center" background="../images/table_bg.gif" class="t21">工作名稱</td>
			          <td width="80" background="../images/table_bg.gif" class="t21"> 工作內容</td>
			          <td width="100" background="../images/table_bg.gif" class="t21">代理人</td>
			          <td background="../images/table_bg.gif" class="t21">備 註</td>
		    				<?php if (trim(strstr($_SESSION["reg_MPer"],'G')) != ""){?>
				          <td width="60" background="../images/table_bg.gif" class="t21">查 詢</td>
				          <!--td width="60" background="../images/table_bg.gif" class="t21">刪 除</td-->
		    				<?php } else {?>
				          <td width="60" background="../images/table_bg.gif" class="t21">查 詢</td>
		    				<?php }?>
			        </tr>
		          <?php
		          $tmp = 1;
		          while(list($MJID,$MJPeriod,$MJTitle,$MJDescription,$MJDeputyID,$MJNote, $MJDeputy)=mysqli_fetch_row($result_Manager)){
		        	?>
		        	<tr<?php if ($tmp%2 == 0) echo " bgcolor=\"#F6F6F6\"";?>>
				
				<?php 
					if ($MJPeriod == 'D') echo "<td align='center' class='h3'> 每天</td>";
					if ($MJPeriod == 'W') echo "<td align='center' class='h3'>每周</td>";
					if ($MJPeriod == 'M') echo "<td align='center' class='h3'>每月</td>";
					if ($MJPeriod == 'Y') echo "<td align='center' class='h3'>每年</td>";
					if ($MJPeriod == 'U') echo "<td align='center' class='h3'>不定期</td>";
		
				?>
			          <td align="center" class="h3"><?php echo $MJTitle;?></td>
			          <td align="center" class="h3"><?php echo $MJDescription;?></td>
			          <td align="center" class="h3"><?php echo $MJDeputy;?></td>
			          <td align="center" class="h3"><?php echo $MJNote;?></td>
		    				<?php if (trim(strstr($_SESSION["reg_MPer"],'G')) != ""){?>
				          <td align="center"><input type="button" name="edit" value="查 詢" class="input_bot" onclick="javascript:location.href='ManagerJobDetail.php?MJID=<?php echo $MJID;?>';"></td>
				          <!--td align="center"><input type="button" name="edit" value="刪 除" class="input_bot" onclick="javascript:location.href='ManagerJob.php?MID=<?php echo $MID;?>&page=<?php echo $page;?>';"></td-->
		    				<?php } else {?>
				          <td align="center"><input type="button" name="edit" value="查 詢" class="input_bot" onclick="javascript:location.href='ManagerJobDetail.php?MJID=<?php echo $MJID;?>';"></td>
		    				<?php }?>
			        </tr>
			        <?php
            			$tmp++;
			      			}
            	mysqli_free_result($result_Manager);
			        ?>
			      </table>
			      <table width="750" border="0" cellpadding="5" cellspacing="2" class="s2">
			        <tr align="center">
			          <td bgcolor="#E8F0C2" class="h4"><?php Page_show($Sql_str,$page_rows,$php_Self,$link,$page,$url_str,$button_css);?></td>
			        </tr>
			      </table>
    			</td>
    		</tr>
    	</table>
    </td>
	</tr>
</table>
<?php include "down.php";?>
</body>
</html>
<?php
mysqli_close($link);
?>