<?php
include "CheckPermission.php";
include "../global.php";
include "include/page_function.php";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $PageAdminTitle;?></title>
<link href="../type.css" rel="stylesheet" type="text/css" />
<Script type="text/javascript" language="javascript" src="../script/CheckForm.js"></Script>
<script type="text/JavaScript">
<!--
function SelCustomer(CName) {
		opener.document.form1.KeyWord.value=CName;
		opener.document.form1.submit();
		self.close();
		}
//-->
</script>
</head>

<body>
<table width="770" border="0" align="center" cellpadding="2" cellspacing="0">
  <tr>
    <td align="left"><span class="c2"><b>歷史薪資</b></span>
    </td>
  </tr>
  <tr>
    <td align="left">
		<!--
    	<table width="100%" border="0" cellpadding="0" cellspacing="0">
    		<form name="form1" action="SelCustomerContact.php" method="post">
    		<tr>
    			<td align="left" class="h3">關鍵字：<input type="text" name="KeyWord" size="20"> <input type="submit" name="search" value="查詢"></td>
    		</tr>
    		</form>
    	</table>
		-->
			<?php
		//$SqlTxt ="";
    	//$KeyWord = empty($_POST['KeyWord'])?"":$_POST['KeyWord'];
    	//if (trim($KeyWord) == "") $KeyWord = empty($_GET['KeyWord'])?"":$_GET['KeyWord'];
    	//if (trim($KeyWord) != "") $SqlTxt = $SqlTxt." and (a.CName like '%".$KeyWord."%' or b.Contact like '%".$KeyWord."%' or b.CMobile like '%".$KeyWord."%' or b.CEMail like '%".$KeyWord."%' or b.CNote like '%".$KeyWord."%')";
			$page = empty($_GET['page'])?"":$_GET['page'];
			$MID = $_GET['MID'];
			if (trim($page) == "") $page = 1;
			$page_rows=15;  //每頁筆數
			$php_Self = "SalaryHistory.php";  //分頁web檔名

			$button_css = "h4";
			$limit_txt =" limit ".(($page-1) * $page_rows).",".$page_rows;
			$url_str = "&MID=".urlencode($MID);
			//$url_str="";
			$Sql_str="select EPDate,EPay,Salary,Allowance,FullAttendance,Bonus,CLabor,ELabor,CHealth,EHealth,CRetirement,other from employeepay where Deltag='N' and MID='".$MID."' order by EPDate";
			$Salary="select EPDate,EPay,Salary,Allowance,FullAttendance,Bonus,CLabor,ELabor,CHealth,EHealth,CRetirement,other from employeepay where Deltag='N' and MID='".$MID."' order by EPDate ".$limit_txt;
			//echo $Salary;
			$result_Salary=mysqli_query($link,$Salary) or die ("無法執行查詢");
			?>
    	<table width="100%" border="0" cellpadding="2" cellspacing="2" class="s2">
        <tr align="center" height="40">
          <td width="270" background="../images/table_bg.gif" class="t21">日期</td>
		  <td width="250" background="../images/table_bg.gif" class="t21">實領薪資</td>
          <td width="250" background="../images/table_bg.gif" class="t21">薪資</td>
		  <td width="250" background="../images/table_bg.gif" class="t21">職務加給</td>
		  <td width="250" background="../images/table_bg.gif" class="t21">全勤獎金</td>
		  <td width="250" background="../images/table_bg.gif" class="t21">績效獎金</td>
		  <td width="250" background="../images/table_bg.gif" class="t21">勞保費-公司負擔</td>
		  <td width="250" background="../images/table_bg.gif" class="t21">勞保費-員工負擔</td>
		  <td width="250" background="../images/table_bg.gif" class="t21">健保費-公司負擔</td>
		  <td width="250" background="../images/table_bg.gif" class="t21">健保費-員工負擔</td>
		  <td width="250" background="../images/table_bg.gif" class="t21">勞退公司提撥</td>
		  <td width="250" background="../images/table_bg.gif" class="t21">其他</td>
        </tr>
        <?php
        $tmp = 1;
        while(list($EPDate,$EPay,$Salary,$Allowance,$FullAttendance,$Bonus,$CLabor,$ELabor,$CHealth,$EHealth,$CRetirement,$other)=mysqli_fetch_row($result_Salary)){
      	?>
    	  
	    <tr <?php if ($tmp%2 == 0) echo " bgcolor=\"#F6F6F6\"";?>>
          <td class="h3"><?php echo $EPDate;?></td>
		  <td align="center" class="h3"><?php echo $EPay;?></td>
          <td align="center" class="h3"><?php echo $Salary;?></td>
		  <td align="center" class="h3"><?php echo $Allowance;?></td>
		  <td align="center" class="h3"><?php echo $FullAttendance;?></td>
		  <td align="center" class="h3"><?php echo $Bonus;?></td>
		  <td align="center" class="h3"><?php echo $CLabor;?></td>
		  <td align="center" class="h3"><?php echo $ELabor;?></td>
		  <td align="center" class="h3"><?php echo $CHealth;?></td>
		  <td align="center" class="h3"><?php echo $EHealth;?></td>
		  <td align="center" class="h3"><?php echo $CRetirement;?></td>
		  <td align="center" class="h3"><?php echo $other;?></td>
        </tr>
    		
        <?php
      			$tmp++;
      			}
      	mysqli_free_result($result_Salary);
        ?>
      </table>
      <table width="100%" border="0" cellpadding="2" cellspacing="2" class="s2">
        <tr align="center">
          <td bgcolor="#E8F0C2" class="h4"><?php Page_show($Sql_str,$page_rows,$php_Self,$link,$page,$url_str,$button_css);?></td>
        </tr>
      </table>

    </td>
  </tr>
</table>
</body>
</html>
<?php
mysqli_close($link);
?>