<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="<?php echo $GlobalKeyword;?>">
<title></title>
<link href="css/txt01.css" rel="stylesheet" type="text/css" />
<style type="text/css">
<!--
body {
	margin-top: 0px;
}
-->
</style></head>

<body>
<?php
include "../global.php";
session_start();
$now_time = date ("Y-m-d H:i:s", mktime (date("H"),date("i")-1,date("s"),date("m"),date("d"),date("Y")));
$sql_update = "update Manager set MLoginTime = '".$now_time."' where DelTag = 'N' and MUID = '".$_SESSION["reg_MUID"]."';";
$result_update=mysqli_query($link,$sql_update) or die ("無法執行修改");
session_unset(void);
mysqli_close($link);
?>
<SCRIPT language=javascript>
	<!--
	alert ("登出成功！");
	location.href="login.php";
	//-->
</SCRIPT>
</body>
</html>

