﻿<?php	
include "CheckPermission.php";
include "CheckAccountingReport.php";
include "../global.php";

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $PageAdminTitle;?></title>
<link href="../type.css" rel="stylesheet" type="text/css" />
<style type="text/css">
<!--
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
}
-->
</style>
<Script type="text/javascript" language="javascript" src="../script/CheckForm.js"></Script>
<script type="text/JavaScript">
<!--
function jsCheck() 
		{
		if (jsTrim(document.form1.QSCAYear.value) == "" && jsTrim(document.form1.QSCAMonth.value) == "" && jsTrim(document.form1.QECAYear.value) == "" && jsTrim(document.form1.QECAMonth.value) == "" && jsTrim(document.form1.QCAType.value) == "" && jsTrim(document.form1.KeyWord.value) == "") {
				alert ('您必須輸入查詢條件！');
				document.form1.QSCAYear.focus();
				return false;
				}
		if (jsTrim(document.form1.QSCAYear.value) != "" || jsTrim(document.form1.QSCAMonth.value) != "") if (ChkDate('QSCAYear',document.form1.QSCAYear.value,document.form1.QSCAMonth.value,document.form1.QSCADay.value,'查詢起始月份') == false) return false;
		if (jsTrim(document.form1.QECAYear.value) != "" || jsTrim(document.form1.QECAMonth.value) != "") if (ChkDate('QECAYear',document.form1.QECAYear.value,document.form1.QECAMonth.value,document.form1.QECADay.value,'查詢結束月份') == false) return false;
		if (jsTrim(document.form1.QSCAYear.value) != "" && jsTrim(document.form1.QSCAMonth.value) != "" && jsTrim(document.form1.QSCADay.value) != "" && jsTrim(document.form1.QECAYear.value) != "" && jsTrim(document.form1.QECAMonth.value) != "" && jsTrim(document.form1.QECADay.value) != "") if (CompareDate('QSCAYear',document.form1.QSCAYear.value,document.form1.QSCAMonth.value,document.form1.QSCADay.value,document.form1.QECAYear.value,document.form1.QECAMonth.value,document.form1.QECADay.value,'查詢啟始月份','查詢結束月份') == false) return false;
		}
//-->
</script>
</head>
<body>
<?php include "top.php";?>
<table width="100%" border="0" cellspacing="0" cellpadding="5">
	<tr>
    <td width="160" height="600" align="left" valign="top">
			<?php include "menu.php";?>
    </td>
    <td valign="top">
    	<table width="100%" border="0" cellpadding="0" cellspacing="0">
    		<tr>
    			<td>
			    	<table width="750" border="0" cellpadding="0" cellspacing="0">
			    		<tr height="30">
			    			<td class="c2"><b>公司營收報表</b></td>
			    		</tr>
			    	</table>
			    	<table width="500" border="0" cellpadding="0" cellspacing="0">
			        <form name="form1" method="post" action="FinancialReportExport.php" target="_FinancialReport" onSubmit="return jsCheck();">
			        <tr height="50" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td width="150" align="right" class="c3">請選擇所屬月份：</td>
			          <td colspan="3" class="h3" align="left">
			    				<select name="QSCAYear">
			    					<option value=""></option>
			    					<option value="2008"<?php if (trim(empty($_POST['QSCAYear'])?"":$_POST['QSCAYear']) == "2008") echo " selected";?>>2008</option>
			    					<option value="2009"<?php if (trim(empty($_POST['QSCAYear'])?"":$_POST['QSCAYear']) == "2009") echo " selected";?>>2009</option>
			    					<option value="2010"<?php if (trim(empty($_POST['QSCAYear'])?"":$_POST['QSCAYear']) == "2010") echo " selected";?>>2010</option>
			    					<option value="2011"<?php if (trim(empty($_POST['QSCAYear'])?"":$_POST['QSCAYear']) == "2011") echo " selected";?>>2011</option>
			    					<option value="2012"<?php if (trim(empty($_POST['QSCAYear'])?"":$_POST['QSCAYear']) == "2012") echo " selected";?>>2012</option>
			    					<option value="2013"<?php if (trim(empty($_POST['QSCAYear'])?"":$_POST['QSCAYear']) == "2013") echo " selected";?>>2013</option>
			    					<option value="2014"<?php if (trim(empty($_POST['QSCAYear'])?"":$_POST['QSCAYear']) == "2014") echo " selected";?>>2014</option>
			    					<option value="2015"<?php if (trim(empty($_POST['QSCAYear'])?"":$_POST['QSCAYear']) == "2015") echo " selected";?>>2015</option>
			    					<option value="2016"<?php if (trim(empty($_POST['QSCAYear'])?"":$_POST['QSCAYear']) == "2016") echo " selected";?>>2016</option>
			    					<option value="2017"<?php if (trim(empty($_POST['QSCAYear'])?"":$_POST['QSCAYear']) == "2017") echo " selected";?>>2017</option>
			    					<option value="2018"<?php if (trim(empty($_POST['QSCAYear'])?"":$_POST['QSCAYear']) == "2018") echo " selected";?>>2018</option>
			    					<option value="2019"<?php if (trim(date("Y",mktime())) == "2019" || trim(empty($_POST['QSCAYear'])?"":$_POST['QSCAYear']) == "2019") echo " selected";?>>2019</option>
			    					<option value="2020"<?php if (trim(date("Y",mktime())) == "2020" ||trim(empty($_POST['QSCAYear'])?"":$_POST['QSCAYear']) == "2020") echo " selected";?>>2020</option>
			    					<option value="2021"<?php if (trim(date("Y",mktime())) == "2021" ||trim(empty($_POST['QSCAYear'])?"":$_POST['QSCAYear']) == "2021") echo " selected";?>>2021</option>
			    					<option value="2022"<?php if (trim(date("Y",mktime())) == "2022" ||trim(empty($_POST['QSCAYear'])?"":$_POST['QSCAYear']) == "2022") echo " selected";?>>2022</option>
			    					<option value="2023"<?php if (trim(date("Y",mktime())) == "2023" ||trim(empty($_POST['QSCAYear'])?"":$_POST['QSCAYear']) == "2023") echo " selected";?>>2023</option>
			    					<option value="2024"<?php if (trim(date("Y",mktime())) == "2024" ||trim(empty($_POST['QSCAYear'])?"":$_POST['QSCAYear']) == "2024") echo " selected";?>>2024</option>
			    					<option value="2025"<?php if (trim(date("Y",mktime())) == "2025" ||trim(empty($_POST['QSCAYear'])?"":$_POST['QSCAYear']) == "2025") echo " selected";?>>2025</option>
									<option value="2026"<?php if (trim(date("Y",mktime())) == "2026" ||trim(empty($_POST['QSCAYear'])?"":$_POST['QSCAYear']) == "2026") echo " selected";?>>2026</option>
									<option value="2027"<?php if (trim(date("Y",mktime())) == "2027" ||trim(empty($_POST['QSCAYear'])?"":$_POST['QSCAYear']) == "2027") echo " selected";?>>2027</option>
									<option value="2028"<?php if (trim(date("Y",mktime())) == "2028" ||trim(empty($_POST['QSCAYear'])?"":$_POST['QSCAYear']) == "2028") echo " selected";?>>2028</option>
									<option value="2029"<?php if (trim(date("Y",mktime())) == "2029" ||trim(empty($_POST['QSCAYear'])?"":$_POST['QSCAYear']) == "2029") echo " selected";?>>2029</option>
									<option value="2030"<?php if (trim(date("Y",mktime())) == "2030" ||trim(empty($_POST['QSCAYear'])?"":$_POST['QSCAYear']) == "2030") echo " selected";?>>2030</option>
									<option value="2031"<?php if (trim(date("Y",mktime())) == "2031" ||trim(empty($_POST['QSCAYear'])?"":$_POST['QSCAYear']) == "2031") echo " selected";?>>2031</option>
									<option value="2032"<?php if (trim(date("Y",mktime())) == "2032" ||trim(empty($_POST['QSCAYear'])?"":$_POST['QSCAYear']) == "2032") echo " selected";?>>2032</option>
									<option value="2033"<?php if (trim(date("Y",mktime())) == "2033" ||trim(empty($_POST['QSCAYear'])?"":$_POST['QSCAYear']) == "2033") echo " selected";?>>2033</option>
									<option value="2034"<?php if (trim(date("Y",mktime())) == "2034" ||trim(empty($_POST['QSCAYear'])?"":$_POST['QSCAYear']) == "2034") echo " selected";?>>2034</option>
									<option value="2035"<?php if (trim(date("Y",mktime())) == "2035" ||trim(empty($_POST['QSCAYear'])?"":$_POST['QSCAYear']) == "2035") echo " selected";?>>2035</option>
			    				</select> <font color=blue><b>年</b></font> 
			    				<select name="QSCAMonth">
			    					<option value=""></option>
			    					<option value="01"<?php if (trim(date("m",mktime())) == "01" ||trim(empty($_POST['QSCAMonth'])?"":$_POST['QSCAMonth']) == "01") echo " selected";?>>01</option>
			    					<option value="02"<?php if (trim(date("m",mktime())) == "02" ||trim(empty($_POST['QSCAMonth'])?"":$_POST['QSCAMonth']) == "02") echo " selected";?>>02</option>
			    					<option value="03"<?php if (trim(date("m",mktime())) == "03" ||trim(empty($_POST['QSCAMonth'])?"":$_POST['QSCAMonth']) == "03") echo " selected";?>>03</option>
			    					<option value="04"<?php if (trim(date("m",mktime())) == "04" ||trim(empty($_POST['QSCAMonth'])?"":$_POST['QSCAMonth']) == "04") echo " selected";?>>04</option>
			    					<option value="05"<?php if (trim(date("m",mktime())) == "05" ||trim(empty($_POST['QSCAMonth'])?"":$_POST['QSCAMonth']) == "05") echo " selected";?>>05</option>
			    					<option value="06"<?php if (trim(date("m",mktime())) == "06" ||trim(empty($_POST['QSCAMonth'])?"":$_POST['QSCAMonth']) == "06") echo " selected";?>>06</option>
			    					<option value="07"<?php if (trim(date("m",mktime())) == "07" ||trim(empty($_POST['QSCAMonth'])?"":$_POST['QSCAMonth']) == "07") echo " selected";?>>07</option>
			    					<option value="08"<?php if (trim(date("m",mktime())) == "08" ||trim(empty($_POST['QSCAMonth'])?"":$_POST['QSCAMonth']) == "08") echo " selected";?>>08</option>
			    					<option value="09"<?php if (trim(date("m",mktime())) == "09" ||trim(empty($_POST['QSCAMonth'])?"":$_POST['QSCAMonth']) == "09") echo " selected";?>>09</option>
			    					<option value="10"<?php if (trim(date("m",mktime())) == "10" ||trim(empty($_POST['QSCAMonth'])?"":$_POST['QSCAMonth']) == "10") echo " selected";?>>10</option>
			    					<option value="11"<?php if (trim(date("m",mktime())) == "11" ||trim(empty($_POST['QSCAMonth'])?"":$_POST['QSCAMonth']) == "11") echo " selected";?>>11</option>
			    					<option value="12"<?php if (trim(date("m",mktime())) == "12" ||trim(empty($_POST['QSCAMonth'])?"":$_POST['QSCAMonth']) == "12") echo " selected";?>>12</option>
			    				</select> <font color=blue><b>月</b></font><input type="hidden" name="QSCADay" value="1"> ~ 
			    				<select name="QECAYear">
			    					<option value=""></option>
			    					<option value="2008"<?php if (trim(empty($_POST['QECAYear'])?"":$_POST['QECAYear']) == "2008") echo " selected";?>>2008</option>
			    					<option value="2009"<?php if (trim(empty($_POST['QECAYear'])?"":$_POST['QECAYear']) == "2009") echo " selected";?>>2009</option>
			    					<option value="2010"<?php if (trim(empty($_POST['QECAYear'])?"":$_POST['QECAYear']) == "2010") echo " selected";?>>2010</option>
			    					<option value="2011"<?php if (trim(empty($_POST['QECAYear'])?"":$_POST['QECAYear']) == "2011") echo " selected";?>>2011</option>
			    					<option value="2012"<?php if (trim(empty($_POST['QECAYear'])?"":$_POST['QECAYear']) == "2012") echo " selected";?>>2012</option>
			    					<option value="2013"<?php if (trim(empty($_POST['QECAYear'])?"":$_POST['QECAYear']) == "2013") echo " selected";?>>2013</option>
			    					<option value="2014"<?php if (trim(empty($_POST['QECAYear'])?"":$_POST['QECAYear']) == "2014") echo " selected";?>>2014</option>
			    					<option value="2015"<?php if (trim(empty($_POST['QECAYear'])?"":$_POST['QECAYear']) == "2015") echo " selected";?>>2015</option>
			    					<option value="2016"<?php if (trim(empty($_POST['QECAYear'])?"":$_POST['QECAYear']) == "2016") echo " selected";?>>2016</option>
			    					<option value="2017"<?php if (trim(empty($_POST['QECAYear'])?"":$_POST['QECAYear']) == "2017") echo " selected";?>>2017</option>
			    					<option value="2018"<?php if (trim(empty($_POST['QECAYear'])?"":$_POST['QECAYear']) == "2018") echo " selected";?>>2018</option>
			    					<option value="2019"<?php if (trim(empty($_POST['QECAYear'])?"":$_POST['QECAYear']) == "2019") echo " selected";?>>2019</option>
			    					<option value="2020"<?php if (trim(empty($_POST['QECAYear'])?"":$_POST['QECAYear']) == "2020") echo " selected";?>>2020</option>
			    					<option value="2021"<?php if (trim(empty($_POST['QECAYear'])?"":$_POST['QECAYear']) == "2021") echo " selected";?>>2021</option>
			    					<option value="2022"<?php if (trim(empty($_POST['QECAYear'])?"":$_POST['QECAYear']) == "2022") echo " selected";?>>2022</option>
			    					<option value="2023"<?php if (trim(empty($_POST['QECAYear'])?"":$_POST['QECAYear']) == "2023") echo " selected";?>>2023</option>
			    					<option value="2024"<?php if (trim(empty($_POST['QECAYear'])?"":$_POST['QECAYear']) == "2024") echo " selected";?>>2024</option>
			    					<option value="2025"<?php if (trim(empty($_POST['QECAYear'])?"":$_POST['QECAYear']) == "2025") echo " selected";?>>2025</option>
									<option value="2026"<?php if (trim(empty($_POST['QECAYear'])?"":$_POST['QECAYear']) == "2026") echo " selected";?>>2026</option>
									<option value="2027"<?php if (trim(empty($_POST['QECAYear'])?"":$_POST['QECAYear']) == "2027") echo " selected";?>>2027</option>
									<option value="2028"<?php if (trim(empty($_POST['QECAYear'])?"":$_POST['QECAYear']) == "2028") echo " selected";?>>2028</option>
									<option value="2029"<?php if (trim(empty($_POST['QECAYear'])?"":$_POST['QECAYear']) == "2029") echo " selected";?>>2029</option>
									<option value="2030"<?php if (trim(empty($_POST['QECAYear'])?"":$_POST['QECAYear']) == "2030") echo " selected";?>>2030</option>
									<option value="2031"<?php if (trim(empty($_POST['QECAYear'])?"":$_POST['QECAYear']) == "2031") echo " selected";?>>2031</option>
									<option value="2032"<?php if (trim(empty($_POST['QECAYear'])?"":$_POST['QECAYear']) == "2032") echo " selected";?>>2032</option>
									<option value="2033"<?php if (trim(empty($_POST['QECAYear'])?"":$_POST['QECAYear']) == "2033") echo " selected";?>>2033</option>
									<option value="2034"<?php if (trim(empty($_POST['QECAYear'])?"":$_POST['QECAYear']) == "2034") echo " selected";?>>2034</option>
									<option value="2035"<?php if (trim(empty($_POST['QECAYear'])?"":$_POST['QECAYear']) == "2035") echo " selected";?>>2035</option>
			    				</select> <font color=blue><b>年</b></font> 
			    				<select name="QECAMonth">
			    					<option value=""></option>
			    					<option value="01"<?php if (trim(empty($_POST['QECAMonth'])?"":$_POST['QECAMonth']) == "01") echo " selected";?>>01</option>
			    					<option value="02"<?php if (trim(empty($_POST['QECAMonth'])?"":$_POST['QECAMonth']) == "02") echo " selected";?>>02</option>
			    					<option value="03"<?php if (trim(empty($_POST['QECAMonth'])?"":$_POST['QECAMonth']) == "03") echo " selected";?>>03</option>
			    					<option value="04"<?php if (trim(empty($_POST['QECAMonth'])?"":$_POST['QECAMonth']) == "04") echo " selected";?>>04</option>
			    					<option value="05"<?php if (trim(empty($_POST['QECAMonth'])?"":$_POST['QECAMonth']) == "05") echo " selected";?>>05</option>
			    					<option value="06"<?php if (trim(empty($_POST['QECAMonth'])?"":$_POST['QECAMonth']) == "06") echo " selected";?>>06</option>
			    					<option value="07"<?php if (trim(empty($_POST['QECAMonth'])?"":$_POST['QECAMonth']) == "07") echo " selected";?>>07</option>
			    					<option value="08"<?php if (trim(empty($_POST['QECAMonth'])?"":$_POST['QECAMonth']) == "08") echo " selected";?>>08</option>
			    					<option value="09"<?php if (trim(empty($_POST['QECAMonth'])?"":$_POST['QECAMonth']) == "09") echo " selected";?>>09</option>
			    					<option value="10"<?php if (trim(empty($_POST['QECAMonth'])?"":$_POST['QECAMonth']) == "10") echo " selected";?>>10</option>
			    					<option value="11"<?php if (trim(empty($_POST['QECAMonth'])?"":$_POST['QECAMonth']) == "11") echo " selected";?>>11</option>
			    					<option value="12"<?php if (trim(empty($_POST['QECAMonth'])?"":$_POST['QECAMonth']) == "12") echo " selected";?>>12</option>
			    				</select> <font color=blue><b>月</b></font><input type="hidden" name="QECADay" value="1">
			          </td>
			        </tr>
			    		<!--<tr height="30">
			          <td width="150" align="right" class="c3">類　別：</td>
			    			<td width="100" class="h3">
			          	<select name="QCAType">
			          		<option value="">不限</option>
			          		<option value="C">公司</option>
			          		<option value="P">個人</option>
			          	</select>　
			    			</td>
			          <td width="80" align="right" class="c3">關鍵字：</td>
			    			<td class="h3">
			    				<input type="text" name="KeyWord" size="15">　
			    			</td>
			    		</tr>-->
			        <tr height="40" align="center" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td colspan="4" class="h3"><input type="submit" name="submit" class="input_bot" value="送 出"></td>
			        </tr>
				      </form>
			      </table>
    			</td>
    		</tr>
    	</table>
    </td>
	</tr>
</table>
<?php include "down.php";?>
</body>
</html>
<?php
mysqli_close($link);
?>