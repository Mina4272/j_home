﻿<?php
include "CheckPermission.php";
include "CheckEmployeePay.php";
include "../global.php";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $PageAdminTitle;?></title>
<link href="../type.css" rel="stylesheet" type="text/css" />
<style type="text/css">
<!--
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
}
-->
</style>
<link href="../script/DatePicker.css" rel="stylesheet" type="text/css" />
<Script LANGUAGE="Javascript" SRC="../script/DatePicker.js"></Script>
<Script type="text/javascript" language="javascript" src="../script/CheckForm.js"></Script>
<script type="text/JavaScript">
<!--
function jsCheck() 
		{
		if (jsTrim(document.form1.Bonus.value) != "") if (ChkNaN('Bonus',document.form1.Bonus.value,'績效獎金','') == false) return false;
		if (jsTrim(document.form1.Other.value) != "") if (ChkNaN('Other',document.form1.Other.value,'他項','') == false) return false;
		if (jsTrim(document.form1.Other.value) != "" && jsTrim(document.form1.Other.value) != "0") if (ChkImp('OtherDesc',document.form1.OtherDesc.value,'他項說明','') == false) return false;
		}
//-->
</script>
</head>
<body>
<?php include "top.php";?>
<?php
$EPID = $_GET['EPID'];
$page = $_GET['page'];
$QSEPDate = $_GET['QSEPDate'];
$QEEPDate = $_GET['QEEPDate'];
$KeyWord = $_GET['KeyWord'];
if (trim($EPID) == "")
		{
		mysqli_close($link);
		?>
		<script type="text/JavaScript">
			<!--
			alert ("查無資料，請冾網站管理人員！");
			history.go(-1);
			//-->
		</script>
		<?php
		exit;
		}
$SQL_EmployeePay="select MID,(select MName from Manager where MID = EmployeePay.MID) MName,(select MEName from Manager where MID = EmployeePay.MID) MEName,(select EmployeeNo from Manager where MID=EmployeePay.MID) EmployeeNo,EPDate,date_format(EPDate,'%Y'),date_format(EPDate,'%m'),EPay,Salary,Allowance,CLabor,CHealth,ELabor,EHealth,CRetirement,Overtime,Transportation1,Transportation2,Bonus,PLeave,SickLeave,EVAmount,Other,OtherDesc from EmployeePay where Deltag='N' and EPID = '".$EPID."';";

$result_EmployeePay=mysqli_query($link,$SQL_EmployeePay) or die ("無法執行查詢");
if (mysqli_num_rows($result_EmployeePay) == 0)
		{
		mysqli_free_result($result_EmployeePay);
		mysqli_close($link);
		?>
		<SCRIPT language=javascript>
		<!--
		alert ("查無資料，請冾網站管理人員！"); 
		history.go(-1);
		//-->
		</SCRIPT>
		<?php 	
		exit;
		}
list($MID,$MName,$MEName,$EmployeeNo,$EPDate,$EPYear,$EPMonth,$EPay,$Salary,$Allowance,$CLabor,$CHealth,$ELabor,$EHealth,$CRetirement,$Overtime,$Transportation1,$Transportation2,$Bonus,$PLeave,$SickLeave,$EVAmount,$Other,$OtherDesc)=mysqli_fetch_row($result_EmployeePay);
mysqli_free_result($result_EmployeePay);

?>
<table width="100%" border="0" cellspacing="0" cellpadding="5">
	<tr>
    <td width="160" height="600" align="left" valign="top">
			<?php include "menu.php";?>
    </td>
    <td valign="top">
    	<table width="100%" border="0" cellpadding="0" cellspacing="0">
    		<tr>
    			<td>
			    	<table width="750" border="0" cellpadding="0" cellspacing="0">
			    		<tr height="30">
			    			<td class="c2"><b>修改薪資資料</b></td>
			    		</tr>
			    	</table>
			    	<table width="750" border="0" cellpadding="0" cellspacing="0">
			        <form name="form1" method="post" action="EmployeePayEditDB.php" onSubmit="return jsCheck();">
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td width="180" align="right" class="c3">所屬年月：</td>
			          <td class="h3"><?php echo $EPYear."-".$EPMonth;?>                  
			          	<input type="hidden" name="EPID" value="<?php echo $EPID;?>">
			          	<input type="hidden" name="page" value="<?php echo $page;?>">
			          	<input type="hidden" name="QSEPDate" value="<?php echo $QSEPDate;?>">
			          	<input type="hidden" name="QEEPDate" value="<?php echo $QEEPDate;?>">
			          	<input type="hidden" name="KeyWord" value="<?php echo $KeyWord;?>">
			          </td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">員工編號：</td>
			          <td class="h3"><?php echo $EmployeeNo;?></td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">姓名：</td>
			          <td class="h3"><?php echo $MEName.$MName;?></td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">當月薪資：</td>
			          <td class="h3"><?php echo $EPay;?></td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">本薪：</td>
			          <td class="h3"><?php echo $Salary;?></td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">職務加給：</td>
			          <td class="h3"><?php echo $Allowance;?></td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">勞保費-公司負擔：</td>
			          <td class="h3"><?php echo $CLabor;?></td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">健保費-公司負擔：</td>
			          <td class="h3"><?php echo $CHealth;?></td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">勞保費-員工負擔：</td>
			          <td class="h3"><?php echo $ELabor;?></td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">健保費-員工負擔：</td>
			          <td class="h3"><?php echo $EHealth;?></td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">勞退提撥-公司負擔：</td>
			          <td class="h3"><?php echo $CRetirement;?></td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">加班費：</td>
			          <td class="h3"><?php echo $Overtime;?></td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">交通費-公里數計算：</td>
			          <td class="h3"><?php echo $Transportation1;?></td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">交通費-實報實銷：</td>
			          <td class="h3"><?php echo $Transportation2;?></td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">績效獎金：</td>
			          <td class="h3"><input type="text" name="Bonus" size="20" value="<?php echo $Bonus;?>"></td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">事假：</td>
			          <td class="h3"><?php echo $PLeave;?></td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">病假：</td>
			          <td class="h3"><?php echo $SickLeave;?></td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">年假折現：</td>
			          <td class="h3"><?php echo $EVAmount;?></td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">他項：</td>
			          <td class="h3"><input type="text" name="Other" size="20" value="<?php echo $Other;?>"></td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">他項說明：</td>
			          <td class="h3"><input type="text" name="OtherDesc" size="20" value="<?php echo $OtherDesc;?>"></td>
			        </tr>
			        <tr height="40" align="center">
			          <td colspan="2" class="h3"><input type="submit" name="submit" class="input_bot" value="送 出"></td>
			        </tr>
				      </form>
			      </table>
    			</td>
    		</tr>
    	</table>
    </td>
	</tr>
</table>
<?php include "down.php";?>
</body>
</html>
<?php
mysqli_close($link);
?>