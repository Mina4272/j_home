﻿<?php
include "CheckPermission.php";
include "../global.php";
include "include/page_function.php";
include "include/utf8.php";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $PageAdminTitle;?></title>
<link href="../type.css" rel="stylesheet" type="text/css" />
<style type="text/css">
<!--
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
}
-->
</style></head>

<body>
<?php include "top.php";?>
<table width="100%" border="0" cellspacing="0" cellpadding="5">
	<tr>
    <td width="160" height="600" align="left" valign="top">
			<?php include "menu.php";?>
    </td>
		<?php
	$SqlTxt = "";
  	$KeyWord = empty($_POST['KeyWord'])?"":$_POST['KeyWord'];
  	if (trim($KeyWord) == "") $KeyWord = empty($_GET['KeyWord'])?"":$_GET['KeyWord'];
  	if (trim($KeyWord) != "") $SqlTxt = $SqlTxt." and (NTitle like '%".$KeyWord."%' or NContent like '%".$KeyWord."%')";
		$page = empty($_GET['page'])?"":$_GET['page'];
		if (trim($page) == "") $page = 1;
		$page_rows=15;  //每頁筆數
		$php_Self = "NewsList.php";  //分頁web檔名

		$button_css = "h4";
		$limit_txt =" limit ".(($page-1) * $page_rows).",".$page_rows;
		$url_str = "&KeyWord=".urlencode($KeyWord);
		?>
    <td valign="top">
    	<table width="100%" border="0" cellpadding="0" cellspacing="0">
    		<tr>
    			<td>
			    	<table width="750" border="0" cellpadding="0" cellspacing="0">
			    		<form name="form1" action="NewsList.php" method="post">
			    		<tr height="30">
			    			<td class="c2">公佈欄資訊</td>
			    			<td align="left" class="h3">關鍵字：<input type="text" name="KeyWord" size="20"> <input type="submit" name="search" class="input_bot" value="查詢"></td>
			    			<td align="right" class="h3"><?php if (trim(strstr($_SESSION["reg_MPer"],'H')) != ""){?><input type="button" name="add" value="新 增" class="input_bot" onclick="javascript:location.href='NewsAdd.php';"><?php }?></td>
			    			<td width="20"></td>
			    		</tr>
			    	</form>
			    	</table>
						<?php
						$Sql_str="select NID,NTitle,NFile,AddDate,ProcDate from News where Deltag='N' ".$SqlTxt." order by NID desc;";
						$SQL_NewsList="select NID,NTitle,NFile,AddDate,ProcDate from News where Deltag='N' ".$SqlTxt." order by NID desc ".$limit_txt.";";
						$result_NewsList=mysqli_query($link,$SQL_NewsList) or die ("無法執行查詢");
						?>
			    	<table width="750" border="0" cellpadding="5" cellspacing="2" class="s2">
			        <tr align="center">
			          <td width="550" align="center" background="../images/table_bg.gif" class="t21">主 旨</td>
			          <td width="100" background="../images/table_bg.gif" class="t21">詳 細</td>
			          <?php if (trim(strstr($_SESSION["reg_MPer"],'H')) != ""){?>
			          <td width="50" background="../images/table_bg.gif" class="t21">修 改</td>
			          <td width="50" background="../images/table_bg.gif" class="t21">刪 除</td>
			          <?php }?>
			        </tr>
		          <?php
		          $tmp = 1;
		          while(list($NID,$NTitle,$NFile,$AddDate,$ProcDate)=mysqli_fetch_row($result_NewsList)){
		        	?>
		        	<tr<?php if ($tmp%2 == 0) echo " bgcolor=\"#F6F6F6\"";?>>
			          <td class="h3">
			          	<?php if (trim($NFile) == "") echo $NTitle;
			          	else {?>
			          		<a href="getfile.php?FolderName=Admin\\NFile&FileName=<?php echo $NFile;?>"><?php echo $NTitle;?></a>
			          	<?php }?>
			          </td>
			          <td align="center"><input type="button" name="edit" value="詳 細" class="input_bot" onclick="javascript:location.href='NewsDetail.php?NID=<?php echo $NID;?>&page=<?php echo $page;?><?php echo $url_str;?>';"></td>
			          <?php if (trim(strstr($_SESSION["reg_MPer"],'H')) != ""){?>
			          <td align="center"><input type="button" name="edit" value="修 改" class="input_bot" onclick="javascript:location.href='NewsEdit.php?NID=<?php echo $NID;?>&page=<?php echo $page;?><?php echo $url_str;?>';"></td>
			          <td align="center"><input type="button" name="edit" value="刪 除" class="input_bot" onclick="javascript:if (confirm('您是否確定要刪除？')) location.href='NewsDelDB.php?NID=<?php echo $NID;?>&page=<?php echo $page;?><?php echo $url_str;?>';"></td>
			          <?php }?>
			        </tr>
			        <?php
            			$tmp++;
			      			}
            	mysqli_free_result($result_NewsList);
			        ?>
			      </table>
			      <table width="750" border="0" cellpadding="5" cellspacing="2" class="s2">
			        <tr align="center">
			          <td bgcolor="#E8F0C2" class="h4"><?php Page_show($Sql_str,$page_rows,$php_Self,$link,$page,$url_str,$button_css);?></td>
			        </tr>
			      </table>
    			</td>
    		</tr>
    	</table>
    </td>
	</tr>
</table>
<?php include "down.php";?>
</body>
</html>
<?php
mysqli_close($link);
?>