﻿<?php
include "CheckPermission.php";
include "CheckCustomer.php";
include "../global.php";
include "include/page_function.php";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $PageAdminTitle;?></title>
<link href="../type.css" rel="stylesheet" type="text/css" />
<style type="text/css">
<!--
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
}
-->
</style></head>

<body>
<?php
$CID = $_GET['CID'];
$CFID = $_GET['CFID'];
if (trim($CID) == "" || trim($CFID) == "")
		{
		mysqli_close($link);
		?>
		<script type="text/JavaScript">
			<!--
			alert ("查無資料，請冾網站管理人員！");
			history.go(-1);
			//-->
		</script>
		<?php
		exit;
		}
$SQL_CustomerFile="select CFName,CFile,AddUser,AddDate,ProcUser,ProcDate from CustomerFile where Deltag='N' and CID = '".$CID."' and CFID = '".$CFID."';";
$result_CustomerFile=mysqli_query($link,$SQL_CustomerFile) or die ("無法執行查詢");
if (mysqli_num_rows($result_CustomerFile) == 0)
		{
		mysqli_free_result($result_CustomerFile);
		mysqli_close($link);
		?>
		<SCRIPT language=javascript>
		<!--
		alert ("查無資料，請冾網站管理人員！"); 
		self.close();
		//-->
		</SCRIPT>
		<?php 	
		exit;
		}
mysqli_free_result($result_CustomerFile);
?>
<table width="100%" border="0" cellpadding="0" cellspacing="0">
	<tr>
		<td>
			<?php
			$page = $_GET['page'];
			if (trim($page) == "") $page = 1;
			$page_rows=15;  //每頁筆數
			$php_Self = "CustomerFileHistory.php";  //分頁web檔名

			$button_css = "h4";
			$limit_txt =" limit ".(($page-1) * $page_rows).",".$page_rows;
			$url_str = "&CID=".$CID."&CFID=".$CFID;
			$Sql_str="select CFID,CFName,CFile,AddUser,AddDate,ProcUser,ProcDate from CustomerFileHistory where Deltag='N' and CID = '".$CID."' order by CFHID desc;";
			$SQL_CustomerFile="select CFID,CFName,CFile,AddUser,AddDate,ProcUser,ProcDate from CustomerFileHistory where Deltag='N' and CID = '".$CID."' order by CFHID desc ".$limit_txt.";";
			$result_CustomerFile=mysqli_query($link,$SQL_CustomerFile) or die ("無法執行查詢");
			?>
    	<table width="100%" border="0" cellpadding="5" cellspacing="2" class="s2">
        <tr align="center">
          <td width="20%" align="center" background="../images/table_bg.gif" class="t21">編號 </td>
          <td width="40%" background="../images/table_bg.gif" class="t21">名稱</td>
          <td width="40%" background="../images/table_bg.gif" class="t21">最後更新</td>
        </tr>
        <?php
        $tmp = 1;
        while(list($CFID,$CFName,$CFile,$AddUser,$AddDate,$ProcUser,$ProcDate)=mysqli_fetch_row($result_CustomerFile)){
      	?>
      	<tr<?php if ($tmp%2 == 0) echo " bgcolor=\"#F6F6F6\"";?>>
          <td align="center" class="h3"><?php echo $CFID;?></td>
          <td align="center" class="h3"><a href="getfile.php?FolderName=Admin\\CFile&FileName=<?php echo $CFile;?>"><?php echo $CFName;?></a></td>
          <td align="center" class="h3">
          	<?php
          	if (trim($ProcUser) == "") echo $AddUser."<br>".$AddDate;
          	else echo $ProcUser."<br>".$ProcDate;
          	?>
          </td>
        </tr>
        <?php
      			$tmp++;
      			}
      	mysqli_free_result($result_CustomerFile);
        ?>
      </table>
      <table width="100%" border="0" cellpadding="5" cellspacing="2" class="s2">
        <tr align="center">
          <td bgcolor="#E8F0C2" class="h4"><?php Page_show($Sql_str,$page_rows,$php_Self,$link,$page,$url_str,$button_css);?></td>
        </tr>
      </table>
		</td>
	</tr>
</table>
</body>
</html>
<?php
mysqli_close($link);
?>