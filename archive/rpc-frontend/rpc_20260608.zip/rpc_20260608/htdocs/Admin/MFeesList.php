﻿<?php
include "CheckPermission.php";
include "../global.php";
include "include/page_function.php";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $PageAdminTitle;?></title>
<link href="../type.css" rel="stylesheet" type="text/css" />
<link href="../script/DatePicker.css" rel="stylesheet" type="text/css" />
<Script LANGUAGE="Javascript" SRC="../script/DatePicker.js"></Script>
<style type="text/css">
<!--
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
}
-->
</style>
<Script type="text/javascript" language="javascript" src="../script/CheckForm.js"></Script>
<script type="text/JavaScript">
<!--
function jsCheck() 
		{
		if (jsTrim(document.form1.QMFSYear.value) != "" || jsTrim(document.form1.QMFSMonth.value) != "" || jsTrim(document.form1.QMFSDay.value) != "") if (ChkDate('QMFSYear',document.form1.QMFSYear.value,document.form1.QMFSMonth.value,document.form1.QMFSDay.value,'申請起始時間') == false) return false;
		if (jsTrim(document.form1.QMFEYear.value) != "" || jsTrim(document.form1.QMFEMonth.value) != "" || jsTrim(document.form1.QMFEDay.value) != "") if (ChkDate('QMFEYear',document.form1.QMFEYear.value,document.form1.QMFEMonth.value,document.form1.QMFEDay.value,'申請結束時間') == false) return false;
		if (jsTrim(document.form1.QMFSYear.value) != "" && jsTrim(document.form1.QMFSMonth.value) != "" && jsTrim(document.form1.QMFSDay.value) != "" && jsTrim(document.form1.QMFEYear.value) != "" && jsTrim(document.form1.QMFEMonth.value) != "" && jsTrim(document.form1.QMFEDay.value) != "") if (CompareDate('QMFSYear',document.form1.QMFSYear.value,document.form1.QMFSMonth.value,document.form1.QMFSDay.value,document.form1.QMFEYear.value,document.form1.QMFEMonth.value,document.form1.QMFEDay.value,'申請起始時間','申請結束時間') == false) return false;
		}

function MFeesExport() 
		{
		document.form_exp.QMFSYear.value = document.form1.QMFSYear.value;
		document.form_exp.QMFSMonth.value = document.form1.QMFSMonth.value;
		document.form_exp.QMFSDay.value = document.form1.QMFSDay.value;
		document.form_exp.QMFEYear.value = document.form1.QMFEYear.value;
		document.form_exp.QMFEMonth.value = document.form1.QMFEMonth.value;
		document.form_exp.QMFEDay.value = document.form1.QMFEDay.value;
		document.form_exp.QMFType.value = document.form1.QMFType.value;
		document.form_exp.QMUID.value = document.form1.QMUID.value;
		document.form_exp.KeyWord.value = document.form1.KeyWord.value;
		document.form_exp.QMFCheck.value = document.form1.QMFCheck.value;
		document.form_exp.submit();
		}
//-->
</script>
</head>

<body>
<?php include "top.php";?>
<?php
$SqlTxt="";
$QMFSDate = empty($_POST['QMFSDate'])?"":$_POST['QMFSDate'];
if (trim($QMFSDate) == "") $QMFSDate = empty($_GET['QMFSDate'])?"":$_GET['QMFSDate'];
$QMFEDate = empty($_POST['QMFEDate'])?"":$_POST['QMFEDate'];
if (trim($QMFEDate) == "") $QMFEDate = empty($_GET['QMFEDate'])?"":$_GET['QMFEDate'];
if (trim($QMFSDate) == "") {
		$QMFSYear = empty($_POST['QMFSYear'])?"":$_POST['QMFSYear'];
		$QMFSMonth = empty($_POST['QMFSMonth'])?"":$_POST['QMFSMonth'];
		$QMFSDay = empty($_POST['QMFSDay'])?"":$_POST['QMFSDay'];
		if (trim($QMFSYear) != "" || trim($QMFSMonth) != "" || trim($QMFSDay) != "") if (checkdate($QMFSMonth,$QMFSDay ,$QMFSYear)) $QMFSDate = $QMFSYear."-".$QMFSMonth."-".$QMFSDay;
		}
if (trim($QMFEDate) == "") {
		$QMFEYear = empty($_POST['QMFEYear'])?"":$_POST['QMFEYear'];
		$QMFEMonth = empty($_POST['QMFEMonth'])?"":$_POST['QMFEMonth'];
		$QMFEDay = empty($_POST['QMFEDay'])?"":$_POST['QMFEDay'];
		if (trim($QMFEYear) != "" || trim($QMFEMonth) != "" || trim($QMFEDay) != "") if (checkdate($QMFEMonth,$QMFEDay ,$QMFEYear)) $QMFEDate = $QMFEYear."-".$QMFEMonth."-".$QMFEDay;
		}
$QMFType = empty($_POST['QMFType'])?"":$_POST['QMFType'];
if (trim($QMFType) == "") $QMFType = empty($_GET['QMFType'])?"":$_GET['QMFType'];
$QMUID = empty($_POST['QMUID'])?"":$_POST['QMUID'];
if (trim($QMUID) == "") $QMUID = empty($_GET['QMUID'])?"":$_GET['QMUID'];
$KeyWord = empty($_POST['KeyWord'])?"":$_POST['KeyWord'];
if (trim($KeyWord) == "") $KeyWord = empty($_GET['KeyWord'])?"":$_GET['KeyWord'];
$QMFCheck = empty($_POST['QMFCheck'])?"":$_POST['QMFCheck'];
if (trim($QMFCheck) == "") $QMFCheck = empty($_GET['QMFCheck'])?"":$_GET['QMFCheck'];
?>
<table width="100%" border="0" cellspacing="0" cellpadding="5">
	<tr>
    <td width="160" height="600" align="left" valign="top">
			<?php include "menu.php";?>
    </td>
    <td valign="top">
    	<table width="100%" border="0" cellpadding="0" cellspacing="0">
    		<tr>
    			<td>
			    	<table width="750" border="0" cellpadding="0" cellspacing="0">
			    		<tr>
			    			<td class="c2" width="200">費用申請列表</td>
			    			<td align="right" class="h3"></td>
			    			<td width="20"></td>
			    		</tr>
			    	</table>
			    	<table width="750" border="0" cellpadding="0" cellspacing="0">
			    		<form name="form1" action="MFeesList.php" method="post" onSubmit="return jsCheck();">
			    		<tr>
			    			<td align="left" class="h3" colspan="3">申請時間：
			            <input name="QMFSYear" type="text" size="4" value="<?php echo $QMFSYear;?>" />年
			            <input name="QMFSMonth" type="text" size="2" value="<?php echo $QMFSMonth;?>" />月
			            <input name="QMFSDay" type="text" size="2" value="<?php echo $QMFSDay;?>" />日
			            <img src="../images/icon.gif" width="16" height="18" style="cursor: hand" onclick="javascript:displayDatePicker('QMFSYear','QMFSMonth','QMFSDay');"/>～
			            <input name="QMFEYear" type="text" size="4" value="<?php echo $QMFEYear;?>" />年
			            <input name="QMFEMonth" type="text" size="2" value="<?php echo $QMFEMonth;?>" />月
			            <input name="QMFEDay" type="text" size="2" value="<?php echo $QMFEDay;?>" />日
			            <img src="../images/icon.gif" width="16" height="18" style="cursor: hand" onclick="javascript:displayDatePicker('QMFEYear','QMFEMonth','QMFEDay');"/>
			    				<?php if (trim(strstr($_SESSION["reg_MPer"],'K')) != "") {?>
			    				 <input type="button" name="report" class="input_bot" value="報表輸出" onclick="javascript:MFeesExport();">
			    				 <input type="button" name="report" class="input_bot" value="統計報表" onclick="javascript:window.open ('MFeesExportSummary.php','Exp','');">
			    				<?php }?>
			    			</td>
			    		</tr>
			    		<tr>
			    			<td width="300" align="left" class="h3">
			    				申請項目：
			          	<select name="QMFType">
			          		<option value="">不限</option>
			          		<option value="A"<?php if (trim($QMFType) == "A") echo " selected";?>>加班費</option>
			          		<option value="B"<?php if (trim($QMFType) == "B") echo " selected";?>>交通費-公里</option>
			          		<option value="C"<?php if (trim($QMFType) == "C") echo " selected";?>>交通費-實報實銷/餐費</option>
			          	</select>
			    			</td>
			    			<td width="300" align="left" class="h3">
			    				申請人：
			          	<select name="QMUID">
			          		<option value="">不限</option>
			          		<?php
										$SQL_Manager="select MUID,MName,MEName from Manager where Deltag='N' and IsLeft='N' order by MID;";
										$result_Manager=mysqli_query($link,$SQL_Manager) or die ("無法執行查詢");
			          		while(list($MUID,$MName,$MEName)=mysqli_fetch_row($result_Manager)){
					          		?>
					          		<option value="<?php echo $MUID;?>"<?php if (trim($MUID) == trim($QMUID)) echo " selected";?>><?php echo $MEName.$MName;?></option>
					          		<?php
						      			}
			            	mysqli_free_result($result_Manager);
			          		?>
			          	</select>
			    			</td>
			    			<td width="240" align="left" class="h3">狀　態：
			          	<select name="QMFCheck">
			          		<option value="">不限</option>
			          		<option value="W"<?php if (trim(empty($_POST['QMVCheck'])?"":$_POST['QMVCheck']) == "W") echo " selected";?>>等待簽核</option>
			          		<option value="Y"<?php if (trim(empty($_POST['QMVCheck'])?"":$_POST['QMVCheck']) == "Y") echo " selected";?>>已簽核</option>
			          		<option value="N"<?php if (trim(empty($_POST['QMVCheck'])?"":$_POST['QMVCheck']) == "N") echo " selected";?>>未簽核</option>
			          	</select>
			    			</td>
			    		</tr>
			    		<tr>
			    			<td align="left" colspan="2" class="h3">
			    				關鍵字：<input type="text" name="KeyWord" size="15" value="<?php echo $KeyWord;?>"> 
			    				<input type="submit" class="input_bot" name="search" value="查詢"> 
			    				<input type="button" name="button" class="input_bot" value="全部列出" onclick="javascript:location.href='MFeesList.php';"> 
			    			</td>
			    			<td align="right" class="h3">
			    				<input type="button" name="add" value="新 增" class="input_bot" onclick="javascript:location.href='MFeesAdd.php';">
			    			</td>
			    		</tr>
			    		</form>
			    	</table>
						<?php
						if (trim($QMFSDate) != "" && trim($QMFEDate) != "") $SqlTxt = $SqlTxt." and (MFDate >= '".$QMFSDate." 00:00:00') and (MFDate <= '".$QMFEDate." 23:59:59') ";
						else if (trim($QMFSDate) != "" && trim($QMFEDate) == "") $SqlTxt = $SqlTxt." and (MFDate >= '".$QMFSDate." 00:00:00') ";
						else if (trim($QMFSDate) == "" && trim($QMFEDate) != "") $SqlTxt = $SqlTxt." and (MFDate <= '".$QMFEDate." 23:59:59') ";
						if (trim($QMFType) != "") $SqlTxt = $SqlTxt." and MFType='".$QMFType."' ";
						if (trim($QMUID) != "") $SqlTxt = $SqlTxt." and MUID='".$QMUID."' ";
						if (trim($QMFCheck) != "") $SqlTxt = $SqlTxt." and MFCheck='".$QMFCheck."' ";
						if (trim($KeyWord) != "") $SqlTxt = $SqlTxt." and (MFCause like '%".$KeyWord."%' or MFComment like '%".$KeyWord."%' or MFNote like '%".$KeyWord."%' or Quantity like '%".$KeyWord."%')";
						$page = empty($_GET['page'])?"":$_GET['page'];
						if (trim($page) == "") $page = 1;
						$page_rows=15;  //每頁筆數
						$php_Self = "MFeesList.php";  //分頁web檔名

						$button_css = "h4";
						$limit_txt =" limit ".(($page-1) * $page_rows).",".$page_rows;
						$url_str = "&QMFSDate=".$QMFSDate."&QMFEDate=".$QMFEDate."&QMFType=".$QMFType."&QMUID=".$QMUID."&QMFCheck=".$QMFCheck."&KeyWord=".urlencode($KeyWord);
						$Sql_str="select MFID,MUID,MFType,MFDate,MFCause,MFComment,Quantity,MFNote,MFSend,MFCheck,MFCNote,MFCheckID,MFCheckDate,MFCheckIP,AddDate from ManagerFees where Deltag='N' ".$SqlTxt." order by MFID desc;";
						
						//add limit 0,1 to skip error : #1242 - Subquery returns more than 1 row. 2017 June 19
						//$SQL_ManagerFees="select MFID,MUID,MFType,MFDate,MFCause,MFComment,Quantity,MFNote,MFSend,MFCheck,MFCNote,MFCheckID,(select MName from Manager where MUID=ManagerFees.MFCheckID) MFCMName,(select MEName from Manager where MUID=ManagerFees.MFCheckID) MFCMEName,MFCheckDate,MFCheckIP,AddDate,(select MName from Manager where MUID=ManagerFees.MUID) MName,(select MEName from Manager where MUID=ManagerFees.MUID) MEName from ManagerFees where Deltag='N' ".$SqlTxt." order by MFID desc ".$limit_txt.";";
						$SQL_ManagerFees="select MFID,MUID,MFType,MFDate,MFCause,MFComment,Quantity,MFNote,MFSend,MFCheck,MFCNote,MFCheckID,(select MName from Manager where MUID=ManagerFees.MFCheckID) MFCMName,(select MEName from Manager where MUID=ManagerFees.MFCheckID) MFCMEName,MFCheckDate,MFCheckIP,AddDate,(select MName from Manager where MUID=ManagerFees.MUID limit 0,1) MName,(select MEName from Manager where MUID=ManagerFees.MUID limit 0,1) MEName from ManagerFees where Deltag='N' ".$SqlTxt." order by MFID desc ".$limit_txt.";";
						//echo $SQL_ManagerFees;
						$result_ManagerFees=mysqli_query($link,$SQL_ManagerFees); // or die ("無法執行查詢");
						?>
			    	<table width="760" border="0" cellpadding="5" cellspacing="2" class="s2">
			        <tr align="center">
			          <td width="105" align="center" background="../images/table_bg.gif" class="t21">項目<br>日期</td>
			          <td width="75" background="../images/table_bg.gif" class="t21">事由</td>
			          <td width="60" background="../images/table_bg.gif" class="t21">數量/金額</td>
			          <td width="50" background="../images/table_bg.gif" class="t21">申請人</td>
			          <td width="90" background="../images/table_bg.gif" class="t21">狀態</td>
			          <td width="80" background="../images/table_bg.gif" class="t21">備註</td>
			          <td width="50" background="../images/table_bg.gif" class="t21">修改<br>刪除</td>
			        </tr>
		          <?php
		          $tmp = 1;
		          while(list($MFID,$MUID,$MFType,$MFDate,$MFCause,$MFComment,$Quantity,$MFNote,$MFSend,$MFCheck,$MFCNote,$MFCheckID,$MFCMName,$MFCMEName,$MFCheckDate,$MFCheckIP,$AddDate,$MName,$MEName)=mysqli_fetch_row($result_ManagerFees)){
		        		if (trim($MFType) == "A") {
		        				$MFType="加班費";
		        				$MFUnit="小時";
		        				}
		        		else if (trim($MFType) == "B") {
		        				$MFType="交通費-公里";
		        				$MFUnit="公里";
		        				}
		        		else if (trim($MFType) == "C") {
		        				$MFType="交通費-實報實銷/餐費";
		        				$MFUnit="元";
		        				}
		        	?>
		        	<tr<?php if ($tmp%2 == 0) echo " bgcolor=\"#F6F6F6\"";?>>
			          <td align="center" class="h3"><?php echo $MFType;?><br><?php echo $MFDate;?></td>
			          <td class="h3"><?php echo $MFCause;?><br><?php echo $MFComment;?></td>
			          <td align="center" class="h3"><?php echo $Quantity;?><?php echo $MFUnit;?></td>
			          <td align="center" class="h3"><?php echo $MEName.$MName;?></td>
			          <td align="center" class="h3">
			          	<?php
			          	if (trim($MFSend) == "N") echo "編輯中";
			          	else if (trim($MFSend) == "Y") {
					        		if (trim($MFCheck) == "W") {
					        				echo "待簽核<br>";
					        				if (trim(strstr($_SESSION["reg_MPer"],'K')) != "") {
							        				?>
							        				<input type="button" name="audit" value="簽核" class="input_bot" onclick="javascript:window.open ('MFeesAudit.php?MFID=<?php echo $MFID;?>','audit','height=400,width=700,top=200,left=200,scrollbars=yes,status=yes');">
							        				<?php
					        						}
					        				}
					        		else if (trim($MFCheck) == "Y") {
					        				echo "<font color=blue>已核準</font><br>".$MFCNote."<br>".$MFCMEName.$MFCMName."<br>".$MFCheckDate;
					        				}
					        		else if (trim($MFCheck) == "N") {
					        				echo "<font color=red>不核準</font><br>".$MFCNote."<br>".$MFCMEName.$MFCMName."<br>".$MFCheckDate;
					        				}
			        				}
			          	?>	
			          </td>
			          <td class="h4"><?php echo $MFNote;?></td>
			          <td align="center">
			          	<?php
			          	if (trim($MFCheck) != "W" || (trim($MUID) != trim($_SESSION["reg_MUID"]))) $CKT=" disabled";
			          	else $CKT="";
			          	?>
			          	<input type="button" name="edit" <?php echo $CKT;?> value="修 改" class="input_bot" onclick="javascript:location.href='MFeesEdit.php?MFID=<?php echo $MFID;?>&page=<?php echo $page;?><?php echo $url_str;?>';">
									<?php if (trim($_SESSION["reg_MUID"]) == "Benson" || trim($_SESSION["reg_MUID"]) == "amanda" || trim($_SESSION["reg_MUID"]) == "jacky") $CKT=""?>
			          	<br><input type="button" <?php if (trim($_SESSION["reg_MUID"]) == "Benson" || trim($_SESSION["reg_MUID"]) == "amanda" || trim($_SESSION["reg_MUID"]) == "jacky") {} else {echo $CKT;};?> name="edit" value="刪 除" class="input_bot" onclick="javascript:if (confirm('您是否確定要刪除？')) location.href='MFeesDelDB.php?MFID=<?php echo $MFID;?>&page=<?php echo $page;?><?php echo $url_str;?>';">
			          </td>
			        </tr>
			        <?php
            			$tmp++;
			      			}
            	mysqli_free_result($result_ManagerFees);
			        ?>
			      </table>
			      <table width="760" border="0" cellpadding="5" cellspacing="2" class="s2">
			        <tr align="center">
			          <td bgcolor="#E8F0C2" class="h4"><?php Page_show($Sql_str,$page_rows,$php_Self,$link,$page,$url_str,$button_css);?></td>
			        </tr>
			      </table>
    			</td>
    		</tr>
    	</table>
    </td>
	</tr>
</table>
<form name="form_exp" action="MFeesExport.php" method="post" target="_MFeesExport">
	<input type="hidden" name="QMFSYear">
	<input type="hidden" name="QMFSMonth">
	<input type="hidden" name="QMFSDay">
	<input type="hidden" name="QMFEYear">
	<input type="hidden" name="QMFEMonth">
	<input type="hidden" name="QMFEDay">
	<input type="hidden" name="QMFType">
	<input type="hidden" name="QMUID">
	<input type="hidden" name="KeyWord">
	<input type="hidden" name="QMFCheck">
</form>
<?php include "down.php";?>
</body>
</html>
<?php
mysqli_close($link);
?>