﻿<?php
include "CheckPermission.php";
include "CheckAgendum.php";
include "../global.php";
include "include/function.php";
require_once("../include/chinese_party.class.php");
require("class.phpmailer.php");
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $PageAdminTitle;?></title>
</head>
<body>
<?php
$AID = $_GET['AID'];
$page = $_GET['page'];
$KeyWord = $_GET['KeyWord'];
$QAStatus = $_GET['QAStatus'];
$QASID = $_GET['QASID'];
$QARID = $_GET['QARID'];
$QACID = $_GET['QACID'];
$Late = $_GET['Late'];

if (trim($AID) == "")
		{
		mysqli_close($link);
		?>
		<script type="text/JavaScript">
			<!--
			alert ("您輸入的資料不足，請重新輸入！");
			history.go(-1);
			//-->
		</script>
		<?php
		exit;
		}

$now_time = date("Y-m-d H:i:s",mktime());
$SQL_select="select AUID,ASID,(select MName from Manager where Deltag='N' and MUID=Agendum.ASID) ASName,(select EMail from Manager where Deltag='N' and MUID=Agendum.ASID) ASEMail,ARID,(select MName from Manager where Deltag='N' and MUID=Agendum.ARID) ARName,(select EMail from Manager where Deltag='N' and MUID=Agendum.ARID) AREMail,ACID,(select MName from Manager where Deltag='N' and MUID=Agendum.ACID) ACName,(select EMail from Manager where Deltag='N' and MUID=Agendum.ACID) ACEMail,AEDate,AItem from Agendum where Deltag='N' and AID = '".$AID."';";
$result_select=mysqli_query($link,$SQL_select) or die ("無法執行查詢");

if (mysqli_num_rows($result_select) == 0)
		{
		mysqli_free_result($result_select);
		mysqli_close($link);
		?>
		<script type="text/JavaScript">
			<!--
			alert ("查無資料，請冾網站管理人員！");
			history.go(-1);
			//-->
		</script>
		<?php
		exit;
		}
list($AUID,$ASID,$ASName,$ASEMail,$ARID,$ARName,$AREMail,$ACID,$ACName,$ACEMail,$AEDate,$AItem)=mysqli_fetch_row($result_select);
mysqli_free_result($result_select);

//if (trim(strtolower($_SESSION["reg_MUID"])) != trim(strtolower($ARID))) {
if ((trim(strtolower($_SESSION["reg_MUID"])) != trim(strtolower($ARID))) and ($_SESSION["reg_MUID"] != "Benson")) {
		
		mysqli_free_result($result_select);
		mysqli_close($link);
		?>
		<script type="text/JavaScript">
			<!--
			alert ("您沒有權限回報！");
			history.go(-1);
			//-->
		</script>
		<?php
		exit;
		}

$sql_insert = "INSERT INTO AgendumHistory(AID,AUID,ASID,ARID,ACID,CheckProc,ADate,AEDate,ACDate,AStatus,ReviewID,ReviewDate,ReviewIP,ReceiveID,ReceiveDate,ReceiveIP,FinishID,FinishDate,FinishIP,CheckID,CheckDate,CheckIP,AItem,Attribute,PID,CID,CName,CTel,CFax,Contact,CMobile,CEMail,CAddress,AFile,ANote,AddUser,AddDate,AddIP,Deltag,ProcUser,ProcDate,ProcIP,UpdateUser,UpdateDate,UpdateIP) SELECT AID,AUID,ASID,ARID,ACID,CheckProc,ADate,AEDate,ACDate,AStatus,ReviewID,ReviewDate,ReviewIP,ReceiveID,ReceiveDate,ReceiveIP,FinishID,FinishDate,FinishIP,CheckID,CheckDate,CheckIP,AItem,Attribute,PID,CID,CName,CTel,CFax,Contact,CMobile,CEMail,CAddress,AFile,ANote,AddUser,AddDate,AddIP,Deltag,ProcUser,ProcDate,ProcIP,'".$_SESSION["reg_MUID"]."','".$now_time."','".$_SERVER["REMOTE_ADDR"]."' FROM Agendum where Deltag='N' and AID = '".$AID."';";
$result_insert=mysqli_query($link,$sql_insert) or die ("無法執行新增");
$sql_update = "update Agendum set AStatus = 'D',FinishID='".$_SESSION["reg_MUID"]."',FinishDate='".$now_time."',FinishIP='".$_SERVER["REMOTE_ADDR"]."',ProcUser = '".$_SESSION["reg_MUID"]."',ProcDate = '".$now_time."',ProcIP = '".$_SERVER["REMOTE_ADDR"]."' where Deltag='N' and AID = '".$AID."';";
$result_update=mysqli_query($link,$sql_update) or die ("無法執行修改");

$EMAILFN = "AgendumFinish.htm";
$subject="全威驗證事項完成通知 ！！";
$fp=fopen($EMAILFN,"r");
$content="";
while($line=fgets($fp,512)){
	$content.=$line;
	}
fclose($fp);

$content = str_replace("{AUID}",$AUID,$content);
$content = str_replace("{ASID}",$ASName,$content);
$content = str_replace("{ARID}",$ARName,$content);
$content = str_replace("{ACID}",$ACName,$content);
$content = str_replace("{FinishDate}",$now_time,$content);
$content = str_replace("{AEDate}",$AEDate,$content);
$content = str_replace("{AItem}",$AItem,$content);

//$cconv =& new chinese_party();
//$content = $cconv->u82tchi($content);
//$subject = $cconv->u82tchi($subject);

$EMailList=array($ASEMail,$ACEMail);
for ($tmp=0;$tmp<=count($EMailList)-1;$tmp++){
		$mail = new PHPMailer();
		$mail->IsSMTP();
		$mail->SMTPAuth = true; //設定SMTP需要驗證
		$mail->SMTPSecure = "ssl"; // Gmail的SMTP主機需要使用SSL連線
		$mail->Host = "smtp.gmail.com"; //Gamil的SMTP主機
		$mail->Port = 465; //Gamil的SMTP主機的埠號(Gmail為465)。
		$mail->CharSet = "utf-8"; //郵件編碼
		$mail->Username = "Benson@rpclab.com"; //Gamil帳號
		$mail->Password = "76197619"; //Gmail密碼
		$mail->From     = "Benson@rpclab.com";
		$mail->FromName = $subject;
		$mail->WordWrap = 50;
		$mail->IsHTML(true);                               // send as HTML
		//$mail->CharSet = "big5";
		$mail->Subject  = $subject;
		$mail->Body     =  $content;
		$mail->AddAddress($EMailList[$tmp],"");
		$mail->AddReplyTo("Benson@rpclab.com");
		if(!$mail->Send())
				{
		    //echo "There has been a mail error sending to " . $SendEMail . "<br>";
		    //echo "Mailer Error: " . $mail->ErrorInfo . "<br>";
		  	}
		else
				{
				//echo $SendEMail . " sending !!<br>";
				}
				
		$mail->ClearAddresses();
		$mail->ClearReplyTos();
		$mail->SmtpClose();
		}

mysqli_close($link);
?>
<script type="text/JavaScript">
	<!--
	alert ("處理完成！");
	location.href='AgendumList.php?page=<?php echo $page;?>&QAStatus=<?php echo $QAStatus;?>&QASID=<?php echo $QASID;?>&QARID=<?php echo $QARID;?>&QACID=<?php echo $QACID;?>&Late=<?php echo $Late;?>&KeyWord=<?php echo urlencode($KeyWord);?>';
	//-->
</script>

</body>
</html>
