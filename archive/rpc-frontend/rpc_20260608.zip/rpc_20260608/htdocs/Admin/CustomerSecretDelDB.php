﻿<?php
include "CheckPermission.php";
include "CheckCustomer.php";
include "../global.php";
include "include/function.php";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $PageAdminTitle;?></title>
</head>
<body>
<?php
$CSID = $_GET['CSID'];
$CID = $_GET['CID'];
$page = $_GET['page'];

if (trim($CSID) == "" || trim($CID) == "")
		{
		mysqli_close($link);
		?>
		<script type="text/JavaScript">
			<!--
			alert ("您輸入的資料不足，請重新輸入！");
			history.go(-1);
			//-->
		</script>
		<?php
		exit;
		}

$SQL_CustomerSecret="select CSMode from CustomerSecret where Deltag='N' and CID = '".$CID."' and CSID = '".$CSID."';";
$result_CustomerSecret=mysqli_query($link,$SQL_CustomerSecret) or die ("無法執行查詢");
if (mysqli_num_rows($result_CustomerSecret) == 0)
		{
		mysqli_free_result($result_CustomerSecret);
		mysqli_close($link);
		?>
		<SCRIPT language=javascript>
		<!--
		alert ("查無資料，請冾網站管理人員！"); 
		history.go(-1);
		//-->
		</SCRIPT>
		<?php 	
		exit;
		}
list($CSMode)=mysqli_fetch_row($result_CustomerSecret);
mysqli_free_result($result_CustomerSecret);

if (trim(strstr($_SESSION["reg_MPer"],'P')) != "") $CSModeStr="I";
if (trim(strstr($_SESSION["reg_MPer"],'Q')) != "") {
		if (trim($CSModeStr) == "") $CSModeStr="O";
		else $CSModeStr=$CSModeStr.",O";
		}
if (trim(strstr($CSModeStr,$CSMode)) == "") {
		mysqli_close($link);
		exit;
		}

$now_time = date("Y-m-d H:i:s",mktime());

$sql_insert = "INSERT INTO CustomerSecretHistory(CSID,CID,CSMode,CSContent,CSFile,AddUser,AddDate,AddIP,Deltag,ProcUser,ProcDate,ProcIP,UpdateUser,UpdateDate,UpdateIP) SELECT CSID,CID,CSMode,CSContent,CSFile,AddUser,AddDate,AddIP,Deltag,ProcUser,ProcDate,ProcIP,'".$_SESSION["reg_MUID"]."','".$now_time."','".$_SERVER["REMOTE_ADDR"]."' FROM CustomerSecret where Deltag='N' and CID = '".$CID."' and CSID = '".$CSID."';";
$result_insert=mysqli_query($link,$sql_insert) or die ("無法執行新增");

$sql_update = "update CustomerSecret set Deltag='Y',ProcUser = '".$_SESSION["reg_MUID"]."',ProcDate = '".$now_time."',ProcIP = '".$_SERVER["REMOTE_ADDR"]."' where Deltag='N' and CID = '".$CID."' and CSID = '".$CSID."';";
$result_update=mysqli_query($link,$sql_update) or die ("無法執行修改");

mysqli_close($link);
?>
<script type="text/JavaScript">
	<!--
	alert ("刪除成功！");
	location.href="CustomerSecret.php?CID=<?php echo $CID;?>&page=<?php echo $page;?>";
	//-->
</script>

</body>
</html>
