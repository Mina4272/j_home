﻿<?php
include "CheckPermission.php";
include "../global.php";
include "include/function.php";
include "include/create_image.php";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $PageAdminTitle;?></title>
<link href="../type.css" rel="stylesheet" type="text/css" />
</head>

<body>
<?php
//echo "TrademarkImg=".$HTTP_POST_FILES['TrademarkImg']['tmp_name']."<br>";
//if(file_exists($HTTP_POST_FILES['TrademarkImg']['tmp_name'])) echo "true";
//else echo "false";
$TrademarkImg = "TrademarkImg_".rand_string(12, 'ABCDEFGHIJKLMNPQRSTUVWXYZ23456789abcdefghijklmnopqrstuvwxyz').".".strtolower(substr($_FILES['TrademarkImg']['name'],strrpos($_FILES['TrademarkImg']['name'],".")+1,strlen($_FILES['TrademarkImg']['name'])+1));
//if(file_exists($HTTP_POST_FILES['TrademarkImg']['tmp_name']))
if(trim($_FILES['TrademarkImg']['tmp_name']) != "")
		{
		if($_FILES['TrademarkImg']['size'] > 20971520)
				{
				?>
				<script type="text/JavaScript">
					<!--
					alert ("您上傳的檔案 Size 超過 20 M，請重新上傳！");
					location.href='TrademarkImgUpload.php';
					//-->
				</script>
				<?php
				exit();
				}

		@copy($_FILES['TrademarkImg']['tmp_name'],$_SERVER["DOCUMENT_ROOT"]."\\Admin\\TrademarkImg\\".$TrademarkImg);
		Createsmalljpg($_SERVER["DOCUMENT_ROOT"]."\\Admin\\TrademarkImg\\".$TrademarkImg, $_SERVER["DOCUMENT_ROOT"]."\\Admin\\TrademarkImg\\s".$TrademarkImg,120,120);
		mysqli_close($link);
		?>
		<SCRIPT language=javascript>
		<!--
				alert ("上傳成功！"); 
				opener.document.form1.TrademarkImg.value='<?php echo $TrademarkImg;?>';
				opener.document.getElementById('TrademarkImgPreview').style.display = '';
				opener.document.getElementById('TrademarkImgPreview').innerHTML = '<a href="getfile.php?FolderName=Admin\\TrademarkImg&FileName=<?php echo $TrademarkImg;?>"><img src="TrademarkImg/s<?php echo $TrademarkImg;?>" border="0"></a>';
				opener.document.getElementById('TrademarkImgDel').style.display = '';
				opener.document.getElementById('TrademarkImgDel').innerHTML = '<a href="javascript:;" onclick="javascript:DelTrademarkImg();">刪除</a>';
				self.close();
		//-->
		</SCRIPT>
		<?php
		}
else
		{
		mysqli_close($link);
		?>
		<SCRIPT language=javascript>
		<!--
				alert ("上傳失敗！"); 
				self.close();
		//-->
		</SCRIPT>
		<?php
		}
?>
</body>
</html>
