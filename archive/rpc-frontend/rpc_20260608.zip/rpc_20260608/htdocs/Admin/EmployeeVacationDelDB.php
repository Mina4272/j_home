﻿<?php
include "CheckPermission.php";
include "CheckEmployeePay.php";
include "../global.php";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $PageAdminTitle;?></title>
</head>
<body>
<?php
$EVID = $_GET['EVID'];

if (trim($EVID) == "")
		{
		mysqli_close($link);
		?>
		<script type="text/JavaScript">
			<!--
			alert ("您輸入的資料不足，請重新輸入！");
			history.go(-1);
			//-->
		</script>
		<?php
		exit;
		}

$SQL_EmployeeVacation="select EVID from EmployeeVacation where Deltag='N' and EVID=".$EVID.";";
$result_EmployeeVacation=mysqli_query($link,$SQL_EmployeeVacation) or die ("無法執行查詢");
if (mysqli_num_rows($result_EmployeeVacation) == 0)
		{
		mysqli_free_result($result_EmployeeVacation);
		mysqli_close($link);
		?>
		<SCRIPT language=javascript>
		<!--
		alert ("查無資料，請冾網站管理人員！"); 
		history.go(-1);
		//-->
		</SCRIPT>
		<?php 	
		exit;
		}
mysqli_free_result($result_EmployeeVacation);

$now_time = date("Y-m-d H:i:s",mktime());
$sql_insert = "INSERT INTO EmployeeVacationHistory(EVID,MID,EVType,MVID,EPDate,EVCount,EVDesc,AddUser,AddDate,AddIP,Deltag,ProcUser,ProcDate,ProcIP,UpdateUser,UpdateDate,UpdateIP) SELECT EVID,MID,EVType,MVID,EPDate,EVCount,EVDesc,AddUser,AddDate,AddIP,Deltag,ProcUser,ProcDate,ProcIP,'".$_SESSION["reg_MUID"]."','".$now_time."','".$_SERVER["REMOTE_ADDR"]."' from EmployeeVacation where Deltag='N' and EVID=".$EVID.";";
$result_insert=mysqli_query($link,$sql_insert) or die ("無法執行新增");
$sql_update = "update EmployeeVacation set Deltag = 'Y',ProcUser = '".$_SESSION["reg_MUID"]."',ProcDate = '".$now_time."',ProcIP = '".$_SERVER["REMOTE_ADDR"]."' where Deltag='N' and EVID=".$EVID.";";
$result_update=mysqli_query($link,$sql_update) or die ("無法執行修改");
mysqli_close($link);
?>
<script type="text/JavaScript">
	<!--
	alert ("刪除成功！");
	location.href='EmployeeVacationList.php?page=<?php echo $page;?>&SDate=<?php echo $SDate;?>&EDate=<?php echo $EDate;?>&QEVType=<?php echo $QEVType;?>&KeyWord=<?php echo urlencode($KeyWord);?>';
	//-->
</script>

</body>
</html>
