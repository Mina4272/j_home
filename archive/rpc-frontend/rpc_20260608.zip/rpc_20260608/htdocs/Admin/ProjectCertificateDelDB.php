﻿<?php
include "CheckPermission.php";
include "CheckProject.php";
include "../global.php";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $PageAdminTitle;?></title>
</head>
<body>
<?php
$PID = $_GET['PID'];
$PCID = $_GET['PCID'];
$page = $_GET['page'];
if (trim($PID) == "" || trim($PCID) == "")
		{
		mysqli_close($link);
		?>
		<script type="text/JavaScript">
			<!--
			alert ("您輸入的資料不足，請重新輸入！");
			self.close();
			//-->
		</script>
		<?php
		exit;
		}
$SQL_ProjectCertificate="select PCNo,PCName,PCFile,PCSDate,date_format(PCSDate,'%Y'),date_format(PCSDate,'%m'),date_format(PCSDate,'%d'),PCEDate,date_format(PCEDate,'%Y'),date_format(PCEDate,'%m'),date_format(PCEDate,'%d'),PCNote,AddUser,AddDate,ProcUser,ProcDate from ProjectCertificate where Deltag='N' and PID = '".$PID."' and PCID = '".$PCID."';";
$result_ProjectCertificate=mysqli_query($link,$SQL_ProjectCertificate) or die ("無法執行查詢");
if (mysqli_num_rows($result_ProjectCertificate) == 0)
		{
		mysqli_free_result($result_ProjectCertificate);
		mysqli_close($link);
		?>
		<SCRIPT language=javascript>
		<!--
		alert ("查無資料，請冾網站管理人員！"); 
		self.close();
		//-->
		</SCRIPT>
		<?php 	
		exit;
		}
mysqli_free_result($result_ProjectCertificate);

$now_time = date("Y-m-d H:i:s",mktime());
$sql_insert = "INSERT INTO ProjectCertificateHistory(PCID,PID,PCNo,PCName,PCType,PCTypeName,PCFile,PCSDate,PCEDate,ISRemind,RemindNote,Reminder,RemindDate,RemindIP,ISNotice,NoticeNote,Notifier,NoticeDate,NoticeIP,PCNote,ExpireDate,AddUser,AddDate,AddIP,Deltag,ProcUser,ProcDate,ProcIP,UpdateUser,UpdateDate,UpdateIP) SELECT PCID,PID,PCNo,PCName,PCType,PCTypeName,PCFile,PCSDate,PCEDate,ISRemind,RemindNote,Reminder,RemindDate,RemindIP,ISNotice,NoticeNote,Notifier,NoticeDate,NoticeIP,PCNote,ExpireDate,AddUser,AddDate,AddIP,Deltag,ProcUser,ProcDate,ProcIP,'".$_SESSION["reg_MUID"]."','".$now_time."','".$_SERVER["REMOTE_ADDR"]."' FROM ProjectCertificate where Deltag='N' and PID = '".$PID."' and PCID = '".$PCID."';";
$result_insert=mysqli_query($link,$sql_insert) or die ("無法執行新增");
$sql_update = "update ProjectCertificate set Deltag = 'Y',ProcUser = '".$_SESSION["reg_MUID"]."',ProcDate = '".$now_time."',ProcIP = '".$_SERVER["REMOTE_ADDR"]."' where Deltag='N' and PID = '".$PID."' and PCID = '".$PCID."';";
$result_update=mysqli_query($link,$sql_update) or die ("無法執行修改");

mysqli_close($link);
?>
<script type="text/JavaScript">
	<!--
	alert ("刪除成功！");
	location.href="ProjectCertificate.php?PID=<?php echo $PID;?>&page=<?php echo $page;?>";
	//-->
</script>

</body>
</html>
