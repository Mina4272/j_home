﻿<?php
include "CheckPermission.php";
include "../global.php";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $PageAdminTitle;?></title>
</head>

<body>
<?php
$MID = $_POST['MID'];
$EVType = $_POST['EVType'];
//echo $MID;
//echo $EVType;
//exit;
if (trim($EVType) == "C") {
		$SQL_EmployeeVacation="SELECT ifnull( sum( EVCount ) , 0 ) FROM EmployeeVacation WHERE Deltag = 'N' and MID=".$MID.";";
		//echo $SQL_EmployeeVacation;
		//exit;
		$result_EmployeeVacation=mysqli_query($link,$SQL_EmployeeVacation) or die ("無法執行查詢");
		list($NVDate)=mysqli_fetch_row($result_EmployeeVacation);
		mysqli_free_result($result_EmployeeVacation);
}

$SQL_Manager="select MUID,MName,MEName,RDate,date_format(RDate,'%m'),DATEDIFF(NOW(),RDate) RDateCount from Manager where Deltag='N' and MID=".$MID.";";
$result_Manager=mysqli_query($link,$SQL_Manager) or die ("無法執行查詢");
list($MUID,$MName,$MEName,$RDate,$RMonth,$RDateCount)=mysqli_fetch_row($result_Manager);
mysqli_free_result($result_Manager);

//$SDate = (floor($RDateCount / 365));
// 2017 新版年假
$SDate = $RDateCount / 365;
if ($SDate < 0.5) $VDate = 0;
else if ($SDate >= 0.5 && $SDate < 1) $VDate = 3;
else if ($SDate >= 1 && $SDate < 2) $VDate = 7;
else if ($SDate >= 2 && $SDate < 3) $VDate = 10;
else if ($SDate >= 3 && $SDate < 5) $VDate = 14;
else if ($SDate >= 5 && $SDate < 10) $VDate = 15;
else if ($SDate >= 10 && $SDate < 11) $VDate = 16;
else if ($SDate >= 11 && $SDate < 12) $VDate = 17;
else if ($SDate >= 12 && $SDate < 13) $VDate = 18;
else if ($SDate >= 13 && $SDate < 14) $VDate = 19;
else if ($SDate >= 14 && $SDate < 15) $VDate = 20;
else if ($SDate >= 15 && $SDate < 16) $VDate = 21;
else if ($SDate >= 16 && $SDate < 17) $VDate = 22;
else if ($SDate >= 17 && $SDate < 18) $VDate = 23;
else if ($SDate >= 18 && $SDate < 19) $VDate = 24;
else if ($SDate >= 19 && $SDate < 20) $VDate = 25;
else if ($SDate >= 20 && $SDate < 21) $VDate = 26;
else if ($SDate >= 21 && $SDate < 22) $VDate = 27;
else if ($SDate >= 22 && $SDate < 23) $VDate = 28;
else if ($SDate >= 23 && $SDate < 24) $VDate = 29;
else if ($SDate >= 24 && $SDate < 25) $VDate = 30;
else if ($SDate >= 25 && $SDate < 26) $VDate = 30;
else if ($SDate >= 26) {
		//$VDate = 15 + (floor($SDate)-10);
		if ($VDate > 30) $VDate = 30;
		}

if ($SDate < 0.5) $VMsg = ' 未滿六個月';
else if ($SDate >= 0.5 && $SDate < 1) $VMsg = ' (6個月以上未滿1年)';
else if ($SDate >= 1 && $SDate < 2) $VMsg = ' (1年以上未滿2年)';
else if ($SDate >= 2 && $SDate < 3) $VMsg = ' (2年以上未滿3年)';
else if ($SDate >= 3 && $SDate < 5) $VMsg = ' (3年以上未滿5年)';
else if ($SDate >= 5 && $SDate < 10) $VMsg = ' (5年以上未滿10年)';
else if ($SDate >= 10 && $SDate < 11) $VMsg = ' (10年以上未滿11年)';
else if ($SDate >= 11 && $SDate < 12) $VMsg = ' (11年以上未滿12年)';
else if ($SDate >= 12 && $SDate < 13) $VMsg = ' (12年以上未滿13年)';
else if ($SDate >= 13 && $SDate < 14) $VMsg = ' (13年以上未滿14年)';
else if ($SDate >= 14 && $SDate < 15) $VMsg = ' (14年以上未滿15年)';
else if ($SDate >= 15 && $SDate < 16) $VMsg = ' (15年以上未滿16年)';
else if ($SDate >= 16 && $SDate < 17) $VMsg = ' (16年以上未滿17年)';
else if ($SDate >= 17 && $SDate < 18) $VMsg = ' (17年以上未滿18年)';
else if ($SDate >= 18 && $SDate < 19) $VMsg = ' (18年以上未滿19年)';
else if ($SDate >= 19 && $SDate < 20) $VMsg = ' (19年以上未滿20年)';
else if ($SDate >= 20 && $SDate < 21) $VMsg = ' (20年以上未滿21年)';
else if ($SDate >= 21 && $SDate < 22) $VMsg = ' (21年以上未滿22年)';
else if ($SDate >= 22 && $SDate < 23) $VMsg = ' (22年以上未滿23年)';
else if ($SDate >= 23 && $SDate < 24) $VMsg = ' (23年以上未滿24年)';
else if ($SDate >= 24 && $SDate < 25) $VMsg = ' (24年以上未滿25年)';
else if ($SDate >= 25 && $SDate < 26) $VMsg = ' (25年以上未滿26年)';
else if ($SDate >= 26) $VMsg = ' (26年以上)';
	

/*
$SDate = (floor($RDateCount / 365));
if ($SDate > 1) {
		$SQL_Vacation="select VDay1,VDay2,VDay3,VDay4,VDay5,VDay6 from Vacation where VDate ='2011-".$RMonth."-01';";
		$result_Vacation=mysqli_query($link,$SQL_Vacation) or die ("無法執行查詢");
		list($VDay1,$VDay2,$VDay3,$VDay4,$VDay5,$VDay6)=mysqli_fetch_row($result_Vacation);
		mysqli_free_result($result_Vacation);
		$VDay = array($VDay1,$VDay2,$VDay3,$VDay4,$VDay5,$VDay6);
		$VIndex = $SDate;
		if ($VIndex > 6) $VIndex = 6;
		$VDate=$VDay[$VIndex-1];
		if ($SDate > 10) {
				$VDate = $VDate + ($SDate-10);
				if ($VDate > 30) $VDate = 30;
				}
		}
else $VDate=0;
*/
?>
<script type="text/JavaScript">
		<!--
		opener.document.form1.MID.value='<?php echo $MID;?>';
		opener.document.getElementById('MNamePreview').style.display = '';
		<?php if (trim($EVType) == "C") {?>
		opener.document.form1.NVDate.value='<?php echo $NVDate;?>';
		opener.document.getElementById('MNamePreview').innerHTML = '<?php echo $MEName.$MName;?>(<?php echo $MUID;?>)　<font color=blue>到職日：<?php echo $RDate;?>　剩餘年假：<?php echo $NVDate;?> 天</font>';
		<?php } else {?>
		opener.document.getElementById('MNamePreview').innerHTML = '<?php echo $MEName.$MName;?>(<?php echo $MUID;?>)　<font color=blue>到職日：<?php echo $RDate; echo $VMsg;?>　建議年假：<?php echo $VDate;?> 天</font>';
		opener.document.form1.EVCount.value='<?php echo $VDate;?>';
		<?php }?>
		self.close();
		//-->
</script>
</body>
</html>
<?php
mysqli_close($link);
?>