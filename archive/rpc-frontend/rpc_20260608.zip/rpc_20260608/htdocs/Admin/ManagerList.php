﻿<?php
include "CheckPermission.php";
include "../global.php";
include "include/page_function.php";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $PageAdminTitle;?></title>
<link href="../type.css" rel="stylesheet" type="text/css" />
<style type="text/css">
<!--
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
}
-->
</style></head>

<body>
<?php include "top.php";?>
<table width="100%" border="0" cellspacing="0" cellpadding="5">
	<tr>
    <td width="160" height="600" align="left" valign="top">
			<?php include "menu.php";?>
    </td>
    <td valign="top">
    	<table width="100%" border="0" cellpadding="0" cellspacing="0">
    		<tr>
    			<td>
			    	<table width="750" border="0" cellpadding="0" cellspacing="0">
			    		<tr height="30">
			    			<td class="c2">員工資訊</td>
			    		</tr>
			    	</table>
			    	<table width="750" border="0" cellpadding="0" cellspacing="0">
					<form name="form1" action="ManagerList.php" method="post">
			    		
						<!--
			    			<td width="240" align="right" class="h3">關鍵字：<input type="text" name="KeyWord" size="20" value="<?php echo $KeyWord;?>"></td>
						-->
						<tr height="30">
			    			<td class="h3">
			    				<font color=blue><b>關鍵字：</b></font><input type="text" name="KeyWord" size="15" value="<?php echo empty($_POST['KeyWord'])?"":$_POST['KeyWord'];?>"> 
								<font color=blue><b>工作內容、備註：</b></font><input type="text" name="job" size="15" value="<?php echo empty($_POST['job'])?"":$_POST['job'];?>"> 
			    				<?php if (trim(strstr($_SESSION["reg_MPer"],'G')) != ""){?>
								<font color=blue><b>是否離職：</b></font>
			    				<select id="IsLeft" name="IsLeft">
								<?php
									$IsLeft = empty($_POST['IsLeft'])?"":$_POST['IsLeft'];
									if($IsLeft ==""){
										$IsLeft = empty($_GET['IsLeft'])?"":$_GET['IsLeft'];
									}
								?>
									<option value="N"<?php if ($IsLeft =='N') echo " selected";?>>否</option>
									<option value="Y"<?php if ($IsLeft =='Y') echo " selected";?>>是</option>
			    				</select>
								<?php }?>
			    				<input type="submit" name="submit" value="查 詢" class="input_bot"> 
			    				<!--<input type="button" name="button" class="input_bot" value="全部列出" onclick="javascript:location.href='EmployeePayList.php';"> -->
			    			
			   
						
			    		<td align="right" class="h3">
			    			<?php if (trim(strstr($_SESSION["reg_MPer"],'G')) != ""){?>
			    				<input type="button" name="add" value="新 增" class="input_bot" onclick="javascript:location.href='ManagerAdd.php';">
			    			<?php }?>
			    		</td>
			    		<td width="20"></td>
			    		</tr>
			    	</table>
						<?php
						$page = empty($_GET['page'])?"":$_GET['page'];
						//echo $page;
						if (trim($page) == "") $page = 1;
						$page_rows=15;  //每頁筆數
						$php_Self = "ManagerList.php";  //分頁web檔名
						$button_css = "h4";
						$limit_txt =" limit ".(($page-1) * $page_rows).",".$page_rows;
						
						$IsLeft = empty($_POST['IsLeft'])?"":$_POST['IsLeft'];
						if($IsLeft ==""){
							$IsLeft = empty($_GET['IsLeft'])?"":$_GET['IsLeft'];
						}
						$url_str = "&IsLeft=".$IsLeft."&KeyWord='".urlencode(empty($_POST['KeyWord'])?"":$_POST['KeyWord'])."'";
						if(!empty($IsLeft)){
							$SqlTxt = "and IsLeft ='".$IsLeft."'";
						}else{
							$SqlTxt="and IsLeft ='N'";
						}
						$KeyWord = empty($_POST['KeyWord'])?"":$_POST['KeyWord'];
						$job = empty($_POST['job'])?"":$_POST['job'];
						$MID ="0";
						if(!empty($job)){
							$Sql_job = "select DISTINCT(MID) as ID from Managerjob where MJDescription like '%".$job."%' or MJNote like '%".$job."%'";
							$result_job=mysqli_query($link,$Sql_job) or die ("無法執行查詢");
							while(list($ID)=mysqli_fetch_row($result_job)){
								if(empty($MID)){
									$MID = "'".$ID."'";
								}else{
									$MID .= ",'".$ID."'";
								}
							}
							
							
						}
						//echo $MID;
						
					
						if (trim($KeyWord) != "") $SqlTxt = $SqlTxt." and (MName like '%".$KeyWord."%' or MUID like '%".$KeyWord."%' or MIntro like '%".$KeyWord."%')";
						if (trim($job) != "") $SqlTxt = $SqlTxt." and MID IN(".$MID.")";
						//echo $SqlTxt;
						if (trim(strstr($_SESSION["reg_MPer"],'G')) != ""){
							$Sql_str="select MID,MUID,MPassword,MName,MEName,EmployeeNo,EMail,MIntro,MPer from Manager where Deltag='N' ".$SqlTxt." order by MID desc;";
						}else{
							$Sql_str="select MID,MUID,MPassword,MName,MEName,EmployeeNo,EMail,MIntro,MPer from Manager where IsLeft='N' and Deltag='N' ".$SqlTxt." order by MID desc;";
						}
						
						if (trim(strstr($_SESSION["reg_MPer"],'G')) != ""){
							if ($KeyWord || $job){
								//$KeyWord = empty($_POST['KeyWord'])?"":$_POST['KeyWord'];
								$SQL_Manager="select MID,MUID,MPassword,MName,MEName,EmployeeNo,EMail,MIntro,MPer,ISEngineer,ISBusiness from Manager where Deltag='N' ".$SqlTxt." order by MID ".$limit_txt.";";
							}else{
								$SQL_Manager="select MID,MUID,MPassword,MName,MEName,EmployeeNo,EMail,MIntro,MPer,ISEngineer,ISBusiness from Manager where Deltag='N' ".$SqlTxt." order by MID ".$limit_txt.";";
							}
							
						}else{
							if ($KeyWord || $job){
								//$KeyWord = empty($_POST['KeyWord'])?"":$_POST['KeyWord'];
								$SQL_Manager="select MID,MUID,MPassword,MName,MEName,EmployeeNo,EMail,MIntro,MPer,ISEngineer,ISBusiness from Manager where IsLeft='N' and Deltag='N' ".$SqlTxt." order by MID ".$limit_txt.";";
							}else{
								$SQL_Manager="select MID,MUID,MPassword,MName,MEName,EmployeeNo,EMail,MIntro,MPer,ISEngineer,ISBusiness from Manager where IsLeft='N' and Deltag='N' order by MID ".$limit_txt.";";
							}
						}
						//echo $SQL_Manager;
						
						$result_Manager=mysqli_query($link,$SQL_Manager) or die ("無法執行查詢");
						?>
			    	<table width="750" border="0" cellpadding="5" cellspacing="2" class="s2">
			        <tr align="center">
			          <td width="80" align="center" background="../images/table_bg.gif" class="t21">案件管理</td>
			          <td width="80" background="../images/table_bg.gif" class="t21">帳 號</td>
			          <td width="100" background="../images/table_bg.gif" class="t21">姓 名</td>
			          <td background="../images/table_bg.gif" class="t21">備 註</td>
		    				<?php if (trim(strstr($_SESSION["reg_MPer"],'G')) != ""){?>
				          <td width="60" background="../images/table_bg.gif" class="t21">查 詢</td>
				          <td width="60" background="../images/table_bg.gif" class="t21">例行工作</td>
		    				<?php } else {?>
				          <td width="60" background="../images/table_bg.gif" class="t21">查 詢</td>
					  <td width="60" background="../images/table_bg.gif" class="t21">例行工作</td>
		    				<?php }?>
			        </tr>
		          <?php
		          $tmp = 1;
		          while(list($MID,$MUID,$MPassword,$MName,$MEName,$EmployeeNo,$EMail,$MIntro,$MPer,$ISEngineer,$ISBusiness)=mysqli_fetch_row($result_Manager)){
		        	?>
		        	<tr<?php if ($tmp%2 == 0) echo " bgcolor=\"#F6F6F6\"";?>>
			                <td align="center">
							       <?php if ($ISEngineer == "Y") {?> <input type="button" name="edit" value="工程" class="input_bot" onclick="javascript:location.href='ProjectList.php?QPE=<?php echo $MUID;?>&page=<?php echo $page;?>';"> <?php }?>
							       <?php if ($ISBusiness == "Y") {?> <input type="button" name="edit" value="客服" class="input_bot" onclick="javascript:location.href='ProjectList.php?QBMUID=<?php echo $MUID;?>&page=<?php echo $page;?>';"> <?php }?>
				            </td>
					<!--td align="center" class="h3"><?php echo $MID;?></td-->
			          <td align="center" class="h3"><?php echo $MUID;?></td>
			          <td align="center" class="h3"><?php echo $MName;?><br><?php echo $MEName?></td>
			          <td class="h4"><?php echo $MIntro;?></td>
		    				<?php if (trim(strstr($_SESSION["reg_MPer"],'G')) != ""){?>
				          <td align="center"><input type="button" name="edit" value="查 詢" class="input_bot" onclick="javascript:location.href='ManagerDetail.php?MID=<?php echo $MID;?>&page=<?php echo $page;?>';"></td>
					  <!--td align="center"><input type="button" name="edit" value="例行工作" class="input_bot" onclick="javascript:location.href='ManagerJob.php?MID=<?php echo $MID;?>&MName=<?php echo $MName;?>&page=<?php echo $page;?>';"></td-->
				          <!--td align="center"><input type="button" name="edit" value="例行工作" class="input_bot" onclick="javascript:location.href='ManagerJob.php?MID=<?php echo $MID;?>&MName=<?php echo $MName;?>&page=<?php echo 1;?>';"></td-->
						   <td align="center" width="60"><a  target="_blank" href="ManagerJob.php?MID=<?php echo $MID;?>&MName=<?php echo $MName;?>&page=<?php echo 1;?>" class="input_bot"><font size="1px">例行工作</font></a></td>
		    				<?php } else {?>
				          <td align="center"><input type="button" name="edit" value="查 詢" class="input_bot" onclick="javascript:location.href='ManagerDetail.php?MID=<?php echo $MID;?>&page=<?php echo $page;?>';"></td>
					  <!--td align="center"><input type="button" name="edit" value="例行工作" class="input_bot" onclick="javascript:location.href='ManagerJob.php?MID=<?php echo $MID;?>&MName=<?php echo $MName;?>&page=<?php echo $page;?>';"></td-->
					  <!--td align="center"><input type="button" name="edit" value="例行工作" class="input_bot" onclick="javascript:location.href='ManagerJob.php?MID=<?php echo $MID;?>&MName=<?php echo $MName;?>&page=<?php echo 1;?>';"></td-->
		    				<td align="center" width="60"><a  target="_blank" href="ManagerJob.php?MID=<?php echo $MID;?>&MName=<?php echo $MName;?>&page=<?php echo 1;?>" class="input_bot"><font size="1px">例行工作</font></a></td>
							<?php }?>
			        </tr>
			        <?php
            			$tmp++;
			      			}
            	mysqli_free_result($result_Manager);
			        ?>
			      </table>
			      <table width="750" border="0" cellpadding="5" cellspacing="2" class="s2">
			        <tr align="center">
			          <td bgcolor="#E8F0C2" class="h4"><?php Page_show($Sql_str,$page_rows,$php_Self,$link,$page,$url_str,$button_css);?></td>
			        </tr>
			      </table>
    			</td>
    		</tr>
    	</table>
    </td>
	</tr>
</table>
<?php include "down.php";?>
</body>
</html>
<?php
mysqli_close($link);
?>