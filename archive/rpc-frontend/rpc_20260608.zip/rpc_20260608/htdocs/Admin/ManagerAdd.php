﻿<?php	
include "CheckPermission.php";
include "CheckManager.php";
include "../global.php";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $PageAdminTitle;?></title>
<link href="../type.css" rel="stylesheet" type="text/css" />
<style type="text/css">
<!--
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
}
-->
</style>
<link href="../script/DatePicker.css" rel="stylesheet" type="text/css" />
<Script LANGUAGE="Javascript" SRC="../script/DatePicker.js"></Script>
<Script type="text/javascript" language="javascript" src="../script/CheckForm.js"></Script>
<script type="text/JavaScript">
<!--
function jsCheck() 
		{
		if (ChkImp('MUID',document.form1.MUID.value,'帳號') == false) return false;
		if (isBig5(document.form1.MUID.value))
				{
				alert ('您輸入的帳號不得含有中文字及其他符號！');
				document.form1.MUID.focus();
				document.form1.MUID.select();
				return false;
				}
		if (ChkImp('MPassword',document.form1.MPassword.value,'密碼') == false) return false;
		if (ChkImp('MPasswordCheck',document.form1.MPasswordCheck.value,'確認密碼') == false) return false;
		if (jsTrim(document.form1.MPassword.value) != jsTrim(document.form1.MPasswordCheck.value))
				{
				alert ('您輸入的密碼與確認密碼不相同，請重新輸入！');
				document.form1.MPassword.value = '';
				document.form1.MPasswordCheck.value = '';
				document.form1.MPassword.focus();
				return false;
				}
		if (ChkImp('MName',document.form1.MName.value,'姓名') == false) return false;
    <?php if (trim($_SESSION["reg_MUID"]) == "Benson" || trim($_SESSION["reg_MUID"]) == "vivi" || trim($_SESSION["reg_MUID"]) == "jacky") {?>
		if (jsTrim(document.form1.Salary.value) != "") if (ChkNaN('Salary',document.form1.Salary.value,'本薪','') == false) return false;
		if (jsTrim(document.form1.Allowance.value) != "") if (ChkNaN('Allowance',document.form1.Allowance.value,'職務加給','') == false) return false;
		if (jsTrim(document.form1.FullAttendance.value) != "") if (ChkNaN('FullAttendance',document.form1.FullAttendance.value,'全勤獎金','') == false) return false;
		if (jsTrim(document.form1.Bonus.value) != "") if (ChkNaN('Bonus',document.form1.Bonus.value,'績效獎金','') == false) return false;
		if (jsTrim(document.form1.CLabor.value) != "") if (ChkNaN('CLabor',document.form1.CLabor.value,'勞保費-公司負擔','') == false) return false;
		if (jsTrim(document.form1.ELabor.value) != "") if (ChkNaN('ELabor',document.form1.ELabor.value,'勞保費-員工負擔','') == false) return false;
		if (jsTrim(document.form1.CHealth.value) != "") if (ChkNaN('CHealth',document.form1.CHealth.value,'健保費-公司負擔','') == false) return false;
		if (jsTrim(document.form1.EHealth.value) != "") if (ChkNaN('EHealth',document.form1.EHealth.value,'健保費-員工負擔','') == false) return false;
		if (jsTrim(document.form1.CRetirement.value) != "") if (ChkNaN('CRetirement',document.form1.CRetirement.value,'勞退提撥-公司負擔','') == false) return false;
		<?php }?>
		if (ChkEmail('EMail',document.form1.EMail.value,'E-Mail') == false) return false;
		if (document.form1.MPer[0].checked == false && document.form1.MPer[1].checked == false && document.form1.MPer[2].checked == false && document.form1.MPer[3].checked == false && document.form1.MPer[4].checked == false && document.form1.MPer[5].checked == false && document.form1.MPer[6].checked == false && document.form1.MPer[7].checked == false && document.form1.MPer[8].checked == false && document.form1.MPer[9].checked == false && document.form1.MPer[10].checked == false && document.form1.MPer[11].checked == false && document.form1.MPer[12].checked == false && document.form1.MPer[13].checked == false && document.form1.MPer[14].checked == false && document.form1.MPer[15].checked == false && document.form1.MPer[16].checked == false)
				{
				alert ('您必須選擇一項權限！');
				document.form1.MPer[0].focus();
				return false;
				}
		if (jsTrim(document.form1.RYear.value) != "" || jsTrim(document.form1.RMonth.value) != "" || jsTrim(document.form1.RDay.value) != "") if (ChkDate('RYear',document.form1.RYear.value,document.form1.RMonth.value,document.form1.RDay.value,'到職日') == false) return false;
		if (jsTrim(document.form1.BirthYear.value) != "" || jsTrim(document.form1.BirthMonth.value) != "" || jsTrim(document.form1.BirthDay.value) != "") if (ChkDate('BirthYear',document.form1.BirthYear.value,document.form1.BirthMonth.value,document.form1.BirthDay.value,'生日') == false) return false;
		}
function CheckMPer(MPerValue)
		{
		if (MPerValue == "D") {
				if (document.form1.MPer[5].checked==true) {
						if (document.form1.MPer[6].checked==true) document.form1.MPer[6].checked=false;
						if (document.form1.MPer[7].checked==true) document.form1.MPer[7].checked=false;
						}
				}
		else if (MPerValue == "I") {
				if (document.form1.MPer[6].checked==true) if (document.form1.MPer[5].checked==true) document.form1.MPer[5].checked=false;
				}
		else if (MPerValue == "L") {
				if (document.form1.MPer[7].checked==true) if (document.form1.MPer[5].checked==true) document.form1.MPer[5].checked=false;
				}
		}
//-->
</script>
</head>
<body>
<?php include "top.php";?>
<table width="100%" border="0" cellspacing="0" cellpadding="5">
	<tr>
    <td width="160" height="600" align="left" valign="top">
			<?php include "menu.php";?>
    </td>
    <td valign="top">
    	<table width="100%" border="0" cellpadding="0" cellspacing="0">
    		<tr>
    			<td>
			    	<table width="750" border="0" cellpadding="0" cellspacing="0">
			    		<tr height="30">
			    			<td class="c2"><b>新增帳號資料</b></td>
			    		</tr>
			    	</table>
			    	<table width="750" border="0" cellpadding="0" cellspacing="0">
			        <form name="form1" method="post" action="ManagerAddDB.php" onSubmit="return jsCheck();">
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td width="160" align="right" class="c3">帳 號：</td>
			          <td class="h3"><input type="text" id="MUID" name="MUID" size="20"></td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">密 碼：</td>
			          <td class="h3"><input type="password" id="MPassword" name="MPassword" size="20"></td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">密碼確認：</td>
			          <td class="h3"><input type="password" id="MPasswordCheck" name="MPasswordCheck" size="20"></td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">中文姓名：</td>
			          <td class="h3"><input type="text" id="MName" name="MName" size="20"></td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">英文姓名：</td>
			          <td class="h3"><input type="text" id="MEName" name="MEName" size="30"></td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">員工編號：</td>
			          <td class="h3"><input type="text" id="EmployeeNo" name="EmployeeNo" size="20"></td>
			        </tr>
			        <?php if (trim($_SESSION["reg_MUID"]) == "Benson" || trim($_SESSION["reg_MUID"]) == "vivi" || trim($_SESSION["reg_MUID"]) == "jacky") {?>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">身份證號：</td>
			          <td class="h3"><input type="text" id="MPID" name="MPID" size="20" value="<?php echo empty($_POST['MPID'])?"":$_POST['MPID'];?>"></td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">本薪：</td>
			          <td class="h3"><input type="text" id="Salary" name="Salary" size="20" value="<?php echo empty($_POST['Salary'])?"":$_POST['Salary'];?>"></td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">職務加給：</td>
			          <td class="h3"><input type="text" id="Allowance" name="Allowance" size="20" value="<?php echo empty($_POST['Allowance'])?"":$_POST['Allowance'];?>"></td>
			        </tr>
					 <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">全勤獎金：</td>
			          <td class="h3"><input type="text" id="FullAttendance" name="FullAttendance" size="20" value="<?php echo empty($_POST['FullAttendance'])?"":$_POST['FullAttendance'];?>"></td>
			        </tr>
					 <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">績效獎金：</td>
			          <td class="h3"><input type="text" id="Bonus" name="Bonus" size="20" value="<?php echo empty($_POST['Bonus'])?"":$_POST['Bonus'];?>"></td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">勞保費-公司負擔：</td>
			          <td class="h3"><input type="text" id="CLabor" name="CLabor" size="20" value="<?php echo empty($_POST['CLabor'])?"":$_POST['CLabor'];?>"></td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">勞保費-員工負擔：</td>
			          <td class="h3"><input type="text" id="ELabor" name="ELabor" size="20" value="<?php echo empty($_POST['ELabor'])?"":$_POST['ELabor'];?>"></td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">健保費-公司負擔：</td>
			          <td class="h3"><input type="text" id="CHealth" name="CHealth" size="20" value="<?php echo empty($_POST['CHealth'])?"":$_POST['CHealth'];?>"></td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">健保費-員工負擔：</td>
			          <td class="h3"><input type="text" id="EHealth" name="EHealth" size="20" value="<?php echo empty($_POST['EHealth'])?"":$_POST['EHealth'];?>"></td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">勞退提撥-公司負擔：</td>
			          <td class="h3"><input type="text" id="CRetirement" name="CRetirement" size="20" value="<?php echo empty($_POST['CRetirement'])?"":$_POST['CRetirement'];?>"></td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">行庫代號：</td>
			          <td class="h3"><input type="text" id="BCode" name="BCode" size="10" value="<?php echo empty($_POST['BCode'])?"":$_POST['BCode'];?>"></td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">銀行帳號：</td>
			          <td class="h3"><input type="text" id="BAccount" name="BAccount" size="60"></td>
			        </tr>
			        <?php }?>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">部門別：</td>
			          <td class="h3">
			          	<select id="Departments" name="Departments">
			          		<option value="A">工程部</option>
			          		<option value="B">行政品質部</option>
			          		<option value="C">客服部</option>
			          	</select>
			          </td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">職稱：</td>
			          <td class="h3"><input type="text" id="Title" name="Title" size="20"></td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">分機號碼：</td>
			          <td class="h3"><input type="text" id="Ext" name="Ext" size="10"></td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">E-Mail：</td>
			          <td class="h3"><input type="text" id="EMail" name="EMail" size="60"></td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">是否為案件工程師：</td>
			          <td class="h3">
			          	<input type="radio" name="ISEngineer" value="Y"> 是　
			          	<input type="radio" name="ISEngineer" value="N" checked> 否
			          </td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">是否為客服：</td>
			          <td class="h3">
			          	<input type="radio" name="ISBusiness" value="Y"> 是　
			          	<input type="radio" name="ISBusiness" value="N" checked> 否
			          </td>
			        </tr>
			        <tr height="60" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">權限管理：</td>
			          <td class="h3">
			          	<input type="checkbox" id="MPer" name="MPer[]" value="A"> 客戶資料管理
			          	<input type="checkbox" id="MPer" name="MPer[]" value="P"> 報價/機密約定事項(收入)
			          	<input type="checkbox" id="MPer" name="MPer[]" value="Q"> 報價/機密約定事項(支出)<br>
			          	<input type="checkbox" id="MPer" name="MPer[]" value="B"> 客戶案件管理
			          	<input type="checkbox" id="MPer" name="MPer[]" value="C"> 重要零組件搜尋引擎<br>
			          	<input type="checkbox" id="MPer" name="MPer[]" value="D" onclick="javascript:CheckMPer('D');"> 客戶案件帳務管理
			          	<input type="checkbox" id="MPer" name="MPer[]" value="I" onclick="javascript:CheckMPer('I');"> 帳務收入管理
			          	<input type="checkbox" id="MPer" name="MPer[]" value="L" onclick="javascript:CheckMPer('L');"> 帳務支出管理
			          	<input type="checkbox" id="MPer" name="MPer[]" value="E"> 一般帳務管理<br>
			          	<input type="checkbox" id="MPer" name="MPer[]" value="F"> 帳務報表
			          	<input type="checkbox" id="MPer" name="MPer[]" value="G"> 系統帳號管理
			          	<input type="checkbox" id="MPer" name="MPer[]" value="H"> 公佈欄管理
			          	<input type="checkbox" id="MPer" name="MPer[]" value="J"> 請假單簽核<br>
			          	<input type="checkbox" id="MPer" name="MPer[]" value="K"> 費用申請簽核
			          	<input type="checkbox" id="MPer" name="MPer[]" value="M"> 事項處理
			          	<input type="checkbox" id="MPer" name="MPer[]" value="N"> 教育訓練
			          	<input type="checkbox" id="MPer" name="MPer[]" value="O"> 薪資管理
			          </td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">到職日：</td>
			          <td class="h3">
		              <input id="RYear" name="RYear" type="text" size="4" /> 年 
		              <input id="RMonth" name="RMonth" type="text" size="2" /> 月 
		              <input id="RDay" name="RDay" type="text" size="2" /> 日 
		              <img src="../images/icon.gif" width="16" height="18" style="cursor: hand" onclick="javascript:displayDatePicker('RYear','RMonth','RDay');"/>
			          </td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">生日：</td>
			          <td class="h3">
		              <input id="BirthYear" name="BirthYear" type="text" size="4" /> 年 
		              <input id="BirthMonth" name="BirthMonth" type="text" size="2" /> 月 
		              <input id="BirthDay" name="BirthDay" type="text" size="2" /> 日 
		              <img src="../images/icon.gif" width="16" height="18" style="cursor: hand" onclick="javascript:displayDatePicker('BirthYear','BirthMonth','BirthDay');"/>
			          </td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">連絡地址：</td>
			          <td class="h3"><input type="text" id="Address" name="Address" size="60"></td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">戶籍地址：</td>
			          <td class="h3"><input type="text" id="RAddress" name="RAddress" size="60"></td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">聯絡電話：</td>
			          <td class="h3"><input type="text" id="Tel" name="Tel" size="30"></td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">手機號碼：</td>
			          <td class="h3"><input type="text" id="Mobile" name="Mobile" size="30"></td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">備註：</td>
			          <td class="h3"><input type="text" id="MIntro" name="MIntro" size="60"></td>
			        </tr>
			        <tr height="40" align="center">
			          <td colspan="2" class="h3"><input type="submit" name="submit" class="input_bot" value="送 出"></td>
			        </tr>
				      </form>
			      </table>
    			</td>
    		</tr>
    	</table>
    </td>
	</tr>
</table>
<?php include "down.php";?>
</body>
</html>
<?php
mysqli_close($link);
?>