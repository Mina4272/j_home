﻿<?php	
include "CheckPermission.php";
include "CheckCustomer.php";
include "../global.php";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $PageAdminTitle;?></title>
<link href="../type.css" rel="stylesheet" type="text/css" />
<style type="text/css">
<!--
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
}
-->
</style>
<link href="../script/DatePicker.css" rel="stylesheet" type="text/css" />
<Script LANGUAGE="Javascript" SRC="../script/DatePicker.js"></Script>
<Script type="text/javascript" language="javascript" src="../script/CheckForm.js"></Script>
<script type="text/JavaScript">
<!--
function jsCheck() 
		{
		if (ChkImp('CFName',document.form1.CFName.value,'檔案說明') == false) return false;
		}
//-->
</script>
</head>
<body>
<?php
$CFID = $_GET['CFID'];
$CID = $_GET['CID'];
if (trim($CID) == "" || trim($CFID) == "")
		{
		mysqli_close($link);
		?>
		<script type="text/JavaScript">
			<!--
			alert ("查無資料，請冾網站管理人員！");
			self.close();
			//-->
		</script>
		<?php
		exit;
		}
$SQL_CustomerFile="select CFName,CFile,AddUser,AddDate,ProcUser,ProcDate from CustomerFile where Deltag='N' and CID = '".$CID."' and CFID = '".$CFID."';";
$result_CustomerFile=mysqli_query($link,$SQL_CustomerFile) or die ("無法執行查詢");
if (mysqli_num_rows($result_CustomerFile) == 0)
		{
		mysqli_free_result($result_CustomerFile);
		mysqli_close($link);
		?>
		<SCRIPT language=javascript>
		<!--
		alert ("查無資料，請冾網站管理人員！"); 
		self.close();
		//-->
		</SCRIPT>
		<?php 	
		exit;
		}
list($CFName,$CFile,$AddUser,$AddDate,$ProcUser,$ProcDate)=mysqli_fetch_row($result_CustomerFile);
mysqli_free_result($result_CustomerFile);
?>
<table width="100%" border="0" cellpadding="0" cellspacing="0">
	<tr>
		<td>
    	<table width="100%" border="0" cellpadding="0" cellspacing="0">
    		<tr height="30">
					<td width="15" background="../images/table_bg.gif"></td>
    			<td class="c3" background="../images/table_bg.gif"><b>修改客戶相關檔案</b></td>
    		</tr>
    	</table>
    	<table width="100%" border="0" cellpadding="0" cellspacing="0">
        <form name="form1" method="post" action="CustomerFileEditDB.php" enctype="multipart/form-data" onSubmit="return jsCheck();">
        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
					<td width="15"></td>
          <td width="80" class="c3" align="right">檔案說明：</td>
          <td class="c3">
          	<input name="CFName" type="text" size="20" value="<?php echo $CFName;?>" />
          </td>
        </tr>
        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
					<td width="15"></td>
          <td class="c3" align="right">相關檔案：</td>
          <td class="c3">
          	<input name="CFile" type="file" size="60" />
          	<input type="button" name="edit" value="下 載" class="input_bot" onclick="javascript:location.href='getfile.php?FolderName=Admin\\CFile&FileName=<?php echo $CFile;?>';">
          </td>
        </tr>
        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
					<td width="15"></td>
          <td align="right" class="c3">新增人員：</td>
          <td class="h3"><?php echo $AddUser;?>　<?php echo $AddDate;?></td>
        </tr>
        <?php if (trim($ProcUser) != "") {?>
        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
					<td width="15"></td>
          <td align="right" class="c3">最後更新：</td>
          <td class="h3"><?php echo $ProcUser;?>　<?php echo $ProcDate;?>
          	<input type="button" name="edit" value="歷史記錄" class="input_bot" onclick="javascript:window.open ('CustomerFileHistory.php?CID=<?php echo $CID;?>&CFID=<?php echo $CFID;?>','CustomerFileHistory','height=500,width=750,top=200,left=200,scrollbars=yes,status=yes');">
          </td>
        </tr>
        <?php }?>
        <tr height="40" align="center">
					<td width="15"></td>
          <td colspan="2" class="h3">
          	<input type="submit" name="submit" class="input_bot" value="送 出">
          	<input name="CFID" type="hidden" id="CFID" value="<?php echo $CFID;?>" />
          	<input name="CID" type="hidden" id="CID" value="<?php echo $CID;?>" />
          </td>
        </tr>
	      </form>
      </table>
		</td>
	</tr>
</table>
</body>
</html>
<?php
mysqli_close($link);
?>