<?php
function SecretProc($SourceDate,$SourceKey,$Decrypt) {
		//$cwd = getcwd();
		require_once('crypt_class.php');
		$crypt = new CRYPT_CLASS;
		$crypt->set_cipher('twofish');
		$crypt->set_mode('cfb');
      
		if (isset($_COOKIE['enckey'])) {
				$key = $_COOKIE['enckey'];
				$crypt->set_key($key);
		} else {
				$key = $SourceKey;
				$crypt->set_key($key);
		}
   
		if (!empty($key) && !empty($SourceDate) && $Decrypt != 't') {
			  $data = $crypt->encrypt($SourceDate);      
		} elseif (!empty($key) && !empty($SourceDate) && $Decrypt == 't') {
			  $data = $crypt->decrypt($SourceDate);    
		}
return $data;
}
?>
