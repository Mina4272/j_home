﻿<?php	
include "CheckPermission.php";
include "CheckTraining.php";
include "../global.php";
include "include/utf8.php";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $PageAdminTitle;?></title>
<link href="../type.css" rel="stylesheet" type="text/css" />
<style type="text/css">
<!--
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
}
-->
</style>
<link href="../script/DatePicker.css" rel="stylesheet" type="text/css" />
<Script LANGUAGE="Javascript" SRC="../script/DatePicker.js"></Script>
<Script type="text/javascript" language="javascript" src="../script/CheckForm.js"></Script>
<script type="text/JavaScript">
<!--
function jsCheck() 
		{
		//
		//alert(Chkcheckbox('TMid',document.form1.TMid,'參與人員'));
		if (ChkDate('TYear',document.form1.TYear.value,document.form1.TMonth.value,document.form1.TDay.value,'日期') == false) return false;
		if (ChkImp('TTitle',document.form1.TTitle.value,'課程名稱') == false) return false;
		if (ChkImp('Lecturer',document.form1.Lecturer.value,'講師') == false) return false;
		if (ChkImp('TContent',document.form1.TContent.value,'課程大綱') == false) return false;
		if (!Chkcheckbox('TMid',document.form1.TMid,'參與人員') == true) { alert("請輸入參與人員");return false};
		
    //if (jsTrim(document.form1.TFile.value) == "")
    //		{
		//		alert("請選擇您要上傳相關檔案！");
		//		document.form1.TFile.focus();
		//		return false;
    //		}
		}
function Chkcheckbox(OName,str,Omsg)
{

	for (var i=0; i<str.length; i++) {
        if (str[i].checked) {
			return true;
        }
		
    }
	
	return false ;
	
}
//-->
</script>
</head>
<body>
<?php include "top.php";?>
<table width="100%" border="0" cellspacing="0" cellpadding="5">
	<tr>
    <td width="160" height="600" align="left" valign="top">
			<?php include "menu.php";?>
    </td>
    <td valign="top">
    	<table width="100%" border="0" cellpadding="0" cellspacing="0">
    		<tr>
    			<td>
			    	<table width="750" border="0" cellpadding="0" cellspacing="0">
			    		<tr height="30">
			    			<td class="c2">新增教育訓練資訊</td>
			    		</tr>
			    	</table>
			    	<table width="750" border="0" cellpadding="0" cellspacing="0">
			        <form name="form1" method="post" action="TrainingAddDB.php" enctype="multipart/form-data" onSubmit="return jsCheck();">
			        <tr height="40" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td width="120" align="right" class="c3">日期：</td>
			          <td class="h3">
		              <input id="TYear" name="TYear" type="text" size="4" /> 年 
		              <input id="TMonth" name="TMonth" type="text" size="2" /> 月 
		              <input id="TDay" name="TDay" type="text" size="2" /> 日 
		              <img src="../images/icon.gif" width="16" height="18" style="cursor: hand" onclick="javascript:displayDatePicker('TYear','TMonth','TDay');"/>
			          </td>
			        </tr>
					<tr height="40" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td width="120" align="right" class="c3">課程主要名稱:</td>
					  	<td class="h3">
						<select name="TCID">
						<?php
							$SQL="select TCID,TCTTitle from TrainingCamp where Deltag='N' order by TCID;";
							$result=mysqli_query($link,$SQL) or die ("無法執行查詢");
			          		while(list($TCID,$TCTTitle)=mysqli_fetch_row($result)){
						?>
							<option value="<?php echo $TCID;?>"><?php echo $TCTTitle;?></option>
					   <?php
							}
					   ?>
					   </select>
					   </td>
			        </tr>
			        <tr height="40" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td width="120" align="right" class="c3">課程名稱：</td>
			          <td class="h3">
			          	<input type="text" id="TTitle" name="TTitle" size="80">
			          </td>
			        </tr>
			        <tr height="40" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td width="120" align="right" class="c3">講師：</td>
			          <td class="h3">
			          	<input type="text" id="Lecturer" name="Lecturer" size="40">
			          </td>
			        </tr>
					 </tr>
			        <tr height="40" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td width="120" align="right" class="c3">上課地點：</td>
			          <td class="h3">
			          	<input type="radio" name="TLocation" value="meetingroom" checked>會議室<br>
						<input type="radio" name="TLocation" value="other">其他<input type="text" name="othertext"><br>
			          </td>
			        </tr>
					 </tr>
			        <tr height="40" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td width="120" align="right" class="c3">內訓/外訓：</td>
			          <td class="h3">
			          	<input type="radio" name="TTrain" value="in" checked>內訓<br>
						<input type="radio" name="TTrain" value="out">外訓<input type="text" name="outtext"><br>
			          </td>
			        </tr>
					 </tr>
			        <tr height="40" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td width="120" align="right" class="c3">課程時數：</td>
			          <td class="h3">
						<select name="THour">
							<option value="0.5">0.5</option>
							<option value="1">1</option>
							<option value="2">2</option>
							<option value="3">3</option>
							<option value="4">4</option>
							<option value="5">5</option>
							<option value="6">6</option>
							<option value="7">7</option>
							<option value="8">8</option>
							<option value="9">9</option>
							<option value="10">10</option>
							<option value="11">11</option>
							<option value="12">12</option>
							<option value="13">13</option>
							<option value="14">14</option>
							<option value="15">15</option>
							<option value="16">16</option>
							<option value="17">17</option>
							<option value="18">18</option>
							<option value="19">19</option>
							<option value="20">20</option>
							<option value="21">21</option>
							<option value="22">22</option>
							<option value="23">23</option>
							<option value="24">24</option>
							<option value="25">25</option>
							<option value="26">26</option>
							<option value="27">27</option>
							<option value="28">28</option>
							<option value="29">29</option>
							<option value="30">30</option>
							<option value="31">31</option>
							<option value="32">32</option>
							<option value="33">33</option>
							<option value="34">34</option>
							<option value="35">35</option>
							<option value="36">36</option>
							<option value="37">37</option>
							<option value="38">38</option>
							<option value="39">39</option>
							<option value="40">40</option>
						</select>
			          </td>
			        </tr>
					<tr height="40" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td width="120" align="right" class="c3">測試方法：</td>
			          <td class="h3">
			          	<input type="radio" name="TExam" value="no">無<br>
						<input type="radio" name="TExam" value="pen" checked>筆試<br>
						<input type="radio" name="TExam" value="mouth">口試<br>
						<input type="radio" name="TExam" value="operating">實作<br>
						<input type="radio" name="TExam" value="other">其他<input type="text" name="othernote"><br>
			          </td>
			        </tr>
			        <tr height="40" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td width="120" align="right" class="c3">課程大綱：</td>
			          <td class="h3">
    	          	<textarea id="TContent" name="TContent" cols="70" rows="15" class="h3"></textarea>
			          </td>
			        </tr>
			        <tr height="40" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td width="120" align="right" class="c3">課程檔案:</td>
			          <td class="h3"><input type="file" name="TFile" size="60"></td>
			        </tr>
					<tr height="40" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td width="120" align="right" class="c3">教育訓練紀錄:</td>
			          <td class="h3"><input type="file" name="TTrainRecord" size="60"></td>
			        </tr>
					<tr height="40" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td width="120" align="right" class="c3">參與人員:</td>
					  	<td class="h3">
						<?php
							$SQL_Manager="select MID,MUID,MName,MEName from Manager where Deltag='N' and IsLeft='N' order by MID;";
							$result_Manager=mysqli_query($link,$SQL_Manager) or die ("無法執行查詢");
			          		while(list($MID,$MUID,$MName,$MEName)=mysqli_fetch_row($result_Manager)){
						?>
							<input type="checkbox" id="TMid" name="TMid[]" value="<?php echo $MID;?>"/><?php echo $MEName.$MName;?><br/>
					   <?php
							}
					   ?>
					   </td>
			        </tr>
					<?php						
						
						$code = 0;  
						$_SESSION['code'] = $code;
						
						
					  ?>
					  <td><input type="hidden" name="code" value="0"></td>
			        <tr height="40" align="center">
			          <td colspan="2" class="h3"><input type="submit" name="submit" class="input_bot" value="送 出"></td>
			        </tr>
				      </form>
			      </table>
    			</td>
    		</tr>
    	</table>
    </td>
	</tr>
</table>
<?php include "down.php";?>
</body>
</html>
<?php
mysqli_close($link);
?>