﻿<?php
include "CheckPermission.php";
include "../global.php";
include "include/page_function.php";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $PageAdminTitle;?></title>
<link href="../type.css" rel="stylesheet" type="text/css" />
<style type="text/css">
<!--
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
}
-->
</style></head>

<body>
<?php
$CID = $_GET['CID'];
if (trim($CID) == "")
		{
		mysqli_close($link);
		?>
		<script type="text/JavaScript">
			<!--
			alert ("查無資料，請冾網站管理人員！");
			history.go(-1);
			//-->
		</script>
		<?php
		exit;
		}
$SQL_Customer="select CUID,CPWD,CName,EName,TrademarkTxt,TrademarkImg,CTel,CFax,Contact,CMobile,CEMail,CAddress,CNote,CType,CLevel,CRecord,BSMI,AddUser,AddDate,ProcUser,ProcDate from Customer where Deltag='N' and CID = '".$CID."';";
$result_Customer=mysqli_query($link,$SQL_Customer) or die ("無法執行查詢");
if (mysqli_num_rows($result_Customer) == 0)
		{
		mysqli_free_result($result_Customer);
		mysqli_close($link);
		?>
		<SCRIPT language=javascript>
		<!--
		alert ("查無資料，請冾網站管理人員！"); 
		history.go(-1);
		//-->
		</SCRIPT>
		<?php 	
		exit;
		}
mysqli_free_result($result_Customer);

?>
<table width="100%" border="0" cellpadding="0" cellspacing="0">
	<tr>
		<td>
			<?php
			$page = empty($_GET['page'])?"":$_GET['page'];
			if (trim($page) == "") $page = 1;
			$page_rows=15;  //每頁筆數
			$php_Self = "CustomerHistory.php";  //分頁web檔名

			$button_css = "h4";
			$limit_txt =" limit ".(($page-1) * $page_rows).",".$page_rows;
			$url_str = "&CID=".$CID;
			$Sql_str="select CHID,CUID,CType,CPWD,CName,EName,TrademarkTxt,TrademarkImg,CTel,CFax,Contact,CMobile,CEMail,CAddress,CNote,CType,CLevel,CRecord,BSMI,AddUser,AddDate,ProcUser,ProcDate from CustomerHistory where Deltag='N' and CID = '".$CID."' order by CHID desc;";
			$SQL_Customer="select CHID,CUID,CType,CPWD,CName,EName,TrademarkTxt,TrademarkImg,CTel,CFax,Contact,CMobile,CEMail,CAddress,CNote,CType,CLevel,CRecord,BSMI,AddUser,AddDate,ProcUser,ProcDate from CustomerHistory where Deltag='N' and CID = '".$CID."' order by CHID desc ".$limit_txt.";";
			$result_Customer=mysqli_query($link,$SQL_Customer) or die ("無法執行查詢");
			?>
    	<table width="100%" border="0" cellpadding="5" cellspacing="2" class="s2">
        <tr align="center">
          <td align="center" background="../images/table_bg.gif" class="t21">統一編號</td>
          <td background="../images/table_bg.gif" class="t21">客戶種類</td>
          <td background="../images/table_bg.gif" class="t21">公司名稱</td>
          <td background="../images/table_bg.gif" class="t21">公司英文名稱</td>
          <td background="../images/table_bg.gif" class="t21">BSMI識別號碼</td>
          <td background="../images/table_bg.gif" class="t21">詳細</td>
          <td width="150" background="../images/table_bg.gif" class="t21">最後更新</td>
        </tr>
        <?php
        $tmp = 1;
        while(list($CHID,$CUID,$CType,$CPWD,$CName,$EName,$TrademarkTxt,$TrademarkImg,$CTel,$CFax,$Contact,$CMobile,$CEMail,$CAddress,$CNote,$CType,$CLevel,$CRecord,$BSMI,$AddUser,$AddDate,$ProcUser,$ProcDate)=mysqli_fetch_row($result_Customer)){
      	?>
      	<tr<?php if ($tmp%2 == 0) echo " bgcolor=\"#F6F6F6\"";?>>
          <td align="center" class="h3"><?php echo $CUID;?></td>
          <td align="center" class="h3">
	          <?php
	          if (trim(strstr($CType,'N')) != "") echo "一般客戶<br>";
	          if (trim(strstr($CType,'P')) != "") echo "供應商";
	          ?>
          </td>
          <td align="center" class="h3"><?php echo $CName;?></td>
          <td align="center" class="h3"><?php echo $EName;?></td>
          <td align="center" class="h3"><?php echo $BSMI;?></td>
          <td align="center" class="h3"><input type="button" name="detail" value="詳細" class="input_bot" onclick="javascript:location.href='CustomerHistoryDetail.php?CHID=<?php echo $CHID;?>&CID=<?php echo $CID;?>&page=<?php echo $page;?><?php echo $url_str;?>';"></td>
          <td align="center" class="h3">
          	<?php
          	if (trim($ProcUser) == "") echo $AddUser."<br>".$AddDate;
          	else echo $ProcUser."<br>".$ProcDate;
          	?>
          </td>
        </tr>
        <?php
      			$tmp++;
      			}
      	mysqli_free_result($result_Customer);
        ?>
      </table>
      <table width="100%" border="0" cellpadding="5" cellspacing="2" class="s2">
        <tr align="center">
          <td bgcolor="#E8F0C2" class="h4"><?php Page_show($Sql_str,$page_rows,$php_Self,$link,$page,$url_str,$button_css);?></td>
        </tr>
      </table>
		</td>
	</tr>
</table>
</body>
</html>
<?php
mysqli_close($link);
?>