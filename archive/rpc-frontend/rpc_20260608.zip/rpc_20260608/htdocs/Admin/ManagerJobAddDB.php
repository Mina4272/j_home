﻿<?php
include "CheckPermission.php";
//include "CheckManager.php";
include "../global.php";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $PageAdminTitle;?></title>
</head>
<body>
<?php
$MID = $_GET['MID'];
//$MName = $_POST['MName'];
$MJPeriod = $_POST['MJPeriod'];
$MJTitle = $_POST['MJTitle'];
$MJDescription = $_POST['MJDescription'];
$MJDeputyID = $_POST['MJDeputyID'];
$MJNote="";

if (trim($MJTitle) == "" || trim($MJPeriod) == "" || trim($MID) == "")
		{
		mysqli_close($link);
		?>
		<script type="text/JavaScript">
			<!--
			alert ("您輸入的資料不足，請重新輸入@@！");
			history.go(-1);
			//-->
		</script>
		<?php
		exit;
		}

$now_time = date("Y-m-d H:i:s",mktime());

//if (trim($_SESSION["reg_MUID"]) == "Benson" || trim($_SESSION["reg_MUID"]) == "vivi" || trim($_SESSION["reg_MUID"]) == "jacky") 
		$sql_insert = "insert into ManagerJob (MID,MJPeriod,MJTitle,MJDescription,MJDeputyID,MJNote,AddUser,AddDate,AddIP) values ('".$MID."','".$MJPeriod."','".$MJTitle."','".$MJDescription."','".$MJDeputyID."','".$MJNote."','".$_SESSION["reg_MUID"]."','".$now_time."','".$_SERVER["REMOTE_ADDR"]."');";
		//echo $sql_insert;
//else 
//		$sql_insert = "insert into Manager (MUID,MPassword,MName,MEName,EmployeeNo,MPID,Departments,Title,Ext,EMail,MIntro,MPer,ISEngineer,ISBusiness,RDate,BirthDay,Address,RAddress,Tel,Mobile,BCode,BAccount,AddUser,AddDate,AddIP) values ('".$MUID."','".$MPassword."','".$MName."','".$MEName."','".$EmployeeNo."','".$MPID."','".$Departments."','".$Title."','".$Ext."','".$EMail."','".$MIntro."','".$MPerTxt."','".$ISEngineer."','".$ISBusiness."',".$RDate.",".$BirthDate.",'".$Address."','".$RAddress."','".$Tel."','".$Mobile."','".$BCode."','".$BAccount."','".$_SESSION["reg_MUID"]."','".$now_time."','".$_SERVER["REMOTE_ADDR"]."');";

$result_insert=mysqli_query($link,$sql_insert) or die ("無法執行新增");

mysqli_close($link);
?>
<script type="text/JavaScript">
	<!--
	alert ("新增成功！");
	location.href='ManagerJob.php?MID=<?php echo $MID; ?>';
	//-->
</script>

</body>
</html>
