﻿<?php	
include "CheckPermission.php";
//include "CheckMVac.php";
include "../global.php";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $PageAdminTitle;?></title>
<link href="../type.css" rel="stylesheet" type="text/css" />
<style type="text/css">
<!--
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
}
-->
</style>
<link href="../script/DatePicker.css" rel="stylesheet" type="text/css" />
<Script LANGUAGE="Javascript" SRC="../script/DatePicker.js"></Script>
<Script type="text/javascript" language="javascript" src="../script/CheckForm.js"></Script>
</head>
<body>
<table width="100%" border="0" cellpadding="0" cellspacing="0">
	<tr>
		<td>
    	<table width="100%" border="0" cellpadding="0" cellspacing="0">
    		<tr height="30">
					<td width="300" background="../images/table_bg.gif"></td>
    			<td class="c3" background="../images/table_bg.gif"><b>申請輸出</b></td>
    		</tr>
    	</table>
    	<table width="100%" border="0" cellpadding="0" cellspacing="0">
        <form name="form1" method="post" action="ProjectExportSummaryDB.php" onSubmit="return jsCheck();">
        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
          <td width="250" align="right" class="c3">所屬年月日：</td>
          	<td class="h3">
			            <input name="PSYear" type="text" size="4"/>年
			            <input name="PSMonth" type="text" size="2"/>月
			            <input name="PSDay" type="text" size="2"/>日
			            <img src="../images/icon.gif" width="16" height="18" style="cursor: hand" onclick="javascript:displayDatePicker('PSYear','PSMonth','PSDay');"/>～
			            <input name="PEYear" type="text" size="4"/>年
			            <input name="PEMonth" type="text" size="2"/>月
			            <input name="PEDay" type="text" size="2"/>日
			            <img src="../images/icon.gif" width="16" height="18" style="cursor: hand" onclick="javascript:displayDatePicker('PEYear','PEMonth','PEDay');"/> 
			</td>
        </tr>
		<!--
        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
          <td class="c3" align="right">申請項目：</td>
          <td class="h3">
          	<select name="MFType">
          		<option value="A">加班費</option>
          		<option value="B">交通費-公里</option>
          		<option value="C">交通費-實報實銷</option>
          	</select>
          </td>
        </tr>
		-->
        <tr height="40">
					<td></td>
          <td class="h3">
          	<input type="submit" name="submit" class="input_bot" value="送 出">
          </td>
        </tr>
	      </form>
      </table>
		</td>
	</tr>
</table>
</body>
</html>
<?php
mysqli_close($link);
?>