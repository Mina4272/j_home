﻿<?php	
include "CheckPermission.php";
include "CheckProjectAccounting.php";
include "../global.php";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<?php
$PID = $_GET['PID'];
$spage = $_GET['spage'];
$KeyWord = $_GET['KeyWord'];
$QPStatus = $_GET['QPStatus'];
$QAcc = $_GET['QAcc'];
if (trim($PID) == "")
		{
		mysqli_close($link);
		?>
		<script type="text/JavaScript">
			<!--
			alert ("查無資料，請冾網站管理人員！");
			history.go(-1);
			//-->
		</script>
		<?php
		exit;
		}
$SQL_Project="select PUID,PName,QuoteDate,IFlorin,OFlorin,PTax,(select CRecord from Customer where CID=Project.CID) CRecord,(select CRecordTxt from Customer where CID=Project.CID) CRecordTxt from Project where Deltag='N' and PID = '".$PID."';";
//echo $SQL_Project;
$result_Project=mysqli_query($link,$SQL_Project) or die ("無法執行查詢");
if (mysqli_num_rows($result_Project) == 0)
		{
		mysqli_free_result($result_Project);
		mysqli_close($link);
		?>
		<SCRIPT language=javascript>
		<!--
		alert ("查無資料，請冾網站管理人員！"); 
		history.go(-1);
		//-->
		</SCRIPT>
		<?php 	
		exit;
		}
list($PUID,$PName,$QuoteDate,$IFlorin,$OFlorin,$PTax,$CRecord,$CRecordTxt)=mysqli_fetch_row($result_Project);
mysqli_free_result($result_Project);
if (trim($QuoteDate) == "0000-00-00") $QuoteDate = "";
if (trim($QuoteDate) != "") $QuoteCheck = "True";

if (trim($IFlorin) == "") $IFlorin = "新台幣";
if (trim($OFlorin) == "") $OFlorin = "新台幣";
if (trim($CRecord) == "A") $CRecordDay=60;
else if (trim($CRecord) == "B") $CRecordDay=30;
else if (trim($CRecord) == "C") $CRecordDay=0;
else if (trim($CRecord) == "D") {
		if (is_numeric($CRecordTxt)) $CRecordDay=$CRecordTxt;
		else $CRecordDay=0;
		}
else $CRecordDay=0;
//echo "CRecordDay=".$CRecordDay."<br>";
?>
<title><?php echo $PageAdminTitle;?></title>
<link href="../type.css" rel="stylesheet" type="text/css" />
<style type="text/css">
<!--
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
}
-->
</style>
<link href="../script/DatePicker.css" rel="stylesheet" type="text/css" />
<Script LANGUAGE="Javascript" SRC="../script/DatePicker.js"></Script>
<Script type="text/javascript" language="javascript" src="../script/CheckForm.js"></Script>
<script type="text/JavaScript">
<!--
function jsCheck() 
		{
		if (jsTrim(document.form1.PAItem_I.value) == "" && jsTrim(document.form1.PAItem_O.value) == "") {
				alert ('請輸入要填寫的項目 !!');
				form1.PAItem_I.focus();
				return false ; 
				}
		if (jsTrim(document.form1.PAItem_I.value) != "") {
				if (ChkNaN('Charges_I',document.form1.Charges_I.value,'新台幣費用','') == false) return false;
				if (ChkNaN('Rate_I',document.form1.Rate_I.value,'匯率','') == false) return false;
				if (document.form1.Rate_I.value != "0") {
						if (document.form1.ChargesOther_I.value == "0") {
								alert ('請輸入外幣費用 !!');
								form1.ChargesOther_I.focus();
								return false ; 
								}
						if (ChkNaN('ChargesOther_I',document.form1.ChargesOther_I.value,'外幣費用','') == false) return false;
						}
				if (jsTrim(document.form1.PAPYear_I.value) != "" || jsTrim(document.form1.PAPMonth_I.value) != "" || jsTrim(document.form1.PAPDay_I.value) != "") if (ChkDate('PAPYear_I',document.form1.PAPYear_I.value,document.form1.PAPMonth_I.value,document.form1.PAPDay_I.value,'預計結清日期') == false) return false;
				//if (ChkDate('InvoiceYear_I',document.form1.InvoiceYear_I.value,document.form1.InvoiceMonth_I.value,document.form1.InvoiceDay_I.value,'發票日期') == false) return false;
				if (jsTrim(document.form1.InvoiceYear_I.value) != "" || jsTrim(document.form1.InvoiceMonth_I.value) != "" || jsTrim(document.form1.InvoiceDay_I.value) != "") if (ChkDate('InvoiceYear_I',document.form1.InvoiceYear_I.value,document.form1.InvoiceMonth_I.value,document.form1.InvoiceDay_I.value,'發票日期') == false) return false;
				}
		if (jsTrim(document.form1.PAItem_O.value) != "") {
				if (ChkNaN('Charges_O',document.form1.Charges_O.value,'新台幣費用','') == false) return false;
				if (ChkNaN('Rate_O',document.form1.Rate_O.value,'匯率','') == false) return false;
				if (document.form1.Rate_O.value != "0") {
						if (document.form1.ChargesOther_O.value == "0") {
								alert ('請輸入外幣費用 !!');
								form1.ChargesOther_O.focus();
								return false ; 
								}
						if (ChkNaN('ChargesOther_O',document.form1.ChargesOther_O.value,'外幣費用','') == false) return false;
						}
				if (jsTrim(document.form1.PAPYear_O.value) != "" || jsTrim(document.form1.PAPMonth_O.value) != "" || jsTrim(document.form1.PAPDay_O.value) != "") if (ChkDate('PAPYear_O',document.form1.PAPYear_O.value,document.form1.PAPMonth_O.value,document.form1.PAPDay_O.value,'預計結清日期') == false) return false;
				//if (ChkDate('InvoiceYear_O',document.form1.InvoiceYear_O.value,document.form1.InvoiceMonth_O.value,document.form1.InvoiceDay_O.value,'發票日期') == false) return false;
				if (jsTrim(document.form1.InvoiceYear_O.value) != "" || jsTrim(document.form1.InvoiceMonth_O.value) != "" || jsTrim(document.form1.InvoiceDay_O.value) != "") if (ChkDate('InvoiceYear_O',document.form1.InvoiceYear_O.value,document.form1.InvoiceMonth_O.value,document.form1.InvoiceDay_O.value,'發票日期') == false) return false;
				}
		}

function CheckRate_I() {
		if (ChkNaN('Rate_I',document.form1.Rate_I.value,'匯率','') == false) return false;
		if (document.form1.Rate_I.value != "0") {
				document.getElementById('ChargesOtherText_I').style.display = '';
				document.getElementById('ChargesOtherValue_I').style.display = '';
				}
		else {
				document.getElementById('ChargesOtherText_I').style.display = 'none';
				document.getElementById('ChargesOtherValue_I').style.display = 'none';
				}
		}
function CheckRate_O() {
		if (ChkNaN('Rate_O',document.form1.Rate_O.value,'匯率','') == false) return false;
		if (document.form1.Rate_O.value != "0") {
				document.getElementById('ChargesOtherText_O').style.display = '';
				document.getElementById('ChargesOtherValue_O').style.display = '';
				}
		else {
				document.getElementById('ChargesOtherText_O').style.display = 'none';
				document.getElementById('ChargesOtherValue_O').style.display = 'none';
				}
		}

function DateAdd(interval,number,date){
	// date 可以是時間對象也可以是字符串，如果是後者，形式必須為: yyyy-mm-dd hh:mm:ss 
	// 其中分隔符不定。"2006年12月29日 16點01分23秒" 也是合法的
	number = parseInt(number);
	if (typeof(date)=="string"){
		date = date.split(/\D/);
		--date[1];
		eval("var date = new Date("+date.join(",")+")");
		}
	if (typeof(date)=="object"){
		var date = date
		}
	switch(interval){
		case "y": date.setFullYear(date.getFullYear()+number); break;
		case "m": date.setMonth(date.getMonth()+number); break;
		case "d": date.setDate(date.getDate()+number); break;
		case "w": date.setDate(date.getDate()+7*number); break;
		case "h": date.setHours(date.getHour()+number); break;
		case "n": date.setMinutes(date.getMinutes()+number); break;
		case "s": date.setSeconds(date.getSeconds()+number); break;
		case "l": date.setMilliseconds(date.getMilliseconds()+number); break;
		}
	return date;
	}

function InvoiceCheck_I(){
	if (jsTrim(document.form1.InvoiceYear_I.value) != "" && jsTrim(document.form1.InvoiceMonth_I.value) != "" && jsTrim(document.form1.InvoiceDay_I.value) != "") {
			if (ChkDate('InvoiceYear_I',document.form1.InvoiceYear_I.value,document.form1.InvoiceMonth_I.value,document.form1.InvoiceDay_I.value,'發票日期') == false) return false;
			var dd = DateAdd('d',<?php echo $CRecordDay;?>,document.form1.InvoiceYear_I.value+'-'+document.form1.InvoiceMonth_I.value+'-'+document.form1.InvoiceDay_I.value);
			document.form1.PAPYear_I.value = dd.getFullYear();
			var jPAPMonth = dd.getMonth()+1;
			if (jPAPMonth.toString().length < 2) jPAPMonth='0'+jPAPMonth.toString();
			var jPAPDay = dd.getDate();
			if (jPAPDay.toString().length < 2) jPAPDay='0'+jPAPDay.toString();
			document.form1.PAPMonth_I.value = jPAPMonth;
			document.form1.PAPDay_I.value = jPAPDay;
			return false;
			}
	}

function InvoiceCheck_O(){
	if (jsTrim(document.form1.InvoiceYear_O.value) != "" && jsTrim(document.form1.InvoiceMonth_O.value) != "" && jsTrim(document.form1.InvoiceDay_O.value) != "") {
			if (ChkDate('InvoiceYear_O',document.form1.InvoiceYear_O.value,document.form1.InvoiceMonth_O.value,document.form1.InvoiceDay_O.value,'發票日期') == false) return false;
			var dd = DateAdd('d',<?php echo $CRecordDay;?>,document.form1.InvoiceYear_O.value+'-'+document.form1.InvoiceMonth_O.value+'-'+document.form1.InvoiceDay_O.value);
			document.form1.PAPYear_O.value = dd.getFullYear();
			var jPAPMonth = dd.getMonth()+1;
			if (jPAPMonth.toString().length < 2) jPAPMonth='0'+jPAPMonth.toString();
			var jPAPDay = dd.getDate();
			if (jPAPDay.toString().length < 2) jPAPDay='0'+jPAPDay.toString();
			document.form1.PAPMonth_O.value = jPAPMonth;
			document.form1.PAPDay_O.value = jPAPDay;
			return false;
			}
	}
//-->
</script>
</head>
<body>
<?php include "top.php";?>
<table width="100%" border="0" cellspacing="0" cellpadding="5">
	<tr>
    <td width="160" height="600" align="left" valign="top">
			<?php include "menu.php";?>
    </td>
    <td valign="top">
    	<table width="100%" border="0" cellpadding="0" cellspacing="0">
    		<tr>
    			<td>
			    	<table width="750" border="0" cellpadding="0" cellspacing="0">
			    		<tr height="30">
			    			<td class="c2"><a href="ProjectAccounting.php?page=<?php echo $spage;?>&QPStatus=<?php echo $QPStatus;?>&QAcc=<?php echo $QAcc;?>&KeyWord=<?php echo urlencode($KeyWord);?>">客戶案件帳務管理</a> &gt; <a href="ProjectAccountingList.php?PID=<?php echo $PID;?>&page=<?php echo $spage;?>&QPStatus=<?php echo $QPStatus;?>&QAcc=<?php echo $QAcc;?>&KeyWord=<?php echo urlencode($KeyWord);?>"><?php echo $PName;?> 帳務管理</a> &gt; 新增項目</td>
			    		</tr>
			    	</table>
			    	<table width="750" border="0" cellpadding="0" cellspacing="0">
			        <form name="form1" method="post" action="ProjectAccountingAddNewDB.php" onSubmit="return jsCheck();">
			        <tr height="35" bgColor='#F0F0F0'>
			          <td width="130" align="right" class="c3"><font color=blue><b>新增類型：</b></font></td>
			          <td class="h3"><font color=blue><b>收入</b></font></td>
			        </tr>
			        <tr height="35" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">對帳編號：</td>
			          <td class="h3">
			          	<input type="text" id="PANo_I" name="PANo_I" size="30" maxlength="20">
			          </td>
			        </tr>
			        <tr height="35" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">項 目：</td>
			          <td class="h3">
			          	<input type="text" id="PAItem_I" name="PAItem_I" size="60">
			          </td>
			        </tr>
			        <tr height="35" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">費 用：</td>
			          <td class="h3">
			          	<table width="100%" border="0" cellpadding="0" cellspacing="0">
			          		<tr class="c3">
			          			<td width="100" align="right">新台幣：</td>
			          			<td width="100"><input type="text" id="Charges_I" name="Charges_I" size="10"></td>
			          			<td width="80" align="right">匯率：</td>
			          			<td width="100"><input type="text" id="Rate_I" name="Rate_I" size="10" value="0" onKeyUp="CheckRate_I();"></td>
			          			<td width="100" align="right"><div id="ChargesOtherText_I" style="display:none">外幣：</div></td>
			          			<td width="300"><div id="ChargesOtherValue_I" style="display:none"><input type="text" id="ChargesOther_I" name="ChargesOther_I" size="10"></div></td>
			          		</tr>
			          	</table>
			          </td>
			        </tr>
			        <tr height="35" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">是否含稅：</td>
			          <td class="h3">
			          	<input type="radio" name="PATax_I" value="Y"<?php if (trim($PTax) == "Y") echo " checked";?>> 是 
			          	<input type="radio" name="PATax_I" value="N"<?php if (trim($PTax) == "N") echo " checked";?>> 否 
			          </td>
			        </tr>
			        <tr height="35" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">發票日期：</td>
			          <td class="h3">
		              <input id="InvoiceYear_I" name="InvoiceYear_I" type="text" size="4" onblur="javascript:InvoiceCheck_I();" /> 年 
		              <input id="InvoiceMonth_I" name="InvoiceMonth_I" type="text" size="2" onblur="javascript:InvoiceCheck_I();" /> 月 
		              <input id="InvoiceDay_I" name="InvoiceDay_I" type="text" size="2" onblur="javascript:InvoiceCheck_I();" /> 日 
		              <img src="../images/icon.gif" width="16" height="18" style="cursor: hand" onclick="javascript:displayDatePicker('InvoiceYear_I','InvoiceMonth_I','InvoiceDay_I');"/>
			          </td>
			        </tr>
			        <tr height="35" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">發票號碼：</td>
			          <td class="h3">
			          	<input type="text" id="Invoice_I" name="Invoice_I" size="20">
			          </td>
			        </tr>
			        <tr height="35" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">預計結清日期：</td>
			          <td class="h3">
		              <input id="PAPYear_I" name="PAPYear_I" type="text" size="4" /> 年 
		              <input id="PAPMonth_I" name="PAPMonth_I" type="text" size="2" /> 月 
		              <input id="PAPDay_I" name="PAPDay_I" type="text" size="2" /> 日 
		              <img src="../images/icon.gif" width="16" height="18" style="cursor: hand" onclick="javascript:displayDatePicker('PAPYear_I','PAPMonth_I','PAPDay_I');"/>
			          </td>
			        </tr>
			        <tr height="35" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">備 註：</td>
			          <td class="h3">
			          	<textarea rows="3" id="PANote_I" name="PANote_I" cols="60"></textarea>
			          </td>
			        </tr>
			        <tr height="35" bgColor='#F0F0F0'>
			          <td width="130" align="right" class="c3"><font color=blue><b>新增類型：</b></font></td>
			          <td class="h3"><font color=blue><b>支出</b></font></td>
			        </tr>
			        <tr height="35" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">對帳編號：</td>
			          <td class="h3">
			          	<input type="text" id="PANo_O" name="PANo_O" size="30" maxlength="20">
			          </td>
			        </tr>
			        <tr height="35" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">項 目：</td>
			          <td class="h3">
			          	<input type="text" id="PAItem_O" name="PAItem_O" size="60">
			          </td>
			        </tr>
			        <tr height="35" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">費 用：</td>
			          <td class="h3">
			          	<table width="100%" border="0" cellpadding="0" cellspacing="0">
			          		<tr class="c3">
			          			<td width="100" align="right">新台幣：</td>
			          			<td width="100"><input type="text" id="Charges_O" name="Charges_O" size="10"></td>
			          			<td width="80" align="right">匯率：</td>
			          			<td width="100"><input type="text" id="Rate_O" name="Rate_O" size="10" value="0" onKeyUp="CheckRate_O();"></td>
			          			<td width="100" align="right"><div id="ChargesOtherText_O" style="display:none">外幣：</div></td>
			          			<td width="300"><div id="ChargesOtherValue_O" style="display:none"><input type="text" id="ChargesOther_O" name="ChargesOther_O" size="10"></div></td>
			          		</tr>
			          	</table>
			          </td>
			        </tr>
			        <tr height="35" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">是否含稅：</td>
			          <td class="h3">
			          	<input type="radio" name="PATax_O" value="Y"<?php if (trim($PTax) == "Y") echo " checked";?>> 是 
			          	<input type="radio" name="PATax_O" value="N"<?php if (trim($PTax) == "N") echo " checked";?>> 否 
			          </td>
			        </tr>
			        <tr id="CheckCustomer" style="display:" height="35" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">供應商：</td>
			          <td class="h3">
						    	<table width="100%" border="0" cellpadding="0" cellspacing="0">
						        <form name="form1" method="post" action="CustomerSurveyExport.php" onSubmit="return jsCheck();" target="_CustomerSurvey">
						        <tr height="30">
						          <td width="90" align="right" class="c3">客戶名稱：</td>
						          <td class="h3">
						          	<table width="100%" border="0" cellpadding="0" cellspacing="0">
						          		<tr>
						          			<td><div id="CNamePreview" style="display:none"></div></td>
						          			<td>
									          	<input type="hidden" id="CID" name="CID">
									          	<input type="hidden" id="CName" name="CName">
									          	<input type="button" id="SelCID" name="SelCID" class="input_bot" value="請選擇" onclick="javascript:window.open ('SelCustomer.php?QCType=P','SelCustomer','height=300,width=550,top=200,left=200,scrollbars=yes,status=yes');">
						          			</td>
						          		</tr>
						          	</table>
						          	
						          </td>
						        </tr>
						        <tr height="30">
						          <td align="right" class="c3">客戶電話：</td>
						          <td class="h3">
						          	<table width="100%" border="0" cellpadding="0" cellspacing="0">
						          		<tr>
						          			<td width="150">
						          				<div id="CTelPreview" style="display:none"></div>
									          	<input type="hidden" id="CTel" name="CTel">
						          			</td>
						          			<td width="60" align="right" class="c3">傳真：</td>
						          			<td>
						          				<div id="CFaxPreview" style="display:none"></div>
						          				<input type="hidden" id="CFax" name="CFax">
						          				<input type="hidden" id="Contact" name="Contact" size="20">
						          				<input type="hidden" id="CMobile" name="CMobile" size="20">
						          				<input type="hidden" id="CEMail" name="CEMail" size="60">
						          			</td>
						          		</tr>
						          	</table>
						          </td>
						        </tr>
						        <tr height="30">
						          <td align="right" class="c3">客戶地址：</td>
						          <td class="h3">
						          	<div id="CAddressPreview" style="display:none"></div>
						          	<input type="hidden" id="CAddress" name="CAddress">
						          </td>
						        </tr>
						      </table>
			          </td>
			        </tr>
			        <tr height="35" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">發票日期：</td>
			          <td class="h3">
		              <input id="InvoiceYear_O" name="InvoiceYear_O" type="text" size="4" onblur="javascript:InvoiceCheck_O();" /> 年 
		              <input id="InvoiceMonth_O" name="InvoiceMonth_O" type="text" size="2" onblur="javascript:InvoiceCheck_O();" /> 月 
		              <input id="InvoiceDay_O" name="InvoiceDay_O" type="text" size="2" onblur="javascript:InvoiceCheck_O();" /> 日 
		              <img src="../images/icon.gif" width="16" height="18" style="cursor: hand" onclick="javascript:displayDatePicker('InvoiceYear_O','InvoiceMonth_O','InvoiceDay_O');"/>
			          </td>
			        </tr>
			        <tr height="35" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">發票號碼：</td>
			          <td class="h3">
			          	<input type="text" id="Invoice_O" name="Invoice_O" size="20">
			          </td>
			        </tr>
			        <tr height="35" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">預計結清日期：</td>
			          <td class="h3">
		              <input id="PAPYear_O" name="PAPYear_O" type="text" size="4" /> 年 
		              <input id="PAPMonth_O" name="PAPMonth_O" type="text" size="2" /> 月 
		              <input id="PAPDay_O" name="PAPDay_O" type="text" size="2" /> 日 
		              <img src="../images/icon.gif" width="16" height="18" style="cursor: hand" onclick="javascript:displayDatePicker('PAPYear_O','PAPMonth_O','PAPDay_O');"/>
			          </td>
			        </tr>
			        <tr height="35" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">備 註：</td>
			          <td class="h3">
			          	<textarea rows="3" id="PANote_O" name="PANote_O" cols="60"></textarea>
			          	<input type="hidden" id="PID" name="PID" value="<?php echo $PID;?>">
			          	<input type="hidden" id="spage" name="spage" value="<?php echo $spage;?>">
			          	<input type="hidden" id="KeyWord" name="KeyWord" value="<?php echo $KeyWord;?>">
			          	<input type="hidden" id="QPStatus" name="QPStatus" value="<?php echo $QPStatus;?>">
			          	<input type="hidden" id="QAcc" name="QAcc" value="<?php echo $QAcc;?>">
			          </td>
			        </tr>
			        <tr height="40" align="center">
			          <td colspan="2" class="h3"><input type="submit" name="submit" class="input_bot" value="送 出"></td>
			        </tr>
				      </form>
			      </table>
    			</td>
    		</tr>
    	</table>
    </td>
	</tr>
</table>
<?php include "down.php";?>
</body>
</html>
<?php
mysqli_close($link);
?>