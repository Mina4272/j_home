﻿<?php
include "CheckPermission.php";
include "CheckProject.php";
include "../global.php";
include "include/function.php";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $PageAdminTitle;?></title>
<link href="../type.css" rel="stylesheet" type="text/css" />
</head>

<body>
<?php
//echo "PFileName1=".$HTTP_POST_FILES['PFileName1']['name']."<br>";
//echo "PFileName1=".$HTTP_POST_FILES['PFileName1']['tmp_name']."<br>";
//exit;
$PID = $_POST['PID'];
$PFCID = $_POST['PFCID'];
$spage = $_POST['spage'];
$KeyWord = $_POST['KeyWord'];
$QPStatus = $_POST['QPStatus'];
$QPE = $_POST['QPE'];

$SQL_Project="select PUID,PName from Project where Deltag='N' and PID = '".$PID."';";
$result_Project=mysqli_query($link,$SQL_Project) or die ("無法執行查詢");
if (mysqli_num_rows($result_Project) == 0)
		{
		mysqli_free_result($result_Project);
		mysqli_close($link);
		?>
		<SCRIPT language=javascript>
		<!--
		alert ("查無資料，請冾網站管理人員！"); 
		history.go(-1);
		//-->
		</SCRIPT>
		<?php 	
		exit;
		}
mysqli_free_result($result_Project);

$SQL_ProjectFileClass="select PFCName from ProjectFileClass where Deltag='N' and PFCID = '".$PFCID."';";
$result_ProjectFileClass=mysqli_query($link,$SQL_ProjectFileClass) or die ("無法執行查詢");
if (mysqli_num_rows($result_ProjectFileClass) == 0)
		{
		mysqli_free_result($result_ProjectFileClass);
		mysqli_close($link);
		?>
		<SCRIPT language=javascript>
		<!--
		alert ("查無資料，請冾網站管理人員！"); 
		history.go(-1);
		//-->
		</SCRIPT>
		<?php 	
		exit;
		}
mysqli_free_result($result_ProjectFileClass);

$now_time = date("Y-m-d H:i:s",mktime());
if(trim($_FILES['PFileName1']['tmp_name']) != "")
		{
		if($_FILES['PFileName1']['size'] > 20971520)
				{
				?>
				<script type="text/JavaScript">
					<!--
					alert ("您上傳的檔案 Size 超過 20 M，請重新上傳！");
					history.go(-1);
					//-->
				</script>
				<?php
				exit();
				}
		$PFIntro1 = $_POST['PFIntro1'];
		$PFileName1 = "PFile_1".$PID.$PFCID.date("ymdHis",mktime()).rand_string(5, 'ABCDEFGHIJKLMNPQRSTUVWXYZ23456789abcdefghijklmnopqrstuvwxyz').".".strtolower(substr($_FILES['PFileName1']['name'],strrpos($_FILES['PFileName1']['name'],".")+1,strlen($_FILES['PFileName1']['name'])+1));
		@copy($_FILES['PFileName1']['tmp_name'],$_SERVER["DOCUMENT_ROOT"]."\\Admin\\PFile\\".$PFileName1);
		$sql_insert = "insert into ProjectFile (PID,PFCID,PFName,PFileName,PFIntro,AddUser,AddDate,AddIP) values ('".$PID."','".$PFCID."','".$_FILES['PFileName1']['name']."','".$PFileName1."','".$PFIntro1."','".$_SESSION["reg_MUID"]."','".$now_time."','".$_SERVER["REMOTE_ADDR"]."');";
		$result_insert=mysqli_query($link,$sql_insert) or die ("無法執行新增");
		}

if(trim($_FILES['PFileName2']['tmp_name']) != "")
		{
		if($_FILES['PFileName2']['size'] > 20971520)
				{
				?>
				<script type="text/JavaScript">
					<!--
					alert ("您上傳的檔案 Size 超過 20 M，請重新上傳！");
					history.go(-1);
					//-->
				</script>
				<?php
				exit();
				}
		$PFIntro2 = $_POST['PFIntro2'];
		$PFileName2 = "PFile_2".$PID.$PFCID.date("ymdHis",mktime()).rand_string(5, 'ABCDEFGHIJKLMNPQRSTUVWXYZ23456789abcdefghijklmnopqrstuvwxyz').".".strtolower(substr($_FILES['PFileName2']['name'],strrpos($_FILES['PFileName2']['name'],".")+1,strlen($_FILES['PFileName2']['name'])+1));
		@copy($HTTP_POST_FILES['PFileName2']['tmp_name'],$_SERVER["DOCUMENT_ROOT"]."\\Admin\\PFile\\".$PFileName2);
		$sql_insert = "insert into ProjectFile (PID,PFCID,PFName,PFileName,PFIntro,AddUser,AddDate,AddIP) values ('".$PID."','".$PFCID."','".$_FILES['PFileName2']['name']."','".$PFileName2."','".$PFIntro2."','".$_SESSION["reg_MUID"]."','".$now_time."','".$_SERVER["REMOTE_ADDR"]."');";
		$result_insert=mysqli_query($link,$sql_insert) or die ("無法執行新增");
		}

if(trim($_FILES['PFileName3']['tmp_name']) != "")
		{
		if($_FILES['PFileName3']['size'] > 20971520)
				{
				?>
				<script type="text/JavaScript">
					<!--
					alert ("您上傳的檔案 Size 超過 20 M，請重新上傳！");
					history.go(-1);
					//-->
				</script>
				<?php
				exit();
				}
		$PFIntro3 = $_POST['PFIntro3'];
		$PFileName3 = "PFile_3".$PID.$PFCID.date("ymdHis",mktime()).rand_string(5, 'ABCDEFGHIJKLMNPQRSTUVWXYZ23456789abcdefghijklmnopqrstuvwxyz').".".strtolower(substr($_FILES['PFileName3']['name'],strrpos($_FILES['PFileName3']['name'],".")+1,strlen($_FILES['PFileName3']['name'])+1));
		@copy($HTTP_POST_FILES['PFileName3']['tmp_name'],$_SERVER["DOCUMENT_ROOT"]."\\Admin\\PFile\\".$PFileName3);
		$sql_insert = "insert into ProjectFile (PID,PFCID,PFName,PFileName,PFIntro,AddUser,AddDate,AddIP) values ('".$PID."','".$PFCID."','".$_FILES['PFileName3']['name']."','".$PFileName3."','".$PFIntro3."','".$_SESSION["reg_MUID"]."','".$now_time."','".$_SERVER["REMOTE_ADDR"]."');";
		$result_insert=mysqli_query($link,$sql_insert) or die ("無法執行新增");
		}

if(trim($_FILES['PFileName4']['tmp_name']) != "")
		{
		if($_FILES['PFileName4']['size'] > 20971520)
				{
				?>
				<script type="text/JavaScript">
					<!--
					alert ("您上傳的檔案 Size 超過 20 M，請重新上傳！");
					history.go(-1);
					//-->
				</script>
				<?php
				exit();
				}
		$PFIntro4 = $_POST['PFIntro4'];
		$PFileName4 = "PFile_4".$PID.$PFCID.date("ymdHis",mktime()).rand_string(5, 'ABCDEFGHIJKLMNPQRSTUVWXYZ23456789abcdefghijklmnopqrstuvwxyz').".".strtolower(substr($_FILES['PFileName4']['name'],strrpos($_FILES['PFileName4']['name'],".")+1,strlen($_FILES['PFileName4']['name'])+1));
		@copy($HTTP_POST_FILES['PFileName4']['tmp_name'],$_SERVER["DOCUMENT_ROOT"]."\\Admin\\PFile\\".$PFileName4);
		$sql_insert = "insert into ProjectFile (PID,PFCID,PFName,PFileName,PFIntro,AddUser,AddDate,AddIP) values ('".$PID."','".$PFCID."','".$_FILES['PFileName4']['name']."','".$PFileName4."','".$PFIntro4."','".$_SESSION["reg_MUID"]."','".$now_time."','".$_SERVER["REMOTE_ADDR"]."');";
		$result_insert=mysqli_query($link,$sql_insert) or die ("無法執行新增");
		}

if(trim($_FILES['PFileName5']['tmp_name']) != "")
		{
		if($_FILES['PFileName5']['size'] > 20971520)
				{
				?>
				<script type="text/JavaScript">
					<!--
					alert ("您上傳的檔案 Size 超過 20 M，請重新上傳！");
					history.go(-1);
					//-->
				</script>
				<?php
				exit();
				}
		$PFIntro5 = $_POST['PFIntro5'];
		$PFileName5 = "PFile_5".$PID.$PFCID.date("ymdHis",mktime()).rand_string(5, 'ABCDEFGHIJKLMNPQRSTUVWXYZ23456789abcdefghijklmnopqrstuvwxyz').".".strtolower(substr($_FILES['PFileName5']['name'],strrpos($_FILES['PFileName5']['name'],".")+1,strlen($_FILES['PFileName5']['name'])+1));
		@copy($HTTP_POST_FILES['PFileName5']['tmp_name'],$_SERVER["DOCUMENT_ROOT"]."\\Admin\\PFile\\".$PFileName5);
		$sql_insert = "insert into ProjectFile (PID,PFCID,PFName,PFileName,PFIntro,AddUser,AddDate,AddIP) values ('".$PID."','".$PFCID."','".$_FILES['PFileName5']['name']."','".$PFileName5."','".$PFIntro5."','".$_SESSION["reg_MUID"]."','".$now_time."','".$_SERVER["REMOTE_ADDR"]."');";
		$result_insert=mysqli_query($link,$sql_insert) or die ("無法執行新增");
		}

mysqli_close($link);
?>
<script type="text/JavaScript">
	<!--
	alert ("檔案上傳成功！");
	location.href='ProjectFileList.php?PID=<?php echo $PID;?>&PFCID=<?php echo $PFCID;?>&spage=<?php echo $spage;?>&QPStatus=<?php echo $QPStatus;?>&QPE=<?php echo $QPE;?>&KeyWord=<?php echo urlencode($KeyWord);?>';
	//-->
</script>

</body>
</html>
