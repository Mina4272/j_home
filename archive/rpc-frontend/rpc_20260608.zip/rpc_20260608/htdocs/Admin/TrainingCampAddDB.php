﻿<?php

include "CheckPermission.php";
include "CheckTraining.php";
include "../global.php";
include "include/function.php";
require_once("../include/chinese_party.class.php");
require("class.phpmailer.php");


?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $PageAdminTitle;?></title>
<link href="../type.css" rel="stylesheet" type="text/css" />
</head>

<body>
<?php
//echo "TFile=".$HTTP_POST_FILES['TFile']['name']."<br>";
//echo "TFile=".$HTTP_POST_FILES['TFile']['tmp_name']."<br>";
//exit;


if(isset($_POST['code'])) {
if($_POST['code'] == $_SESSION['code']){
	
	$_SESSION['code']+=1;


$TCTTitle = $_POST['TCTTitle'];
$now_time = date("Y-m-d H:i:s",mktime());

$sql_insert = "insert into TrainingCamp (TCTTitle,Adduser,AddDate,AddIP) values ('".$TCTTitle."','".$_SESSION["reg_MUID"]."','".$now_time."','".$_SERVER["REMOTE_ADDR"]."');";
$result_insert=mysqli_query($link,$sql_insert) or die ("無法執行新增");


}
}
?>

<script type="text/JavaScript">

	alert ("新增完成！");
	location.href='TrainingCamp.php';

</script>

</body>
</html>
