			<table width="170" border="0" cellpadding="2" cellspacing="0" bgcolor="#FFFFCC" class="s1">
			  <tr height="35">
			    <td align="center" bgcolor="#FFDA68" class="t2">
			    	<table width="100%" border="0" cellpadding="0" cellspacing="0">
			    		<tr height="35">
			    			<td class="t2">管理選單</td>
			    			<td class="h3" valign="bottom"><?php echo $_SESSION["reg_MName"];?></td>
			    		</tr>
			    	</table>
			    </td>
			  </tr>
			  <tr height="35" bgcolor="#FFFFCC" class="h3">
			    <td align="left">&nbsp;<a href="index.php">首頁-提醒及管理事項</a>
			   	</td>
			  </tr>
			  <tr height="35" bgcolor="#FFFFCC" class="h3">
			  	<td align="left"><b>案件管理系統</b>
			   	</td>
			  </tr>
				<?php if (trim(strstr($_SESSION["reg_MPer"],'B')) != ""){?>
			  <tr height="35" bgcolor="#FFFFCC" class="h3">
			    <td align="center">&nbsp;<a href="ProjectList.php">客戶案件管理</a>
			   	</td>
			  </tr>
			  <?php }?>
				<?php if (trim(strstr($_SESSION["reg_MPer"],'M')) != ""){?>
			  <tr height="35" bgcolor="#FFFFCC" class="h3">
			    <td align="center">&nbsp;<a href="AgendumList.php">事項處理</a>
			   	</td>
			  </tr>
			  <?php }?>
				<?php if (trim(strstr($_SESSION["reg_MPer"],'B')) != ""){?>
			  <tr height="35" bgcolor="#FFFFCC" class="h3">
			    <td align="center">&nbsp;<a href="ProjectCertificateList.php">證書管理</a>
			   	</td>
			  </tr>
			  <!--tr height="35" bgcolor="#FFFFCC" class="h3">
			    <td align="left">&nbsp;<a href="\\\\192.168.1.60" target="_OtherFile">共用資料庫</a>
			   	</td>
			  </tr-->
			  <?php }?>
			  <tr height="35" bgcolor="#FFFFCC" class="h3">
			  	<td align="center">&nbsp;<a href="Over.php">證書過期清單</a>
			   	</td>
			  </tr>
			 <?php if (trim(strstr($_SESSION["reg_MPer"],'C')) != ""){?>
			  <tr height="35" bgcolor="#FFFFCC" class="h3">
				<td align="center">&nbsp;<a href="Agent.php">代理商證書管理</a>
			   	</td>
			  </tr>
			  <?php }?>
				<?php if (trim(strstr($_SESSION["reg_MPer"],'C')) != ""){?>
			  <tr height="35" bgcolor="#FFFFCC" class="h3">
			    <td align="center">&nbsp;<a href="PartLibrary.php">零組件/檔案查詢</a>
				</td>
			  </tr>
			  <?php }?>
			   <tr height="35" bgcolor="#FFFFCC" class="h3">
			  	<td align="left"><b>顧客服務管理系統</b>
			   	</td>
			  </tr>
				<?php if (trim(strstr($_SESSION["reg_MPer"],'A')) != ""){?>
			  <tr height="35" bgcolor="#FFFFCC" class="h3">
			    <td align="center">&nbsp;<a href="CustomerList.php">客戶資料管理</a>
			   	</td>
			  </tr>
			  <?php }?>
			  <tr height="35" bgcolor="#FFFFCC" class="h3">
			  	<td align="left"><b>帳務管理系統</b>
			   	</td>
			  </tr>
			  <?php if (trim(strstr($_SESSION["reg_MPer"],'E')) != ""){?>
			  <tr height="35" bgcolor="#FFFFCC" class="h3">
			    <td align="center">&nbsp;<a href="CommonAccounting.php">一般帳務管理</a>
			   	</td>
			  </tr>
			  <?php }?>
				<?php if (trim(strstr($_SESSION["reg_MPer"],'F')) != ""){?>
			  <tr height="35" bgcolor="#FFFFCC" class="h3">
			    <td align="center">&nbsp;<a href="AccountingReport.php">帳務報表</a>
			   	</td>
			  </tr>
			  <?php }?>
			  <?php if (trim(strstr($_SESSION["reg_MPer"],'D')) != "" || trim(strstr($_SESSION["reg_MPer"],'I')) != "" || trim(strstr($_SESSION["reg_MPer"],'L')) != ""){?>
			  <tr height="35" bgcolor="#FFFFCC" class="h3">
			    <td align="center">&nbsp;<a href="ProjectAccounting.php">客戶案件帳務管理</a>
			   	</td>
			  </tr>
			  <?php }?>
			  <?php if (trim(strstr($_SESSION["reg_MPer"],'D')) != "" || trim(strstr($_SESSION["reg_MPer"],'I')) != "" || trim(strstr($_SESSION["reg_MPer"],'L')) != ""){?>
			  <tr height="35" bgcolor="#FFFFCC" class="h3">
			    <td align="center">&nbsp;<a href="Invoice.php">電子發票字軌</a>
			   	</td>
			  </tr>
			  <?php }?>
			  <tr height="35" bgcolor="#FFFFCC" class="h3">
			  	<td align="left"><b>公司設備</b>
			   	</td>
			  </tr>
			   <tr height="35" bgcolor="#FFFFCC" class="h3">
			    <td align="center">&nbsp;<a href="Device.php">儀器設備管理</a>
			   	</td>
			  </tr>
			  <tr height="35" bgcolor="#FFFFCC" class="h3">
			  	<td align="left"><b>人事資料管理系統</b>
			   	</td>
			  </tr>
			  <tr height="35" bgcolor="#FFFFCC" class="h3">
			    <td align="center">&nbsp;<a href="NewsList.php">公佈欄</a>
			   	</td>
			  </tr>
			  <tr height="35" bgcolor="#FFFFCC" class="h3">
			    <td align="center">&nbsp;<a href="TrainingList.php">教育訓練</a>
			   	</td>
			  </tr>
			  <?php if (trim(strstr($_SESSION["reg_MPer"],'G')) != ""){?>
			  <tr height="35" bgcolor="#FFFFCC" class="h3">
			    <td align="center">&nbsp;<a href="TrainingCamp.php">訓練營</a>
			   	</td>
			  </tr>
			  <?php }?>
			  <tr height="35" bgcolor="#FFFFCC" class="h3">
			    <td align="center">&nbsp;<a href="ManagerList.php">員工資訊</a>
			   	</td>
			  </tr>
				<?php if (trim(strstr($_SESSION["reg_MPer"],'O')) != ""){?>
			  <tr height="35" bgcolor="#FFFFCC" class="h3">
			    <td align="center">&nbsp;<a href="EmployeePayList.php">薪資管理</a>
			   	</td>
			  </tr>
			  <tr height="35" bgcolor="#FFFFCC" class="h3">
			    <td align="center">&nbsp;<a href="EmployeeVacationList.php">年假管理</a>
			   	</td>
			  </tr>
			  <?php }?>
			  <tr height="35" bgcolor="#FFFFCC" class="h3">
			    <td align="center">&nbsp;<a href="MVacList.php">請假申請</a>
			   	</td>
			  </tr>
			  <tr height="35" bgcolor="#FFFFCC" class="h3">
			    <td align="center">&nbsp;<a href="MFeesList.php">費用申請</a>
			   	</td>
			  </tr>
			  <tr height="35" bgcolor="#FFFFCC" class="h3">
			    <td align="center">&nbsp;<a href="EditPassword.php">修改密碼</a>
			   	</td>
			  </tr>
			  <!--<tr height="35" bgcolor="#FFFFCC" class="h3">
			  	<td align="left">品質管理系統
			   	</td>
			  </tr>
			   <tr height="35" bgcolor="#FFFFCC" class="h3">
			    <!--td align="center">&nbsp;<a href="http://Ds715/實驗室品質文件/" Target="_blank">品質文件</a>
			   	</td>
			  </tr>-->
			  <tr height="35" bgcolor="#FFFFCC" class="h3">
			    <td align="left">&nbsp;
			    	<a href="logout.php">登出</a>
			   	</td>
			  </tr>
			</table>