﻿<?php	
include "CheckPermission.php";
include "../global.php";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $PageAdminTitle;?></title>
<link href="../type.css" rel="stylesheet" type="text/css" />
<style type="text/css">
<!--
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
}
-->
</style>
<link href="../script/DatePicker.css" rel="stylesheet" type="text/css" />
<Script LANGUAGE="Javascript" SRC="../script/DatePicker.js"></Script>
<Script type="text/javascript" language="javascript" src="../script/CheckForm.js"></Script>
<script type="text/JavaScript">
<!--
function jsCheck() 
		{
		if (ChkDate('MFYear',document.form1.MFYear.value,document.form1.MFMonth.value,document.form1.MFDay.value,'申請起始時間') == false) return false;
		if (ChkImp('MFCause',document.form1.MFCause.value,'申請事由','') == false) return false;
		if (ChkImp('MFComment',document.form1.MFComment.value,'申請說明','') == false) return false;
		if (ChkNaN('Quantity',document.form1.Quantity.value,'申請數量','') == false) return false;
		}
//-->
</script>
</head>
<body>
<?php include "top.php";?>
<table width="100%" border="0" cellspacing="0" cellpadding="5">
	<tr>
    <td width="160" height="600" align="left" valign="top">
			<?php include "menu.php";?>
    </td>
    <td valign="top">
    	<table width="100%" border="0" cellpadding="0" cellspacing="0">
    		<tr>
    			<td>
			    	<table width="750" border="0" cellpadding="0" cellspacing="0">
			    		<tr height="30">
			    			<td class="c2"><b>新增申請資料</b></td>
			    		</tr>
			    	</table>
			    	<table width="750" border="0" cellpadding="0" cellspacing="0">
			        <form name="form1" method="post" action="MFeesAddDB.php" onSubmit="return jsCheck();">
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td width="160" align="right" class="c3">申請人：</td>
			          <td class="h3"><?php echo $_SESSION["reg_MName"];?></td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">申請項目：</td>
			          <td class="h3">
			          	<select id="MFType" name="MFType">
			          		<option value="A">加班費</option>
			          		<option value="B">交通費-公里</option>
			          		<option value="C">交通費-實報實銷/餐費</option>
			          	</select>
			          </td>
			        </tr>
					<?php
						$month_start = date('Y-m-01'); //本月第一天 
						$month_end = strtotime($month_start);					
						$month_end = strtotime('+1 month -1 days', $month_end); 
						$month_end = date("Y-m-d", $month_end);  //本月最後一天
						//echo $month_start;
						//echo $month_end;
						$sql = "SELECT IFNULL(sum(Quantity),0) as H FROM `managerfees` where deltag='N' and MFType ='A' and MFDate >='".$month_start."' and MFDate <='".$month_end."' and MUID = '".$_SESSION["reg_MUID"]."'";
						//echo $sql;
						$result=mysqli_query($link,$sql) or die ("無法執行修改");
						list($H)=mysqli_fetch_row($result);
						mysqli_free_result($result);

						if ($H >= 46) {
							
					?>
					<script type="text/JavaScript">
					<!--
						alert('此月加班費已到達46H,請多休息唷!');
					//-->
					</script>
					<?php
						}

					?>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">申請日期：</td>
			          <td class="h3">
			            <input id="MFYear" name="MFYear" type="text" size="4" />年
			            <input id="MFMonth" name="MFMonth" type="text" size="2" />月
			            <input id="MFDay" name="MFDay" type="text" size="2" />日
			            <img src="../images/icon.gif" width="16" height="18" style="cursor: hand" onclick="javascript:displayDatePicker('MFYear','MFMonth','MFDay');"/>
			          </td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">申請事由：</td>
			          <td class="h3"><input type="text" id="MFCause" name="MFCause" size="40"></td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">申請說明：</td>
			          <td class="h3"><input type="text" id="MFComment" name="MFComment" size="40"><br><font color=blue>( 請註明申請加班起迄時間或交通費起迄地點 )</font></td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">申請數量/金額：</td>
			          <td class="h3"><input type="text" id="Quantity" name="Quantity" size="10"> <font color=blue>( 加班時數/公里數/金額 )</font></td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">備註：</td>
			          <td class="h3"><input type="text" id="MFNote" name="MFNote" size="60"></td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">是否送審：</td>
			          <td class="h3">
			          	<input type="radio" id="MFSend" name="MFSend" value="N" checked> 否 
			          	<input type="radio" id="MFSend" name="MFSend" value="Y"> 是
			          </td>
			        </tr>
			        <tr height="40" align="center">
			          <td colspan="2" class="h3"><input type="submit" name="submit" class="input_bot" value="送 出"></td>
			        </tr>
				      </form>
			      </table>
    			</td>
    		</tr>
    	</table>
    </td>
	</tr>
</table>
<?php include "down.php";?>
</body>
</html>
<?php
mysqli_close($link);
?>