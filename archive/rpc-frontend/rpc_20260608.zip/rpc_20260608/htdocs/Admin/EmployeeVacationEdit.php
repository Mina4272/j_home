﻿<?php	
include "CheckPermission.php";
include "CheckEmployeePay.php";
include "../global.php";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $PageAdminTitle;?></title>
<link href="../type.css" rel="stylesheet" type="text/css" />
<style type="text/css">
<!--
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
}
-->
</style>
<link href="../script/DatePicker.css" rel="stylesheet" type="text/css" />
<Script LANGUAGE="Javascript" SRC="../script/DatePicker.js"></Script>
<Script type="text/javascript" language="javascript" src="../script/CheckForm.js"></Script>
</head>
<body>
<?php include "top.php";?>
<?php
$EVID = $_GET['EVID'];
$page = $_GET['page'];
$SDate = $_GET['SDate'];
$EDate = $_GET['EDate'];
$QEVType = $_GET['QEVType'];
$KeyWord = $_GET['KeyWord'];

if (trim($EVID) == "")
		{
		mysqli_close($link);
		?>
		<script type="text/JavaScript">
			<!--
			alert ("查無資料，請冾網站管理人員！");
			history.go(-1);
			//-->
		</script>
		<?php
		exit;
		}
$SQL_EmployeeVacation="select MID,(select MUID from Manager where MID=EmployeeVacation.MID) MUID,(select MName from Manager where MID=EmployeeVacation.MID) MName,(select MEName from Manager where MID=EmployeeVacation.MID) MEName,(select EmployeeNo from Manager where MID=EmployeeVacation.MID) EmployeeNo,(select RDate from Manager where MID=EmployeeVacation.MID) RDate,EVType,MVID,EVCount,EVDesc,date_format(AddDate,'%Y'),date_format(AddDate,'%m'),date_format(AddDate,'%d') from EmployeeVacation where Deltag='N' and EVID=".$EVID.";";
$result_EmployeeVacation=mysqli_query($link,$SQL_EmployeeVacation) or die ("無法執行查詢");
if (mysqli_num_rows($result_EmployeeVacation) == 0)
		{
		mysqli_free_result($result_EmployeeVacation);
		mysqli_close($link);
		?>
		<SCRIPT language=javascript>
		<!--
		alert ("查無資料，請冾網站管理人員！"); 
		history.go(-1);
		//-->
		</SCRIPT>
		<?php 	
		exit;
		}
list($MID,$MUID,$MName,$MEName,$EmployeeNo,$RDate,$EVType,$MVID,$EVCount,$EVDesc,$AddYear,$AddMonth,$AddDay)=mysqli_fetch_row($result_EmployeeVacation);
mysqli_free_result($result_EmployeeVacation);
?>
<table width="100%" border="0" cellspacing="0" cellpadding="5">
	<tr>
    <td width="160" height="600" align="left" valign="top">
			<?php include "menu.php";?>
    </td>
    <td valign="top">
    	<table width="100%" border="0" cellpadding="0" cellspacing="0">
    		<tr>
    			<td>
			    	<table width="750" border="0" cellpadding="0" cellspacing="0">
			    		<tr height="30">
			    			<td class="c2"><b>修改年假資料</b></td>
			    		</tr>
			    	</table>
			    	<table width="750" border="0" cellpadding="0" cellspacing="0">
			        <form name="form1" method="post" action="EmployeeVacationEditDB.php">
			        <tr height="35" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td width="120" align="right" class="c3">員工姓名：</td>
			          <td class="h3">
			          	<table width="100%" border="0" cellpadding="0" cellspacing="0">
			          		<tr>
			          			<td><?php echo $MEName.$MName;?>(<?php echo $MUID;?>)　<font color=blue>到職日：<?php echo $RDate;?></font></td>
			          			<td>
						          	<input type="hidden" name="MID" value="<?php echo $MID;?>">
						          	<input type="hidden" name="page" value="<?php echo $page;?>">
						          	<input type="hidden" name="SDate" value="<?php echo $SDate;?>">
						          	<input type="hidden" name="EDate" value="<?php echo $EDate;?>">
						          	<input type="hidden" name="QEVType" value="<?php echo $QEVType;?>">
						          	<input type="hidden" name="KeyWord" value="<?php echo $KeyWord;?>">
						          	<input type="hidden" name="EVID" value="<?php echo $EVID;?>">
			          			</td>
			          		</tr>
			          	</table>
			          </td>
			        </tr>
			        <tr height="35" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td width="120" align="right" class="c3">新增天數：</td>
			          <td class="h3"><?php echo $EVCount;?>　
			          	<input type="button" id="Vacation" name="Vacation" class="input_bot" value="參考公式" onclick="javascript:window.open ('Vacation.htm','Vacation','height=510,width=400,top=100,left=400,scrollbars=no,status=no');">
			          </td>
			        </tr>
			        <tr height="35" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td width="120" align="right" class="c3">說明：</td>
			          <td class="h3"><input type="text" name="EVDesc" size="60" value="<?php echo $EVDesc;?>"></td>
			        </tr>
			        <tr height="40" align="center">
			          <td colspan="2" class="h3"><input type="submit" name="submit" class="input_bot" value="送 出"></td>
			        </tr>
				      </form>
			      </table>
    			</td>
    		</tr>
    	</table>
    </td>
	</tr>
</table>
<?php include "down.php";?>
</body>
</html>
<?php
mysqli_close($link);
?>