﻿<?php
include "CheckPermission.php";
include "CheckProjectAccounting.php";
include "../global.php";
include "include/function.php";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>全威驗證科技內部系統</title>
<style type="text/css">
<!--
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
}
.Q1 {
	font-family: "標楷體", Arial, sans-serif;
	font-size: 18px;
	color: #000000;
	font-weight: bold;
	}
.Q2 {
	font-family: Arial, sans-serif;
	font-size: 18px;
	color: #000000;
	font-weight: bold;
	}
.Q3 {
	font-family: Arial, sans-serif;
	font-size: 18px;
	color: #000000;
	font-weight: bold;
	font-style:italic;
	}
.Q4 {
	font-family: "標楷體", Arial, sans-serif;
	font-size: 12px;
	color: #000000;
	font-weight: bold;
	}
.Q5 {
	font-family: "細明體", Arial, sans-serif;
	font-size: 12px;
	color: #000000;
	font-weight: bold;
	}
.Q6 {
	font-family: "標楷體", Arial, sans-serif;
	font-size: 12px;
	color: #000000;
	}
.Q7 {
	font-family: "標楷體", Arial, sans-serif;
	font-size: 12px;
	color: #000000;
	font-weight: bold;
	}
.Q8 {
	font-family: "標楷體", Arial, sans-serif;
	font-size: 12px;
	color: #000000;
	font-weight: bold;
	}
.Q9 {
	font-family: "標楷體", Arial, sans-serif;
	font-size: 10px;
	color: #000000;
	font-weight: bold;
	}
.Q10 {
	font-family: Arial, sans-serif;
	font-size: 11px;
	color: #000000;
	}
-->
</style></head>

<body>
<?php
$PID = $_GET['PID'];
$Florin = $_GET['Florin'];
$CheckQuotation = $_GET['CheckQuotation'];
$Company = $_GET['Company'];
if (trim($Florin) == "") $Florin = "T";
if (trim($PID) == "")
		{
		mysqli_close($link);
		?>
		<script type="text/JavaScript">
			<!--
			alert ("查無資料，請冾網站管理人員！");
			history.go(-1);
			//-->
		</script>
		<?php
		exit;
		}
$SQL_Project="select PUID,PName,ApplyItem,CID,CName,CTel,CFax,Contact,CMobile,CEMail,CAddress,QuoteDate,IFlorin,(select GUI from Customer where Deltag='N' and CID = Project.CID) as GUI,InvoiceCUID,InvoiceTitle,InvoiceAddress,Leadtime,Trademark,PTax,ModelName,SeriesModel,(select TrademarkTxt from Customer where Deltag='N' and CID = Project.CID) as TrademarkTxt,(select MName from Manager where Deltag='N' and MUID=Project.BMUID) MName,(select MEName from Manager where Deltag='N' and MUID=Project.BMUID) MEName,(select Mobile from Manager where Deltag='N' and MUID=Project.BMUID) Mobile from Project where Deltag='N' and PID = '".$PID."';";
$result_Project=mysqli_query($link,$SQL_Project) or die ("無法執行查詢");
if (mysqli_num_rows($result_Project) == 0)
		{
		mysqli_free_result($result_Project);
		mysqli_close($link);
		?>
		<SCRIPT language=javascript>
		<!--
		alert ("查無資料，請冾網站管理人員！"); 
		history.go(-1);
		//-->
		</SCRIPT>
		<?php 	
		exit;
		}
list($PUID,$PName,$ApplyItem,$CID,$CName,$CTel,$CFax,$Contact,$CMobile,$CEMail,$CAddress,$QuoteDate,$IFlorin,$GUI,$InvoiceCUID,$InvoiceTitle,$InvoiceAddress,$Leadtime,$Trademark,$PTax,$ModelName,$SeriesModel,$TrademarkTxt,$MName,$MEName,$Mobile)=mysqli_fetch_row($result_Project);
mysqli_free_result($result_Project);
if (trim($Trademark) != "") $TrademarkTxt = $Trademark;
if (trim($MName) == "" && trim($Mobile) == "") {
		$MName="vivi王郁齡";
		$Mobile="0933-335-410";
		}
?>
<table border="0" cellpadding="0" cellspacing="0">
	<tr>
		<td>
			<table width="800" border="0" cellpadding="0" cellspacing="0">
				<tr>
					<td colspan="3" height="5"></td>
				</tr>
				<?php if($Company == 'RPC'){echo '<tr>
					<td width="150" rowspan="4" align="center"><img src="../images/logo.gif" border="0" width="100" height="96" /></td>
					<td width="350" height="20">&nbsp;</td>
					<td width="200" height="20">&nbsp;</td>
				</tr>';}elseif($Company == 'RPC2'){ echo '<td width="150" rowspan="4" align="center"></td>
					<td width="350" height="20">&nbsp;</td>
					<td width="200" height="20">&nbsp;</td>';}elseif($Company == 'OBU'){ echo '<td width="150" rowspan="4" align="center"></td>
					<td width="350" height="20">&nbsp;</td>
					<td width="200" height="20">&nbsp;</td>';}?>
				
				<tr>
					<td class="Q1" height="20"><?php if($Company == 'RPC'){echo '全威驗證科技股份有限公司';}elseif($Company == 'RPC2'){ echo '瑞寶國際科技有限公司';}elseif($Company == 'OBU'){ echo '';}?></td>
					<td class="Q2" height="20">TEL:+886-2-8201-1888</td>
				</tr>
				<tr>
					<td class="Q3" height="20"><?php if($Company == 'RPC'){echo '<font color="red">R</font>ight&nbsp;&nbsp;<font color="red">P</font>ower&nbsp;&nbsp;<font color="red">C</font>ertification&nbsp;&nbsp;Co., Ltd.';}elseif($Company == 'RPC2'){ echo '<font color="red">R</font>uei&nbsp;&nbsp;<font color="red">P</font>au&nbsp;&nbsp;<font color="red">C</font>orporation&nbsp;&nbsp;';}elseif($Company == 'OBU'){ echo '<font color="red">R</font>ight&nbsp;&nbsp;<font color="red">P</font>ower&nbsp;&nbsp;<font color="red">C</font>ertification&nbsp;&nbsp;Co., Ltd.';}?></td>
					<td class="Q2" height="20">FAX:+886-2-8201-8388</td>
				</tr>
				<tr>
					<td colspan="3" height="20">&nbsp;</td>
				</tr>
				<tr>
					<td colspan="3" height="20" align="center" valign="bottom" class="Q2"><font color="purple">服  務  報  價  單</font></td>
				</tr>
				<tr>
					<td colspan="3" height="20" align="center" valign="top" class="Q2"><hr width="120" height="25" color="purple"></td>
				</tr>
			</table>
			<table width="720" border="1" cellpadding="0" cellspacing="0" bordercolor="#000000" align="center">
				<tr>
					<td>
						<table width="720" border="0" cellpadding="0" cellspacing="0" align="center">
							<tr height="20">
								<td class="Q4" width="155">公司名稱 Company：</td>
								<td class="Q5" width="255"><?php echo $CName;?></td>
								<td class="Q4" width="190">合約編號Contract No.</td>
								<td class="Q5" width="80" align="center"><font color="#000000"><?php echo $PUID;?></font></td>
							</tr>
							<tr height="20">
								<td class="Q4">聯絡人Contact Person：</td>
								<td class="Q5"><?php echo $Contact;?></td>
								<td class="Q4">發票抬頭  Title of invoice：</td>
								<td class="Q5" align="center"><font color="#000000"><?php if (trim($InvoiceTitle) != "") echo $InvoiceTitle; else echo "同左";?></font></td>
							</tr>
							<tr height="20">
								<td class="Q4">電話Telephone No.：</td>
								<td class="Q5"><?php echo $CTel;?></td>
								<td class="Q4">統一編號 Tax ID:</td>
								<td class="Q5" align="center"><font color="#000000"><?php if (trim($InvoiceCUID) != "") echo $InvoiceCUID; else echo $GUI;?></font></td>
							</tr>
							<tr height="20">
								<td class="Q4">公司地址<br/>Company Address：</td>
								<td class="Q5"><?php echo $CAddress;?></td>
								<td class="Q4">發票寄送地址<br/>Invoice Address：</td>
								<td class="Q5" align="center"><font color="#000000"><?php if (trim($InvoiceAddress) != "") echo $InvoiceAddress; else echo "同左";?></font></td>
							</tr>
							<tr height="20">
								<td class="Q4">專案名稱Project:</td>
								<td class="Q5"><?php echo $PName;?>-<?php echo $ApplyItem;?></td>
								<td class="Q4">報價日期 Date：</td>
								<td class="Q5" align="center"><font color="#000000"><?php echo $QuoteDate;?></font></td>
							</tr>
						</table>
						<table width="720" border="0" cellpadding="0" cellspacing="0" align="center" height="1" style="border-style: dashed; border-width: 2px" bordercolor="#000000">
							<tr>
								<td>
									<table width="680" border="0" cellpadding="0" cellspacing="0" align="center">
										<tr height="20">
											<td class="Q4" width="260" align="center">服  務  內  容</td>
											<td class="Q4" width="85" align="center">報告費用</td>
											<td class="Q4" width="60" align="center">稅    金</td>
											<td class="Q4" width="85" align="center">總    價</td>
											<td class="Q4" width="190" align="center">備    註</td>
										</tr>
									</table>
								</td>
							</tr>
						</table>
						<table width="720" border="0" cellpadding="0" cellspacing="0" align="center">
							<?php
							$SQL_ProjectAccounting="select PAID,PAMode,PAItem,Charges,Rate,ChargesOther,PATax,PAStatus,PADate,PANote from ProjectAccounting where Deltag='N' and PAMode='I' and PID = '".$PID."' and (PAStatus = 'W' or PAStatus = 'S') order by PAMode asc,PAID asc;";
							$result_ProjectAccounting=mysqli_query($link,$SQL_ProjectAccounting) or die ("無法執行查詢");
							$ShowLine = 17 - mysqli_num_rows($result_ProjectAccounting);
		          $SumPrice = 0;
		          $PATaxPrice = 0;
		          while(list($PAID,$PAMode,$PAItem,$Charges,$Rate,$ChargesOther,$PATax,$PAStatus,$PADate,$PANote)=mysqli_fetch_row($result_ProjectAccounting)){
								if (trim($Florin) == "O") $Charges = $ChargesOther;
								$SumPrice = $SumPrice + $Charges;
		          	if (trim($PATax) == "") {
				          	if (trim($PTax) == "Y") $PATax = "Y";
				          	else if (trim($PTax) == "N") $PATax = "N";
		          			}
		          	if (trim($PATax) == "Y") $PATaxPrice = $PATaxPrice + round($Charges*0.05);
							?>
							<tr height="15">
								<td class="Q6" width="260" align="center"><?php echo $PAItem;?></td>
								<td class="Q6" width="85" align="center"><?php echo number_format($Charges);?></td>
								<td class="Q6" width="60" align="center">
									<?php
			          	if (trim($PATax) == "Y") echo number_format(round($Charges*0.05));
			          	else if (trim($PATax) == "N") echo "0";
									?>
								</td>
								<td class="Q6" width="85" align="center">
									<?php
			          	if (trim($PATax) == "Y") echo number_format((round($Charges*0.05))+$Charges);
			          	else if (trim($PATax) == "N") echo number_format($Charges);
									?>
								</td>
								<td class="Q6" width="190"><?php echo $PANote;?></td>
							</tr>
			        <?php
			      			}
            	mysqli_free_result($result_ProjectAccounting);
            	for ($tmp=0;$tmp<=$ShowLine-1;$tmp++){
			        ?>
							<?php }?>
							<tr height="15">
								<td class="Q6" align="center" colspan="5">
									Lead-time：<?php echo $Leadtime;?>　
									<?//php echo $TrademarkTxt;?>　
									Model name：<?php echo $ModelName;?> / <?php echo $SeriesModel;?>
								</td>
							</tr>
						</table>
						<table width="720" border="0" cellpadding="0" cellspacing="0" align="center" height="1" style="border-style: dashed; border-width: 2px" bordercolor="#000000">
							<tr>
								<td>
									<table width="680" border="0" cellpadding="0" cellspacing="0" align="center">
										<tr height="20">
											<td class="Q4" width="410">&nbsp;委託費用</td>
											<td class="Q7" width="90" align="center"><?php echo number_format($SumPrice);?></td>
											<td class="Q7" width="180" align="center">&nbsp;</td>
										</tr>
										<tr height="20">
											<td class="Q4">&nbsp;營業稅</td>
											<td class="Q7" align="center"><?php echo number_format($PATaxPrice);?></td>
											<td class="Q7" align="center">&nbsp;</td>
										</tr>
									</table>
								</td>
							</tr>
						</table>
						<table width="720" border="0" cellpadding="0" cellspacing="0" align="center">
							<tr height="20">
								<td class="Q4">&nbsp;總　計 (<?php if (trim($Florin) == "T") echo "TWD"; else echo $IFlorin;?>)</td>
								<td class="Q7" align="center"><?php echo number_format($SumPrice + $PATaxPrice);?></td>
								<td class="Q7" align="center">&nbsp;</td>
								<td class="Q7" align="center">&nbsp;</td>
								<td class="Q7" align="center">&nbsp;</td>
								<td class="Q7" align="center">&nbsp;</td>
							</tr>
						</table>

					</td>
				</tr>
			</table>
			<table width="730" border="0" cellpadding="0" cellspacing="0" align="center">
				<tr height="10">
					<td></td>
				</tr>
				<tr height="10">
					<td class="Q8">注意事項</td>
				</tr>
				<tr height="10">
					<td class="Q8">1.以上報價有效期限三十天。請簽名後回傳Email or FAX:+886-2-8201-8388</td>
				</tr>
				<tr height="10">
					<td class="Q8">2.申請規費及測試費用會隨產品結構,SECOND SOURCE 零件而變。</td>
				</tr>
				<tr height="10">
					<td class="Q8">3.委託申請之產品其功能需正常。申請期間不得再做影響試驗內容之變更或安規重要零組件加報事項,否則進度減緩,費用增加,得由顧客自行負責。在測試期間,顧客需全力配合,確認對策可行性,若測試Fail將加收測試費用。</td>
				</tr>
				<tr height="10">
					<td class="Q8">4.本申請案所列示Lead-time,係以送測時樣品、零件及所須文件等齊全且測試無誤計算,申請過程若因樣品測試Fail或所須文件不齊,則時間延後起算。</td>
				</tr>
				<tr height="10">
					<td class="Q8">5.本實驗室服務內容(不包括工廠檢查部份),及保留因故更動服務內容之權利。</td>
				</tr>
				<tr height="10">
					<td class="Q8">6.顧客必須配合本實驗室所開出之INVOICE付款條件,以匯款或現金支票支付,以利支付案件相關費用。(電匯時請告知付款銀行,顧客欲付擔銀行手續費用包含中間銀行相關費用,避免無法沖帳)。</td>
				</tr>
				<tr height="10">
					<td class="Q8">7.待餘款結清後將正本證書以掛號或Email方式寄送,產品測試完成後若須退運,請事先提出聲明,費用另計。</td>
				</tr>
				<tr height="10">
					<td class="Q8">8.本報價內容為約定保密標的,非經本實驗室同意,不得使用於約定目地範圍外之事務或為他人之利益而使用。</td>
				</tr>
				<tr height="10">
					<td class="Q8">9.本實驗室對於本報告測試活動中所獲得之所有資訊皆予以保密,除實驗室為認證要求外。</td>
				</tr>
				<tr height="10">
					<td class="Q8">10.本試驗報告之符合性判定規則為依據法規標準要求,且不考慮量測不確定度。</td>
				</tr>
				<tr height="10">
					<td class="Q8">11.如樣品不需退回則由本實驗室自動銷毀,如須退回樣品所產生運費由顧客負擔。</td>
				</tr>
				<tr height="10">
					<td class="Q8">12.顧客同意委由本實驗室安排必要之相關外部實驗室活動，並將相關資訊提供予外部實驗單位。</td>
				</tr>
				<tr height="10">
					<td></td>
				</tr>
				<?php if($Company == 'RPC'){echo '<tr height="10">
					<td class="Q8">付款方式：</td>
				</tr>
				<tr height="10">
					<td class="Q8">戶名:全威驗證科技股份有限公司</td>
				</tr>
				<tr height="10">
					<td class="Q8">電匯 (金融機構:中國信託商業銀行822 基隆分行帳號381-54018788-5)</td>
				</tr>
				<tr height="15">
					<td class="Q8"></td>
				</tr>';}elseif($Company == 'RPC2'){ echo '<tr height="10">
					<td class="Q8">付款方式：</td>
				</tr>
				<tr height="10">
					<td class="Q8">戶名:瑞寶國際科技有限公司</td>
				</tr>
				<tr height="10">
					<td class="Q8">電匯 (金融機構:中國信託商業銀行822 丹鳳分行帳號761-54012112-8)</td>
				</tr>
				<tr height="15">
					<td class="Q8"></td>';}elseif($Company == 'OBU'){ echo '<tr height="15">
					<td class="Q8">Payment information:</td>
				</tr>
				<tr height="15">
					<td><span class="Q8">Beneficiary Bank Name：</span><span class="Q10">CTBC Bank Co., Ltd. Hong Kong Branch 中國信託商業銀行股份有限公司 香港分行</span></td>
				</tr>
				<tr height="15">
					<td><span class="Q8">Swift Code：</span><span class="Q10">CTCBHKHH</span></td>
				</tr>
				<tr height="15">
					<td><span class="Q8">Beneficiary Account Name：</span><span class="Q10">Right Power Certification Company Co., Ltd.. </span></td>
				</tr>
				<tr height="15">
					<td><span class="Q8">Beneficiary Account No.：</span><span class="Q10">904-10-104616-6</span></td>
				</tr>
				<tr height="15">
					<td><span class="Q8">Bank Code：</span><span class="Q10">229</span></td>
				</tr>
				<tr height="15">
					<td><span class="Q8">Branch Code：</span><span class="Q10">972</span></td>
				</tr>
				<tr height="15">
					<td><span class="Q8">Bank Address：</span><span class="Q10">Suite 2801, 28/F., Two International Finance Centre, 8 Finance Street, Central, Hong Kong</span></td>
				</tr>';}?>				<tr height="5">
					<td></td>
				</tr>
			</table>
			<table width="720" border="0" cellpadding="0" cellspacing="0" align="center">
				<tr height="30">
					<td>
						<table width="250" border="1" cellpadding="4" cellspacing="0" bordercolor="#000000" align="center">
							
							<tr height="73">
								<td class="Q8" valign="top">實驗室主管：</td>
							</tr>
						</table>
					</td>
					<td>
					<!--
						<table width="250" border="1" cellpadding="0" cellspacing="0" bordercolor="#000000" align="center">
							<tr height="73">
								<td class="Q8" valign="top">技術主管：</td>
							</tr>
						</table>
					-->
						<table width="250" border="1" cellpadding="4" cellspacing="0" bordercolor="#000000" align="center">
							<tr height="73">
								<td class="Q8" valign="top">顧客簽名/日期：</td>
							</tr>
						</table>
					</td>
				</tr>
			</table>
			<table width="250" border="0" cellpadding="0" cellspacing="0" align="center">
				<tr height="30">
					<td>
					</td>
				</tr>
			</table>
			<table width="720" border="0" cellpadding="0" cellspacing="0" align="center">
				<tr height="30">
					<td>
						<table width="250" border="1" cellpadding="0" cellspacing="0" bordercolor="#000000" align="center">
							<tr>
								<td>
									<table width="250" border="0" cellpadding="4" cellspacing="0" align="center">
										<tr height="50">
											<td class="Q8" width="80" valign="top">承辦客服：</td>
											<td class="Q8" align="center"><?php echo $MEName.$MName;?></td>
										</tr>
									</table>
									<table width="250" border="0" cellpadding="4" cellspacing="0" align="center">
										<tr height="15">
											<td class="Q8" align="center">行動電話：<?php echo $Mobile;?></td>
										</tr>
									</table>
								</td>
							</tr>
						</table>
					</td>
					<td>
						<table width="250" border="0" cellpadding="0" cellspacing="0" bordercolor="#000000" align="center">
							<tr height="73">
								<td class="Q8" valign="top"></td>
							</tr>
						</table>
					</td>
				</tr>
			</table>
			<table width="800" border="0" cellpadding="0" cellspacing="0" align="center">
				<tr height="10">
					<td></td>
				</tr>
				<tr height="15">
					<td class="Q9">241新北市三重興德路115號2樓2F., No. 115, Xingde Rd., Sanchong Dist., New Taipei City 241 , Taiwan (R.O.C.)</td>
				</tr>
				<tr height="15">
					<td class="Q9">文件編號: RPC-OD-201</td> <td class="Q9" align="right">版次: Version 1.7(20230304)</td>
				</tr>
			</table>
		</td>
	</tr>
</table>
</body>
</html>
<?php
if (trim($CheckQuotation) == "Y") {
		$QuotationURL="http://".$_SERVER["HTTP_HOST"]."/Admin/ProjectQuotationOutput.php?PID=".$PID."&Florin=".$Florin;
		$fp=fopen($QuotationURL,"r");
		$PQRUContent="";
		while($line=fgets($fp,512)){
			$PQRUContent.=$line;
			}
		fclose($fp);
		
		$PQRUID = "Q".rand_string(10, 'ABCDEFGHIJKLMNPQRSTUVWXYZ23456789abcdefghijklmnopqrstuvwxyz').$PID.$Florin;
		
		$now_time = date("Y-m-d H:i:s",mktime());
		$sql_update = "update ProjectQuotationRecord set Deltag='Y' where Deltag='N' and PID = '".$PID."';";
		$result_update=mysqli_query($link,$sql_update) or die ("無法執行修改");
		$sql_insert = "insert into ProjectQuotationRecord (PID,PQRUID,QuoteDate,PQRUContent,AddUser,AddDate,AddIP) values ('".$PID."','".$PQRUID."','".$QuoteDate."','".$PQRUContent."','".$_SESSION["reg_MUID"]."','".$now_time."','".$_SERVER["REMOTE_ADDR"]."');";
		$result_insert=mysqli_query($link,$sql_insert) or die ("無法執行新增");
		}
mysqli_close($link);
?>