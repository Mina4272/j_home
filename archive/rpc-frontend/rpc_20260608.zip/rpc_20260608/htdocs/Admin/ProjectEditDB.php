﻿<?php
include "CheckPermission.php";
include "CheckProject.php";
include "../global.php";
require_once("../include/chinese_party.class.php");
require("class.phpmailer.php");
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $PageAdminTitle;?></title>
</head>
<body>
<?php

$CloseDate="";
$PAADate ="";
$PADate="";
$PNoteDate ="";
$SqlTxt="";
$Msg="";

$PID = $_POST['PID'];
$page = $_POST['page'];
$KeyWord = $_POST['KeyWord'];
$QPStatus = $_POST['QPStatus'];
$QPE = $_POST['QPE'];
$QBMUID = $_POST['QBMUID'];
$ISINo = $_POST['ISINo'];
$ISAdd = $_POST['ISAdd'];

$CID = $_POST['CID'];
$CName = $_POST['CName'];
$CTel = $_POST['CTel'];
$CFax = $_POST['CFax'];
$CAddress = $_POST['CAddress'];
$Contact = $_POST['Contact'];
$CMobile = $_POST['CMobile'];
$CEMail = $_POST['CEMail'];
$PName = $_POST['PName'];
$ModelName = $_POST['ModelName'];
$SeriesModel = $_POST['SeriesModel'];
$PE = $_POST['PE'];
$test = $_POST['test'];
$BMUID = $_POST['BMUID'];
$ApplyItem = $_POST['ApplyItem'];
$Agent = $_POST['Agent'];
$Canon = $_POST['Canon'];
$StartYear = $_POST['StartYear'];
$StartMonth = $_POST['StartMonth'];
$StartDay = $_POST['StartDay'];
if (trim($StartYear) != "" || trim($StartMonth) != "" || trim($StartDay) != "") if (checkdate($StartMonth,$StartDay ,$StartYear)) $StartDate = $StartYear."-".$StartMonth."-".$StartDay;
$PlanYear = $_POST['PlanYear'];
$PlanMonth = $_POST['PlanMonth'];
$PlanDay = $_POST['PlanDay'];
if (trim($PlanYear) != "" || trim($PlanMonth) != "" || trim($PlanDay) != "") if (checkdate($PlanMonth,$PlanDay ,$PlanYear)) $PlanDate = $PlanYear."-".$PlanMonth."-".$PlanDay;

$CloseYear = $_POST['CloseYear'];
$CloseMonth = $_POST['CloseMonth'];
$CloseDay = $_POST['CloseDay'];
if (trim($CloseYear) != "" || trim($CloseMonth) != "" || trim($CloseDay) != "") if (checkdate($CloseMonth,$CloseDay ,$CloseYear)) $CloseDate = $CloseYear."-".$CloseMonth."-".$CloseDay;
if (trim($CloseDate) == "") $CloseDate = "0000-00-00";
$PStatus = $_POST['PStatus'];
$SNote = $_POST['SNote'];
$PNote = $_POST['PNote'];
$PNote1 = $_POST['PNote1'];

$CCCCode = $_POST['CCCCode'];
$EMC = $_POST['EMC'];
$POther = $_POST['POther'];
$PAYear = $_POST['PAYear'];
$PAMonth = $_POST['PAMonth'];
$PADay = $_POST['PADay'];
if (trim($PAYear) != "" || trim($PAMonth) != "" || trim($PADay) != "") if (checkdate($PAMonth,$PADay ,$PAYear)) $PADate = $PAYear."-".$PAMonth."-".$PADay;
$PNoteYear = $_POST['PNoteYear'];
$PNoteMonth = $_POST['PNoteMonth'];
$PNoteDay = $_POST['PNoteDay'];
if (trim($PNoteYear) != "" || trim($PNoteMonth) != "" || trim($PNoteDay) != "") if (checkdate($PNoteMonth,$PNoteDay ,$PNoteYear)) $PNoteDate = $PNoteYear."-".$PNoteMonth."-".$PNoteDay;

$PAAYear = empty($_POST['PAAYear'])?"":$_POST['PAAYear'];
$PAAMonth = empty($_POST['PAAMonth'])?"":$_POST['PAAMonth'];
$PAADay = empty($_POST['PAADay'])?"":$_POST['PAADay'];
if (trim($PAAYear) != "" || trim($PAAMonth) != "" || trim($PAADay) != "") if (checkdate($PAAMonth,$PAADay ,$PAAYear)) $PAADate = $PAAYear."-".$PAAMonth."-".$PAADay;
$PAAReason = empty($_POST['PAAReason'])?"":$_POST['PAAReason'];
$PAAReason = str_replace("\r\n","<br>",$PAAReason);
$PAACheck = empty($_POST['PAACheck'])?"":$_POST['PAACheck'];
$PAAReCheck = empty($_POST['PAAReCheck'])?"":$_POST['PAAReCheck'];
if (trim($PAACheck) == "") $PAACheck="N";

if (trim($PID) == "" || trim($CID) == "" || trim($PName) == "")
		{
		mysqli_close($link);
		?>
		<script type="text/JavaScript">
			<!--
			alert ("您輸入的資料不足，請重新輸入！");
			history.go(-1);
			//-->
		</script>
		<?php
		exit;
		}

if (trim($CloseDate) == "0000-00-00") $CloseDate = "";
if (trim($PStatus) == "H" && trim($CloseDate) == "") {
		mysqli_close($link);
		?>
		<script type="text/JavaScript">
			<!--
			alert ("請輸入結案日期！");
			history.go(-1);
			//-->
		</script>
		<?php
		exit;
		}

$now_time = date("Y-m-d H:i:s",mktime());
$SQL_select="select PUID,(select MName from Manager where Deltag='N' and ISEngineer = 'Y' and MUID=Project.PE) as MName,(select EMail from Manager where Deltag='N' and ISEngineer = 'Y' and MUID=Project.PE) as EMail,PE,PENotify,PENotifyMUID from Project where Deltag='N' and PID = '".$PID."';";
$result_select=mysqli_query($link,$SQL_select) or die ("無法執行查詢");

if (mysqli_num_rows($result_select) == 0)
		{
		mysqli_free_result($result_select);
		mysqli_close($link);
		?>
		<script type="text/JavaScript">
			<!--
			alert ("查無資料，請冾網站管理人員！");
			history.go(-1);
			//-->
		</script>
		<?php
		exit;
		}
list($PUID,$MName,$EMail,$SPE,$PENotify,$PENotifyMUID)=mysqli_fetch_row($result_select);
mysqli_free_result($result_select);

$sql_insert = "INSERT INTO ProjectHistory(PID,PUID,CID,CName,CTel,CFax,Contact,CMobile,CEMail,CAddress,PStatus,PName,ModelName,SeriesModel,PE,test,PENotify,PENotifyMUID,Quote,BMUID,ApplyItem,Canon,CCCCode,SNote,StartDate,PlanDate,CloseDate,PNote,PNoteDate,EMC,POther,PADate,PNote1,QuoteDate,QRecord,QRecordDate,QRecordIP,ReturnDate,RRecord,RRecordDate,RRecordIP,IFlorin,OFlorin,InvoiceCUID,InvoiceTitle,InvoiceAddress,Leadtime,Trademark,PTax,IDate,INo,InvoiceDate,InvoiceNote,IRecord,IRecordDate,IRecordIP,AddUser,AddDate,AddIP,Deltag,ProcUser,ProcDate,ProcIP,UpdateUser,UpdateDate,UpdateIP) SELECT PID,PUID,CID,CName,CTel,CFax,Contact,CMobile,CEMail,CAddress,PStatus,PName,ModelName,SeriesModel,PE,test,PENotify,PENotifyMUID,Quote,BMUID,ApplyItem,Canon,CCCCode,SNote,StartDate,PlanDate,CloseDate,PNote,PNoteDate,EMC,POther,PADate,PNote1,QuoteDate,QRecord,QRecordDate,QRecordIP,ReturnDate,RRecord,RRecordDate,RRecordIP,IFlorin,OFlorin,InvoiceCUID,InvoiceTitle,InvoiceAddress,Leadtime,Trademark,PTax,IDate,INo,InvoiceDate,InvoiceNote,IRecord,IRecordDate,IRecordIP,AddUser,AddDate,AddIP,Deltag,ProcUser,ProcDate,ProcIP,'".$_SESSION["reg_MUID"]."','".$now_time."','".$_SERVER["REMOTE_ADDR"]."' FROM Project where Deltag='N' and PID = '".$PID."';";
$result_insert=mysqli_query($link,$sql_insert) or die ("無法執行新增");
if (trim($PENotifyMUID) != trim($PE)) $SqlTxt = ",PENotify='Y',PENotifyMUID='".$PE."'";

if (trim($PAADate) != "" && trim($PAACheck) == "N" && trim($PAAReCheck) == "Y") {
		$SQL_ProjectAccountingAdd="select PAAID from ProjectAccountingAdd where PAACheck='N' and PID = ".$PID.";";
		$result_ProjectAccountingAdd=mysqli_query($link,$SQL_ProjectAccountingAdd) or die ("無法執行查詢");
		if (mysqli_num_rows($result_ProjectAccountingAdd) == 0) {
				$sql_insert = "insert into ProjectAccountingAdd (PID,PAADate,PAAReason,AddUser,AddDate,AddIP) values ('".$PID."','".$PAADate."','".$PAAReason."','".$_SESSION["reg_MUID"]."','".$now_time."','".$_SERVER["REMOTE_ADDR"]."');";
				$result_insert=mysqli_query($link,$sql_insert) or die ("無法執行新增");
				}
		else {
				$sql_insert = "INSERT INTO ProjectAccountingAddHistory(PAAID,PID,PAADate,PAAReason,PAACheck,AddUser,AddDate,AddIP,ProcUser,ProcDate,ProcIP,UpdateUser,UpdateDate,UpdateIP) SELECT PAAID,PID,PAADate,PAAReason,PAACheck,AddUser,AddDate,AddIP,ProcUser,ProcDate,ProcIP,'".$_SESSION["reg_MUID"]."','".$now_time."','".$_SERVER["REMOTE_ADDR"]."' FROM ProjectAccountingAdd where PID = ".$PID.";";
				$result_insert=mysqli_query($link,$sql_insert) or die ("無法執行新增");
				$sql_update = "update ProjectAccountingAdd set PAADate = '".$PAADate."',PAAReason = '".$PAAReason."',ProcUser = '".$_SESSION["reg_MUID"]."',ProcDate = '".$now_time."',ProcIP = '".$_SERVER["REMOTE_ADDR"]."' where PID = ".$PID.";";
				$result_update=mysqli_query($link,$sql_update) or die ("無法執行修改");
				}
		$SqlTxt .= ",PStatus='B',QuoteDate=NULL,QRecord='',QRecordDate=NULL,QRecordIP='' ";
		mysqli_free_result($result_ProjectAccountingAdd);
		}

if (trim($StartDate)=="") $StartDate = "NULL";
else $StartDate = "'$StartDate'";
if (trim($PlanDate)=="") $PlanDate = "NULL";
else $PlanDate = "'$PlanDate'";
if (trim($CloseDate)=="") $CloseDate = "NULL";
else $CloseDate = "'$CloseDate'";
if (trim($PADate)=="") $PADate = "NULL";
else $PADate = "'$PADate'";
if (trim($PNoteDate)=="") $PNoteDate = "NULL";
else $PNoteDate = "'$PNoteDate'";

$sql_update = "update Project set CID = '".$CID."',CName = '".$CName."',CTel = '".$CTel."',CFax = '".$CFax."',CAddress = '".$CAddress."',Contact = '".$Contact."',CMobile = '".$CMobile."',CEMail = '".$CEMail."',PName = '".$PName."',ModelName = '".$ModelName."',SeriesModel = '".$SeriesModel."',BMUID = '".$BMUID."',PE = '".$PE."',test='".$test."',ApplyItem = '".$ApplyItem."',Agent = '".$Agent."',Canon = '".addslashes($Canon)."',CCCCode = '".$CCCCode."',StartDate = ".$StartDate.",PlanDate = ".$PlanDate.",CloseDate = ".$CloseDate.",PStatus = '".$PStatus."',SNote = '".$SNote."',PNote = '".$PNote."',PNoteDate = ".$PNoteDate.",EMC = '".$EMC."',POther = '".$POther."',PADate = ".$PADate.",PNote1 = '".$PNote1."'".$SqlTxt.",ProcUser = '".$_SESSION["reg_MUID"]."',ProcDate = '".$now_time."',ProcIP = '".$_SERVER["REMOTE_ADDR"]."' where Deltag='N' and PID = '".$PID."';";

//echo $sql_update;

$result_update=mysqli_query($link,$sql_update) or die ("無法執行修改");

if (trim($PStatus) == "C" && (trim($PENotifyMUID) != trim($PE))) {
		/*
		$EMAILFN = "notify.htm";
		$subject="全威驗證案件確認通知 ！！";
		$fp=fopen($EMAILFN,"r");
		$content="";
		while($line=fgets($fp,512)){
			$content.=$line;
			}
		fclose($fp);
		
		$content = str_replace("{PUID}",$PUID,$content);
		$content = str_replace("{PName}",$PName,$content);
		$content = str_replace("{ModelName}",$ModelName,$content);
		$content = str_replace("{CName}",$CName,$content);
		$content = str_replace("{PE}",$MName,$content);
		
		$cconv =& new chinese_party();
		$content = $cconv->u82tchi($content);
		$subject = $cconv->u82tchi($subject);
		
		$mail = new PHPMailer();
		$mail->IsSMTP();
		$mail->Host     = "127.0.0.1";
		$mail->SMTPAuth = true;
		$mail->From     = "Benson@rpclab.com";
		$mail->FromName = $subject;
		$mail->WordWrap = 50;
		$mail->IsHTML(true);                               // send as HTML
		$mail->CharSet = "big5";
		$mail->Subject  = $subject;
		$mail->Body     =  $content;
		$mail->AddAddress($EMail,"");
		$mail->AddReplyTo("Benson@rpclab.com");
		if(!$mail->Send())
				{
		    //echo "There has been a mail error sending to " . $SendEMail . "<br>";
		    //echo "Mailer Error: " . $mail->ErrorInfo . "<br>";
		  	}
		else
				{
				//echo $SendEMail . " sending !!<br>";
				}
				
		$mail->ClearAddresses();
		$mail->ClearReplyTos();
		$mail->SmtpClose();
		*/
		}

if (trim($PStatus) == "H") {
		$SQL_ProjectCertificate="select PCID from ProjectCertificate where Deltag='N' and PID = '".$PID."';";
		$result_ProjectCertificate=mysqli_query($link,$SQL_ProjectCertificate) or die ("無法執行查詢");
		if (mysqli_num_rows($result_ProjectCertificate) == 0) $Msg=" ( 請記得上傳案件証書!! )";
		mysqli_free_result($result_ProjectCertificate);
		}
mysqli_close($link);
?>
<script type="text/JavaScript">
	<!--
	alert ("<?php echo '修改成功'.$Msg;?>");
	location.href='ProjectList.php?page=<?php echo $page;?>&QPStatus=<?php echo $QPStatus;?>&QPE=<?php echo $QPE;?>&QBMUID=<?php echo $QBMUID;?>&ISINo=<?php echo $ISINo;?>&ISAdd=<?php echo $ISAdd;?>&KeyWord=<?php echo urlencode($KeyWord);?>';
	//-->
</script>

</body>
</html>
