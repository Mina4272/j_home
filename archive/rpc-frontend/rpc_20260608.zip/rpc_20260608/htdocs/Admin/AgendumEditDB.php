﻿<?php
include "CheckPermission.php";
include "CheckAgendum.php";
include "../global.php";
include "include/function.php";
require_once("../include/chinese_party.class.php");
require("class.phpmailer.php");
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $PageAdminTitle;?></title>
</head>
<body>
<?php
$AFile="";
$SqlTxt="";
$AID = $_POST['AID'];
$page = $_POST['page'];
$KeyWord = $_POST['KeyWord'];
$QAStatus = $_POST['QAStatus'];
$QASID = $_POST['QASID'];
$QARID = $_POST['QARID'];
$QACID = empty($_POST['QACID'])?"":$_POST['QACID'];
$Late = empty($_POST['Late'])?"":$_POST['Late'];

//$ASID = $_POST['ASID'];
$ARID = empty($_POST['ARID'])?"":$_POST['ARID'];
$ACID = empty($_POST['ACID'])?"":$_POST['ACID'];
$AYear = $_POST['AYear'];
$AMonth = $_POST['AMonth'];
$ADay = $_POST['ADay'];
if (trim($AYear) != "" || trim($AMonth) != "" || trim($ADay) != "") if (checkdate($AMonth,$ADay ,$AYear)) $ADate = $AYear."-".$AMonth."-".$ADay;
$AEYear = $_POST['AEYear'];
$AEMonth = $_POST['AEMonth'];
$AEDay = $_POST['AEDay'];
if (trim($AEYear) != "" || trim($AEMonth) != "" || trim($AEDay) != "") if (checkdate($AEMonth,$AEDay ,$AEYear)) $AEDate = $AEYear."-".$AEMonth."-".$AEDay;
$ACYear = $_POST['ACYear'];
$ACMonth = $_POST['ACMonth'];
$ACDay = $_POST['ACDay'];
if (trim($ACYear) != "" || trim($ACMonth) != "" || trim($ACDay) != "") if (checkdate($ACMonth,$ACDay ,$ACYear)) $ACDate = $ACYear."-".$ACMonth."-".$ACDay;
$AItem = $_POST['AItem'];
//$AStatus = $_POST['AStatus'];
$Attribute = $_POST['Attribute'];
$PID = $_POST['PID'];
if (trim($PID) == "") $PID = 0;
$CID = $_POST['CID'];
if (trim($CID) == "") $CID = 0;
$CName = $_POST['CName'];
$CTel = $_POST['CTel'];
$CFax = $_POST['CFax'];
$CAddress = $_POST['CAddress'];
$Contact = $_POST['Contact'];
$CMobile = $_POST['CMobile'];
$CEMail = $_POST['CEMail'];
$ANote = $_POST['ANote'];
$CheckProc = empty($_POST['CheckProc'])?"":$_POST['CheckProc'];

if(trim($_FILES['AFile']['tmp_name']) != "")
		{
		if($_FILES['AFile']['size'] > 20971520)
				{
				?>
				<script type="text/JavaScript">
					<!--
					alert ("您上傳的檔案 Size 超過 20 M，請重新上傳！");
					history.go(-1);
					//-->
				</script>
				<?php
				exit();
				}
		$AFile = "AFile_".date("ymdHis",mktime()).rand_string(5, 'ABCDEFGHIJKLMNPQRSTUVWXYZ23456789abcdefghijklmnopqrstuvwxyz').".".strtolower(substr($_FILES['AFile']['name'],strrpos($_FILES['AFile']['name'],".")+1,strlen($_FILES['AFile']['name'])+1));
		@copy($_FILES['AFile']['tmp_name'],$_SERVER["DOCUMENT_ROOT"]."\\Admin\\AFile\\".$AFile);
		}

if (trim($AID) == "" || trim($ADate) == "" || trim($AItem) == "")
		{
		mysqli_close($link);
		?>
		<script type="text/JavaScript">
			<!--
			alert ("您輸入的資料不足，請重新輸入！");
			history.go(-1);
			//-->
		</script>
		<?php
		exit;
		}

$now_time = date("Y-m-d H:i:s",mktime());
$SQL_select="select CheckProc from Agendum where Deltag='N' and AID = '".$AID."';";
$result_select=mysqli_query($link,$SQL_select) or die ("無法執行查詢");

if (mysqli_num_rows($result_select) == 0)
		{
		mysqli_free_result($result_select);
		mysqli_close($link);
		?>
		<script type="text/JavaScript">
			<!--
			alert ("查無資料，請冾網站管理人員！");
			history.go(-1);
			//-->
		</script>
		<?php
		exit;
		}
list($CheckProcOld)=mysqli_fetch_row($result_select);
mysqli_free_result($result_select);

$sql_insert = "INSERT INTO AgendumHistory(AID,AUID,ASID,ARID,ACID,CheckProc,ADate,AEDate,ACDate,AStatus,ReviewID,ReviewDate,ReviewIP,ReceiveID,ReceiveDate,ReceiveIP,FinishID,FinishDate,FinishIP,CheckID,CheckDate,CheckIP,AItem,Attribute,PID,CID,CName,CTel,CFax,Contact,CMobile,CEMail,CAddress,AFile,ANote,AddUser,AddDate,AddIP,Deltag,ProcUser,ProcDate,ProcIP,UpdateUser,UpdateDate,UpdateIP) SELECT AID,AUID,ASID,ARID,ACID,CheckProc,ADate,AEDate,ACDate,AStatus,ReviewID,ReviewDate,ReviewIP,ReceiveID,ReceiveDate,ReceiveIP,FinishID,FinishDate,FinishIP,CheckID,CheckDate,CheckIP,AItem,Attribute,PID,CID,CName,CTel,CFax,Contact,CMobile,CEMail,CAddress,AFile,ANote,AddUser,AddDate,AddIP,Deltag,ProcUser,ProcDate,ProcIP,'".$_SESSION["reg_MUID"]."','".$now_time."','".$_SERVER["REMOTE_ADDR"]."' FROM Agendum where Deltag='N' and AID = '".$AID."';";
$result_insert=mysqli_query($link,$sql_insert) or die ("無法執行新增");

if (trim($ACDate)=="") $ACDate = "NULL";
else $ACDate = "'$ACDate'";

if (trim($AFile) != "") $SqlTxt = ",AFile='".$AFile."'";
if (trim($CheckProcOld) == "N")  $SqlTxt .= ",ARID='".$ARID."',ACID='".$ACID."',CheckProc = '".$CheckProc."'";
$sql_update = "update Agendum set ADate = '".$ADate."',AEDate = '".$AEDate."',ACDate = ".$ACDate.",AItem = '".$AItem."',Attribute = '".$Attribute."',PID = '".$PID."',CID = '".$CID."',CName = '".$CName."',CTel = '".$CTel."',CFax = '".$CFax."',Contact = '".$Contact."',CMobile = '".$CMobile."',CEMail = '".$CEMail."',CAddress = '".$CAddress."',ANote = '".$ANote."'".$SqlTxt.",ProcUser = '".$_SESSION["reg_MUID"]."',ProcDate = '".$now_time."',ProcIP = '".$_SERVER["REMOTE_ADDR"]."' where Deltag='N' and AID = '".$AID."';";
$result_update=mysqli_query($link,$sql_update) or die ("無法執行修改");

if (trim($CheckProcOld) == "N" && trim($CheckProc) == "Y") {
		$SQL_select="select AUID,ASID,(select MName from Manager where MUID=Agendum.ASID) ASName,(select EMail from Manager where MUID=Agendum.ASID) ASEMail,ARID,(select MName from Manager where MUID=Agendum.ARID) ARName,(select EMail from Manager where MUID=Agendum.ARID) AREMail,ACID,(select MName from Manager where MUID=Agendum.ACID) ACName,(select EMail from Manager where MUID=Agendum.ACID) ACEMail,AEDate,AItem from Agendum where Deltag='N' and AID = '".$AID."';";
		$result_select=mysqli_query($link,$SQL_select) or die ("無法執行查詢");
		list($AUID,$ASID,$ASName,$ASEMail,$ARID,$ARName,$AREMail,$ACID,$ACName,$ACEMail,$AEDate,$AItem)=mysqli_fetch_row($result_select);
		mysqli_free_result($result_select);

		$EMAILFN = "Agendum.htm";
		$subject="全威驗證事項派案通知 ！！";
		$fp=fopen($EMAILFN,"r");
		$content="";
		while($line=fgets($fp,512)){
			$content.=$line;
			}
		fclose($fp);
		
		$content = str_replace("{AUID}",$AUID,$content);
		$content = str_replace("{ASID}",$ASName,$content);
		$content = str_replace("{ARID}",$ARName,$content);
		$content = str_replace("{ACID}",$ACName,$content);
		$content = str_replace("{ADate}",$ADate,$content);
		$content = str_replace("{AEDate}",$AEDate,$content);
		$content = str_replace("{AItem}",$AItem,$content);
		
		//$cconv = new chinese_party();
		//$content = $cconv->u82tchi($content);
		//$subject = $cconv->u82tchi($subject);
		
		$EMailList=array($AREMail,$ACEMail);
		for ($tmp=0;$tmp<=count($EMailList)-1;$tmp++){
				$mail = new PHPMailer();
				$mail->IsSMTP();
				$mail->SMTPAuth = true; //設定SMTP需要驗證
				$mail->SMTPSecure = "ssl"; // Gmail的SMTP主機需要使用SSL連線
				$mail->Host = "smtp.gmail.com"; //Gamil的SMTP主機
				$mail->Port = 465; //Gamil的SMTP主機的埠號(Gmail為465)。
				$mail->CharSet = "utf-8"; //郵件編碼
				$mail->Username = "Benson@rpclab.com"; //Gamil帳號
				$mail->Password = "76197619"; //Gmail密碼
				$mail->From     = "Benson@rpclab.com";
				$mail->FromName = $subject;
				$mail->WordWrap = 50;
				$mail->IsHTML(true);                               // send as HTML
				//$mail->CharSet = "big5";
				$mail->Subject  = $subject;
				$mail->Body     =  $content;
				$mail->AddAddress($EMailList[$tmp],"");
				$mail->AddReplyTo("Benson@rpclab.com");
				if(!$mail->Send())
						{
				    //echo "There has been a mail error sending to " . $SendEMail . "<br>";
				    //echo "Mailer Error: " . $mail->ErrorInfo . "<br>";
				  	}
				else
						{
						//echo $SendEMail . " sending !!<br>";
						}
						
				$mail->ClearAddresses();
				$mail->ClearReplyTos();
				$mail->SmtpClose();	
				}
		}

mysqli_close($link);
?>
<script type="text/JavaScript">
	<!--
	alert ("修改成功！");
	location.href='AgendumList.php?page=<?php echo $page;?>&QAStatus=<?php echo $QAStatus;?>&QASID=<?php echo $QASID;?>&QARID=<?php echo $QARID;?>&QACID=<?php echo $QACID;?>&Late=<?php echo $Late;?>&KeyWord=<?php echo urlencode($KeyWord);?>';
	//-->
</script>

</body>
</html>
