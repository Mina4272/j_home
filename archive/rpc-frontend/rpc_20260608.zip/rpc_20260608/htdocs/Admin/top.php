﻿<table width="100%" border="0" cellpadding="0" cellspacing="0">
  <tr>
    <td>
    	<table width="100%" border="0" cellpadding="0" cellspacing="0">
    		<tr>
    			<td width="10"></td>
    			<td class="c2"><img src="../images/logo.jpg" border="0" /></td>
    			<td width="200" class="c3" valign="bottom"><?php echo date("Y");?> 年 <?php echo date("m");?> 月 <?php echo date("d");?> 日</td>
    		</tr>
    	</table>
    </td>
  </tr>
  <tr>
    <td height="11" valign="bottom"><img src="../images/line.jpg" width="100%" height="11" /></td>
  </tr>
</table>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
	<tr>
    <td height="30" valign="top" background="../images/table_bg.gif"></td>
	</tr>
</table>
