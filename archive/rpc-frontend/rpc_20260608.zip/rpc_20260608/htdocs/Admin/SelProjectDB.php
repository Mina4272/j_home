﻿<?php
include "CheckPermission.php";
include "../global.php";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $PageAdminTitle;?></title>
</head>

<body>
<?php
$PID = $_POST['PID'];

$SQL_Project="select PUID,PName,ModelName,CID,CName,CTel,CFax,Contact,CMobile,CEMail,CAddress from Project where Deltag='N' and PID=".$PID.";";
$result_Project=mysqli_query($link,$SQL_Project) or die ("無法執行查詢");
list($PUID,$PName,$ModelName,$CID,$CName,$CTel,$CFax,$Contact,$CMobile,$CEMail,$CAddress)=mysqli_fetch_row($result_Project);
mysqli_free_result($result_Project);
?>
<script type="text/JavaScript">
		<!--
		opener.document.form1.PID.value='<?php echo $PID;?>';
		opener.document.form1.CName.value='<?php echo $CName;?>';
		opener.document.form1.CID.value='<?php echo $CID;?>';
		opener.document.form1.CTel.value='<?php echo $CTel;?>';
		opener.document.form1.CFax.value='<?php echo $CFax;?>';
		opener.document.form1.CAddress.value='<?php echo $CAddress;?>';
		opener.document.form1.Contact.value='<?php echo $Contact;?>';
		opener.document.form1.CMobile.value='<?php echo $CMobile;?>';
		opener.document.form1.CEMail.value='<?php echo $CEMail;?>';
		opener.document.getElementById('PNamePreview').style.display = '';
		opener.document.getElementById('PNamePreview').innerHTML = '<a href="ProjectDetail.php?PID=<?php echo $PID;?>" target="_blank"><font color=blue><b><?php echo $PUID;?></b></font></a> <?php echo $PName;?> <font color=blue><b>/</b></font> <?php echo $ModelName;?>';
		opener.document.getElementById('CNamePreview').style.display = '';
		opener.document.getElementById('CNamePreview').innerHTML = '<?php echo $CName;?>';
		opener.document.getElementById('CTelPreview').style.display = '';
		opener.document.getElementById('CTelPreview').innerHTML = '<?php echo $CTel;?>';
		opener.document.getElementById('CFaxPreview').style.display = '';
		opener.document.getElementById('CFaxPreview').innerHTML = '<?php echo $CFax;?>';
		opener.document.getElementById('CAddressPreview').style.display = '';
		opener.document.getElementById('CAddressPreview').innerHTML = '<?php echo $CAddress;?>';
		self.close();
		//-->
</script>
</body>
</html>
<?php
mysqli_close($link);
?>