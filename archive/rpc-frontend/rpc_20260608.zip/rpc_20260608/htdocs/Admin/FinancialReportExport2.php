<?php
include "CheckPermission.php";
include "CheckAccountingReport.php";
include "../global.php";

$QSCAYear = $_POST['QSCAYear'];
$QSCAMonth = $_POST['QSCAMonth'];
$QECAYear = $_POST['QECAYear'];
$QECAMonth = $_POST['QECAMonth'];
$QCAType = $_POST['QCAType'];
$KeyWord = $_POST['KeyWord'];

if (trim($QCAType) != "") $QqlType = " and CAType='".$QCAType."' ";

$QSCAYear = "2011";
$QSCAMonth = "01";
$QECAYear = "2011";
$QECAMonth = "09";


if (trim($QSCAYear) != "" && trim($QSCAMonth) != "") {
		$QSCADate = $QSCAYear."-".$QSCAMonth."-01";
		$QSMonth = $QSCAYear."-".$QSCAMonth;
		}
if (trim($QECAYear) != "" && trim($QECAMonth) != "") {
		$QECADate = $QECAYear."-".$QECAMonth."-31";
		$QEMonth = $QECAYear."-".$QECAMonth;
		}

if (trim($QSCADate) != "" && trim($QECADate) != "") {
		$SqlTxt1 = " AND date_format( a.AddDate, '%Y-%m-%d' ) BETWEEN '".$QSCADate."' AND '".$QECADate."' ";
		$SqlTxt2 = " AND CADate BETWEEN '".$QSCADate."' AND '".$QEMonth."-01' ";
		}
else if (trim($QSCADate) != "" && trim($QECADate) == "") {
		$SqlTxt1 = " AND date_format( a.AddDate, '%Y-%m' ) = '".$QSMonth."' ";
		$SqlTxt2 = " AND CADate = '".$QSCADate."' ";
		}
else if (trim($QSCADate) == "" && trim($QECADate) != "") {
		$SqlTxt1 = " AND date_format( a.AddDate, '%Y-%m' ) = '".$QEMonth."' ";
		$SqlTxt2 = " AND CADate = '".$QEMonth."-01' ";
		}

//echo "QSCADate=$QSCADate<br>";
//echo "QECADate=$QECADate<br>";
//exit;
//if (trim($QCAYear) != "" && trim($QCAMonth) != "") {
//		$QMonth = $QCAYear."-".$QCAMonth;
//		$QCADate = $QCAYear."-".$QCAMonth."-01";
//		}

//echo "QCADate=$QCADate<br>";
//if (trim($QCADate) == "") {
//		$QMonth = date("Y-m",mktime());
//		$QCADate = date("Y-m",mktime())."-01";
//		}
							
$SQL_Project="select a.PID,a.PUID,a.CID,a.CName,a.CTel,a.CFax,a.Contact,a.CMobile,a.CEMail,a.CAddress,a.PStatus,a.PName,a.ModelName,a.SeriesModel,a.PE,a.Quote,a.ApplyItem,a.Canon,a.SNote,a.PlanDate,a.CloseDate,a.PNote,a.QuoteDate,a.ReturnDate,a.IFlorin,a.OFlorin,a.InvoiceDate,a.InvoiceCUID,(select CUID from Customer where Deltag='N' and CID = a.CID) as CUID,date_format( a.AddDate, '%Y-%m' ) date_month,a.PTax from Project a where a.Deltag='N' ".$SqlTxt1." order by a.PID desc;";
echo "SQL_Project=$SQL_Project<br>";
echo "SqlTxt1=$SqlTxt1<br>";
$result_Project=mysql_query($SQL_Project,$link) or die ("無法執行查詢");

		$SQL="SELECT a.CID, a.CName, b.PAMode, ifnull( sum( b.Charges ) , 0 ) Charges
									FROM Project a, ProjectAccounting b
									WHERE a.PID = b.PID
									AND a.Deltag = 'N'
									AND b.Deltag = 'N'
									AND (
									b.PAStatus = 'W'
									OR b.PAStatus = 'S'
									)
									$SqlTxt1
									and a.CID=154
									GROUP BY a.CID, a.CName, b.PAMode";
		echo "SQL=$SQL<br>";
		$result=mysql_query($SQL,$link) or die ("無法執行查詢");
		$PaccArr=array();
		while(list($CID,$CName,$PAMode,$Charges)=mysql_fetch_row($result)){
				$PaccArr[$CID]['CName']=$CName;
				$PaccArr[$CID]['Charges'."_".$PAMode]=$PaccArr[$CID]['Charges'."_".$PAMode]+$Charges;
				}
		mysql_free_result($result);
		print_r($PaccArr);

		$Charges_I_Tol=0;
		$Charges_O_Tol=0;
		foreach ($PaccArr as $key=>$val) {
				$Charges_I_Tol=$Charges_I_Tol+$PaccArr[$key]['Charges_I'];
				$Charges_O_Tol=$Charges_O_Tol+$PaccArr[$key]['Charges_O'];
				}
		//print_r($PaccArr);
		foreach ($PaccArr as $key=>$val) {
				echo $PaccArr[$key]['CName']."<br>";
				echo $PaccArr[$key]['Charges_I']."<br>";
				echo ($PaccArr[$key]['Charges_I']/$Charges_I_Tol)."<br>";
				echo $PaccArr[$key]['Charges_O']."<br>";
				echo ($PaccArr[$key]['Charges_O']/$Charges_O_Tol)."<br>";
				}

mysql_close($link);
?>