﻿<?php
include "CheckPermission.php";
//include "CheckManager.php";
include "../global.php";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $PageAdminTitle;?></title>
</head>
<body>
<?php
$ID = $_POST['ID'];
$MIDC = $_POST['MIDC'];
$MID = $_GET['MID'];

if (!is_array($ID)|| trim($MIDC) == "" || trim($MID) == "")
		{
		mysqli_close($link);
		?>
		<script type="text/JavaScript">
			<!--
			alert ("您輸入的資料不足，請重新輸入@@！");
			history.go(-1);
			//-->
		</script>
		<?php
		exit;
		}

$now_time = date("Y-m-d H:i:s",mktime());

foreach($ID as $v){
	$sql_update = "update managerjob set ReceiveMid ='".$MIDC."' where MJID ='".$v."'";
	$result_update=mysqli_query($link,$sql_update) or die ("無法執行新增");
	
}
mysqli_close($link);
?>
<script type="text/JavaScript">
	<!--
	alert ("更新成功！");
	location.href='ManagerJob.php?MID=<?php echo $MID; ?>';
	//-->
</script>

</body>
</html>
