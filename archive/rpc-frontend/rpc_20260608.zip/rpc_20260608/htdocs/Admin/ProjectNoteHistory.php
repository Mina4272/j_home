﻿<?php
include "CheckPermission.php";
include "CheckProject.php";
include "../global.php";
include "include/page_function.php";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $PageAdminTitle;?></title>
<link href="../type.css" rel="stylesheet" type="text/css" />
<style type="text/css">
<!--
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
}
-->
</style></head>

<body>
<?php
$PNID = $_GET['PNID'];
$PID = $_GET['PID'];
if (trim($PID) == "" || trim($PNID) == "")
		{
		mysqli_close($link);
		?>
		<script type="text/JavaScript">
			<!--
			alert ("查無資料，請冾網站管理人員！");
			self.close();
			//-->
		</script>
		<?php
		exit;
		}
$SQL_ProjectNote="select PContent,AddUser,AddDate,ProcUser,ProcDate from ProjectNote where Deltag='N' and PID = '".$PID."' and PNID = '".$PNID."';";
$result_ProjectNote=mysqli_query($link,$SQL_ProjectNote) or die ("無法執行查詢");
if (mysqli_num_rows($result_ProjectNote) == 0)
		{
		mysqli_free_result($result_ProjectNote);
		mysqli_close($link);
		?>
		<SCRIPT language=javascript>
		<!--
		alert ("查無資料，請冾網站管理人員！"); 
		self.close();
		//-->
		</SCRIPT>
		<?php 	
		exit;
		}
mysqli_free_result($result_ProjectNote);
?>
<table width="100%" border="0" cellpadding="0" cellspacing="0">
	<tr>
		<td>
			<?php
			$page = $_GET['page'];
			if (trim($page) == "") $page = 1;
			$page_rows=15;  //每頁筆數
			$php_Self = "ProjectNoteHistory.php";  //分頁web檔名

			$button_css = "h4";
			$limit_txt =" limit ".(($page-1) * $page_rows).",".$page_rows;
			$url_str = "&PID=".$PID."&PNID=".$PNID;
			$Sql_str="select PContent,AddUser,AddDate,ProcUser,ProcDate from ProjectNoteHistory where Deltag='N' and PID = '".$PID."' and PNID = '".$PNID."' order by PNHID desc;";
			$SQL_ProjectNote="select PContent,AddUser,AddDate,ProcUser,ProcDate from ProjectNoteHistory where Deltag='N' and PID = '".$PID."' and PNID = '".$PNID."' order by PNHID desc ".$limit_txt.";";
			$result_ProjectNote=mysqli_query($link,$SQL_ProjectNote) or die ("無法執行查詢");
			?>
    	<table width="100%" border="0" cellpadding="5" cellspacing="2" class="s2">
        <tr align="center">
          <td width="80%" align="center" background="../images/table_bg.gif" class="t21">案件記事</td>
          <td width="20%" background="../images/table_bg.gif" class="t21">最後更新</td>
        </tr>
        <?php
        $tmp = 1;
        while(list($PContent,$AddUser,$AddDate,$ProcUser,$ProcDate)=mysqli_fetch_row($result_ProjectNote)){
      	?>
      	<tr<?php if ($tmp%2 == 0) echo " bgcolor=\"#F6F6F6\"";?>>
          <td align="center" class="h3"><?php echo $PContent;?></td>
          <td align="center" class="h3">
          	<?php
          	if (trim($ProcUser) == "") echo $AddUser."<br>".$AddDate;
          	else echo $ProcUser."<br>".$ProcDate;
          	?>
          </td>
        </tr>
        <?php
      			$tmp++;
      			}
      	mysqli_free_result($result_ProjectNote);
        ?>
      </table>
      <table width="100%" border="0" cellpadding="5" cellspacing="2" class="s2">
        <tr align="center">
          <td bgcolor="#E8F0C2" class="h4"><?php Page_show($Sql_str,$page_rows,$php_Self,$link,$page,$url_str,$button_css);?></td>
        </tr>
      </table>
		</td>
	</tr>
</table>
</body>
</html>
<?php
mysqli_close($link);
?>