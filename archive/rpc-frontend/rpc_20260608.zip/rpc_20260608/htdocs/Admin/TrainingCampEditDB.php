﻿<?php
include "CheckPermission.php";
include "CheckTraining.php";
include "../global.php";
include "include/function.php";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $PageAdminTitle;?></title>
<link href="../type.css" rel="stylesheet" type="text/css" />
</head>

<body>
<?php
$page = $_POST['page'];
$TCID = $_POST['TCID'];
$TCTTitle = $_POST['TCTTitle'];

if (trim($TCID) == "")
		{
		mysqli_close($link);
		?>
		<script type="text/JavaScript">
			<!--
			alert ("查無資料，請冾網站管理人員！");
			history.go(-1);
			//-->
		</script>
		<?php
		exit;
		}

$SQL_Training="select * from TrainingCamp where Deltag='N' and TCID = '".$TCID."';";
$result_Training=mysqli_query($link,$SQL_Training) or die ("無法執行查詢");
if (mysqli_num_rows($result_Training) == 0)
		{
		mysqli_free_result($result_Training);
		mysqli_close($link);
		?>
		<SCRIPT language=javascript>
		<!--
		alert ("查無資料，請冾網站管理人員！"); 
		history.go(-1);
		//-->
		</SCRIPT>
		<?php 	
		exit;
		}
mysqli_free_result($result_Training);

$now_time = date("Y-m-d H:i:s",mktime());

$sql_update = "update TrainingCamp set TCTTitle = '".$TCTTitle."',ProcUser = '".$_SESSION["reg_MUID"]."',ProcDate = '".$now_time."',ProcIP = '".$_SERVER["REMOTE_ADDR"]."' where Deltag='N' and TCID = '".$TCID."';";
$result_update=mysqli_query($link,$sql_update) or die ("無法執行修改");

mysqli_close($link);
?>
<script type="text/JavaScript">
	<!--
	alert ("修改成功！");
	location.href='TrainingCamp.php?page=<?php echo $page;?>';
	//-->
</script>

</body>
</html>
