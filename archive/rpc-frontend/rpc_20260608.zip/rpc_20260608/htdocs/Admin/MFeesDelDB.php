﻿<?php
include "CheckPermission.php";
include "CheckProjectAccounting.php";
include "../global.php";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $PageAdminTitle;?></title>
</head>
<body>
<?php
$MFID = $_GET['MFID'];
$page = $_GET['page'];
$QMFSDate = $_GET['QMFSDate'];
$QMFEDate = $_GET['QMFEDate'];
$QMFType = $_GET['QMFType'];
$QMUID = $_GET['QMUID'];
$KeyWord = $_GET['KeyWord'];
$QMFCheck = $_GET['QMFCheck'];

if (trim($MFID) == "")
		{
		mysqli_close($link);
		?>
		<script type="text/JavaScript">
			<!--
			alert ("您輸入的資料不足，請重新輸入！");
			history.go(-1);
			//-->
		</script>
		<?php
		exit;
		}

$SQL_ManagerFees="select MUID,MFCheck from ManagerFees where Deltag='N' and MFID=".$MFID.";";
$result_ManagerFees=mysqli_query($link,$SQL_ManagerFees) or die ("無法執行查詢");
if (mysqli_num_rows($result_ManagerFees) == 0)
		{
		mysqli_free_result($result_Manager);
		mysqli_close($link);
		?>
		<SCRIPT language=javascript>
		<!--
		alert ("查無資料，請冾網站管理人員！"); 
		history.go(-1);
		//-->
		</SCRIPT>
		<?php 	
		exit;
		}
list($MUID,$MFCheck)=mysqli_fetch_row($result_ManagerFees);
mysqli_free_result($result_ManagerFees);

if (trim($_SESSION["reg_MUID"]) == "Benson" || trim($_SESSION["reg_MUID"]) == "amanda" || trim($_SESSION["reg_MUID"]) == "jacky") {}
else {
		if (trim($MFCheck) != "W")
				{
				mysqli_close($link);
				?>
				<script type="text/JavaScript">
					<!--
					alert ("此申請單已簽核，不得修改！");
					history.go(-1);
					//-->
				</script>
				<?php
				exit;
				}
		
		if (trim($MUID) != trim($_SESSION["reg_MUID"]))
				{
				mysqli_close($link);
				?>
				<script type="text/JavaScript">
					<!--
					alert ("此申請單非本人，不得修改！");
					history.go(-1);
					//-->
				</script>
				<?php
				exit;
				}
		}

$now_time = date("Y-m-d H:i:s",mktime());
$sql_insert = "INSERT INTO ManagerFeesHistory(MFID,MUID,MFType,MFDate,MFCause,MFComment,Quantity,MFNote,MFSend,MFCheck,MFCNote,MFCheckID,MFCheckDate,MFCheckIP,AddUser,AddDate,AddIP,Deltag,ProcUser,ProcDate,ProcIP,UpdateUser,UpdateDate,UpdateIP) SELECT MFID,MUID,MFType,MFDate,MFCause,MFComment,Quantity,MFNote,MFSend,MFCheck,MFCNote,MFCheckID,MFCheckDate,MFCheckIP,AddUser,AddDate,AddIP,Deltag,ProcUser,ProcDate,ProcIP,'".$_SESSION["reg_MUID"]."','".$now_time."','".$_SERVER["REMOTE_ADDR"]."' from ManagerFees where Deltag='N' and MFID=".$MFID.";";
$result_insert=mysqli_query($link,$sql_insert) or die ("無法執行新增");
$sql_update = "update ManagerFees set Deltag = 'Y',ProcUser = '".$_SESSION["reg_MUID"]."',ProcDate = '".$now_time."',ProcIP = '".$_SERVER["REMOTE_ADDR"]."' where Deltag='N' and MFID=".$MFID.";";
$result_update=mysqli_query($link,$sql_update) or die ("無法執行修改");

mysqli_close($link);
?>
<script type="text/JavaScript">
	<!--
	alert ("刪除成功！");
	location.href='MFeesList.php?page=<?php echo $page;?>&QMFSDate=<?php echo $QMFSDate;?>&QMFEDate=<?php echo $QMFEDate;?>&QMFType=<?php echo $QMFType;?>&QMUID=<?php echo $QMUID;?>&QMFCheck=<?php echo $QMFCheck;?>&KeyWord=<?php echo urlencode($KeyWord);?>';
	//-->
</script>

</body>
</html>
