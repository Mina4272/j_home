﻿<?php
include "CheckPermission.php";
include "CheckProject.php";
include "../global.php";
include "include/page_function.php";
include "include/utf8.php";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $PageAdminTitle;?></title>
<link href="../type.css" rel="stylesheet" type="text/css" />
<style type="text/css">
<!--
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
}
-->
</style></head>

<body>
<?php include "top.php";?>
<?php
$PID = $_GET['PID'];
$PFCID = $_GET['PFCID'];
$spage = $_GET['spage'];
$KeyWord = $_GET['KeyWord'];
$QPStatus = $_GET['QPStatus'];
$QPE = $_GET['QPE'];
if (trim($PID) == "" || trim($PFCID) == "")
		{
		mysqli_close($link);
		?>
		<script type="text/JavaScript">
			<!--
			alert ("查無資料，請冾網站管理人員！");
			history.go(-1);
			//-->
		</script>
		<?php
		exit;
		}
$SQL_Project="select PUID,PName,CName,ModelName from Project where Deltag='N' and PID = '".$PID."';";
$result_Project=mysqli_query($link,$SQL_Project) or die ("無法執行查詢");
if (mysqli_num_rows($result_Project) == 0)
		{
		mysqli_free_result($result_Project);
		mysqli_close($link);
		?>
		<SCRIPT language=javascript>
		<!--
		alert ("查無資料，請冾網站管理人員！"); 
		history.go(-1);
		//-->
		</SCRIPT>
		<?php 	
		exit;
		}
list($PUID,$PName,$CName,$ModelName)=mysqli_fetch_row($result_Project);
mysqli_free_result($result_Project);
if (utf8_strlen(strip_tags($CName)) > 4) $CName = utf8_substr(strip_tags($CName),0,4);
else $CName = strip_tags($CName);

$SQL_ProjectFileClass="select PFCName from ProjectFileClass where Deltag='N' and PFCID = '".$PFCID."';";
$result_ProjectFileClass=mysqli_query($link,$SQL_ProjectFileClass) or die ("無法執行查詢");
if (mysqli_num_rows($result_ProjectFileClass) == 0)
		{
		mysqli_free_result($result_ProjectFileClass);
		mysqli_close($link);
		?>
		<SCRIPT language=javascript>
		<!--
		alert ("查無資料，請冾網站管理人員！"); 
		history.go(-1);
		//-->
		</SCRIPT>
		<?php 	
		exit;
		}
list($PFCName)=mysqli_fetch_row($result_ProjectFileClass);
mysqli_free_result($result_ProjectFileClass);
?>
<table width="100%" border="0" cellspacing="0" cellpadding="5">
	<tr>
    <td width="160" height="600" align="left" valign="top">
			<?php include "menu.php";?>
    </td>
		<?php
		$page = empty($_GET['page'])?"":$_GET['page'];
		if (trim($page) == "") $page = 1;
		$page_rows=15;  //每頁筆數
		$php_Self = "ProjectFileList.php";  //分頁web檔名

		$button_css = "h4";
		$limit_txt =" limit ".(($page-1) * $page_rows).",".$page_rows;
		$url_str = "&PID=".$PID."&PFCID=".$PFCID."&spage=".$spage."&QPStatus=".$QPStatus."&QPE=".$QPE."&KeyWord=".urlencode($KeyWord);
		?>
    <td valign="top">
    	<table width="100%" border="0" cellpadding="0" cellspacing="0">
    		<tr>
    			<td>
			    	<table width="750" border="0" cellpadding="0" cellspacing="0">
			    		<tr height="30">
			    			<td class="c2"><a href="ProjectList.php?page=<?php echo $spage;?>&QPStatus=<?php echo $QPStatus;?>&QPE=<?php echo $QPE;?>&KeyWord=<?php echo urlencode($KeyWord);?>">案件資料列表</a> &gt; <a href="ProjectFileClassList.php?PID=<?php echo $PID;?>&PFCID=<?php echo $PFCID;?>&page=<?php echo $spage;?>&QPStatus=<?php echo $QPStatus;?>&QPE=<?php echo $QPE;?>&KeyWord=<?php echo urlencode($KeyWord);?>"><?php echo $CName;?> - <?php echo $ModelName;?> 類別列表</a> &gt; <?php echo $PFCName;?></td>
			    			<td align="right" class="h3"><input type="button" name="add" value="新 增" class="input_bot" onclick="javascript:location.href='ProjectFileAdd.php?PID=<?php echo $PID;?>&PFCID=<?php echo $PFCID;?><?php echo $url_str;?>';"></td>
			    			<td width="20"></td>
			    		</tr>
			    	</table>
						<?php
						$Sql_str="select PFID,PFName,PFileName,PFIntro,AddUser,AddDate,ProcUser,ProcDate from ProjectFile where Deltag='N' and PID = '".$PID."' and PFCID = '".$PFCID."' order by PFID desc;";
						$SQL_ProjectFile="select PFID,PFName,PFileName,PFIntro,AddUser,AddDate,ProcUser,ProcDate from ProjectFile where Deltag='N' and PID = '".$PID."' and PFCID = '".$PFCID."' order by PFID desc ".$limit_txt.";";
						$result_ProjectFile=mysqli_query($link,$SQL_ProjectFile) or die ("無法執行查詢");
						?>
			    	<table width="750" border="0" cellpadding="5" cellspacing="2" class="s2">
			        <tr align="center">
			          <td width="150" align="center" background="../images/table_bg.gif" class="t21">檔案名稱</td>
			          <td background="../images/table_bg.gif" class="t21">說 明</td>
			          <td width="150" background="../images/table_bg.gif" class="t21">最後更新</td>
			          <td width="50" background="../images/table_bg.gif" class="t21">下 載</td>
			          <td width="50" background="../images/table_bg.gif" class="t21">修 改</td>
			          <td width="50" background="../images/table_bg.gif" class="t21">刪 除</td>
			        </tr>
		          <?php
		          $tmp = 1;
		          while(list($PFID,$PFName,$PFileName,$PFIntro,$AddUser,$AddDate,$ProcUser,$ProcDate)=mysqli_fetch_row($result_ProjectFile)){
		        	?>
		        	<tr<?php if ($tmp%2 == 0) echo " bgcolor=\"#F6F6F6\"";?>>
			          <td align="center" class="h3"><?php echo $PFName;?></td>
			          <td align="center" class="h3"><?php echo $PFIntro;?></td>
			          <td align="center" class="h3">
			          	<?php
			          	if (trim($ProcUser) == "") echo $AddUser."<br>".$AddDate;
			          	else echo $ProcUser."<br>".$ProcDate;
			          	?>
			          </td>
			          <td align="center"><input type="button" name="edit" value="下 載" class="input_bot" onclick="javascript:location.href='getfile.php?FolderName=Admin\\PFile&FileName=<?php echo $PFileName;?>&FileCName=<?php echo urlencode($PFName);?>';"></td>
			          <td align="center"><input type="button" name="edit" value="修 改" class="input_bot" onclick="javascript:location.href='ProjectFileEdit.php?PFID=<?php echo $PFID;?>&page=<?php echo $page;?><?php echo $url_str;?>';"></td>
			          <td align="center"><input type="button" name="edit" value="刪 除" class="input_bot" onclick="javascript:if (confirm('您是否確定要刪除？')) location.href='ProjectFileDelDB.php?PFID=<?php echo $PFID;?>&page=<?php echo $page;?><?php echo $url_str;?>';"></td>
			        </tr>
			        <?php
            			$tmp++;
			      			}
            	mysqli_free_result($result_ProjectFile);
			        ?>
			      </table>
			      <table width="750" border="0" cellpadding="5" cellspacing="2" class="s2">
			        <tr align="center">
			          <td bgcolor="#E8F0C2" class="h4"><?php Page_show($Sql_str,$page_rows,$php_Self,$link,$page,$url_str,$button_css);?></td>
			        </tr>
			      </table>
    			</td>
    		</tr>
    	</table>
    </td>
	</tr>
</table>
<?php include "down.php";?>
</body>
</html>
<?php
mysqli_close($link);
?>