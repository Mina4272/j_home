﻿<?php
include "CheckPermission.php";
include "CheckMFees.php";
include "../global.php";
require_once 'PHPExcel.php';

$QMFSDate = "";
$QMFEDate = "";
$SqlTxt = "";

$QMFSYear = $_POST['QMFSYear'];
$QMFSMonth = $_POST['QMFSMonth'];
$QMFSDay = $_POST['QMFSDay'];
if (trim($QMFSYear) != "" || trim($QMFSMonth) != "" || trim($QMFSDay) != "") if (checkdate($QMFSMonth,$QMFSDay ,$QMFSYear)) $QMFSDate = $QMFSYear."-".$QMFSMonth."-".$QMFSDay;
$QMFEYear = $_POST['QMFEYear'];
$QMFEMonth = $_POST['QMFEMonth'];
$QMFEDay = $_POST['QMFEDay'];
if (trim($QMFEYear) != "" || trim($QMFEMonth) != "" || trim($QMFEDay) != "") if (checkdate($QMFEMonth,$QMFEDay ,$QMFEYear)) $QMFEDate = $QMFEYear."-".$QMFEMonth."-".$QMFEDay;

$QMFType = $_POST['QMFType'];
$QMUID = $_POST['QMUID'];
$KeyWord = $_POST['KeyWord'];

if (trim($QMFSDate) != "" && trim($QMFEDate) != "") $SqlTxt = $SqlTxt." and (MFDate >= '".$QMFSDate." 00:00:00') and (MFDate <= '".$QMFEDate." 23:59:59') ";
else if (trim($QMFSDate) != "" && trim($QMFEDate) == "") $SqlTxt = $SqlTxt." and (MFDate >= '".$QMFSDate." 00:00:00') ";
else if (trim($QMFSDate) == "" && trim($QMFEDate) != "") $SqlTxt = $SqlTxt." and (MFDate <= '".$QMFEDate." 23:59:59') ";
if (trim($QMFType) != "") $SqlTxt = $SqlTxt." and MFType='".$QMFType."' ";
if (trim($QMUID) != "") $SqlTxt = $SqlTxt." and MUID='".$QMUID."' ";
if (trim($KeyWord) != "") $SqlTxt = $SqlTxt." and (MFCause like '%".$MFCause."%' or MFComment like '%".$MFComment."%' or MFNote like '%".$KeyWord."%')";

$SQL_ManagerFees="select MFID,MUID,MFType,MFDate,MFCause,MFComment,Quantity,MFNote,MFSend,MFCheck,MFCNote,MFCheckID,(select MName from Manager where Deltag='N' and MUID=ManagerFees.MFCheckID) MFCMName,(select MEName from Manager where Deltag='N' and MUID=ManagerFees.MFCheckID) MFCMEName,MFCheckDate,MFCheckIP,AddDate,(select MName from Manager where Deltag='N' and MUID=ManagerFees.MUID) MName,(select MEName from Manager where Deltag='N' and MUID=ManagerFees.MUID) MEName from ManagerFees where Deltag='N' ".$SqlTxt." order by MUID,MFType,MFID desc;";
$result_ManagerFees=mysqli_query($link,$SQL_ManagerFees) or die ("無法執行查詢");

$objPHPExcel = new PHPExcel();
$objPHPExcel->setActiveSheetIndex(0);

$Ecount=1;

$objPHPExcel->getActiveSheet()->setCellValue('A'.$Ecount,"申請時間");
$objPHPExcel->getActiveSheet()->setCellValue('B'.$Ecount,"申請項目");
$objPHPExcel->getActiveSheet()->setCellValue('C'.$Ecount,"申請人");
$objPHPExcel->getActiveSheet()->setCellValue('D'.$Ecount,"申請事由");
$objPHPExcel->getActiveSheet()->setCellValue('E'.$Ecount,"申請說明");
$objPHPExcel->getActiveSheet()->setCellValue('F'.$Ecount,"申請數量");
$objPHPExcel->getActiveSheet()->setCellValue('G'.$Ecount,"是否送審");
$objPHPExcel->getActiveSheet()->setCellValue('H'.$Ecount,"是否簽核");
$objPHPExcel->getActiveSheet()->setCellValue('I'.$Ecount,"簽核備註");
$objPHPExcel->getActiveSheet()->setCellValue('J'.$Ecount,"簽核人員");
$objPHPExcel->getActiveSheet()->setCellValue('K'.$Ecount,"簽核時間");
$objPHPExcel->getActiveSheet()->setCellValue('L'.$Ecount,"備註");

$objPHPExcel->getActiveSheet()->getStyle("A".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("B".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("C".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("D".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("E".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("F".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("G".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("H".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("I".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("J".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("K".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("L".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);

$Ecount++;

while(list($MFID,$MUID,$MFType,$MFDate,$MFCause,$MFComment,$Quantity,$MFNote,$MFSend,$MFCheck,$MFCNote,$MFCheckID,$MFCMName,$MFCMEName,$MFCheckDate,$MFCheckIP,$AddDate,$MName,$MEName)=mysqli_fetch_row($result_ManagerFees)){
  	if (trim($MFType) == "A") $MFType="加班費";
  	else if (trim($MFType) == "B") $MFType="交通費-公里";
  	else if (trim($MFType) == "C") $MFType="交通費-實報實銷";
  	if (trim($MFSend) == "Y") $MFSend="是";
  	else if (trim($MFSend) == "N") $MFSend="否";
  	if (trim($MFCheck) == "Y") $MFCheck="是";
  	else if (trim($MFCheck) == "N") $MFCheck="否";
  	else if (trim($MFCheck) == "W") $MFCheck="等待簽核";
	
	$objPHPExcel->getActiveSheet()->setCellValue('A'.$Ecount,$MFDate);
	$objPHPExcel->getActiveSheet()->setCellValue('B'.$Ecount,$MFType);
	$objPHPExcel->getActiveSheet()->setCellValue('C'.$Ecount,$MEName.$MName);
	$objPHPExcel->getActiveSheet()->setCellValue('D'.$Ecount,$MFCause);
	$objPHPExcel->getActiveSheet()->setCellValue('E'.$Ecount,$MFComment);
	$objPHPExcel->getActiveSheet()->setCellValue('F'.$Ecount,$Quantity);
	$objPHPExcel->getActiveSheet()->setCellValue('G'.$Ecount,$MFSend);
	$objPHPExcel->getActiveSheet()->setCellValue('H'.$Ecount,$MFCheck);
	$objPHPExcel->getActiveSheet()->setCellValue('I'.$Ecount,$MFCNote);
	$objPHPExcel->getActiveSheet()->setCellValue('J'.$Ecount,$MFCMEName.$MFCMName);
	$objPHPExcel->getActiveSheet()->setCellValue('K'.$Ecount,$MFCheckDate);
	$objPHPExcel->getActiveSheet()->setCellValue('L'.$Ecount,$MFNote);
	
	$objPHPExcel->getActiveSheet()->getStyle('A'.$Ecount)->getFont()->setSize(12);
	$objPHPExcel->getActiveSheet()->getStyle('B'.$Ecount)->getFont()->setSize(12);
	$objPHPExcel->getActiveSheet()->getStyle('C'.$Ecount)->getFont()->setSize(12);
	$objPHPExcel->getActiveSheet()->getStyle('D'.$Ecount)->getFont()->setSize(12);
	$objPHPExcel->getActiveSheet()->getStyle('E'.$Ecount)->getFont()->setSize(12);
	$objPHPExcel->getActiveSheet()->getStyle('F'.$Ecount)->getFont()->setSize(12);
	$objPHPExcel->getActiveSheet()->getStyle('G'.$Ecount)->getFont()->setSize(12);
	$objPHPExcel->getActiveSheet()->getStyle('H'.$Ecount)->getFont()->setSize(12);
	$objPHPExcel->getActiveSheet()->getStyle('I'.$Ecount)->getFont()->setSize(12);
	$objPHPExcel->getActiveSheet()->getStyle('J'.$Ecount)->getFont()->setSize(12);
	$objPHPExcel->getActiveSheet()->getStyle('K'.$Ecount)->getFont()->setSize(12);
	$objPHPExcel->getActiveSheet()->getStyle('L'.$Ecount)->getFont()->setSize(12);
	
	$Ecount++;
}
mysqli_free_result($result_ManagerFees);
mysqli_close($link);

$objPHPExcel->getActiveSheet()->setTitle('MFeesExport');

ob_end_clean();

header('Content-Type: application/vnd.ms-excel');
header('Content-Disposition: attachment;filename="MFeesExport.xls"');
header('Cache-Control: max-age=0');
$objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel5');
$objWriter->save('php://output');
exit;

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $PageAdminTitle;?></title>
<link href="style.css" rel="stylesheet" type="text/css" />
<body>
<table winth="1000" border="0">
	<tr>
		<td colspan="2"><font color=blue>若您無法正常觀看此報表！請下載此 <a href="owc11.zip" target="_File"><font color=red><b>元件</b></font></a> <font color=blue>安裝至您的電腦。</font></td>
	</tr>
</table>
<object id=ProjectAccounting classid=CLSID:0002E559-0000-0000-C000-000000000046 style="width:100%;height:90%"></object>
<script language=vbscript>
	Sub Window_OnLoad()
	Set chConstants = ProjectAccounting.Constants
	ProjectAccounting.ActiveSheet.Cells.Clear
	ProjectAccounting.Worksheets(1).Select
	ProjectAccounting.ActiveSheet.Name ="ProjectAccounting"

	ProjectAccounting.ActiveSheet.Cells(1,1).Value ="申請時間"
	ProjectAccounting.ActiveSheet.Cells(1,2).Value ="申請項目"
	ProjectAccounting.ActiveSheet.Cells(1,3).Value ="申請人"
	ProjectAccounting.ActiveSheet.Cells(1,4).Value ="申請事由"
	ProjectAccounting.ActiveSheet.Cells(1,5).Value ="申請說明"
	ProjectAccounting.ActiveSheet.Cells(1,6).Value ="申請數量"
	ProjectAccounting.ActiveSheet.Cells(1,7).Value ="是否送審"
	ProjectAccounting.ActiveSheet.Cells(1,8).Value ="是否簽核"
	ProjectAccounting.ActiveSheet.Cells(1,9).Value ="簽核備註"
	ProjectAccounting.ActiveSheet.Cells(1,10).Value ="簽核人員"
	ProjectAccounting.ActiveSheet.Cells(1,11).Value ="簽核時間"
	ProjectAccounting.ActiveSheet.Cells(1,12).Value ="備註"
<?php  
$ECount=2;
while(list($MFID,$MUID,$MFType,$MFDate,$MFCause,$MFComment,$Quantity,$MFNote,$MFSend,$MFCheck,$MFCNote,$MFCheckID,$MFCMName,$MFCMEName,$MFCheckDate,$MFCheckIP,$AddDate,$MName,$MEName)=mysqli_fetch_row($result_ManagerFees)){
  	if (trim($MFType) == "A") $MFType="加班費";
  	else if (trim($MFType) == "B") $MFType="交通費-公里";
  	else if (trim($MFType) == "C") $MFType="交通費-實報實銷";
  	if (trim($MFSend) == "Y") $MFSend="是";
  	else if (trim($MFSend) == "N") $MFSend="否";
  	if (trim($MFCheck) == "Y") $MFCheck="是";
  	else if (trim($MFCheck) == "N") $MFCheck="否";
  	else if (trim($MFCheck) == "W") $MFCheck="等待簽核";
		?>
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,1).Value ="'<?php echo $MFDate;?>"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,2).Value ="<?php echo $MFType;?>"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,3).Value ="<?php echo $MEName.$MName;?>"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,4).Value ="<?php echo $MFCause;?>"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,5).Value ="<?php echo $MFComment;?>"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,6).Value ="<?php echo $Quantity;?>"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,7).Value ="<?php echo $MFSend;?>"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,8).Value ="<?php echo $MFCheck;?>"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,9).Value ="<?php echo $MFCNote;?>"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,10).Value ="<?php echo $MFCMEName.$MFCMName;?>"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,11).Value ="'<?php echo $MFCheckDate;?>"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,12).Value ="<?php echo $MFNote;?>"
		<?php
		$ECount++;
		}
mysqli_free_result($result_ManagerFees);
mysqli_close($link);
?>

		ProjectAccounting.ActiveSheet.Range("A1:R<?php echo $ECount;?>").Font.Color="blue"
		ProjectAccounting.ActiveSheet.Range("A1:R<?php echo $ECount;?>").Font.Name="Courier New"
		ProjectAccounting.ActiveSheet.Range("A1:R<?php echo $ECount;?>").Font.Size="11"
		ProjectAccounting.ActiveSheet.Range("A1:R<?php echo $ECount;?>").Columns.AutoFit
		ProjectAccounting.ActiveSheet.Range("A1:R<?php echo $ECount;?>").NumberFormat ="General"

		ProjectAccounting.ActiveSheet.Range("A1:R1").Font.Bold=true
		ProjectAccounting.ActiveSheet.Range("A1:R1").Font.Color="#000000"
		ProjectAccounting.ActiveSheet.Range("A1:R1").Font.Bold=true
		ProjectAccounting.ActiveSheet.Range("A1:R1").Font.Bold=true
		ProjectAccounting.ActiveSheet.Range("A1:R1").Font.Bold=true

	End Sub
	</script>
</body>
</html>
