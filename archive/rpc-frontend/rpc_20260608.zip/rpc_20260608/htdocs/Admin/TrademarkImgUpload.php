﻿<?php
include "CheckPermission.php";
include "../global.php";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $PageAdminTitle;?></title>
<link href="../type.css" rel="stylesheet" type="text/css" />
<Script type="text/javascript" language="javascript" src="../script/CheckForm.js"></Script>
<script type="text/JavaScript">
<!--
function jsCheck() 
		{ 
    if (jsTrim(document.form1.TrademarkImg.value) == "")
    		{
				alert("請選擇您要上傳圖片！");
				document.form1.TrademarkImg.focus();
				return false;
    		}
    if (FileNameChk(document.form1.TrademarkImg.value,Array('jpg','jpeg','gif')) == false)
				{
				alert("上傳圖片格式必需為圖檔！");
				document.form1.TrademarkImg.focus();
				return false;
				}
		location.href='TrademarkImgUpload.php#uploading';
		}
//-->
</script>
<style type="text/css">
<!--
body {
	background-color: #E8F0C2;
}
-->
</style></head>

<body>
<table width="450" border="0" align="center" cellpadding="5" cellspacing="0" bgcolor="#FFFFCC" class="s1">
  <tr>
    <td align="left" bgcolor="#FFDA68"><p align="left"><span class="h3">檔案上傳</span></p>
    </td>
  </tr>
  <form name="form1" action="TrademarkImgUploadDB.php" method="post" enctype="multipart/form-data" onSubmit="return jsCheck();">
  <tr>
    <td align="left">
      <table width="350" border="0" align="center" cellpadding="5" cellspacing="0">
        <tr>
          <td class="h3">請選擇要上傳的圖片：</td>
        </tr>
        <tr>
          <td class="c3"><input name="TrademarkImg" type="file" class="h3" size="50" /></td>
        </tr>
        <tr>
          <td class="h4">*上傳圖片限 gif 或 jpg 格式</td>
        </tr>
        <tr>
          <td height="31" class="h3"><div align="center">
            <input name="submit" type="submit" class="h3" value="上傳" />
          </div></td>
        </tr>
      </table>
    </td>
  </tr>
  </form>
</table>
<br><br><a name="uploading"></a>
<table width="450" border="0" align="center" cellpadding="5" cellspacing="0" bgcolor="#FFFFFF" class="s1">
  <tr>
    <td align="left" bgcolor="#FFDA68"><p align="left"><span class="h3">檔案上傳</span></p>
    </td>
  </tr>
  <tr height="140">
    <td align="center">
      <table width="350" border="0" align="center" cellpadding="5" cellspacing="0">
        <tr>
          <td class="h3"><img src="../images/loading.gif" border="0" align="absmiddle">　檔案上傳中，請稍後.....</td>
        </tr>
      </table>
    </td>
  </tr>
</table>
</body>
</html>
<?php
mysqli_close($link);
?>