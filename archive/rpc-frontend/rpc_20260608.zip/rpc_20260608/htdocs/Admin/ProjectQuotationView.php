﻿<?php
include "CheckPermission.php";
include "CheckProjectAccounting.php";
include "../global.php";
$PQRUID = $_GET['PQRUID'];
if (trim($PQRUID) == "") exit;
$SQL_ProjectQuotationRecord="select PQRUContent from ProjectQuotationRecord where PQRUID='".$PQRUID."';";
$result_ProjectQuotationRecord=mysqli_query($link,$SQL_ProjectQuotationRecord) or die ("無法執行查詢");
list($PQRUContent)=mysqli_fetch_row($result_ProjectQuotationRecord);
mysqli_free_result($result_ProjectQuotationRecord);
mysqli_close($link);
echo $PQRUContent;
?>