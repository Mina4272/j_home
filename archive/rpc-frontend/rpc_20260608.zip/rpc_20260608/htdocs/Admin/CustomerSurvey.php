﻿<?php	
include "CheckPermission.php";
include "CheckAccountingReport.php";
include "../global.php";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $PageAdminTitle;?></title>
<link href="../type.css" rel="stylesheet" type="text/css" />
<style type="text/css">
<!--
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
}
-->
</style>
<link href="../script/DatePicker.css" rel="stylesheet" type="text/css" />
<Script LANGUAGE="Javascript" SRC="../script/DatePicker.js"></Script>
<Script type="text/javascript" language="javascript" src="../script/CheckForm.js"></Script>
<script type="text/JavaScript">
<!--
function jsCheck() 
		{
		if (jsTrim(document.form1.CName.value) == "")
				{
				alert ('請選擇分析客戶！');
				document.form1.SelCID.focus();
				return false;
				}
		if (jsTrim(document.form1.QSYear.value) != "" || jsTrim(document.form1.QSMonth.value) != "") if (ChkDate('QSYear',document.form1.QSYear.value,document.form1.QSMonth.value,document.form1.QSDay.value,'查詢起始月份') == false) return false;
		if (jsTrim(document.form1.QEYear.value) != "" || jsTrim(document.form1.QEMonth.value) != "") if (ChkDate('QEYear',document.form1.QEYear.value,document.form1.QEMonth.value,document.form1.QEDay.value,'查詢結束月份') == false) return false;
		if (jsTrim(document.form1.QSYear.value) != "" && jsTrim(document.form1.QSMonth.value) != "" && jsTrim(document.form1.QSDay.value) != "" && jsTrim(document.form1.QEYear.value) != "" && jsTrim(document.form1.QEMonth.value) != "" && jsTrim(document.form1.QEDay.value) != "") if (CompareDate('QSYear',document.form1.QSYear.value,document.form1.QSMonth.value,document.form1.QSDay.value,document.form1.QEYear.value,document.form1.QEMonth.value,document.form1.QEDay.value,'查詢啟始月份','查詢結束月份') == false) return false;
		}
//-->
</script>
</head>
<body>
<?php include "top.php";?>
<table width="100%" border="0" cellspacing="0" cellpadding="5">
	<tr>
    <td width="160" height="600" align="left" valign="top">
			<?php include "menu.php";?>
    </td>
    <td valign="top">
    	<table width="100%" border="0" cellpadding="0" cellspacing="0">
    		<tr>
    			<td>
			    	<table width="750" border="0" cellpadding="0" cellspacing="0">
			    		<tr height="30">
			    			<td class="c2"><b>顧客消費記錄分析</b></td>
			    		</tr>
			    	</table>
			    	<table width="750" border="0" cellpadding="0" cellspacing="0">
			        <form name="form1" method="post" action="CustomerSurveyExport.php" onSubmit="return jsCheck();" target="_CustomerSurvey">
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td width="150" align="right" class="c3">客戶名稱：</td>
			          <td class="h3">
			          	<table width="100%" border="0" cellpadding="0" cellspacing="0">
			          		<tr>
			          			<td><div id="CNamePreview" style="display:none"></div></td>
			          			<td>
						          	<input type="hidden" name="CID">
						          	<input type="hidden" name="CName">
						          	<input type="button" id="SelCID" name="SelCID" class="input_bot" value="請選擇分析客戶" onclick="javascript:window.open ('SelCustomer.php','SelCustomer','height=300,width=550,top=200,left=200,scrollbars=yes,status=yes');">
			          			</td>
			          		</tr>
			          	</table>
			          	
			          </td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">客戶電話：</td>
			          <td class="h3">
			          	<table width="100%" border="0" cellpadding="0" cellspacing="0">
			          		<tr>
			          			<td width="150">
			          				<div id="CTelPreview" style="display:none"></div>
						          	<input type="hidden" name="CTel">
			          			</td>
			          			<td width="60" align="right" class="c3">傳真：</td>
			          			<td>
			          				<div id="CFaxPreview" style="display:none"></div>
			          				<input type="hidden" name="CFax">
			          				<input type="hidden" name="Contact" size="20">
			          				<input type="hidden" name="CMobile" size="20">
			          				<input type="hidden" name="CEMail" size="60">
			          			</td>
			          		</tr>
			          	</table>
			          </td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">客戶地址：</td>
			          <td class="h3">
			          	<div id="CAddressPreview" style="display:none"></div>
			          	<input type="hidden" name="CAddress">
			          </td>
			        </tr>
			        <tr height="50" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td width="150" align="right" class="c3">請選擇所屬月份：</td>
			          <td colspan="3" class="h3" align="left">
			    				<select name="QSYear">
			    				<option value=""></option>
			    				<option value="2008"<?php if (trim(empty($_POST['QSYear'])?"":$_POST['QSYear']) == "2008") echo " selected";?>>2008</option>
			    				<option value="2009"<?php if (trim(empty($_POST['QSYear'])?"":$_POST['QSYear']) == "2009") echo " selected";?>>2009</option>
			    				<option value="2010"<?php if (trim(empty($_POST['QSYear'])?"":$_POST['QSYear']) == "2010") echo " selected";?>>2010</option>
			    				<option value="2011"<?php if (trim(empty($_POST['QSYear'])?"":$_POST['QSYear']) == "2011") echo " selected";?>>2011</option>
			    				<option value="2012"<?php if (trim(empty($_POST['QSYear'])?"":$_POST['QSYear']) == "2012") echo " selected";?>>2012</option>
			    				<option value="2013"<?php if (trim(empty($_POST['QSYear'])?"":$_POST['QSYear']) == "2013") echo " selected";?>>2013</option>
			    				<option value="2014"<?php if (trim(empty($_POST['QSYear'])?"":$_POST['QSYear']) == "2014") echo " selected";?>>2014</option>
			    				<option value="2015"<?php if (trim(empty($_POST['QSYear'])?"":$_POST['QSYear']) == "2015") echo " selected";?>>2015</option>
			    				<option value="2016"<?php if (trim(empty($_POST['QSYear'])?"":$_POST['QSYear']) == "2016") echo " selected";?>>2016</option>
			    				<option value="2017"<?php if (trim(empty($_POST['QSYear'])?"":$_POST['QSYear']) == "2017") echo " selected";?>>2017</option>
			    				<option value="2018"<?php if (trim(empty($_POST['QSYear'])?"":$_POST['QSYear']) == "2018") echo " selected";?>>2018</option>
								<option value="2019"<?php if (trim(empty($_POST['QSYear'])?"":$_POST['QSYear']) == "2019") echo " selected";?>>2019</option>
								<option value="2020"<?php if (trim(empty($_POST['QSYear'])?"":$_POST['QSYear']) == "2020") echo " selected";?>>2020</option>
								<option value="2021"<?php if (trim(empty($_POST['QSYear'])?"":$_POST['QSYear']) == "2021") echo " selected";?>>2021</option>
								<option value="2022"<?php if (trim(empty($_POST['QSYear'])?"":$_POST['QSYear']) == "2022") echo " selected";?>>2022</option>
								<option value="2023"<?php if (trim(empty($_POST['QSYear'])?"":$_POST['QSYear']) == "2023") echo " selected";?>>2023</option>
								<option value="2024"<?php if (trim(empty($_POST['QSYear'])?"":$_POST['QSYear']) == "2024") echo " selected";?>>2024</option>
								<option value="2025"<?php if (trim(empty($_POST['QSYear'])?"":$_POST['QSYear']) == "2025") echo " selected";?>>2025</option>
			    				</select> <font color=blue><b>年</b></font> 
			    				<select name="QSMonth">
			    					<option value=""></option>
			    					<option value="01"<?php if (trim(empty($_POST['QSMonth'])?"":$_POST['QSMonth']) == "01") echo " selected";?>>01</option>
			    					<option value="02"<?php if (trim(empty($_POST['QSMonth'])?"":$_POST['QSMonth']) == "02") echo " selected";?>>02</option>
			    					<option value="03"<?php if (trim(empty($_POST['QSMonth'])?"":$_POST['QSMonth']) == "03") echo " selected";?>>03</option>
			    					<option value="04"<?php if (trim(empty($_POST['QSMonth'])?"":$_POST['QSMonth']) == "04") echo " selected";?>>04</option>
			    					<option value="05"<?php if (trim(empty($_POST['QSMonth'])?"":$_POST['QSMonth']) == "05") echo " selected";?>>05</option>
			    					<option value="06"<?php if (trim(empty($_POST['QSMonth'])?"":$_POST['QSMonth']) == "06") echo " selected";?>>06</option>
			    					<option value="07"<?php if (trim(empty($_POST['QSMonth'])?"":$_POST['QSMonth']) == "07") echo " selected";?>>07</option>
			    					<option value="08"<?php if (trim(empty($_POST['QSMonth'])?"":$_POST['QSMonth']) == "08") echo " selected";?>>08</option>
			    					<option value="09"<?php if (trim(empty($_POST['QSMonth'])?"":$_POST['QSMonth']) == "09") echo " selected";?>>09</option>
			    					<option value="10"<?php if (trim(empty($_POST['QSMonth'])?"":$_POST['QSMonth']) == "10") echo " selected";?>>10</option>
			    					<option value="11"<?php if (trim(empty($_POST['QSMonth'])?"":$_POST['QSMonth']) == "11") echo " selected";?>>11</option>
			    					<option value="12"<?php if (trim(empty($_POST['QSMonth'])?"":$_POST['QSMonth']) == "12") echo " selected";?>>12</option>
			    				</select> <font color=blue><b>月</b></font><input type="hidden" name="QSDay" value="1"> ~ 
			    				<select name="QEYear">
			    					<option value=""></option>
			    					<option value="2008"<?php if (trim(empty($_POST['QEYear'])?"":$_POST['QEYear']) == "2008") echo " selected";?>>2008</option>
			    					<option value="2009"<?php if (trim(empty($_POST['QEYear'])?"":$_POST['QEYear']) == "2009") echo " selected";?>>2009</option>
			    					<option value="2010"<?php if (trim(empty($_POST['QEYear'])?"":$_POST['QEYear']) == "2010") echo " selected";?>>2010</option>
			    					<option value="2011"<?php if (trim(empty($_POST['QEYear'])?"":$_POST['QEYear']) == "2011") echo " selected";?>>2011</option>
			    					<option value="2012"<?php if (trim(empty($_POST['QEYear'])?"":$_POST['QEYear']) == "2012") echo " selected";?>>2012</option>
			    					<option value="2013"<?php if (trim(empty($_POST['QEYear'])?"":$_POST['QEYear']) == "2013") echo " selected";?>>2013</option>
			    					<option value="2014"<?php if (trim(empty($_POST['QEYear'])?"":$_POST['QEYear']) == "2014") echo " selected";?>>2014</option>
			    					<option value="2015"<?php if (trim(empty($_POST['QEYear'])?"":$_POST['QEYear']) == "2015") echo " selected";?>>2015</option>
			    					<option value="2016"<?php if (trim(empty($_POST['QEYear'])?"":$_POST['QEYear']) == "2016") echo " selected";?>>2016</option>
			    					<option value="2017"<?php if (trim(empty($_POST['QEYear'])?"":$_POST['QEYear']) == "2017") echo " selected";?>>2017</option>
			    					<option value="2018"<?php if (trim(empty($_POST['QEYear'])?"":$_POST['QEYear']) == "2018") echo " selected";?>>2018</option>
			    					<option value="2019"<?php if (trim(empty($_POST['QEYear'])?"":$_POST['QEYear']) == "2019") echo " selected";?>>2019</option>
			    					<option value="2020"<?php if (trim(empty($_POST['QEYear'])?"":$_POST['QEYear']) == "2020") echo " selected";?>>2020</option>
			    					<option value="2021"<?php if (trim(empty($_POST['QEYear'])?"":$_POST['QEYear']) == "2021") echo " selected";?>>2021</option>
			    					<option value="2022"<?php if (trim(empty($_POST['QEYear'])?"":$_POST['QEYear']) == "2022") echo " selected";?>>2022</option>
			    					<option value="2023"<?php if (trim(empty($_POST['QEYear'])?"":$_POST['QEYear']) == "2023") echo " selected";?>>2023</option>
			    					<option value="2024"<?php if (trim(empty($_POST['QEYear'])?"":$_POST['QEYear']) == "2024") echo " selected";?>>2024</option>
			    					<option value="2025"<?php if (trim(empty($_POST['QEYear'])?"":$_POST['QEYear']) == "2025") echo " selected";?>>2025</option>
			    				</select> <font color=blue><b>年</b></font> 
			    				<select name="QEMonth">
			    					<option value=""></option>
			    					<option value="01"<?php if (trim(empty($_POST['QEMonth'])?"":$_POST['QEMonth']) == "01") echo " selected";?>>01</option>
			    					<option value="02"<?php if (trim(empty($_POST['QEMonth'])?"":$_POST['QEMonth']) == "02") echo " selected";?>>02</option>
			    					<option value="03"<?php if (trim(empty($_POST['QEMonth'])?"":$_POST['QEMonth']) == "03") echo " selected";?>>03</option>
			    					<option value="04"<?php if (trim(empty($_POST['QEMonth'])?"":$_POST['QEMonth']) == "04") echo " selected";?>>04</option>
			    					<option value="05"<?php if (trim(empty($_POST['QEMonth'])?"":$_POST['QEMonth']) == "05") echo " selected";?>>05</option>
			    					<option value="06"<?php if (trim(empty($_POST['QEMonth'])?"":$_POST['QEMonth']) == "06") echo " selected";?>>06</option>
			    					<option value="07"<?php if (trim(empty($_POST['QEMonth'])?"":$_POST['QEMonth']) == "07") echo " selected";?>>07</option>
			    					<option value="08"<?php if (trim(empty($_POST['QEMonth'])?"":$_POST['QEMonth']) == "08") echo " selected";?>>08</option>
			    					<option value="09"<?php if (trim(empty($_POST['QEMonth'])?"":$_POST['QEMonth']) == "09") echo " selected";?>>09</option>
			    					<option value="10"<?php if (trim(empty($_POST['QEMonth'])?"":$_POST['QEMonth']) == "10") echo " selected";?>>10</option>
			    					<option value="11"<?php if (trim(empty($_POST['QEMonth'])?"":$_POST['QEMonth']) == "11") echo " selected";?>>11</option>
			    					<option value="12"<?php if (trim(empty($_POST['QEMonth'])?"":$_POST['QEMonth']) == "12") echo " selected";?>>12</option>
			    				</select> <font color=blue><b>月</b></font><input type="hidden" name="QEDay" value="1">
			          </td>
			        </tr>
			        <tr height="40" align="center">
			          <td colspan="2" class="h3"><input type="submit" name="submit" class="input_bot" value="送 出"></td>
			        </tr>
				      </form>
			      </table>
    			</td>
    		</tr>
    	</table>
    </td>
	</tr>
</table>
<?php include "down.php";?>
</body>
</html>
<?php
mysqli_close($link);
?>