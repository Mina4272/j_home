﻿<?php	
include "CheckPermission.php";
include "CheckProjectAccounting.php";
include "../global.php";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $PageAdminTitle;?></title>
<link href="../type.css" rel="stylesheet" type="text/css" />
<style type="text/css">
<!--
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
}
-->
</style>
</head>
<body>
<?php
$IYear = empty($_POST['IYear'])?"":$_POST['IYear'];
$IMonth = empty($_POST['IMonth'])?"":$_POST['IMonth'];
$IDay = empty($_POST['IDay'])?"":$_POST['IDay'];
$IDate = "";
$PID = empty($_POST['PID'])?"":$_POST['PID'];
$InvoiceYear = empty($_POST['InvoiceYear'])?"":$_POST['InvoiceYear'];
$InvoiceMonth = empty($_POST['InvoiceMonth'])?"":$_POST['InvoiceMonth'];
$InvoiceDay = empty($_POST['InvoiceDay'])?"":$_POST['InvoiceDay'];
//$Florin = empty($_POST['Florin'])?"":$_POST['Florin'];
if (trim($InvoiceYear) != "" || trim($InvoiceMonth) != "" || trim($InvoiceDay) != "") if (checkdate($InvoiceMonth,$InvoiceDay ,$InvoiceYear)) $InvoiceDate = $InvoiceYear."-".$InvoiceMonth."-".$InvoiceDay;
$InvoiceCUID = empty($_POST['InvoiceCUID'])?"":$_POST['InvoiceCUID'];
$InvoiceTitle = empty($_POST['InvoiceTitle'])?"":$_POST['InvoiceTitle'];
$InvoiceAddress = empty($_POST['InvoiceAddress'])?"":$_POST['InvoiceAddress'];
$Leadtime = empty($_POST['Leadtime'])?"":$_POST['Leadtime'];
$IAccount = empty($_POST['IAccount'])?"":$_POST['IAccount'];
if (trim($IAccount) == "") $IAccount="R";
$IVersion = empty($_POST['IVersion'])?"":$_POST['IVersion'];
$InvoiceNote = empty($_POST['InvoiceNote'])?"":$_POST['InvoiceNote'];

$INo = empty($_POST['INo'])?"":$_POST['INo'];
if (trim($IYear) != "" || trim($IMonth) != "" || trim($IDay) != "") if (checkdate($IMonth,$IDay ,$IYear)) $IDate = $IYear."-".$IMonth."-".$IDay;

if (trim($PID) == "" || trim($IDate) == "")
		{
		mysqli_close($link);
		?>
		<script type="text/JavaScript">
			<!--
			alert ("您輸入的資料不足，請重新輸入！");
			history.go(-1);
			//-->
		</script>
		<?php
		exit;
		}
/*
$now_time = date("Y-m-d H:i:s",mktime());
$sql_update = "update Project set INo = '".$INo."',IDate = '".$IDate."',InvoiceDate = '".$InvoiceDate."',IRecord = '".$_SESSION["reg_MUID"]."',IRecordDate = '".$now_time."',IRecordIP = '".$_SERVER["REMOTE_ADDR"]."',ProcUser = '".$_SESSION["reg_MUID"]."',ProcDate = '".$now_time."',ProcIP = '".$_SERVER["REMOTE_ADDR"]."',InvoiceNote = '".$InvoiceNote."' where Deltag='N' and PID = '".$PID."';";
//echo $sql_update;
//exit;
$result_update=mysqli_query($link,$sql_update) or die ("無法執行修改");
$sql_update = "update ProjectAccounting set Invoice='".$INo."',InvoiceDate='".$InvoiceDate."' WHERE PID = '".$PID."' AND PAMode = 'I' AND Deltag = 'N'";
$result_update=mysqli_query($link,$sql_update) or die ("無法執行修改");
mysqli_close($link);
*/
?>
<script type="text/JavaScript">
	<!--
	location.href='ProjectCancelInvoice.php?PID=<?php echo $PID;?>';
	//-->
</script>
</body>
</html>
