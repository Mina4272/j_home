﻿<?php
include "CheckPermission.php";
include "CheckNews.php";
include "../global.php";
include "include/function.php";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $PageAdminTitle;?></title>
<link href="../type.css" rel="stylesheet" type="text/css" />
</head>

<body>
<?php
$SqlTxt ="";
$NID = $_POST['NID'];
$NTitle = $_POST['NTitle'];
$NContent = $_POST['NContent'];
$NContent = str_replace("\r\n","<br>",$NContent);
$page = $_POST['page'];
$KeyWord = $_POST['KeyWord'];
if (trim($NID) == "")
		{
		mysqli_close($link);
		?>
		<script type="text/JavaScript">
			<!--
			alert ("查無資料，請冾網站管理人員！");
			history.go(-1);
			//-->
		</script>
		<?php
		exit;
		}

$SQL_News="select NTitle,NFile,AddUser,AddDate,ProcUser,ProcDate from News where Deltag='N' and NID = '".$NID."';";
$result_News=mysqli_query($link,$SQL_News) or die ("無法執行查詢");
if (mysqli_num_rows($result_News) == 0)
		{
		mysqli_free_result($result_News);
		mysqli_close($link);
		?>
		<SCRIPT language=javascript>
		<!--
		alert ("查無資料，請冾網站管理人員！"); 
		history.go(-1);
		//-->
		</SCRIPT>
		<?php 	
		exit;
		}
mysqli_free_result($result_News);

$now_time = date("Y-m-d H:i:s",mktime());
if(trim($_FILES['NFile']['tmp_name']) != "")
		{
		if($_FILES['NFile']['size'] > 20971520)
				{
				?>
				<script type="text/JavaScript">
					<!--
					alert ("您上傳的檔案 Size 超過 20 M，請重新上傳！");
					history.go(-1);
					//-->
				</script>
				<?php
				exit();
				}
		$NFile = "NFile_".date("ymdHis",mktime()).rand_string(5, 'ABCDEFGHIJKLMNPQRSTUVWXYZ23456789abcdefghijklmnopqrstuvwxyz').".".strtolower(substr($_FILES['NFile']['name'],strrpos($_FILES['NFile']['name'],".")+1,strlen($_FILES['NFile']['name'])+1));
		@copy($_FILES['NFile']['tmp_name'],$_SERVER["DOCUMENT_ROOT"]."\\Admin\\NFile\\".$NFile);
		}
		
if (trim($NFile) != "") $SqlTxt = ",NFile='".$NFile."'";
$sql_insert = "INSERT INTO NewsHistory(NID,NTitle,NFile,NContent,AddUser,AddDate,AddIP,Deltag,ProcUser,ProcDate,ProcIP,UpdateUser,UpdateDate,UpdateIP) SELECT NID,NTitle,NFile,NContent,AddUser,AddDate,AddIP,Deltag,ProcUser,ProcDate,ProcIP,'".$_SESSION["reg_MUID"]."','".$now_time."','".$_SERVER["REMOTE_ADDR"]."' FROM News where Deltag='N' and NID = '".$NID."';";
$result_insert=mysqli_query($link,$sql_insert) or die ("無法執行新增");
$sql_update = "update News set NTitle = '".$NTitle."',NContent = '".$NContent."' ".$SqlTxt." ,ProcUser = '".$_SESSION["reg_MUID"]."',ProcDate = '".$now_time."',ProcIP = '".$_SERVER["REMOTE_ADDR"]."' where Deltag='N' and NID = '".$NID."';";
$result_update=mysqli_query($link,$sql_update) or die ("無法執行修改");

mysqli_close($link);
?>
<script type="text/JavaScript">
	<!--
	alert ("檔案修改成功！");
	location.href='NewsList.php?page=<?php echo $page;?>&KeyWord=<?php echo urlencode($KeyWord);?>';
	//-->
</script>

</body>
</html>
