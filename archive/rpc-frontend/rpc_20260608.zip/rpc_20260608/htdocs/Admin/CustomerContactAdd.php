﻿<?php	
include "CheckPermission.php";
include "CheckCustomer.php";
include "../global.php";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $PageAdminTitle;?></title>
<link href="../type.css" rel="stylesheet" type="text/css" />
<style type="text/css">
<!--
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
}
-->
</style>
<link href="../script/DatePicker.css" rel="stylesheet" type="text/css" />
<Script LANGUAGE="Javascript" SRC="../script/DatePicker.js"></Script>
<Script type="text/javascript" language="javascript" src="../script/CheckForm.js"></Script>
<script type="text/JavaScript">
<!--
function jsCheck() 
		{
		if (ChkImp('Contact',document.form1.Contact.value,'聯絡人') == false) return false;
		if (jsTrim(document.form1.CEMail.value) != "") if (ChkEmail('CEMail',document.form1.CEMail.value,'聯絡人E-Mail') == false) return false;
		}
//-->
</script>
</head>
<body>
<?php
$CID = $_GET['CID'];
if (trim($CID) == "")
		{
		mysqli_close($link);
		?>
		<script type="text/JavaScript">
			<!--
			alert ("查無資料，請冾網站管理人員！");
			self.close();
			//-->
		</script>
		<?php
		exit;
		}
?>
<table width="100%" border="0" cellpadding="0" cellspacing="0">
	<tr>
		<td>
    	<table width="100%" border="0" cellpadding="0" cellspacing="0">
    		<tr height="30">
					<td width="15" background="../images/table_bg.gif"></td>
    			<td class="c3" background="../images/table_bg.gif"><b>新增聯絡人</b></td>
    		</tr>
    	</table>
    	<table width="100%" border="0" cellpadding="0" cellspacing="0">
        <form name="form1" method="post" action="CustomerContactAddDB.php" onSubmit="return jsCheck();">
        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
					<td width="15"></td>
          <td width="80" class="c3" align="right">聯絡人：</td>
          <td class="c3"><input name="Contact" type="text" size="20" /></td>
        </tr>
        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
					<td width="15"></td>
          <td class="c3" align="right">部門：</td>
          <td class="c3"><input name="CDep" type="text" size="20" /></td>
        </tr>
        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
					<td width="15"></td>
          <td class="c3" align="right">電話：</td>
          <td class="c3"><input name="CMobile" type="text" size="20" /></td>
        </tr>
        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
					<td width="15"></td>
          <td class="c3" align="right">E-Mail：</td>
          <td class="c3"><input name="CEMail" type="text" size="60" /></td>
        </tr>
        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
					<td width="15"></td>
          <td class="c3" align="right">聯絡事項：</td>
          <td class="c3"><input name="CNote" type="text" size="40" /></td>
        </tr>
        <tr height="40" align="center">
					<td width="15"></td>
          <td colspan="2" class="h3">
          	<input type="submit" name="submit" class="input_bot" value="送 出">
          	<input name="CID" type="hidden" id="CID" value="<?php echo $CID;?>" />
          </td>
        </tr>
	      </form>
      </table>
		</td>
	</tr>
</table>
</body>
</html>
<?php
mysqli_close($link);
?>