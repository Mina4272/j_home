﻿<?php
include "CheckPermission.php";
include "CheckProjectAccounting.php";
include "../global.php";
include "include/page_function.php";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>全威驗證科技內部系統</title>
<style type="text/css">
<!--
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
}
.Q1 {
	font-family: "標楷體", Arial, sans-serif;
	font-size: 18px;
	color: #000000;
	font-weight: bold;
	}
.Q2 {
	font-family: Arial, sans-serif;
	font-size: 18px;
	color: #000000;
	font-weight: bold;
	}
.Q3 {
	font-family: Arial, sans-serif;
	font-size: 18px;
	color: #000000;
	font-weight: bold;
	font-style:italic;
	}
.Q4 {
	font-family: "標楷體", Arial, sans-serif;
	font-size: 12px;
	color: #000000;
	font-weight: bold;
	}
.Q5 {
	font-family: "細明體", Arial, sans-serif;
	font-size: 12px;
	color: #000000;
	font-weight: bold;
	}
.Q6 {
	font-family: "標楷體", Arial, sans-serif;
	font-size: 12px;
	color: #000000;
	}
.Q7 {
	font-family: "標楷體", Arial, sans-serif;
	font-size: 12px;
	color: #000000;
	font-weight: bold;
	}
.Q8 {
	font-family: "標楷體", Arial, sans-serif;
	font-size: 11px;
	color: #000000;
	font-weight: bold;
	}
.Q9 {
	font-family: "標楷體", Arial, sans-serif;
	font-size: 10px;
	color: #000000;
	font-weight: bold;
	}
-->
</style></head>

<body>
<?php
$PID = $_GET['PID'];
$Florin = $_GET['Florin'];
if (trim($Florin) == "") $Florin = "T";
$IAccount = $_GET['IAccount'];
if (trim($IAccount) == "") $IAccount = "R";

if (trim($PID) == "")
		{
		mysqli_close($link);
		?>
		<script type="text/JavaScript">
			<!--
			alert ("查無資料，請冾網站管理人員！");
			history.go(-1);
			//-->
		</script>
		<?php
		exit;
		}
$SQL_Project="select PUID,PName,ApplyItem,CID,CName,CTel,CFax,Contact,CMobile,CEMail,CAddress,InvoiceDate,IFlorin,(select GUI from Customer where Deltag='N' and CID = Project.CID) as GUI,(select CUID from Customer where Deltag='N' and CID = Project.CID) as CUID,InvoiceCUID,InvoiceTitle,InvoiceAddress,Leadtime,Trademark,PTax,ModelName,(select TrademarkTxt from Customer where Deltag='N' and CID = Project.CID) as TrademarkTxt,INo,IDate from Project where Deltag='N' and PID = '".$PID."';";
$result_Project=mysqli_query($link,$SQL_Project) or die ("無法執行查詢");
if (mysqli_num_rows($result_Project) == 0)
		{
		mysqli_free_result($result_Project);
		mysqli_close($link);
		?>
		<SCRIPT language=javascript>
		<!--
		alert ("查無資料，請冾網站管理人員！"); 
		history.go(-1);
		//-->
		</SCRIPT>
		<?php 	
		exit;
		}
list($PUID,$PName,$ApplyItem,$CID,$CName,$CTel,$CFax,$Contact,$CMobile,$CEMail,$CAddress,$InvoiceDate,$IFlorin,$GUI,$CUID,$InvoiceCUID,$InvoiceTitle,$InvoiceAddress,$Leadtime,$Trademark,$PTax,$ModelName,$TrademarkTxt,$INo,$IDate)=mysqli_fetch_row($result_Project);
mysqli_free_result($result_Project);
if (trim($Trademark) != "") $TrademarkTxt = $Trademark;
if (trim($GUI) == "") $GUI=$CUID;
?>
<table width="720" border="0" cellpadding="0" cellspacing="0">
	<tr>
		<td>
			<table width="720" border="0" cellpadding="0" cellspacing="0">
				<tr>
					<td colspan="3" height="5"></td>
				</tr>
				<tr>
					<td width="170" rowspan="4" align="center"><img src="../images/logo.gif" border="0" width="100" height="96" /></td>
					<td width="350" height="20">&nbsp;</td>
					<td width="200" height="20">&nbsp;</td>
				</tr>
				<tr>
					<td height="20">&nbsp;</td>
					<td height="20">&nbsp;</td>
				</tr>
				<tr>
					<td class="Q1" height="20">全威驗證科技股份有限公司</td>
					<td class="Q2" height="20">TEL:+886-2-8201-1888</td>
				</tr>
				<tr>
					<td class="Q3" height="20"><font color="red">R</font>ight&nbsp;&nbsp;<font color="red">P</font>ower&nbsp;&nbsp;<font color="red">C</font>ertification&nbsp;&nbsp;Co., Ltd.</td>
					<td class="Q2" height="20">FAX:+886-2-8201-8388</td>
				</tr>
				<tr>
					<td colspan="3" height="20">&nbsp;</td>
				</tr>
				<tr>
					<td colspan="3" height="20" align="center" valign="bottom" class="Q2"><font color="purple">INVOICE</font></td>
				</tr>
				<tr>
					<td colspan="3" height="20" align="center" valign="top" class="Q2"><hr width="80" height="25" color="purple"></td>
				</tr>
			</table>
			<table width="680" border="1" cellpadding="0" cellspacing="0" bordercolor="#000000" align="center">
				<tr>
					<td>
						<table width="680" border="0" cellpadding="0" cellspacing="0" align="center">
							<tr height="20">
								<td class="Q4" width="155">公司名稱 company：</td>
								<td class="Q5" width="255"><?php echo $CName;?></td>
								<td class="Q4" width="190">合約編號Contract No.</td>
								<td class="Q5" width="80" align="center"><font color="#000000"><?php echo $PUID;?></font></td>
							</tr>
							<tr height="20">
								<td class="Q4">代表人Representative：</td>
								<td class="Q5"><?php echo $Contact;?></td>
								<td class="Q4">發票抬頭  Title of invoice：</td>
								<td class="Q5" align="center"><font color="#000000"><?php if (trim($InvoiceTitle) != "") echo $InvoiceTitle; else echo "同左";?></font></td>
							</tr>
							<tr height="20">
								<td class="Q4">電話Telephone No.：</td>
								<td class="Q5"><?php echo $CTel;?></td>
								<td class="Q4">統一編號Unify the serial No.</td>
								<td class="Q5" align="center"><font color="#000000"><?php if (trim($InvoiceCUID) != "") echo $InvoiceCUID; else echo $GUI;?></font></td>
							</tr>
							<tr height="20">
								<td class="Q4">地址Address：</td>
								<td class="Q5"><?php echo $CAddress;?></td>
								<td class="Q4">發票寄送地址Address：</td>
								<td class="Q5" align="center"><font color="#000000"><font color="#000000"><?php if (trim($InvoiceAddress) != "") echo $InvoiceAddress; else echo "同左";?></font></td>
							</tr>
							<tr height="20">
								<td class="Q4">專案名稱Subject：</td>
								<td class="Q5"><?php echo $PName;?>-<?php echo $ApplyItem;?></td>
								<td class="Q4">列印日期 Date：</td>
								<td class="Q5" align="center"><font color="#000000"><?php echo $InvoiceDate;?></font></td>
							</tr>
							<tr height="20">
								<td class="Q4">發票號碼：</td>
								<td class="Q5"><?php echo $INo;?></td>
								<td class="Q4">發票日期 Date：</td>
								<td class="Q5" align="center"><font color="#000000"><?php echo $IDate;?></font></td>
							</tr>
						</table>
						<table width="680" border="0" cellpadding="0" cellspacing="0" align="center" height="1" style="border-style: dashed; border-width: 2px" bordercolor="#000000">
							<tr>
								<td>
									<table width="680" border="0" cellpadding="0" cellspacing="0" align="center">
										<tr height="20">
											<td class="Q4" width="305" align="center">服務內容 Service Description</td>
											<td class="Q4" width="60" align="center">Tax</td>
											<td class="Q4" width="100" align="center">Amount</td>
											<td class="Q4" width="215" align="center">備 註 Note</td>
										</tr>
									</table>
								</td>
							</tr>
						</table>
						<table width="680" border="0" cellpadding="0" cellspacing="0" align="center">
							<?php
							$SQL_ProjectAccounting="select PAID,PAMode,PAItem,Charges,Rate,ChargesOther,PATax,PAStatus,PADate,PANote from ProjectAccounting where Deltag='N' and PAMode='I' and PID = '".$PID."' and (PAStatus = 'W' or PAStatus = 'S') order by PAMode asc,PAID asc;";
							$result_ProjectAccounting=mysqli_query($link,$SQL_ProjectAccounting) or die ("無法執行查詢");
							$ShowLine = 21 - mysqli_num_rows($result_ProjectAccounting);
		          $SumPrice = 0;
		          $PATaxPrice = 0;
		          while(list($PAID,$PAMode,$PAItem,$Charges,$Rate,$ChargesOther,$PATax,$PAStatus,$PADate,$PANote)=mysqli_fetch_row($result_ProjectAccounting)){
								if (trim($Florin) == "O") $Charges = $ChargesOther;
								$SumPrice = $SumPrice + $Charges;
		          	if (trim($PATax) == "") {
				          	if (trim($PTax) == "Y") $PATax = "Y";
				          	else if (trim($PTax) == "N") $PATax = "N";
		          			}
		          	if (trim($PATax) == "Y") $PATaxPrice = $PATaxPrice + round($Charges*0.05);
							?>
							<tr height="15">
								<td class="Q6" width="305" align="center"><?php echo $PAItem;?></td>
								<td class="Q6" width="60" align="center">
									<?php
			          	if (trim($PATax) == "Y") echo number_format(round($Charges*0.05));
			          	else if (trim($PATax) == "N") echo "0";
									?>
								</td>
								<td class="Q6" width="100" align="center">
									<?php
			          	if (trim($PATax) == "Y") echo number_format((round($Charges*0.05))+$Charges);
			          	else if (trim($PATax) == "N") echo number_format($Charges);
									?>
								</td>
								<td class="Q6" width="215"><?php echo $PANote;?></td>
							</tr>
			        <?php
			      			}
            	mysqli_free_result($result_ProjectAccounting);
            	for ($tmp=0;$tmp<=$ShowLine-1;$tmp++){
			        ?>
							<tr height="15">
								<td class="Q6" align="center">&nbsp;</td>
								<td class="Q6" align="right">&nbsp;</td>
								<td class="Q6" align="right">&nbsp;</td>
								<td class="Q6" align="right">&nbsp;</td>
								<td class="Q6">&nbsp;</td>
							</tr>
							<?php }?>
							<tr height="15">
								<td class="Q6" align="center" colspan="5">
									Leadtime：<?php echo $Leadtime;?>　
									Trademark：<?php echo $TrademarkTxt;?>　
									Modelname：<?php echo $ModelName;?>
								</td>
							</tr>
						</table>
						<table width="680" border="0" cellpadding="0" cellspacing="0" align="center" height="1" style="border-style: dashed; border-width: 2px" bordercolor="#000000">
							<tr>
								<td>
									<table width="680" border="0" cellpadding="0" cellspacing="0" align="center">
										<tr height="20">
											<td class="Q4" width="410">&nbsp;委託費用 Amount</td>
											<td class="Q7" width="90" align="center"><?php echo number_format($SumPrice);?></td>
											<td class="Q7" width="180" align="center">&nbsp;</td>
										</tr>
										<tr height="20">
											<td class="Q4">&nbsp;營業稅 Tax</td>
											<td class="Q7" align="center"><?php echo number_format($PATaxPrice);?></td>
											<td class="Q7" align="center">&nbsp;</td>
										</tr>
									</table>
								</td>
							</tr>
						</table>
						<table width="680" border="0" cellpadding="0" cellspacing="0" align="center">
							<tr height="20">
								<td class="Q4" width="410" colspan="3">&nbsp;總　計 Total (<?php if (trim($Florin) == "T") echo "TWD"; else echo $IFlorin;?>)</td>
								<td class="Q7" width="90" align="center"><?php echo number_format($SumPrice + $PATaxPrice);?></td>
								<td class="Q7" width="180" align="center">&nbsp;</td>
							</tr>
						</table>

					</td>
				</tr>
			</table>
			<table width="690" border="0" cellpadding="0" cellspacing="0" align="center">
				<tr height="20">
					<td></td>
				</tr>
				<tr height="15">
					<td class="Q8">Payment information</td>
				</tr>
				<tr height="15">
					<td><span class="Q8">1. ACCOUNT WITH BANK：</span></td>
				</tr>
				<tr height="15">
					<td><span class="Q8">Bank Name：</span><span class="Q6">CTBC Bank Co., Ltd.</span></td>
				</tr>
				<tr height="15">
					<td><span class="Q8">Address：</span><span class="Q6">2F., No. 115, Xingde Rd., Sanchong Dist., New Taipei City 241 , Taiwan (R.O.C.)</span></td>
				</tr>
				<tr height="15">
					<td><span class="Q8">SWIFT Code：</span><span class="Q6">CTCBTWTP761</span></td>
				</tr>
				<tr height="15">
					<td><span class="Q8">2. IN FAVOR OF:</span></td>
				</tr>
				<tr height="15">
					<td><span class="Q8">Account Name RIGHT POWER CERTIFICATION Co., Ltd.</span></td>
				</tr>
				<tr height="15">
					<td><span class="Q8">Account Number 761131010088</span></td>
				</tr>
				<tr height="80">
					<td></td>
				</tr>
				<tr>
					<td>
						<table width="100%" border="0" cellpadding="0" cellspacing="0">
							<tr height="15">
								<td width="40%"></td>
								<td width="50%" align="right" class="Q8">Contact person: Tony Hsu</td>
								<td width="10%"></td>
							</tr>
							<tr height="15">
								<td width="40%"></td>
								<td width="50%" align="right" class="Q8">聯絡人:許盛凱 0966-522-221</td>
								<td width="10%"></td>
							</tr>
							<tr height="15">
								<td width="40%"></td>
								<td width="50%" align="right" class="Q8">TEL: 886-2-8201-1888</td>
								<td width="10%"></td>
							</tr>
							<tr height="15">
								<td width="40%"></td>
								<td width="50%" align="right" class="Q8">FAX: 886-2-8201-8388</td>
								<td width="10%"></td>
							</tr>
						</table>
					</td>
				</tr>
			</table>
			<table width="700" border="0" cellpadding="0" cellspacing="0" align="center">
				<tr height="20">
					<td></td>
				</tr>
				<tr height="15">
					<td class="Q9">241新北市三重興德路115號2樓      2F., No. 115, Xingde Rd., Sanchong Dist., New Taipei City 241 , Taiwan (R.O.C.)</td>
				</tr>
			</table>
		</td>
	</tr>
</table>
</body>
</html>
<?php
mysqli_close($link);
?>