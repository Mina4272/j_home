﻿<?php	
include "CheckPermission.php";
include "CheckMVac.php";
include "../global.php";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $PageAdminTitle;?></title>
<link href="../type.css" rel="stylesheet" type="text/css" />
<style type="text/css">
<!--
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
}
-->
</style>
<link href="../script/DatePicker.css" rel="stylesheet" type="text/css" />
<Script LANGUAGE="Javascript" SRC="../script/DatePicker.js"></Script>
<Script type="text/javascript" language="javascript" src="../script/CheckForm.js"></Script>
<script type="text/JavaScript">
<!--
function jsCheck() 
		{
		//if (ChkImp('MVCNote',document.form1.MVCNote.value,'簽核備註') == false) return false;
		}
//-->
</script>
</head>
<body>
<?php
$MVID = $_GET['MVID'];
if (trim($MVID) == "")
		{
		mysqli_close($link);
		?>
		<script type="text/JavaScript">
			<!--
			alert ("查無資料，請冾網站管理人員！");
			self.close();
			//-->
		</script>
		<?php
		exit;
		}
$SQL_ManagerVac="select MUID,MVType,MVSDate,date_format(MVSDate,'%Y'),date_format(MVSDate,'%m'),date_format(MVSDate,'%d'),date_format(MVSDate,'%H'),date_format(MVSDate,'%i'),MVEDate,date_format(MVEDate,'%Y'),date_format(MVEDate,'%m'),date_format(MVEDate,'%d'),date_format(MVEDate,'%H'),date_format(MVEDate,'%i'),Hourage,Agent,(select MName from Manager where DELTAG='N' and MUID=ManagerVac.Agent) AMName,(select MEName from Manager where DELTAG='N' and MUID=ManagerVac.Agent) AMEName,MVNote,MVCheck,(select MName from Manager where DELTAG='N' and MUID=ManagerVac.MUID) MName,(select MEName from Manager where DELTAG='N' and MUID=ManagerVac.MUID) MEName from ManagerVac where Deltag='N' and MVID=".$MVID.";";
$result_ManagerVac=mysqli_query($link,$SQL_ManagerVac) or die ("無法執行查詢");
if (mysqli_num_rows($result_ManagerVac) == 0)
		{
		mysqli_free_result($result_Manager);
		mysqli_close($link);
		?>
		<SCRIPT language=javascript>
		<!--
		alert ("查無資料，請冾網站管理人員！"); 
		self.close();
		//-->
		</SCRIPT>
		<?php 	
		exit;
		}
list($MUID,$MVType,$MVSDate,$MVSYear,$MVSMonth,$MVSDay,$MVSHouse,$MVSMin,$MVEDate,$MVEYear,$MVEMonth,$MVEDay,$MVEHouse,$MVEMin,$Hourage,$Agent,$AMName,$AMEName,$MVNote,$MVCheck,$MName,$MEName)=mysqli_fetch_row($result_ManagerVac);
mysqli_free_result($result_ManagerVac);

if (trim($MVCheck) != "W")
		{
		mysqli_close($link);
		?>
		<script type="text/JavaScript">
			<!--
			alert ("此請假單已簽核，不需再作簽核！");
			self.close();
			//-->
		</script>
		<?php
		exit;
		}
?>
<table width="100%" border="0" cellpadding="0" cellspacing="0">
	<tr>
		<td>
    	<table width="100%" border="0" cellpadding="0" cellspacing="0">
    		<tr height="30">
					<td width="15" background="../images/table_bg.gif"></td>
    			<td class="c3" background="../images/table_bg.gif"><b>請假單審核</b></td>
    		</tr>
    	</table>
    	<table width="100%" border="0" cellpadding="0" cellspacing="0">
        <form name="form1" method="post" action="MVacAuditDB.php" enctype="multipart/form-data" onSubmit="return jsCheck();">
        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
					<td width="15"></td>
          <td width="160" align="right" class="c3">申請人：</td>
          <td class="h3"><?php echo $MEName.$MName;?>
          	<input type="hidden" name="MVID" value="<?php echo $MVID;?>">
          </td>
        </tr>
        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
					<td width="15"></td>
          <td class="c3" align="right">假別：</td>
          <td class="h3">
          	<?php
						if (trim($MVType) == "A") echo "事假";
						else if (trim($MVType) == "B") echo "病假";
						else if (trim($MVType) == "C") echo "公假";
						else if (trim($MVType) == "D") echo "喪假";
						else if (trim($MVType) == "E") echo "婚假";
						else if (trim($MVType) == "F") echo "產假";
						else if (trim($MVType) == "G") echo "特休";
						else if (trim($MVType) == "H") echo "其他";
          	?>
          </td>
        </tr>
        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
					<td width="15"></td>
          <td class="c3" align="right">請假時間：</td>
          <td class="h3"><?php echo $MVSDate;?> ~ <?php echo $MVEDate;?></td>
        </tr>
        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
					<td width="15"></td>
          <td class="c3" align="right">時數：</td>
          <td class="h3"><?php echo $Hourage;?></td>
        </tr>
        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
					<td width="15"></td>
          <td class="c3" align="right">代理人：</td>
          <td class="h3"><?php echo $AMEName.$AMName;?></td>
        </tr>
        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
					<td width="15"></td>
          <td class="c3" align="right">備註：</td>
          <td class="h3"><?php echo $MVNote;?></td>
        </tr>
        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
					<td width="15"></td>
          <td class="c3" align="right">是否核準：</td>
          <td class="h3">
            <input name="MVCheckAns" type="radio" value="Y" /> 同意<br>
            <input name="MVCheckAns" type="radio" value="N" checked /> 不同意
          </td>
        </tr>
        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
					<td width="15"></td>
          <td class="c3" align="right">簽核備註：</td>
          <td class="h3">
            <input name="MVCNote" type="text" size="40" />
          </td>
        </tr>
        <tr height="40" align="center">
					<td width="15"></td>
          <td colspan="2" class="h3">
          	<input type="submit" name="submit" class="input_bot" value="送 出">
          </td>
        </tr>
	      </form>
      </table>
		</td>
	</tr>
</table>
</body>
</html>
<?php
mysqli_close($link);
?>