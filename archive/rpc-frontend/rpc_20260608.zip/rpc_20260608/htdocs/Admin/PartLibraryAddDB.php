﻿<?php
include "CheckPermission.php";
include "CheckPartLibrary.php";
include "../global.php";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $PageAdminTitle;?></title>
</head>
<body>
<?php
$PLCID = $_POST['PLCID'];
$PartName = $_POST['PartName'];
$Firm = $_POST['Firm'];
$Model = $_POST['Model'];
$Spec = $_POST['Spec'];
$Standard = $_POST['Standard'];
$Mark = $_POST['Mark'];
$PartCertification = $_POST['PartCertification'];

if (trim($PLCID) == "" || trim($PartName) == "")
		{
		mysqli_close($link);
		?>
		<script type="text/JavaScript">
			<!--
			alert ("您輸入的資料不足，請重新輸入！");
			history.go(-1);
			//-->
		</script>
		<?php
		exit;
		}

$now_time = date("Y-m-d H:i:s",mktime());
$sql_insert = "insert into PartLibrary (PLCID,PartName,Firm,Model,Spec,Standard,Mark,PartCertification,AddUser,AddDate,AddIP) values ('".$PLCID."','".$PartName."','".$Firm."','".$Model."','".$Spec."','".$Standard."','".$Mark."','".$PartCertification."','".$_SESSION["reg_MUID"]."','".$now_time."','".$_SERVER["REMOTE_ADDR"]."');";
$result_insert=mysqli_query($link,$sql_insert) or die ("無法執行新增");

mysqli_close($link);
?>
<script type="text/JavaScript">
	<!--
	alert ("新增成功！");
	location.href='PartLibrary.php';
	//-->
</script>

</body>
</html>
