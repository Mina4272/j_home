<?php
include "CheckPermission.php";
//include "CheckAgendum.php";
include "../global.php";
include "include/page_function.php";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $PageAdminTitle;?></title>
<link href="../type.css" rel="stylesheet" type="text/css" />
<style type="text/css">
<!--
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
}
-->
</style></head>

<body>
<?php
$device_no = $_GET['device_no'];
$page = empty($_GET['page'])?"":$_GET['page'];
if (trim($page) == "") $page = 1;
$page_rows=10;  //每頁筆數
$php_Self = "DeviceCheck.php";  //分頁web檔名

$button_css = "h4";
$limit_txt =" limit ".(($page-1) * $page_rows).",".$page_rows;
$url_str = "&device_no=".$device_no;

$Sql_str="select DC_cycle,DC_date,D_status,DC_result,DC_Note from devicecheck where D_no = '".$device_no."' order by DC_no desc;";
$SQL_DeviceCheck="select DC_cycle,DC_date,D_status,DC_result,DC_Note from devicecheck where D_no = '".$device_no."' order by DC_no desc ".$limit_txt.";";
$result_DeviceCheck=mysqli_query($link,$SQL_DeviceCheck) or die ("無法執行查詢");

?>
<table width="100%" border="0" cellpadding="5" cellspacing="2" class="s2">
  <tr>
	<input type="button" name="add" value="新 增" class="input_bot" onclick="javascript:window.open ('DeviceCheckAdd.php?device_no=<?php echo $device_no;?>','AgendumNote','height=300,width=550,top=200,left=200,scrollbars=yes,status=yes');">
    <td background="../images/table_bg.gif" class="t21">
    校驗週期
    </td>
    <td width="auto" align="center" background="../images/table_bg.gif" class="t21">校驗日期</td>
    <td width="auto" align="center" background="../images/table_bg.gif" class="t21">儀器狀態</td>
    <td width="auto" align="center" background="../images/table_bg.gif" class="t21">校驗結果</td>
	<td width="auto" align="center" background="../images/table_bg.gif" class="t21">備註</td>
  </tr>
  <?php
  $tmp = 1;
  while(list($DC_cycle,$DC_date,$D_status,$DC_result,$DC_Note)=mysqli_fetch_row($result_DeviceCheck)){
	?>
	<tr<?php if ($tmp%2 == 0) echo " bgcolor=\"#F6F6F6\"";?>>
    <td class="h3"><?php echo $DC_cycle;?></td>
    <td class="h3" align="center"><?php echo $DC_date;?></td>
    <td align="center" class="h3"><?php echo $D_status;?></td>
    <td align="center" class="h3"><?php if($DC_result == 'Y'){ echo '符合'; }else{ echo '不符合';}?></td>
	<td align="center" class="h3"><?php echo $DC_Note;?></td>
  </tr>
  <?php
			$tmp++;
			}
	mysqli_free_result($result_DeviceCheck);
  ?>
</table>
<table width="100%" border="0" cellpadding="5" cellspacing="2" class="s2">
  <tr align="center">
    <td bgcolor="#E8F0C2" class="h4"><?php Page_show($Sql_str,$page_rows,$php_Self,$link,$page,$url_str,$button_css);?></td>
  </tr>
</table>
</body>
</html>
<?php
mysqli_close($link);
?>