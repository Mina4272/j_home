﻿<?php
include "CheckPermission.php";
include "CheckAccountingReport.php";
include "../global.php";
require_once 'PHPExcel.php';

function chk_str($chkstr) {
	$chkstr = str_replace('"','〞',$chkstr);
	return $chkstr;
}
$Sql_CID = "";
$SqlTxt = "";
$KeyWord = empty($_POST['KeyWord'])?"":$_POST['KeyWord'];
$QCType = empty($_POST['QCType'])?"":$_POST['QCType'];
$CAR = empty($_POST['CAR'])?"":$_POST['CAR'];

$KeyWord = empty($_POST['KeyWord'])?"":$_POST['KeyWord'];
if (trim($KeyWord) == "") $KeyWord = empty($_GET['KeyWord'])?"":$_GET['KeyWord'];
$QCType = empty($_POST['QCType'])?"":$_POST['QCType'];
if (trim($QCType) == "") $QCType = empty($_GET['QCType'])?"":$_GET['QCType'];
if (trim($KeyWord) != "") $SqlTxt = $SqlTxt." and (CUID like '%".$KeyWord."%' or CName like '%".$KeyWord."%' or EName like '%".$KeyWord."%' or Contact like '%".$KeyWord."%' or CAddress like '%".$KeyWord."%' or CTel like '%".$KeyWord."%' or CFax like '%".$KeyWord."%' or CMobile like '%".$KeyWord."%' or CEMail like '%".$KeyWord."%')";
if (trim($QCType) != "") $SqlTxt = $SqlTxt." and CType like '%".$QCType."%' ";
if (trim($CAR) != "") {
		$SQL_CAR="SELECT DISTINCT a.CID FROM Project a, ProjectAccounting b WHERE a.PID = b.PID AND a.Deltag = 'N' AND b.Deltag = 'N' AND b.PAStatus = 'W' ORDER BY a.CID";
		$result_CAR=mysqli_query($link,$SQL_CAR) or die ("無法執行查詢");
		
		while(list($PQ_CID)=mysqli_fetch_row($result_CAR)){
				if (trim($Sql_CID) == "") $Sql_CID = $PQ_CID;
				else $Sql_CID = $Sql_CID.",".$PQ_CID;
				}
		mysqli_free_result($result_CAR);
		}
if (trim($Sql_CID) != "") $SqlTxt = $SqlTxt . " and CID in (".$Sql_CID.")";

$SQL_Customer="select CID,CUID,CPWD,CName,CTel,Contact,CMobile,CEMail,CAddress,CNote,CLevel,CRecord from Customer where Deltag='N' ".$SqlTxt." order by CID desc;";
$result_Customer=mysqli_query($link,$SQL_Customer) or die ("無法執行查詢");

$objPHPExcel = new PHPExcel();
$objPHPExcel->setActiveSheetIndex(0);

$Ecount=1;
$TolCharges=0;
$TolInputCharges=0;
$TolInputChargesTax=0;
$TolOutputCharges=0;
$TolOutputChargesTax=0;
while(list($CID,$CUID,$CPWD,$CName,$CTel,$Contact,$CMobile,$CEMail,$CAddress,$CNote,$CLevel,$CRecord)=mysqli_fetch_row($result_Customer)){
		$SQL_Project="select PID from Project where Deltag='N' and CID='".$CID."' order by PID;";
		$result_Project=mysqli_query($link,$SQL_Project) or die ("無法執行查詢");
		$PIDTxt="";
		while(list($PID)=mysqli_fetch_row($result_Project)){
			if (trim($PIDTxt) == "") $PIDTxt = "PID='".$PID."'";
			else $PIDTxt = $PIDTxt." or PID='".$PID."'";
		}
		mysqli_free_result($result_Project);
		if (trim($PIDTxt) != "") $PIDTxt = " and (".$PIDTxt.") ";
				
		$objPHPExcel->getActiveSheet()->setCellValue('A'.$Ecount,$CName);
		$objPHPExcel->getActiveSheet()->setCellValue('B'.$Ecount,$CUID);
		$objPHPExcel->getActiveSheet()->setCellValue('C'.$Ecount,"");	
		$objPHPExcel->getActiveSheet()->setCellValue('D'.$Ecount,"");
		$objPHPExcel->getActiveSheet()->setCellValue('E'.$Ecount,"");
		$objPHPExcel->getActiveSheet()->setCellValue('F'.$Ecount,"");
	

		$objPHPExcel->getActiveSheet()->getStyle("A".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
		$objPHPExcel->getActiveSheet()->getStyle("B".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
		$objPHPExcel->getActiveSheet()->getStyle("C".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
		$objPHPExcel->getActiveSheet()->getStyle("D".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
		$objPHPExcel->getActiveSheet()->getStyle("E".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
		$objPHPExcel->getActiveSheet()->getStyle("F".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
		
		$Ecount++;
				
		$objPHPExcel->getActiveSheet()->setCellValue('A'.$Ecount,"合約編號");
		$objPHPExcel->getActiveSheet()->setCellValue('B'.$Ecount,"產品名稱");
		$objPHPExcel->getActiveSheet()->setCellValue('C'.$Ecount,"主型式");
		$objPHPExcel->getActiveSheet()->setCellValue('D'.$Ecount,"收入/支出");
		$objPHPExcel->getActiveSheet()->setCellValue('E'.$Ecount,"項目");
		$objPHPExcel->getActiveSheet()->setCellValue('F'.$Ecount,"費用");
		$objPHPExcel->getActiveSheet()->setCellValue('G'.$Ecount,"稅金");
		$objPHPExcel->getActiveSheet()->setCellValue('H'.$Ecount,"匯率");
		$objPHPExcel->getActiveSheet()->setCellValue('I'.$Ecount,"外幣別");
		$objPHPExcel->getActiveSheet()->setCellValue('J'.$Ecount,"外幣費用");
		$objPHPExcel->getActiveSheet()->setCellValue('K'.$Ecount,"狀態");
		$objPHPExcel->getActiveSheet()->setCellValue('L'.$Ecount,"預計結清日期");
		$objPHPExcel->getActiveSheet()->setCellValue('M'.$Ecount,"收款日/付款日");
		$objPHPExcel->getActiveSheet()->setCellValue('N'.$Ecount,"發票日期");
		$objPHPExcel->getActiveSheet()->setCellValue('O'.$Ecount,"發票號碼");
		$objPHPExcel->getActiveSheet()->setCellValue('P'.$Ecount,"供應商");
		$objPHPExcel->getActiveSheet()->setCellValue('Q'.$Ecount,"備註");
		
		$objPHPExcel->getActiveSheet()->getStyle("A".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
		$objPHPExcel->getActiveSheet()->getStyle("B".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
		$objPHPExcel->getActiveSheet()->getStyle("C".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
		$objPHPExcel->getActiveSheet()->getStyle("D".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
		$objPHPExcel->getActiveSheet()->getStyle("E".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
		$objPHPExcel->getActiveSheet()->getStyle("F".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
		$objPHPExcel->getActiveSheet()->getStyle("G".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
		$objPHPExcel->getActiveSheet()->getStyle("H".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
		$objPHPExcel->getActiveSheet()->getStyle("I".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
		$objPHPExcel->getActiveSheet()->getStyle("J".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
		$objPHPExcel->getActiveSheet()->getStyle("K".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
		$objPHPExcel->getActiveSheet()->getStyle("L".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
		$objPHPExcel->getActiveSheet()->getStyle("M".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
		$objPHPExcel->getActiveSheet()->getStyle("N".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
		$objPHPExcel->getActiveSheet()->getStyle("O".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
		$objPHPExcel->getActiveSheet()->getStyle("P".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
		$objPHPExcel->getActiveSheet()->getStyle("Q".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
		
		$Ecount++;
		
		if (trim($PIDTxt) == "") $PIDTxt=" and PID=0 ";
		
		$SQL_ProjectAccounting="select (select PUID from Project where Deltag='N' and PID=ProjectAccounting.PID) as PUID,(select PName from Project where Deltag='N' and PID=ProjectAccounting.PID) as PName,(select ModelName from Project where Deltag='N' and PID=ProjectAccounting.PID) as ModelName,PAID,PAMode,PAItem,Charges,Rate,ChargesOther,PATax,PAStatus,PAPDate,PADate,InvoiceDate,Invoice,PANote,CName,(select PTax from Project where Deltag='N' and PID=ProjectAccounting.PID) as PTax from ProjectAccounting where Deltag='N' ".$PIDTxt." and (PAStatus = 'W' or PAStatus = 'S') order by PUID,PAMode asc,PAID asc;";
		$result_ProjectAccounting=mysqli_query($link,$SQL_ProjectAccounting) or die ("無法執行查詢");
		
		$SumCharges=0;
		$SumInput=0;
		$SumInputTax=0;
		$SumOutput=0;
		$SumOutputTax=0;
		$PATaxPrice=0;
		while(list($PUID,$PName,$ModelName,$PAID,$PAMode,$PAItem,$Charges,$Rate,$ChargesOther,$PATax,$PAStatus,$PAPDate,$PADate,$InvoiceDate,$Invoice,$PANote,$PCName,$PTax)=mysqli_fetch_row($result_ProjectAccounting)){
			if (trim($PATax) == "") $PATax = $PTax;
			$PATaxPrice=0;
			if (trim($PATax) == "Y") $PATaxPrice = round($Charges*0.05);
			if (trim($PAStatus) == "W") {
					if (trim($PAMode) == "I") $PAStatus="待收"; else if (trim($PAMode) == "O") $PAStatus="未付";
					}
			else if (trim($PAStatus) == "S") $PAStatus="結清";
			else if (trim($PAStatus) == "C") $PAStatus="取消";
			$FlorinTxt="";
			$IFlorin="";
			$OFlorin="";
			if (trim($PAMode) == "I") $FlorinTxt=$IFlorin;
			else if (trim($PAMode) == "O") $FlorinTxt=$OFlorin;
			
			if (trim($PAMode) == "I") {
					$SumInput=$SumInput+$Charges;
					if (trim($PATax) == "Y") $SumInputTax = $SumInputTax + round($Charges*0.05);
					$SumCharges=$SumCharges+$Charges;
					}
			else if (trim($PAMode) == "O") {
					$SumOutput=$SumOutput+$Charges;
					if (trim($PATax) == "Y") $SumOutputTax = $SumOutputTax + round($Charges*0.05);
					$SumCharges=$SumCharges-$Charges;
					}
			
			if (trim($PAMode) == "I") $PAMode="收入";
			else if (trim($PAMode) == "O") $PAMode="支出";
			
			$objPHPExcel->getActiveSheet()->setCellValue('A'.$Ecount,$PUID);
			$objPHPExcel->getActiveSheet()->setCellValue('B'.$Ecount,chk_str($PName));
			$objPHPExcel->getActiveSheet()->setCellValue('C'.$Ecount,chk_str($ModelName));
			$objPHPExcel->getActiveSheet()->setCellValue('D'.$Ecount,chk_str($PAMode));
			$objPHPExcel->getActiveSheet()->setCellValue('E'.$Ecount,chk_str($PAItem));
			$objPHPExcel->getActiveSheet()->setCellValue('F'.$Ecount,$Charges);
			$objPHPExcel->getActiveSheet()->setCellValue('G'.$Ecount,$PATaxPrice);
			$objPHPExcel->getActiveSheet()->setCellValue('H'.$Ecount,$Rate);
			$objPHPExcel->getActiveSheet()->setCellValue('I'.$Ecount,$FlorinTxt);
			$objPHPExcel->getActiveSheet()->setCellValue('J'.$Ecount,$ChargesOther);
			$objPHPExcel->getActiveSheet()->setCellValue('K'.$Ecount,$PAStatus);
			$objPHPExcel->getActiveSheet()->setCellValue('L'.$Ecount,$PAPDate);
			$objPHPExcel->getActiveSheet()->setCellValue('M'.$Ecount,$PADate);
			$objPHPExcel->getActiveSheet()->setCellValue('N'.$Ecount,$InvoiceDate);
			$objPHPExcel->getActiveSheet()->setCellValue('O'.$Ecount,$Invoice);
			$objPHPExcel->getActiveSheet()->setCellValue('P'.$Ecount,chk_str($PCName));
			$objPHPExcel->getActiveSheet()->setCellValue('Q'.$Ecount,chk_str($PANote));
			
			$objPHPExcel->getActiveSheet()->getStyle('A'.$Ecount)->getFont()->setSize(12);
			$objPHPExcel->getActiveSheet()->getStyle('B'.$Ecount)->getFont()->setSize(12);
			$objPHPExcel->getActiveSheet()->getStyle('C'.$Ecount)->getFont()->setSize(12);
			$objPHPExcel->getActiveSheet()->getStyle('D'.$Ecount)->getFont()->setSize(12);
			$objPHPExcel->getActiveSheet()->getStyle('E'.$Ecount)->getFont()->setSize(12);
			$objPHPExcel->getActiveSheet()->getStyle('F'.$Ecount)->getFont()->setSize(12);
			$objPHPExcel->getActiveSheet()->getStyle('G'.$Ecount)->getFont()->setSize(12);
			$objPHPExcel->getActiveSheet()->getStyle('H'.$Ecount)->getFont()->setSize(12);
			$objPHPExcel->getActiveSheet()->getStyle('I'.$Ecount)->getFont()->setSize(12);
			$objPHPExcel->getActiveSheet()->getStyle('J'.$Ecount)->getFont()->setSize(12);
			$objPHPExcel->getActiveSheet()->getStyle('K'.$Ecount)->getFont()->setSize(12);
			$objPHPExcel->getActiveSheet()->getStyle('L'.$Ecount)->getFont()->setSize(12);
			$objPHPExcel->getActiveSheet()->getStyle('M'.$Ecount)->getFont()->setSize(12);
			$objPHPExcel->getActiveSheet()->getStyle('N'.$Ecount)->getFont()->setSize(12);
			$objPHPExcel->getActiveSheet()->getStyle('O'.$Ecount)->getFont()->setSize(12);
			$objPHPExcel->getActiveSheet()->getStyle('P'.$Ecount)->getFont()->setSize(12);
			$objPHPExcel->getActiveSheet()->getStyle('Q'.$Ecount)->getFont()->setSize(12);
			$PATaxPrice=0;
			$Ecount++;
}
mysqli_free_result($result_ProjectAccounting);

$objPHPExcel->getActiveSheet()->setCellValue('A'.$Ecount,"");
$objPHPExcel->getActiveSheet()->setCellValue('B'.$Ecount,"收入");
$objPHPExcel->getActiveSheet()->setCellValue('C'.$Ecount,"稅金(收入)");
$objPHPExcel->getActiveSheet()->setCellValue('D'.$Ecount,"支出");
$objPHPExcel->getActiveSheet()->setCellValue('E'.$Ecount,"稅金(支出)");
$objPHPExcel->getActiveSheet()->setCellValue('F'.$Ecount,"小計");
$objPHPExcel->getActiveSheet()->setCellValue('G'.$Ecount,"");
$objPHPExcel->getActiveSheet()->setCellValue('H'.$Ecount,"");
$objPHPExcel->getActiveSheet()->setCellValue('I'.$Ecount,"");
$objPHPExcel->getActiveSheet()->setCellValue('J'.$Ecount,"");
$objPHPExcel->getActiveSheet()->setCellValue('K'.$Ecount,"");
$objPHPExcel->getActiveSheet()->setCellValue('L'.$Ecount,"");
$objPHPExcel->getActiveSheet()->setCellValue('M'.$Ecount,"");
$objPHPExcel->getActiveSheet()->setCellValue('N'.$Ecount,"");
$objPHPExcel->getActiveSheet()->setCellValue('O'.$Ecount,"");
$objPHPExcel->getActiveSheet()->setCellValue('P'.$Ecount,"");
$objPHPExcel->getActiveSheet()->setCellValue('Q'.$Ecount,"");

$objPHPExcel->getActiveSheet()->getStyle("A".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("B".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("C".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("D".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("E".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("F".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("G".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("H".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("I".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("J".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("K".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("L".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("M".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("N".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("O".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("P".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("Q".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);

$Ecount++;

$objPHPExcel->getActiveSheet()->setCellValue('A'.$Ecount,"");
$objPHPExcel->getActiveSheet()->setCellValue('B'.$Ecount,$SumInput);
$objPHPExcel->getActiveSheet()->setCellValue('C'.$Ecount,$SumInputTax);
$objPHPExcel->getActiveSheet()->setCellValue('D'.$Ecount,$SumOutput);
$objPHPExcel->getActiveSheet()->setCellValue('E'.$Ecount,$SumOutputTax);
$objPHPExcel->getActiveSheet()->setCellValue('F'.$Ecount,$SumCharges);
$objPHPExcel->getActiveSheet()->setCellValue('G'.$Ecount,"");
$objPHPExcel->getActiveSheet()->setCellValue('H'.$Ecount,"");
$objPHPExcel->getActiveSheet()->setCellValue('I'.$Ecount,"");
$objPHPExcel->getActiveSheet()->setCellValue('J'.$Ecount,"");
$objPHPExcel->getActiveSheet()->setCellValue('K'.$Ecount,"");
$objPHPExcel->getActiveSheet()->setCellValue('L'.$Ecount,"");
$objPHPExcel->getActiveSheet()->setCellValue('M'.$Ecount,"");
$objPHPExcel->getActiveSheet()->setCellValue('N'.$Ecount,"");
$objPHPExcel->getActiveSheet()->setCellValue('O'.$Ecount,"");
$objPHPExcel->getActiveSheet()->setCellValue('P'.$Ecount,"");
$objPHPExcel->getActiveSheet()->setCellValue('Q'.$Ecount,"");
			
$objPHPExcel->getActiveSheet()->getStyle('A'.$Ecount)->getFont()->setSize(12);
$objPHPExcel->getActiveSheet()->getStyle('B'.$Ecount)->getFont()->setSize(12);
$objPHPExcel->getActiveSheet()->getStyle('C'.$Ecount)->getFont()->setSize(12);
$objPHPExcel->getActiveSheet()->getStyle('D'.$Ecount)->getFont()->setSize(12);
$objPHPExcel->getActiveSheet()->getStyle('E'.$Ecount)->getFont()->setSize(12);
$objPHPExcel->getActiveSheet()->getStyle('F'.$Ecount)->getFont()->setSize(12);
$objPHPExcel->getActiveSheet()->getStyle('G'.$Ecount)->getFont()->setSize(12);
$objPHPExcel->getActiveSheet()->getStyle('H'.$Ecount)->getFont()->setSize(12);
$objPHPExcel->getActiveSheet()->getStyle('I'.$Ecount)->getFont()->setSize(12);
$objPHPExcel->getActiveSheet()->getStyle('J'.$Ecount)->getFont()->setSize(12);
$objPHPExcel->getActiveSheet()->getStyle('K'.$Ecount)->getFont()->setSize(12);
$objPHPExcel->getActiveSheet()->getStyle('L'.$Ecount)->getFont()->setSize(12);
$objPHPExcel->getActiveSheet()->getStyle('M'.$Ecount)->getFont()->setSize(12);
$objPHPExcel->getActiveSheet()->getStyle('N'.$Ecount)->getFont()->setSize(12);
$objPHPExcel->getActiveSheet()->getStyle('O'.$Ecount)->getFont()->setSize(12);
$objPHPExcel->getActiveSheet()->getStyle('P'.$Ecount)->getFont()->setSize(12);
$objPHPExcel->getActiveSheet()->getStyle('Q'.$Ecount)->getFont()->setSize(12);

$TolCharges = $TolCharges + $SumCharges;
$TolInputCharges = $TolInputCharges + $SumInput;
$TolInputChargesTax = $TolInputChargesTax + $SumInputTax;
$TolOutputCharges = $TolOutputCharges + $SumOutput;
$TolOutputChargesTax = $TolOutputChargesTax + $SumOutputTax;

$Ecount++;
}
mysqli_free_result($result_Customer);
mysqli_close($link);

$objPHPExcel->getActiveSheet()->setCellValue('A'.$Ecount,"");
$objPHPExcel->getActiveSheet()->setCellValue('B'.$Ecount,"總收入");
$objPHPExcel->getActiveSheet()->setCellValue('C'.$Ecount,"總稅金(收入)");
$objPHPExcel->getActiveSheet()->setCellValue('D'.$Ecount,"總支出");
$objPHPExcel->getActiveSheet()->setCellValue('E'.$Ecount,"總稅金(支出)");
$objPHPExcel->getActiveSheet()->setCellValue('F'.$Ecount,"總計");
$objPHPExcel->getActiveSheet()->setCellValue('G'.$Ecount,"");
$objPHPExcel->getActiveSheet()->setCellValue('H'.$Ecount,"");
$objPHPExcel->getActiveSheet()->setCellValue('I'.$Ecount,"");
$objPHPExcel->getActiveSheet()->setCellValue('J'.$Ecount,"");
$objPHPExcel->getActiveSheet()->setCellValue('K'.$Ecount,"");
$objPHPExcel->getActiveSheet()->setCellValue('L'.$Ecount,"");
$objPHPExcel->getActiveSheet()->setCellValue('M'.$Ecount,"");
$objPHPExcel->getActiveSheet()->setCellValue('N'.$Ecount,"");
$objPHPExcel->getActiveSheet()->setCellValue('O'.$Ecount,"");
$objPHPExcel->getActiveSheet()->setCellValue('P'.$Ecount,"");
$objPHPExcel->getActiveSheet()->setCellValue('Q'.$Ecount,"");

$objPHPExcel->getActiveSheet()->getStyle("A".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("B".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("C".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("D".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("E".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("F".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("G".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("H".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("I".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("J".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("K".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("L".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("M".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("N".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("O".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("P".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("Q".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);

$Ecount++;

$objPHPExcel->getActiveSheet()->setCellValue('A'.$Ecount,"");
$objPHPExcel->getActiveSheet()->setCellValue('B'.$Ecount,$TolInputCharges);
$objPHPExcel->getActiveSheet()->setCellValue('C'.$Ecount,$TolInputChargesTax);
$objPHPExcel->getActiveSheet()->setCellValue('D'.$Ecount,$TolOutputCharges);
$objPHPExcel->getActiveSheet()->setCellValue('E'.$Ecount,$TolOutputChargesTax);
$objPHPExcel->getActiveSheet()->setCellValue('F'.$Ecount,$TolCharges);
$objPHPExcel->getActiveSheet()->setCellValue('G'.$Ecount,"");
$objPHPExcel->getActiveSheet()->setCellValue('H'.$Ecount,"");
$objPHPExcel->getActiveSheet()->setCellValue('I'.$Ecount,"");
$objPHPExcel->getActiveSheet()->setCellValue('J'.$Ecount,"");
$objPHPExcel->getActiveSheet()->setCellValue('K'.$Ecount,"");
$objPHPExcel->getActiveSheet()->setCellValue('L'.$Ecount,"");
$objPHPExcel->getActiveSheet()->setCellValue('M'.$Ecount,"");
$objPHPExcel->getActiveSheet()->setCellValue('N'.$Ecount,"");
$objPHPExcel->getActiveSheet()->setCellValue('O'.$Ecount,"");
$objPHPExcel->getActiveSheet()->setCellValue('P'.$Ecount,"");
$objPHPExcel->getActiveSheet()->setCellValue('Q'.$Ecount,"");
			
$objPHPExcel->getActiveSheet()->getStyle('A'.$Ecount)->getFont()->setSize(12);
$objPHPExcel->getActiveSheet()->getStyle('B'.$Ecount)->getFont()->setSize(12);
$objPHPExcel->getActiveSheet()->getStyle('C'.$Ecount)->getFont()->setSize(12);
$objPHPExcel->getActiveSheet()->getStyle('D'.$Ecount)->getFont()->setSize(12);
$objPHPExcel->getActiveSheet()->getStyle('E'.$Ecount)->getFont()->setSize(12);
$objPHPExcel->getActiveSheet()->getStyle('F'.$Ecount)->getFont()->setSize(12);
$objPHPExcel->getActiveSheet()->getStyle('G'.$Ecount)->getFont()->setSize(12);
$objPHPExcel->getActiveSheet()->getStyle('H'.$Ecount)->getFont()->setSize(12);
$objPHPExcel->getActiveSheet()->getStyle('I'.$Ecount)->getFont()->setSize(12);
$objPHPExcel->getActiveSheet()->getStyle('J'.$Ecount)->getFont()->setSize(12);
$objPHPExcel->getActiveSheet()->getStyle('K'.$Ecount)->getFont()->setSize(12);
$objPHPExcel->getActiveSheet()->getStyle('L'.$Ecount)->getFont()->setSize(12);
$objPHPExcel->getActiveSheet()->getStyle('M'.$Ecount)->getFont()->setSize(12);
$objPHPExcel->getActiveSheet()->getStyle('N'.$Ecount)->getFont()->setSize(12);
$objPHPExcel->getActiveSheet()->getStyle('O'.$Ecount)->getFont()->setSize(12);
$objPHPExcel->getActiveSheet()->getStyle('P'.$Ecount)->getFont()->setSize(12);
$objPHPExcel->getActiveSheet()->getStyle('Q'.$Ecount)->getFont()->setSize(12);

$objPHPExcel->getActiveSheet()->setTitle('CustomerAccountingExport');

ob_end_clean();

header('Content-Type: application/vnd.ms-excel');
header('Content-Disposition: attachment;filename="CustomerAccountingExport.xls"');
header('Cache-Control: max-age=0');
$objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel5');
$objWriter->save('php://output');
exit;


?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $PageAdminTitle;?></title>
<link href="style.css" rel="stylesheet" type="text/css" />
<body>
<table winth="1000" border="0">
	<tr>
		<td colspan="2"><font color=blue>若您無法正常觀看此報表！請下載此 <a href="owc11.zip" target="_File"><font color=red><b>元件</b></font></a> <font color=blue>安裝至您的電腦。</font></td>
	</tr>
</table>
<object id=ProjectAccounting classid=CLSID:0002E559-0000-0000-C000-000000000046 style="width:100%;height:90%"></object>
<script language=vbscript>
	Sub Window_OnLoad()
	Set chConstants = ProjectAccounting.Constants
	ProjectAccounting.ActiveSheet.Cells.Clear
	ProjectAccounting.Worksheets(1).Select
	ProjectAccounting.ActiveSheet.Name ="ProjectAccounting"
<?php  
$ECount=1;
$TolCharges=0;
$TolInputCharges=0;
$TolInputChargesTax=0;
$TolOutputCharges=0;
$TolOutputChargesTax=0;
while(list($CID,$CUID,$CPWD,$CName,$CTel,$Contact,$CMobile,$CEMail,$CAddress,$CNote,$CLevel,$CRecord)=mysqli_fetch_row($result_Customer)){
		$SQL_Project="select PID from Project where Deltag='N' and CID='".$CID."' order by PID;";
		$result_Project=mysqli_query($link,$SQL_Project) or die ("無法執行查詢");
		$PIDTxt="";
		while(list($PID)=mysqli_fetch_row($result_Project)){
				if (trim($PIDTxt) == "") $PIDTxt = "PID='".$PID."'";
				else $PIDTxt = $PIDTxt." or PID='".$PID."'";
				}
		mysqli_free_result($result_Project);
		if (trim($PIDTxt) != "") $PIDTxt = " and (".$PIDTxt.") ";
		?>
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,1).Value ="<?php echo $CName;?>"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,2).Value ="<?php echo $CUID;?>"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,3).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,4).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,5).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,6).Value =""
		<?php
		if (trim($TitleLine) == "") $TitleLine = $ECount;
		else $TitleLine = $TitleLine.",".$ECount;
		$ECount++;
		?>
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,1).Value ="合約編號"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,2).Value ="產品名稱"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,3).Value ="主型式"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,4).Value ="收入/支出"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,5).Value ="項目"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,6).Value ="費用"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,7).Value ="稅金"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,8).Value ="匯率"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,9).Value ="外幣別"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,10).Value ="外幣費用"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,11).Value ="狀態"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,12).Value ="預計結清日期"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,13).Value ="收款日/付款日"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,14).Value ="發票日期"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,15).Value ="發票號碼"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,16).Value ="供應商"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,17).Value ="備註"
		<?php
		$ECount++;
		if (trim($PIDTxt) == "") $PIDTxt=" and PID=0 ";
		$SQL_ProjectAccounting="select (select PUID from Project where Deltag='N' and PID=ProjectAccounting.PID) as PUID,(select PName from Project where Deltag='N' and PID=ProjectAccounting.PID) as PName,(select ModelName from Project where Deltag='N' and PID=ProjectAccounting.PID) as ModelName,PAID,PAMode,PAItem,Charges,Rate,ChargesOther,PATax,PAStatus,PAPDate,PADate,InvoiceDate,Invoice,PANote,CName,(select PTax from Project where Deltag='N' and PID=ProjectAccounting.PID) as PTax from ProjectAccounting where Deltag='N' ".$PIDTxt." and (PAStatus = 'W' or PAStatus = 'S') order by PUID,PAMode asc,PAID asc;";
		$result_ProjectAccounting=mysqli_query($link,$SQL_ProjectAccounting) or die ("無法執行查詢");
		$SumCharges=0;
		$SumInput=0;
		$SumInputTax=0;
		$SumOutput=0;
		$SumOutputTax=0;
  	$PATaxPrice=0;
    while(list($PUID,$PName,$ModelName,$PAID,$PAMode,$PAItem,$Charges,$Rate,$ChargesOther,$PATax,$PAStatus,$PAPDate,$PADate,$InvoiceDate,$Invoice,$PANote,$PCName,$PTax)=mysqli_fetch_row($result_ProjectAccounting)){
      	if (trim($PATax) == "") $PATax = $PTax;
      	$PATaxPrice=0;
      	if (trim($PATax) == "Y") $PATaxPrice = round($Charges*0.05);
      	if (trim($PAStatus) == "W") {
      			if (trim($PAMode) == "I") $PAStatus="待收"; else if (trim($PAMode) == "O") $PAStatus="未付";
      			}
      	else if (trim($PAStatus) == "S") $PAStatus="結清";
      	else if (trim($PAStatus) == "C") $PAStatus="取消";
      	$FlorinTxt="";
      	if (trim($PAMode) == "I") $FlorinTxt=$IFlorin;
      	else if (trim($PAMode) == "O") $FlorinTxt=$OFlorin;
      	
      	if (trim($PAMode) == "I") {
      			$SumInput=$SumInput+$Charges;
		      	if (trim($PATax) == "Y") $SumInputTax = $SumInputTax + round($Charges*0.05);
      			$SumCharges=$SumCharges+$Charges;
      			}
      	else if (trim($PAMode) == "O") {
      			$SumOutput=$SumOutput+$Charges;
		      	if (trim($PATax) == "Y") $SumOutputTax = $SumOutputTax + round($Charges*0.05);
      			$SumCharges=$SumCharges-$Charges;
      			}
      	
      	if (trim($PAMode) == "I") $PAMode="收入";
      	else if (trim($PAMode) == "O") $PAMode="支出";
				?>
				ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,1).Value ="<?php echo $PUID;?>"
				ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,2).Value ="<?php echo chk_str($PName);?>"
				ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,3).Value ="<?php echo chk_str($ModelName);?>"
				ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,4).Value ="<?php echo chk_str($PAMode);?>"
				ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,5).Value ="<?php echo chk_str($PAItem);?>"
				ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,6).Value ="<?php echo $Charges;?>"
				ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,7).Value ="<?php echo $PATaxPrice;?>"
				ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,8).Value ="<?php echo $Rate;?>"
				ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,9).Value ="<?php echo $FlorinTxt;?>"
				ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,10).Value ="<?php echo $ChargesOther;?>"
				ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,11).Value ="<?php echo $PAStatus;?>"
				ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,12).Value ="'<?php echo $PAPDate;?>"
				ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,13).Value ="'<?php echo $PADate;?>"
				ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,14).Value ="<?php echo $IDate;?>"
				ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,15).Value ="<?php echo $Invoice;?>"
				ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,16).Value ="<?php echo chk_str($PCName);?>"
				ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,17).Value ="<?php echo chk_str($PANote);?>"
				<?php
				$PATaxPrice=0;
				$ECount++;
				}
		mysqli_free_result($result_ProjectAccounting);
		?>
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,1).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,2).Value ="收入"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,3).Value ="稅金(收入)"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,4).Value ="支出"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,5).Value ="稅金(支出)"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,6).Value ="小計"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,7).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,8).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,9).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,10).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,11).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,12).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,13).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,14).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,15).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,16).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,17).Value =""
		<?php
		if (trim($SumLine) == "") $SumLine = $ECount;
		else $SumLine = $SumLine.",".$ECount;
		$ECount++;
		?>
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,1).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,2).Value ="<?php echo $SumInput?>"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,3).Value ="<?php echo $SumInputTax?>"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,4).Value ="<?php echo $SumOutput?>"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,5).Value ="<?php echo $SumOutputTax?>"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,6).Value ="<?php echo $SumCharges;?>"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,7).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,8).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,9).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,10).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,11).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,12).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,13).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,14).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,15).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,16).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,17).Value =""
		<?php
		$TolCharges = $TolCharges + $SumCharges;
		$TolInputCharges = $TolInputCharges + $SumInput;
		$TolInputChargesTax = $TolInputChargesTax + $SumInputTax;
		$TolOutputCharges = $TolOutputCharges + $SumOutput;
		$TolOutputChargesTax = $TolOutputChargesTax + $SumOutputTax;
		if (trim($SumLine) == "") $SumLine = $ECount;
		else $SumLine = $SumLine.",".$ECount;
		
		$ECount++;
		$ECount++;
		}
mysqli_free_result($result_Customer);
mysqli_close($link);
?>
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,1).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,2).Value ="總收入"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,3).Value ="稅金(總收入)"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,4).Value ="總支出"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,5).Value ="稅金(總支出)"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,6).Value ="總計"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,7).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,8).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,9).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,10).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,11).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,12).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,13).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,14).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,15).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,16).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,17).Value =""
		<?php
		if (trim($SumLine) == "") $SumLine = $ECount;
		else $SumLine = $SumLine.",".$ECount;
		$ECount++;
		?>
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,1).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,2).Value ="<?php echo $TolInputCharges;?>"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,3).Value ="<?php echo $TolInputChargesTax;?>"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,4).Value ="<?php echo $TolOutputCharges;?>"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,5).Value ="<?php echo $TolOutputChargesTax;?>"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,6).Value ="<?php echo $TolCharges;?>"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,7).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,8).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,9).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,10).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,11).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,12).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,13).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,14).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,15).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,16).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,17).Value =""

		ProjectAccounting.ActiveSheet.Range("A1:P<?php echo $ECount;?>").Font.Color="blue"
		ProjectAccounting.ActiveSheet.Range("A1:P<?php echo $ECount;?>").Font.Name="Courier New"
		ProjectAccounting.ActiveSheet.Range("A1:P<?php echo $ECount;?>").Font.Size="11"
		ProjectAccounting.ActiveSheet.Range("A1:P<?php echo $ECount;?>").Columns.AutoFit
		ProjectAccounting.ActiveSheet.Range("A1:P<?php echo $ECount;?>").NumberFormat ="General"

		ProjectAccounting.ActiveSheet.Range("A<?php echo $ECount;?>:J<?php echo $ECount;?>").Font.Bold=true
		<?php
		$TitleLineArr = split(",",$TitleLine);
		$count_i=count($TitleLineArr);
		for ($tmp=0;$tmp<=$count_i-1;$tmp++){
				?>
				ProjectAccounting.ActiveSheet.Range("A<?php echo $TitleLineArr[$tmp];?>:P<?php echo $TitleLineArr[$tmp];?>").Font.Color="#000000"
				ProjectAccounting.ActiveSheet.Range("A<?php echo $TitleLineArr[$tmp];?>:P<?php echo $TitleLineArr[$tmp];?>").Font.Bold=true
				ProjectAccounting.ActiveSheet.Range("A<?php echo $TitleLineArr[$tmp]+1;?>:P<?php echo $TitleLineArr[$tmp]+1;?>").Font.Bold=true
				<?php
				}

		$SumLineArr = split(",",$SumLine);
		$count_i=count($SumLineArr);
		for ($tmp=0;$tmp<=$count_i-1;$tmp++){
				?>
				ProjectAccounting.ActiveSheet.Range("A<?php echo $SumLineArr[$tmp];?>:P<?php echo $SumLineArr[$tmp];?>").Font.Bold=true
				<?php
				}
		?>
	End Sub
	</script>
</body>
</html>
