﻿<?php
include "CheckPermission.php";
include "CheckMVac.php";
include "../global.php";
require_once 'PHPExcel.php';

$SqlPID = "";
$QSDate = "";
$QEDate = "";
$SqlTxt = "";
$SqlTxt2 = "";
$QSYear = $_POST['QSYear'];
$QSMonth = $_POST['QSMonth'];
$QSDay = $_POST['QSDay'];
if (trim($QSYear) != "" || trim($QSMonth) != "" || trim($QSDay) != "") if (checkdate($QSMonth,$QSDay ,$QSYear)) $QSDate = $QSYear."-".$QSMonth."-".$QSDay;
$QEYear = $_POST['QEYear'];
$QEMonth = $_POST['QEMonth'];
$QEDay = $_POST['QEDay'];
if (trim($QEYear) != "" || trim($QEMonth) != "" || trim($QEDay) != "") if (checkdate($QEMonth,$QEDay ,$QEYear)) $QEDate = $QEYear."-".$QEMonth."-".$QEDay;

$KeyWord = empty($_POST['KeyWord'])?"":$_POST['KeyWord'];
if (trim($KeyWord) == "") $KeyWord = empty($_GET['KeyWord'])?"":$_GET['KeyWord'];
$QPStatus = empty($_POST['QPStatus'])?"":$_POST['QPStatus'];
if (trim($QPStatus) == "") $QPStatus = empty($_GET['QPStatus'])?"":$_GET['QPStatus'];
$QBE = empty($_POST['QBE'])?"":$_POST['QBE'];
if (trim($QBE) == "") $QBE = empty($_GET['QBE'])?"":$_GET['QBE'];
$QBMUID = empty($_POST['QBMUID'])?"":$_POST['QBMUID'];
if (trim($QBMUID) == "") $QBMUID = empty($_GET['QBMUID'])?"":$_GET['QBMUID'];
$ISINo = empty($_POST['ISINo'])?"":$_POST['ISINo'];
if (trim($ISINo) == "") $ISINo = empty($_GET['ISINo'])?"":$_GET['ISINo'];
$ISAdd = empty($_POST['ISAdd'])?"":$_POST['ISAdd'];
if (trim($ISAdd) == "") $ISAdd = empty($_GET['ISAdd'])?"":$_GET['ISAdd'];
$QAcR = empty($_POST['QAcR'])?"":$_POST['QAcR'];

if (trim($KeyWord) != "") {
		$SQL_ProjectCertificate="select PID from ProjectCertificate where Deltag='N' and PCNo like '%".$KeyWord."%' group by PID order by PID;";
		$result_ProjectCertificate=mysqli_query($link,$SQL_ProjectCertificate) or die ("無法執行查詢");
		
		while(list($PC_PID)=mysqli_fetch_row($result_ProjectCertificate)){
				//if (trim($SqlPID) == "") $SqlPID = "PID='".$PC_PID."'";
				//else $SqlPID = $SqlPID." or PID='".$PC_PID."'";
				if (trim($SqlPID) == "") $SqlPID = $PC_PID;
				else $SqlPID = $SqlPID.",".$PC_PID;
				}
		mysqli_free_result($result_ProjectCertificate);
		}
if (trim($SqlPID) != "") $SqlPID = " PID in (".$SqlPID.")";
if (trim($KeyWord) != "") {
		if (trim($SqlPID) == "") $SqlTxt = $SqlTxt." and (PUID like '%".$KeyWord."%' or CName like '%".$KeyWord."%' or CTel like '%".$KeyWord."%' or CFax like '%".$KeyWord."%' or Contact like '%".$KeyWord."%' or CMobile like '%".$KeyWord."%' or CEMail like '%".$KeyWord."%' or CAddress like '%".$KeyWord."%' or PName like '%".$KeyWord."%' or ModelName like '%".$KeyWord."%' or SeriesModel like '%".$KeyWord."%' or BMUID like '%".$KeyWord."%' or PNote like '%".$KeyWord."%' or ApplyItem like '%".$KeyWord."%')";
		else $SqlTxt = $SqlTxt." and (PUID like '%".$KeyWord."%' or CName like '%".$KeyWord."%' or CTel like '%".$KeyWord."%' or CFax like '%".$KeyWord."%' or Contact like '%".$KeyWord."%' or CMobile like '%".$KeyWord."%' or CEMail like '%".$KeyWord."%' or CAddress like '%".$KeyWord."%' or PName like '%".$KeyWord."%' or ModelName like '%".$KeyWord."%' or SeriesModel like '%".$KeyWord."%' or BMUID like '%".$KeyWord."%' or PNote like '%".$KeyWord."%' or ApplyItem like '%".$KeyWord."%' or ".$SqlPID.")";
		
		}
if (trim($QPStatus) != "") $SqlTxt = $SqlTxt." and PStatus='".$QPStatus."' ";
if (trim($QBE) != "") $SqlTxt = $SqlTxt." and BMUID='".$QBE."' ";
if (trim($QBMUID) != "") $SqlTxt = $SqlTxt." and ifnull(BMUID,'vivi')='".$QBMUID."' ";
if (trim($ISINo) != "") {
		if (trim($ISINo) == "Y") $SqlTxt = $SqlTxt." and INo <> '' ";
		else $SqlTxt = $SqlTxt." and INo = '' ";
		}
if (trim($ISAdd) != "") {
		if (trim($ISAdd) == "Y") $SqlTxt2 = " WHERE a.PCount > 0";
		else $SqlTxt2 = " WHERE a.PCount = 0";
		}

if (trim($QSDate) != "" && trim($QEDate) != "") $SqlTxt = $SqlTxt." and (AddDate >= '".$QSDate." 00:00:00') and (AddDate <= '".$QEDate." 23:59:59') ";
else if (trim($QSDate) != "" && trim($QEDate) == "") $SqlTxt = $SqlTxt." and (AddDate >= '".$QSDate." 00:00:00') ";
else if (trim($QSDate) == "" && trim($QEDate) != "") $SqlTxt = $SqlTxt." and (AddDate <= '".$QEDate." 23:59:59') ";

$SQL_Project="select a.* from (select PID,PUID,CID,CName,CTel,CFax,Contact,CMobile,CEMail,CAddress,PStatus,PName,ModelName,SeriesModel,BMUID,(select MName from Manager where MUID = Project.BMUID) BEName,(select MEName from Manager where MUID = Project.BMUID) BEEName,Quote,ApplyItem,Canon,SNote,StartDate,PlanDate,replace(CloseDate,'0000-00-00',''),ifnull(DATEDIFF(CloseDate,StartDate),0) ProcDate,PNote,QuoteDate,ReturnDate,(select count(PAAID) PCount from ProjectAccountingAdd where PAACheck='N' and PID=Project.PID) PCount from Project where Deltag='N' ".$SqlTxt.") as a ".$SqlTxt2." order by a.PStatus asc,a.PID desc;";
$result_Project=mysqli_query($link,$SQL_Project) or die ("無法執行查詢");

$objPHPExcel = new PHPExcel();
$objPHPExcel->setActiveSheetIndex(0);

$objPHPExcel->getActiveSheet()->setCellValue('A1',"案件編號");
$objPHPExcel->getActiveSheet()->setCellValue('B1',"案件業務");
$objPHPExcel->getActiveSheet()->setCellValue('C1',"客戶名稱");
$objPHPExcel->getActiveSheet()->setCellValue('D1',"產品名稱");
$objPHPExcel->getActiveSheet()->setCellValue('E1',"型號");
$objPHPExcel->getActiveSheet()->setCellValue('F1',"系列型式");
$objPHPExcel->getActiveSheet()->setCellValue('G1',"申請項目");
$objPHPExcel->getActiveSheet()->setCellValue('H1',"案件開始日期");
$objPHPExcel->getActiveSheet()->setCellValue('I1',"結案日期");
$objPHPExcel->getActiveSheet()->setCellValue('J1',"案件處理時間(天)");
$objPHPExcel->getActiveSheet()->setCellValue('K1',"案件狀態");
$objPHPExcel->getActiveSheet()->getStyle("A1")->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("B1")->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("C1")->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("D1")->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("E1")->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("F1")->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("G1")->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("H1")->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("I1")->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("J1")->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("K1")->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);

$Ecount=2;
while(list($PID,$PUID,$CID,$CName,$CTel,$CFax,$Contact,$CMobile,$CEMail,$CAddress,$PStatus,$PName,$ModelName,$SeriesModel,$BE,$BEName,$BEEName,$Quote,$ApplyItem,$Canon,$SNote,$StartDate,$PlanDate,$CloseDate,$ProcDate,$PNote,$QuoteDate,$ReturnDate)=mysqli_fetch_row($result_Project)){
  	if (trim($PStatus) == "A") $PStatus = "新開案";
  	else if (trim($PStatus) == "B") $PStatus = "報價中";
  	else if (trim($PStatus) == "C") $PStatus = "案件處理中";
  	else if (trim($PStatus) == "D") $PStatus = "審查中";
  	else if (trim($PStatus) == "E") $PStatus = "補件中";
  	else if (trim($PStatus) == "F") $PStatus = "待印證";
  	else if (trim($PStatus) == "G") $PStatus = "案件取消";
  	else if (trim($PStatus) == "H") $PStatus = "已結案";
	
	$objPHPExcel->getActiveSheet()->setCellValue('A'.$Ecount,$PUID);
	$objPHPExcel->getActiveSheet()->setCellValue('B'.$Ecount,$BEEName.$BEName);
	$objPHPExcel->getActiveSheet()->setCellValue('C'.$Ecount,$CName);
	$objPHPExcel->getActiveSheet()->setCellValue('D'.$Ecount,$PName);
	$objPHPExcel->getActiveSheet()->setCellValue('E'.$Ecount,$ModelName);
	$objPHPExcel->getActiveSheet()->setCellValue('F'.$Ecount,$SeriesModel);
	$objPHPExcel->getActiveSheet()->setCellValue('G'.$Ecount,$ApplyItem);
	$objPHPExcel->getActiveSheet()->setCellValue('H'.$Ecount,$StartDate);
	$objPHPExcel->getActiveSheet()->setCellValue('I'.$Ecount,$CloseDate);
	$objPHPExcel->getActiveSheet()->setCellValue('J'.$Ecount,$ProcDate);
	$objPHPExcel->getActiveSheet()->setCellValue('K'.$Ecount,$PStatus);
	$objPHPExcel->getActiveSheet()->getStyle('A'.$Ecount)->getFont()->setSize(12);
	$objPHPExcel->getActiveSheet()->getStyle('B'.$Ecount)->getFont()->setSize(12);
	$objPHPExcel->getActiveSheet()->getStyle('C'.$Ecount)->getFont()->setSize(12);
	$objPHPExcel->getActiveSheet()->getStyle('D'.$Ecount)->getFont()->setSize(12);
	$objPHPExcel->getActiveSheet()->getStyle('E'.$Ecount)->getFont()->setSize(12);
	$objPHPExcel->getActiveSheet()->getStyle('F'.$Ecount)->getFont()->setSize(12);
	$objPHPExcel->getActiveSheet()->getStyle('G'.$Ecount)->getFont()->setSize(12);
	$objPHPExcel->getActiveSheet()->getStyle('H'.$Ecount)->getFont()->setSize(12);
	$objPHPExcel->getActiveSheet()->getStyle('I'.$Ecount)->getFont()->setSize(12);
	$objPHPExcel->getActiveSheet()->getStyle('J'.$Ecount)->getFont()->setSize(12);
	$objPHPExcel->getActiveSheet()->getStyle('K'.$Ecount)->getFont()->setSize(12);
	$Ecount++;
}
mysqli_free_result($result_Project);
mysqli_close($link);
$objPHPExcel->getActiveSheet()->setTitle('ProjectExportSales');

ob_end_clean();

header('Content-Type: application/vnd.ms-excel');
header('Content-Disposition: attachment;filename="ProjectExportSales.xls"');
header('Cache-Control: max-age=0');
$objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel5');
$objWriter->save('php://output');
exit;

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $PageAdminTitle;?></title>
<link href="style.css" rel="stylesheet" type="text/css" />
<body>
<table winth="1000" border="0">
	<tr>
		<td colspan="2"><font color=blue>若您無法正常觀看此報表！請下載此 <a href="owc11.zip" target="_File"><font color=red><b>元件</b></font></a> <font color=blue>安裝至您的電腦。</font></td>
	</tr>
</table>
<object id=Project classid=CLSID:0002E559-0000-0000-C000-000000000046 style="width:100%;height:90%"></object>
<script language=vbscript>
	Sub Window_OnLoad()
	Set chConstants = Project.Constants
	Project.ActiveSheet.Cells.Clear
	Project.Worksheets(1).Select
	Project.ActiveSheet.Name ="Project"

	Project.ActiveSheet.Cells(1,1).Value ="案件編號"
	Project.ActiveSheet.Cells(1,2).Value ="案件業務"
	Project.ActiveSheet.Cells(1,3).Value ="客戶名稱"
	Project.ActiveSheet.Cells(1,4).Value ="產品名稱"
	Project.ActiveSheet.Cells(1,5).Value ="型號"
	Project.ActiveSheet.Cells(1,6).Value ="系列型式"
	Project.ActiveSheet.Cells(1,7).Value ="申請項目"
	Project.ActiveSheet.Cells(1,8).Value ="案件開始日期"
	Project.ActiveSheet.Cells(1,9).Value ="結案日期"
	Project.ActiveSheet.Cells(1,10).Value ="案件處理時間(天)"
	Project.ActiveSheet.Cells(1,11).Value ="案件狀態"
<?php  
$ECount=2;
while(list($PID,$PUID,$CID,$CName,$CTel,$CFax,$Contact,$CMobile,$CEMail,$CAddress,$PStatus,$PName,$ModelName,$SeriesModel,$BE,$BEName,$BEEName,$Quote,$ApplyItem,$Canon,$SNote,$StartDate,$PlanDate,$CloseDate,$ProcDate,$PNote,$QuoteDate,$ReturnDate)=mysqli_fetch_row($result_Project)){
  	if (trim($PStatus) == "A") $PStatus = "新開案";
  	else if (trim($PStatus) == "B") $PStatus = "報價中";
  	else if (trim($PStatus) == "C") $PStatus = "案件處理中";
  	else if (trim($PStatus) == "D") $PStatus = "審查中";
  	else if (trim($PStatus) == "E") $PStatus = "補件中";
  	else if (trim($PStatus) == "F") $PStatus = "待印證";
  	else if (trim($PStatus) == "G") $PStatus = "案件取消";
  	else if (trim($PStatus) == "H") $PStatus = "已結案";
		?>
		Project.ActiveSheet.Cells(<?php echo $ECount;?>,1).Value ="'<?php echo $PUID;?>"
		Project.ActiveSheet.Cells(<?php echo $ECount;?>,2).Value ="<?php echo $BEEName.$BEName;?>"
		Project.ActiveSheet.Cells(<?php echo $ECount;?>,3).Value ="<?php echo $CName;?>"
		Project.ActiveSheet.Cells(<?php echo $ECount;?>,4).Value ="<?php echo $PName;?>"
		Project.ActiveSheet.Cells(<?php echo $ECount;?>,5).Value ="<?php echo $ModelName;?>"
		Project.ActiveSheet.Cells(<?php echo $ECount;?>,6).Value ="<?php echo $SeriesModel;?>"
		Project.ActiveSheet.Cells(<?php echo $ECount;?>,7).Value ="<?php echo $ApplyItem;?>"
		Project.ActiveSheet.Cells(<?php echo $ECount;?>,8).Value ="'<?php echo $StartDate;?>"
		Project.ActiveSheet.Cells(<?php echo $ECount;?>,9).Value ="'<?php echo $CloseDate;?>"
		Project.ActiveSheet.Cells(<?php echo $ECount;?>,10).Value ="<?php echo $ProcDate;?>"
		Project.ActiveSheet.Cells(<?php echo $ECount;?>,11).Value ="<?php echo $PStatus;?>"
		<?php
		$ECount++;
		}
mysqli_free_result($result_Project);
mysqli_close($link);
?>

		Project.ActiveSheet.Range("A1:R<?php echo $ECount;?>").Font.Color="blue"
		Project.ActiveSheet.Range("A1:R<?php echo $ECount;?>").Font.Name="Courier New"
		Project.ActiveSheet.Range("A1:R<?php echo $ECount;?>").Font.Size="11"
		Project.ActiveSheet.Range("A1:R<?php echo $ECount;?>").Columns.AutoFit
		Project.ActiveSheet.Range("A1:R<?php echo $ECount;?>").NumberFormat ="General"

		Project.ActiveSheet.Range("A1:R1").Font.Bold=true
		Project.ActiveSheet.Range("A1:R1").Font.Color="#000000"
		Project.ActiveSheet.Range("A1:R1").Font.Bold=true
		Project.ActiveSheet.Range("A1:R1").Font.Bold=true
		Project.ActiveSheet.Range("A1:R1").Font.Bold=true

	End Sub
	</script>
</body>
</html>
