﻿<?php
include "CheckPermission.php";
include "CheckCommonAccounting.php";
include "../global.php";
include "include/page_function.php";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $PageAdminTitle;?></title>
<link href="../type.css" rel="stylesheet" type="text/css" />
<style type="text/css">
<!--
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
}
-->
</style>
<Script type="text/javascript" language="javascript" src="../script/CheckForm.js"></Script>
<script type="text/JavaScript">
<!--
function jsCheck() 
		{
		if (jsTrim(document.form1.QSCAYear.value) != "" || jsTrim(document.form1.QSCAMonth.value) != "") if (ChkDate('QSCAYear',document.form1.QSCAYear.value,document.form1.QSCAMonth.value,document.form1.QSCADay.value,'查詢起始月份') == false) return false;
		if (jsTrim(document.form1.QECAYear.value) != "" || jsTrim(document.form1.QECAMonth.value) != "") if (ChkDate('QECAYear',document.form1.QECAYear.value,document.form1.QECAMonth.value,document.form1.QECADay.value,'查詢結束月份') == false) return false;
		if (jsTrim(document.form1.QSCAYear.value) != "" && jsTrim(document.form1.QSCAMonth.value) != "" && jsTrim(document.form1.QSCADay.value) != "" && jsTrim(document.form1.QECAYear.value) != "" && jsTrim(document.form1.QECAMonth.value) != "" && jsTrim(document.form1.QECADay.value) != "") if (CompareDate('QSCAYear',document.form1.QSCAYear.value,document.form1.QSCAMonth.value,document.form1.QSCADay.value,document.form1.QECAYear.value,document.form1.QECAMonth.value,document.form1.QECADay.value,'查詢啟始月份','查詢結束月份') == false) return false;
		}

function CommonAccountingExport() 
		{
		document.form_exp.QSCAYear.value = document.form1.QSCAYear.value;
		document.form_exp.QSCAMonth.value = document.form1.QSCAMonth.value;
		document.form_exp.QSCADay.value = document.form1.QSCADay.value;
		document.form_exp.QECAYear.value = document.form1.QECAYear.value;
		document.form_exp.QECAMonth.value = document.form1.QECAMonth.value;
		document.form_exp.QECADay.value = document.form1.QECADay.value;
		document.form_exp.QCAType.value = document.form1.QCAType.value;
		document.form_exp.KeyWord.value = document.form1.KeyWord.value;
		document.form_exp.submit();
		}
//-->
</script>
</head>

<body>
<?php include "top.php";?>
<?php
$SqlTxt = "";
$CKT = "";
$QSCADate = empty($_POST['QSCADate'])?"":$_POST['QSCADate'];
if (trim($QSCADate) == "") $QSCADate = empty($_GET['QSCADate'])?"":$_GET['QSCADate'];
$QECADate = empty($_POST['QECADate'])?"":$_POST['QECADate'];
if (trim($QECADate) == "") $QECADate = empty($_GET['QECADate'])?"":$_GET['QECADate'];
if (trim($QSCADate) == "") {
		$QSCAYear = empty($_POST['QSCAYear'])?"":$_POST['QSCAYear'];
		$QSCAMonth = empty($_POST['QSCAMonth'])?"":$_POST['QSCAMonth'];
		$QSCADay = empty($_POST['QSCADay'])?"":$_POST['QSCADay'];
		if (trim($QSCAYear) != "" || trim($QSCAMonth) != "") if (checkdate($QSCAMonth,$QSCADay ,$QSCAYear)) $QSCADate = $QSCAYear."-".$QSCAMonth."-".$QSCADay;
		}
if (trim($QECADate) == "") {
		$QECAYear = empty($_POST['QECAYear'])?"":$_POST['QECAYear'];
		$QECAMonth = empty($_POST['QECAMonth'])?"":$_POST['QECAMonth'];
		$QECADay = empty($_POST['QECADay'])?"":$_POST['QECADay'];
		if (trim($QECAYear) != "" || trim($QECAMonth) != "") if (checkdate($QECAMonth,$QECADay ,$QECAYear)) $QECADate = $QECAYear."-".$QECAMonth."-".$QECADay;
		}
$QCAType = empty($_POST['QCAType'])?"":$_POST['QCAType'];
if (trim($QCAType) == "") $QCAType = empty($_GET['QCAType'])?"":$_GET['QCAType'];
$KeyWord = empty($_POST['KeyWord'])?"":$_POST['KeyWord'];
if (trim($KeyWord) == "") $KeyWord = empty($_GET['KeyWord'])?"":$_GET['KeyWord'];

if (trim($QSCADate) != "" && trim($QECADate) != "") $SqlTxt = $SqlTxt." and (CADate >= '".$QSCADate."') and (CADate <= '".$QECADate."') ";
else if (trim($QSCADate) != "" && trim($QECADate) == "") $SqlTxt = $SqlTxt." and (CADate >= '".$QSCADate."') ";
else if (trim($QSCADate) == "" && trim($QECADate) != "") $SqlTxt = $SqlTxt." and (CADate <= '".$QECADate."') ";
if (trim($QCAType) != "") $SqlTxt = $SqlTxt." and CAType='".$QCAType."' ";
if (trim($KeyWord) != "") $SqlTxt = $SqlTxt." and (CAUID like '%".$KeyWord."%' or CAItem like '%".$KeyWord."%' or Invoice like '%".$KeyWord."%' or Amount like '%".$KeyWord."%' or CANote like '%".$KeyWord."%')";
?>
<table width="100%" border="0" cellspacing="0" cellpadding="5">
	<tr>
    <td width="160" height="600" align="left" valign="top">
			<?php include "menu.php";?>
    </td>
    <td valign="top">
    	<table width="100%" border="0" cellpadding="0" cellspacing="0">
    		<tr>
    			<td>
			    	<table width="750" border="0" cellpadding="0" cellspacing="0">
			    		<form name="form1" method="post" action="CommonAccounting.php" onSubmit="return jsCheck();">
			    		<tr height="30">
			    			<td width="120" class="c2">一般帳務管理</td>
			    		</tr>
			    		<tr height="30">
			    			<td class="h3"><font color=blue><b>所屬月份：</b></font>
			    				<select name="QSCAYear">
			    					<option value=""></option>
			    					<option value="2008"<?php if (trim($QSCAYear) == "2008") echo " selected";?>>2008</option>
			    					<option value="2009"<?php if (trim($QSCAYear) == "2009") echo " selected";?>>2009</option>
			    					<option value="2010"<?php if (trim($QSCAYear) == "2010") echo " selected";?>>2010</option>
			    					<option value="2011"<?php if (trim($QSCAYear) == "2011") echo " selected";?>>2011</option>
			    					<option value="2012"<?php if (trim($QSCAYear) == "2012") echo " selected";?>>2012</option>
			    					<option value="2013"<?php if (trim($QSCAYear) == "2013") echo " selected";?>>2013</option>
			    					<option value="2014"<?php if (trim($QSCAYear) == "2014") echo " selected";?>>2014</option>
			    					<option value="2015"<?php if (trim($QSCAYear) == "2015") echo " selected";?>>2015</option>
			    					<option value="2016"<?php if (trim($QSCAYear) == "2016") echo " selected";?>>2016</option>
			    					<option value="2017"<?php if (trim($QSCAYear) == "2017") echo " selected";?>>2017</option>
			    					<option value="2018"<?php if (trim($QSCAYear) == "2018") echo " selected";?>>2018</option>
			    					<option value="2019"<?php if (trim($QSCAYear) == "2019") echo " selected";?>>2019</option>
			    					<option value="2020"<?php if (trim($QSCAYear) == "2020") echo " selected";?>>2020</option>
			    					<option value="2021"<?php if (trim($QSCAYear) == "2021") echo " selected";?>>2021</option>
			    					<option value="2022"<?php if (trim($QSCAYear) == "2022") echo " selected";?>>2022</option>
			    					<option value="2023"<?php if (trim($QSCAYear) == "2023") echo " selected";?>>2023</option>
			    					<option value="2024"<?php if (trim($QSCAYear) == "2024") echo " selected";?>>2024</option>
			    					<option value="2025"<?php if (trim($QSCAYear) == "2025") echo " selected";?>>2025</option>
									<option value="2026"<?php if (trim($QSCAYear) == "2026") echo " selected";?>>2026</option>
									<option value="2027"<?php if (trim($QSCAYear) == "2027") echo " selected";?>>2027</option>
									<option value="2028"<?php if (trim($QSCAYear) == "2028") echo " selected";?>>2028</option>
									<option value="2029"<?php if (trim($QSCAYear) == "2029") echo " selected";?>>2029</option>
									<option value="2030"<?php if (trim($QSCAYear) == "2030") echo " selected";?>>2030</option>
									<option value="2031"<?php if (trim($QSCAYear) == "2031") echo " selected";?>>2031</option>
									<option value="2032"<?php if (trim($QSCAYear) == "2032") echo " selected";?>>2032</option>
									<option value="2033"<?php if (trim($QSCAYear) == "2033") echo " selected";?>>2033</option>
									<option value="2034"<?php if (trim($QSCAYear) == "2034") echo " selected";?>>2034</option>
									<option value="2035"<?php if (trim($QSCAYear) == "2035") echo " selected";?>>2035</option>
			    				</select> <font color=blue><b>年</b></font> 
			    				<select name="QSCAMonth">
			    					<option value=""></option>
			    					<option value="01"<?php if (trim($QSCAMonth) == "01") echo " selected";?>>01</option>
			    					<option value="02"<?php if (trim($QSCAMonth) == "02") echo " selected";?>>02</option>
			    					<option value="03"<?php if (trim($QSCAMonth) == "03") echo " selected";?>>03</option>
			    					<option value="04"<?php if (trim($QSCAMonth) == "04") echo " selected";?>>04</option>
			    					<option value="05"<?php if (trim($QSCAMonth) == "05") echo " selected";?>>05</option>
			    					<option value="06"<?php if (trim($QSCAMonth) == "06") echo " selected";?>>06</option>
			    					<option value="07"<?php if (trim($QSCAMonth) == "07") echo " selected";?>>07</option>
			    					<option value="08"<?php if (trim($QSCAMonth) == "08") echo " selected";?>>08</option>
			    					<option value="09"<?php if (trim($QSCAMonth) == "09") echo " selected";?>>09</option>
			    					<option value="10"<?php if (trim($QSCAMonth) == "10") echo " selected";?>>10</option>
			    					<option value="11"<?php if (trim($QSCAMonth) == "11") echo " selected";?>>11</option>
			    					<option value="12"<?php if (trim($QSCAMonth) == "12") echo " selected";?>>12</option>
			    				</select> <font color=blue><b>月</b></font><input type="hidden" name="QSCADay" value="1"> ~ 
			    				<select name="QECAYear">
			    					<option value=""></option>
			    					<option value="2008"<?php if (trim($QECAYear) == "2008") echo " selected";?>>2008</option>
			    					<option value="2009"<?php if (trim($QECAYear) == "2009") echo " selected";?>>2009</option>
			    					<option value="2010"<?php if (trim($QECAYear) == "2010") echo " selected";?>>2010</option>
			    					<option value="2011"<?php if (trim($QECAYear) == "2011") echo " selected";?>>2011</option>
			    					<option value="2012"<?php if (trim($QECAYear) == "2012") echo " selected";?>>2012</option>
			    					<option value="2013"<?php if (trim($QECAYear) == "2013") echo " selected";?>>2013</option>
			    					<option value="2014"<?php if (trim($QECAYear) == "2014") echo " selected";?>>2014</option>
			    					<option value="2015"<?php if (trim($QECAYear) == "2015") echo " selected";?>>2015</option>
			    					<option value="2016"<?php if (trim($QECAYear) == "2016") echo " selected";?>>2016</option>
			    					<option value="2017"<?php if (trim($QECAYear) == "2017") echo " selected";?>>2017</option>
			    					<option value="2018"<?php if (trim($QECAYear) == "2018") echo " selected";?>>2018</option>
			    					<option value="2019"<?php if (trim($QECAYear) == "2019") echo " selected";?>>2019</option>
			    					<option value="2020"<?php if (trim($QECAYear) == "2020") echo " selected";?>>2020</option>
			    					<option value="2021"<?php if (trim($QECAYear) == "2021") echo " selected";?>>2021</option>
			    					<option value="2022"<?php if (trim($QECAYear) == "2022") echo " selected";?>>2022</option>
			    					<option value="2023"<?php if (trim($QECAYear) == "2023") echo " selected";?>>2023</option>
			    					<option value="2024"<?php if (trim($QECAYear) == "2024") echo " selected";?>>2024</option>
			    					<option value="2025"<?php if (trim($QECAYear) == "2025") echo " selected";?>>2025</option>
									<option value="2026"<?php if (trim($QECAYear) == "2026") echo " selected";?>>2026</option>
									<option value="2027"<?php if (trim($QECAYear) == "2027") echo " selected";?>>2027</option>
									<option value="2028"<?php if (trim($QECAYear) == "2028") echo " selected";?>>2028</option>
									<option value="2029"<?php if (trim($QECAYear) == "2029") echo " selected";?>>2029</option>
									<option value="2030"<?php if (trim($QECAYear) == "2030") echo " selected";?>>2030</option>
									<option value="2031"<?php if (trim($QECAYear) == "2031") echo " selected";?>>2031</option>
									<option value="2032"<?php if (trim($QECAYear) == "2032") echo " selected";?>>2032</option>
									<option value="2033"<?php if (trim($QECAYear) == "2033") echo " selected";?>>2033</option>
									<option value="2034"<?php if (trim($QECAYear) == "2034") echo " selected";?>>2034</option>
									<option value="2035"<?php if (trim($QECAYear) == "2035") echo " selected";?>>2035</option>
			    				</select> <font color=blue><b>年</b></font> 
			    				<select name="QECAMonth">
			    					<option value=""></option>
			    					<option value="01"<?php if (trim($QECAMonth) == "01") echo " selected";?>>01</option>
			    					<option value="02"<?php if (trim($QECAMonth) == "02") echo " selected";?>>02</option>
			    					<option value="03"<?php if (trim($QECAMonth) == "03") echo " selected";?>>03</option>
			    					<option value="04"<?php if (trim($QECAMonth) == "04") echo " selected";?>>04</option>
			    					<option value="05"<?php if (trim($QECAMonth) == "05") echo " selected";?>>05</option>
			    					<option value="06"<?php if (trim($QECAMonth) == "06") echo " selected";?>>06</option>
			    					<option value="07"<?php if (trim($QECAMonth) == "07") echo " selected";?>>07</option>
			    					<option value="08"<?php if (trim($QECAMonth) == "08") echo " selected";?>>08</option>
			    					<option value="09"<?php if (trim($QECAMonth) == "09") echo " selected";?>>09</option>
			    					<option value="10"<?php if (trim($QECAMonth) == "10") echo " selected";?>>10</option>
			    					<option value="11"<?php if (trim($QECAMonth) == "11") echo " selected";?>>11</option>
			    					<option value="12"<?php if (trim($QECAMonth) == "12") echo " selected";?>>12</option>
			    				</select> <font color=blue><b>月</b></font><input type="hidden" name="QECADay" value="1">
			    			</td>
			    		</tr>
			    		<tr height="30">
			    			<td class="h3">
			    				<font color=blue><b>類　別：</b></font>
			          	<select name="QCAType">
			          		<option value="">不限</option>
			          		<option value="C"<?php if (trim($QCAType) == "C") echo " selected";?>>公司</option>
			          		<option value="P"<?php if (trim($QCAType) == "P") echo " selected";?>>個人</option>
			          	</select>　
			    				<font color=blue><b>關鍵字：</b></font><input type="text" name="KeyWord" size="15" value="<?php echo $KeyWord;?>">　
			    				<input type="submit" name="submit" value="查 詢" class="input_bot">　
			    				<input type="button" name="button" class="input_bot" value="全部列出" onclick="javascript:location.href='CommonAccounting.php';">　
			    				<input type="button" name="report" class="input_bot" value="報表輸出" onclick="javascript:CommonAccountingExport();">
			    			<td width="60" align="right" class="h3"><input type="button" name="add" value="新 增" class="input_bot" onclick="javascript:location.href='CommonAccountingAdd.php';"></td>
			    			<td width="20"></td>
			    		</tr>
			    		</form>
			    	</table>
						<?php
						if (trim($SqlTxt) == "") $SqlTxt = " and (CADate = '".date("Y-m",mktime())."-1') ";
						$page = empty($_GET['page'])?"":$_GET['page'];
						if (trim($page) == "") $page = 1;
						$page_rows=15;  //每頁筆數
						$php_Self = "CommonAccounting.php";  //分頁web檔名
						$button_css = "h4";
						$limit_txt =" limit ".(($page-1) * $page_rows).",".$page_rows;
						$url_str = "&QCAType=".$QCAType."&QSCADate=".$QSCADate."&QECADate=".$QECADate."&KeyWord=".urlencode($KeyWord);
						$Sql_str="select CAID,CADate,date_format(CADate,'%Y'),date_format(CADate,'%m'),CAItem,CAType,Amount,InvoiceDate,Invoice,CAStatus,PayDate,CANote from CommonAccounting where Deltag='N' ".$SqlTxt." order by CAID desc;";
						$SQL_CommonAccounting="select CAID,CAUID,CADate,date_format(CADate,'%Y'),date_format(CADate,'%m'),CAItem,CAType,Amount,InvoiceDate,Invoice,CAStatus,PayDate,CANote,CAFile from CommonAccounting where Deltag='N' ".$SqlTxt." order by CAID desc ".$limit_txt.";";
						$result_CommonAccounting=mysqli_query($link,$SQL_CommonAccounting) or die ("無法執行查詢");
						$Sql_sum="select sum(Amount) from CommonAccounting where Deltag='N' ".$SqlTxt.";";
						$result_sum=mysqli_query($link,$Sql_sum) or die ("無法執行查詢");
						list($Amount_sum)=mysqli_fetch_row($result_sum);
						mysqli_free_result($result_sum);
						?>
			    	<table width="750" border="0" cellpadding="0" cellspacing="0">
			    		<tr>
			    			<td class="c2">小計：<?php echo $Amount_sum;?></td>
			    		</tr>
			    	</table>
			    	<table width="750" border="0" cellpadding="5" cellspacing="2" class="s2">
			        <tr align="center">
			          <td width="80" background="../images/table_bg.gif" class="t21">帳目编號</td>
			          <td width="60" background="../images/table_bg.gif" class="t21">所屬<br>月份</td>
			          <td width="170" background="../images/table_bg.gif" class="t21">項 目</td>
			          <td width="50" background="../images/table_bg.gif" class="t21">類 別</td>
			          <td width="70" background="../images/table_bg.gif" class="t21">金 額</td>
			          <td width="60" background="../images/table_bg.gif" class="t21">狀 態</td>
			          <td width="150" background="../images/table_bg.gif" class="t21">備 註</td>
					  <td width="100" background="../images/table_bg.gif" class="t21">下載檔案</td>
			          <td width="50" background="../images/table_bg.gif" class="t21">修 改</td>
			          <td width="50" background="../images/table_bg.gif" class="t21">刪 除</td>
			        </tr>
		          <?php
		          $tmp = 1;
		          while(list($CAID,$CAUID,$CADate,$CAYear,$CADay,$CAItem,$CAType,$Amount,$InvoiceDate,$Invoice,$CAStatus,$PayDate,$CANote,$CAFile)=mysqli_fetch_row($result_CommonAccounting)){
		        	?>
		        	<tr<?php if ($tmp%2 == 0) echo " bgcolor=\"#F6F6F6\"";?>>
			          <td class="h3" align="center"><?php echo $CAUID;?></td>
			          <td class="h3" align="center"><?php echo $CAYear."/".$CADay;?></td>
			          <td class="h3"><?php echo $CAItem;?></td>
			          <td align="center" class="h3">
			          	<?php
			          	if (trim($CAType) == "C") echo "公司";
			          	else if (trim($CAType) == "P") echo "個人";
			          	?>
			          </td>
			          <td class="h3" align="center"><?php echo $Amount;?></td>
			          <td align="center" class="h3">
			          	<?php
			          	if (trim($CAStatus) == "W") echo "未付";
			          	else if (trim($CAStatus) == "S") echo "<font color=blue>結清</font><br>".$PayDate;
			          	else if (trim($CAStatus) == "C") echo "<font color=red>取消</font>";
			          	?>
			          </td>
					  <td class="h3"><?php echo $CANote;?></td>
			          <td class="h3"><?php if(!empty($CAFile)){?><a href="getfile.php?FolderName=Admin\\CAFile&FileName=<?php echo $CAFile;?>">下載檔案</a></td><?php } ?>
			          <td align="center"><input type="button" name="edit" value="修 改" class="input_bot" onclick="javascript:location.href='CommonAccountingEdit.php?CAID=<?php echo $CAID;?>&page=<?php echo $page;?><?php echo $url_str;?>';"></td>
			          <?php
			          if (trim($_SESSION["reg_MUID"]) == "Benson" || trim($_SESSION["reg_MUID"]) == "amanda" || trim($_SESSION["reg_MUID"]) == "jacky") $CKT="";
			          else if (trim($CAStatus) == "S") $CKT=" disabled";
			          ?>
			          <td align="center"><input type="button" name="edit" value="刪 除" class="input_bot" onclick="javascript:if (confirm('您是否確定要刪除？')) location.href='CommonAccountingDelDB.php?CAID=<?php echo $CAID;?>&page=<?php echo $page;?><?php echo $url_str;?>';"<?php echo $CKT;?>></td>
			        </tr>
			        <?php
            			$tmp++;
			      			}
            	mysqli_free_result($result_CommonAccounting);
			        ?>
			      </table>
			      <table width="750" border="0" cellpadding="5" cellspacing="2" class="s2">
			        <tr align="center">
			          <td bgcolor="#E8F0C2" class="h4"><?php Page_show($Sql_str,$page_rows,$php_Self,$link,$page,$url_str,$button_css);?></td>
			        </tr>
			      </table>
    			</td>
    		</tr>
    	</table>
    </td>
	</tr>
</table>
<form name="form_exp" action="CommonAccountingExport.php" method="post" target="_CommonAccountingExport">
	<input type="hidden" name="QSCAYear">
	<input type="hidden" name="QSCAMonth">
	<input type="hidden" name="QSCADay">
	<input type="hidden" name="QECAYear">
	<input type="hidden" name="QECAMonth">
	<input type="hidden" name="QECADay">
	<input type="hidden" name="QCAType">
	<input type="hidden" name="KeyWord">
</form>
<?php include "down.php";?>
</body>
</html>
<?php
mysqli_close($link);
?>