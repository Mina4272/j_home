﻿<?php	
include "CheckPermission.php";
include "CheckProject.php";
include "../global.php";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $PageAdminTitle;?></title>
<link href="../type.css" rel="stylesheet" type="text/css" />
<style type="text/css">
<!--
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
}
-->
</style>
<link href="../script/DatePicker.css" rel="stylesheet" type="text/css" />
<Script LANGUAGE="Javascript" SRC="../script/DatePicker.js"></Script>
<Script type="text/javascript" language="javascript" src="../script/CheckForm.js"></Script>
<script type="text/JavaScript">
<!--
function jsCheck() 
		{
		if (ChkImp('CContent',document.form1.CContent.value,'客戶備註') == false) return false;
		}
//-->
</script>
</head>
<body>
<?php
$CNID = $_GET['CNID'];
$CID = $_GET['CID'];
if (trim($CID) == "" || trim($CNID) == "")
		{
		mysqli_close($link);
		?>
		<script type="text/JavaScript">
			<!--
			alert ("查無資料，請冾網站管理人員！");
			self.close();
			//-->
		</script>
		<?php
		exit;
		}
$SQL_CustomerNote="select CContent,AddUser,AddDate,ProcUser,ProcDate from CustomerNote where Deltag='N' and CID = '".$CID."' and CNID = '".$CNID."';";
$result_CustomerNote=mysqli_query($link,$SQL_CustomerNote) or die ("無法執行查詢");
if (mysqli_num_rows($result_CustomerNote) == 0)
		{
		mysqli_free_result($result_CustomerNote);
		mysqli_close($link);
		?>
		<SCRIPT language=javascript>
		<!--
		alert ("查無資料，請冾網站管理人員！"); 
		self.close();
		//-->
		</SCRIPT>
		<?php 	
		exit;
		}
list($CContent,$AddUser,$AddDate,$ProcUser,$ProcDate)=mysqli_fetch_row($result_CustomerNote);
mysqli_free_result($result_CustomerNote);
?>
<table width="100%" border="0" cellpadding="0" cellspacing="0">
	<tr>
		<td>
    	<table width="100%" border="0" cellpadding="0" cellspacing="0">
    		<tr height="30">
					<td width="15" background="../images/table_bg.gif"></td>
    			<td class="c3" background="../images/table_bg.gif"><b>修改客戶備註</b></td>
    		</tr>
    	</table>
    	<table width="100%" border="0" cellpadding="0" cellspacing="0">
        <form name="form1" method="post" action="CustomerNoteEditDB.php" onSubmit="return jsCheck();">
        <tr height="25" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
					<td width="15"></td>
          <td class="c3">客戶備註：</td>
        </tr>
        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
					<td width="15"></td>
          <td class="h3">
          	<textarea name="CContent" cols="60" rows="10" class="h3"><?php echo str_replace("<br>","\r\n",$CContent);?></textarea>
          	<input name="CNID" type="hidden" id="CNID" value="<?php echo $CNID;?>" />
          	<input name="CID" type="hidden" id="CID" value="<?php echo $CID;?>" />
          </td>
        </tr>
        <tr height="25" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
					<td width="15"></td>
          <td class="c3">新增人員：<span class="h3"><?php echo $AddUser;?>　<?php echo $AddDate;?></span></td>
        </tr>
        <?php if (trim($ProcUser) != "") {?>
        <tr height="25" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
					<td width="15"></td>
          <td class="c3">最後更新：<span class="h3"><?php echo $ProcUser;?>　<?php echo $ProcDate;?></span>
          	<input type="button" name="edit" value="歷史記錄" class="input_bot" onclick="javascript:window.open ('CustomerNoteHistory.php?CID=<?php echo $CID;?>&CNID=<?php echo $CNID;?>','CustomerNoteHistory','height=500,width=750,top=200,left=200,scrollbars=yes,status=yes');">
          </td>
        </tr>
        <?php }?>
        <tr height="35" align="center">
					<td width="15"></td>
          <td class="h3"><input type="submit" name="submit" class="input_bot" value="送 出"></td>
        </tr>
	      </form>
      </table>
		</td>
	</tr>
</table>
</body>
</html>
<?php
mysqli_close($link);
?>