﻿<?php
include "CheckPermission.php";
include "../global.php";
include "include/page_function.php";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $PageAdminTitle;?></title>
<link href="../type.css" rel="stylesheet" type="text/css" />
<style type="text/css">
<!--
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
}
-->
</style>
<script type="text/JavaScript">
<!--
function jsCheck() 
		{
		if (ChkImp('MKeyword',document.form1.MKeyword.value,'搜尋') == false)
				{
				document.form1.MKeyword.focus();
				document.form1.MKeyword.select();
				return false;
				}
		}
//-->
</script>
</head>

<body>
<?php include "top.php";?>
<?php
$sql = "SELECT count(MUID) Rcount FROM Manager WHERE IsLeft = 'N' AND Deltag = 'N' AND RDate IS NOT NULL AND date_format( RDate, '%Y' ) <> date_format( now( ) , '%Y' ) AND date_format( RDate, '%m' ) = date_format( now( ) , '%m' )";
$result=mysqli_query($link,$sql) or die ("無法執行修改");
list($Rcount)=mysqli_fetch_row($result);
mysqli_free_result($result);

$_SESSION["reg_Remind"]=0;

if ($Rcount > 0 && $_SESSION["reg_Remind"] <> 1) {
		$_SESSION["reg_Remind"] = 1;
		?>
		<script type="text/JavaScript">
				<!--
				window.open ('Remind.php', 'newwindow', 'height=300, width=540, top=200, left=200, toolbar=no, menubar=no, scrollbars=yes, resizable=no,location=no, status=no');
				//-->
		</script>
		<?php
		}

$sql = "SELECT count(MUID) Rcount FROM Manager WHERE IsLeft = 'N' AND Deltag = 'N' AND BirthDay IS NOT NULL AND date_format( BirthDay, '%Y' ) <> date_format( now( ) , '%Y' ) AND date_format( BirthDay, '%m' ) = date_format( now( ) , '%m' )";
$result=mysqli_query($link,$sql) or die ("無法執行修改");
list($Rcount)=mysqli_fetch_row($result);
mysqli_free_result($result);

if ($Rcount > 0 && $_SESSION["reg_Remind"] <> 1) {
		$_SESSION["reg_Remind"] = 1;
		?>
		<script type="text/JavaScript">
				<!--
				window.open ('Remind_Birthday.php', 'newwindow2', 'height=300, width=540, top=300, left=300, toolbar=no, menubar=no, scrollbars=yes, resizable=no,location=no, status=no');
				//-->
		</script>
		<?php
		}

		
$sql = "SELECT count(ReceiveMid) Rcount FROM managerjob WHERE ReceiveMid ='".$_SESSION["reg_MID"]."'";
$result=mysqli_query($link,$sql) or die ("無法執行修改");
list($Rcount)=mysqli_fetch_row($result);
mysqli_free_result($result);

if ($Rcount > 0) {
	
		
?>
<script type="text/JavaScript">
				<!--
				window.open ('ManagerJobcheck.php', 'ManagerJobcheck', 'height=300, width=540, top=300, left=300, toolbar=no, menubar=no, scrollbars=yes, resizable=no,location=no, status=no');
				//-->
		</script>
		<?php
		}
		
		//$sql = "SELECT count(*) Rcount from Project a,ProjectCertificate b where a.PID=b.PID and a.Deltag='N' and b.Deltag='N'and b.PCEDate != '' and b.PCEDate >='".date('Y-m-d')."' and b.PCEDate2 != '' and b.PCEDate2 <= '".date('Y-m-d')."' order by b.PCID desc";
		//echo $sql; 
		//$result=mysqli_query($link,$sql) or die ("無法執行修改");
		//list($Rcount)=mysqli_fetch_row($result);
		//mysqli_free_result($result);

//if ($Rcount > 0) {
?>
<!--
<script type="text/JavaScript">
			
				window.open ('Over.php', 'Over', 'height=300, width=540, top=300, left=300, toolbar=no, menubar=no, scrollbars=yes, resizable=no,location=no, status=no');
				
		</script>
		-->
<?php
//		}
?>
	
<table width="100%" border="0" cellspacing="0" cellpadding="5">
	<tr>
    <td width="160" height="600" align="left" valign="top">
			<?php include "menu.php";?>
		</td>
    <td valign="top">
    	<table width="100%" border="0" cellpadding="0" cellspacing="0">
    		<tr>
    			<td>
			    	<table width="750" border="0" cellpadding="0" cellspacing="0">
			    		<tr height="30">
			    			<td class="t2">登入成功！

				          	<input type="button" id="BTN_REMIND" name="BTN_REMIND" class="reminder_bot" value="提 醒" onclick="javascript:window.open ('Remind.php', 'newwindow', 'height=300, width=540, top=200, left=200, toolbar=no, menubar=no, scrollbars=yes, resizable=no,location=no, status=no');">

			    			<span class="h3">您上次登入的時間為</span> <span class="c3"><?php echo $_SESSION["reg_MLoginTime"];?></span>
			    			</td>
			    		</tr>
			    		<tr height="30">
			    			<td class="h3">請選擇維護項目！</td>
			    		</tr>

			    		<form name="form1" action="index.php" method="post">
			    		<tr>
			    			<td width="240" align="right" class="h3">關鍵字：<input type="text" name="KeyWord" size="20" value="<?php echo empty($KeyWord)?"":$KeyWord;?>"></td>
			    			<!--td align="left" class="h3"-->
			    				<!--select name="QPStatus">
			    					<option value="">不限</option>
			    					<option value="A"<?php if (trim($QPStatus) == "A") echo " selected";?>>新開案</option>
			    					<option value="B"<?php if (trim($QPStatus) == "B") echo " selected";?>>報價中</option>
			    					<option value="C"<?php if (trim($QPStatus) == "C") echo " selected";?>>案件處理中</option>
			    					<option value="D"<?php if (trim($QPStatus) == "D") echo " selected";?>>審查中</option>
			    					<option value="E"<?php if (trim($QPStatus) == "E") echo " selected";?>>補件中</option>
			    					<option value="F"<?php if (trim($QPStatus) == "F") echo " selected";?>>待印證</option>
			    					<option value="G"<?php if (trim($QPStatus) == "G") echo " selected";?>>案件取消</option>
			    					<option value="H"<?php if (trim($QPStatus) == "H") echo " selected";?>>已結案</option>
			    				</select-->　
			    			</td> 		    				
			    			<td>	<input type="submit" name="search" class="input_bot" value="查詢">　 
	
						</td>
			    		</tr>
			    		<?php 
			    		//mysql_free_result($result_ProjectCount);
			    		?>
			    		</form>


			    	</table>
				
				<table width="750" border="0" cellpadding="5" cellspacing="2" class="s2">
			        <tr align="center">
			          <td width="120" align="center" background="../images/table_bg.gif" class="t21">編號<br>名稱</td>
			          <td width="150" background="../images/table_bg.gif" class="t21">客戶名稱<br>型號</td>
			          <td width="150" background="../images/table_bg.gif" class="t21">相關案件<br>案件工程師</td>
			          <td width="90" background="../images/table_bg.gif" class="t21">有效日期</td>
			          <td width="170" background="../images/table_bg.gif" class="t21">備註</td>
			          <td width="70" background="../images/table_bg.gif" class="t21">詳細<br>取消提醒</td>
			        </tr>
			    	<?php
						$page = empty($_GET['page'])?"":$_GET['page'];
						if (trim($page) == "") $page = 1;
						$page_rows=15;  //每頁筆數
						$php_Self = "index.php";  //分頁web檔名

						$button_css = "h4";
						$limit_txt =" limit ".(($page-1) * $page_rows).",".$page_rows;
						
						$url_str = "";
						
							
						//*** 2013-0525 Keywork search, Start
						$KeyWord = empty($_POST['KeyWord'])?"":$_POST['KeyWord'];
						if (trim($KeyWord) == "") $KeyWord = empty($_GET['KeyWord'])?"":$_GET['KeyWord'];
	
						if (trim($KeyWord) != "") {
								$KeyWordArr = explode("\+",$KeyWord);
								$count_i=count($KeyWordArr);
								$SqlPID = "";
								for ($temp=0;$temp<=$count_i-1;$temp++){
										//echo "KeyWordArr=".$KeyWordArr[$temp]."<br>";
										if (trim($KeyWordArr[$temp]) != "") {
												$Keyword=empty($Keyword)?"":$Keyword."+".$KeyWordArr[$temp];
												$SQL_ProjectCertificate="select b.PCID,a.PID,b.PCNo,b.PCName,b.PCFile,b.PCSDate,b.PCEDate,b.PCNote,a.PName,a.PE,a.CName,a.PName,a.ModelName,a.SeriesModel,b.ExpireDate from Project a,ProjectCertificate b where a.PID=b.PID and a.Deltag='N' and b.Deltag='N' and b.ISRemind='N' and b.ExpireDate <> '0000-00-00' and b.ExpireDate < '".date ("Y/m/d", mktime (0,0,0,date("m")+3,date("d"),date("Y")))."' and PName like '%".$KeyWordArr[$temp]."%' and b.PCEDate >='".date('Y-m-d')."' order by b.PCEDate";
												$Sql_str = $SQL_ProjectCertificate;												
												//$result_ProjectCertificate=mysql_query($SQL_ProjectCertificate,$link) or die ("無法執行查詢");
												//while(list($PC_PID)=mysql_fetch_row($result_ProjectCertificate)){
												//		if (trim($SqlPID) == "") $SqlPID = $PC_PID;
												//		else $SqlPID = $SqlPID.",".$PC_PID;
												//		}
												//mysql_free_result($result_ProjectCertificate);

												//$SQL_ProjectAccounting="select PID from ProjectAccounting where Deltag='N'  and (PANo like '%".$KeyWordArr[$temp]."%' or PAItem like '%".$KeyWordArr[$temp]."%' or Invoice like '%".$KeyWordArr[$temp]."%' or PANote like '%".$KeyWordArr[$temp]."%') group by PID order by PID;";
												//$result_ProjectAccounting=mysql_query($SQL_ProjectAccounting,$link) or die ("無法執行查詢");
												//while(list($PC_PID)=mysql_fetch_row($result_ProjectAccounting)){
												//		if (trim($SqlPID) == "") $SqlPID = $PC_PID;
												//		else $SqlPID = $SqlPID.",".$PC_PID;
												//		}
												//mysql_free_result($result_ProjectAccounting);

												//if (trim($Sql_Txt) == "") $Sql_Txt = "PUID like '%".$KeyWordArr[$temp]."%' or CName like '%".$KeyWordArr[$temp]."%' or CTel like '%".$KeyWordArr[$temp]."%' or CFax like '%".$KeyWordArr[$temp]."%' or Contact like '%".$KeyWordArr[$temp]."%' or CMobile like '%".$KeyWordArr[$temp]."%' or CEMail like '%".$KeyWordArr[$temp]."%' or CAddress like '%".$KeyWordArr[$temp]."%' or PName like '%".$KeyWordArr[$temp]."%' or ModelName like '%".$KeyWordArr[$temp]."%' or SeriesModel like '%".$KeyWordArr[$temp]."%' or PE like '%".$KeyWordArr[$temp]."%' or PNote like '%".$KeyWordArr[$temp]."%' or ApplyItem like '%".$KeyWordArr[$temp]."%' or EMC like '%".$KeyWordArr[$temp]."%' or Canon like '%".$KeyWordArr[$temp]."%'";
												//else $Sql_Txt = $Sql_Txt." or PUID like '%".$KeyWordArr[$temp]."%' or CName like '%".$KeyWordArr[$temp]."%' or CTel like '%".$KeyWordArr[$temp]."%' or CFax like '%".$KeyWordArr[$temp]."%' or Contact like '%".$KeyWordArr[$temp]."%' or CMobile like '%".$KeyWordArr[$temp]."%' or CEMail like '%".$KeyWordArr[$temp]."%' or CAddress like '%".$KeyWordArr[$temp]."%' or PName like '%".$KeyWordArr[$temp]."%' or ModelName like '%".$KeyWordArr[$temp]."%' or SeriesModel like '%".$KeyWordArr[$temp]."%' or PE like '%".$KeyWordArr[$temp]."%' or PNote like '%".$KeyWordArr[$temp]."%' or ApplyItem like '%".$KeyWordArr[$temp]."%' or EMC like '%".$KeyWordArr[$temp]."%' or Canon like '%".$KeyWordArr[$temp]."%'";
												}
										}
								
								}
						else{
							$SQL_ProjectCertificate="select b.PCID,a.PID,b.PCNo,b.PCName,b.PCFile,b.PCSDate,b.PCEDate,b.PCNote,a.PName,a.PE,a.CName,a.PName,a.ModelName,a.SeriesModel,b.ExpireDate from Project a,ProjectCertificate b where a.PID=b.PID and a.Deltag='N' and b.Deltag='N' and b.PCEDate >='".date('Y-m-d')."' and b.ISRemind='N' and b.ExpireDate <> '0000-00-00' and b.ExpireDate < '".date ("Y/m/d", mktime (0,0,0,date("m")+3,date("d"),date("Y")))."' order by b.PCEDate";
							$Sql_str=$SQL_ProjectCertificate;
							$SQL_ProjectCertificate=$SQL_ProjectCertificate.$limit_txt.";";								
						}								
						
						//if (trim($Sql_Txt) != "" && trim($SqlPID) != "") $SqlTxt = $SqlTxt." and (".$Sql_Txt." or PID in (".$SqlPID."))";
						//else if (trim($Sql_Txt) != "" && trim($SqlPID) == "") $SqlTxt = $SqlTxt." and (".$Sql_Txt.")";
						//else if (trim($Sql_Txt) != "" && trim($SqlPID) == "") $SqlTxt = $SqlTxt." and PID in (".$SqlPID.")";		

						//$Sql_str="select b.PCID from Project a,ProjectCertificate b where a.PID=b.PID and a.Deltag='N' and b.Deltag='N' and b.ISRemind='N' and b.ExpireDate <> '0000-00-00' and b.ExpireDate < '".date ("Y/m/d", mktime (0,0,0,date("m")+3,date("d"),date("Y")))."' order by b.ExpireDate desc;";
						//*** 2013-0525 Keywork search, End
						
						//2013-05-13,order by 證書到期日 PCEDate
						//$SQL_ProjectCertificate="select b.PCID,a.PID,b.PCNo,b.PCName,b.PCFile,b.PCSDate,b.PCEDate,b.PCNote,a.PName,a.PE,a.CName,a.PName,a.ModelName,a.SeriesModel,b.ExpireDate from Project a,ProjectCertificate b where a.PID=b.PID and a.Deltag='N' and b.Deltag='N' and b.ISRemind='N' and b.ExpireDate <> '0000-00-00' and b.ExpireDate < '".date ("Y/m/d", mktime (0,0,0,date("m")+3,date("d"),date("Y")))."' order by b.ExpireDate desc ".$limit_txt.";";
	
						//echo $SQL_ProjectCertificate;

						$result_ProjectCertificate=mysqli_query($link,$SQL_ProjectCertificate) or die ("無法執行查詢1");
			    	?>
			    	
		          <?php
		          $tmp = 1;
		          while(list($PCID,$PID,$PCNo,$PCName,$PCFile,$PCSDate,$PCEDate,$PCNote,$PName,$PE,$CName,$PName,$ModelName,$SeriesModel,$ExpireDate)=mysqli_fetch_row($result_ProjectCertificate)){
								$SQL_Manager="SELECT MName,MEName FROM Manager Where Deltag='N' and MUID='".$PE."'";
								$result_Manager=mysqli_query($link,$SQL_Manager) or die ("無法執行查詢2");
								list($MName,$MEName)=mysqli_fetch_row($result_Manager);
								mysqli_free_result($result_Manager);
		        	?>
		        	<tr<?php if ($tmp%2 == 0) echo " bgcolor=\"#F6F6F6\"";?>>
			          <td width="120" class="h3">
			          	<?php echo $PCNo;?><br>
			          	<a href="getfile.php?FolderName=Admin\\PCFile&FileName=<?php echo $PCFile;?>"><?php echo $PCName;?></a>
			          </td>
			          <td width="150" class="h3">
			          	<?php
			          	echo $CName."<br>".$ModelName;
			          	?>
			          </td>
			          <td width="150" class="h3"><?php echo $PName;?><br><?php echo $MEName.$MName;?></td>
			          <?php if (trim($PCEDate) == "0000-00-00") echo $PCEDate="";?>
			          <td width="90" class="h3" align="center"><?php echo $PCSDate;?><br> ~ <br><?php echo $PCEDate;?></td>
			          <td width="170" class="h3"><?php echo $PCNote;?></td>
			          <td width="70" align="center">
			          	<input type="button" name="edit" value="詳細" class="input_bot" onclick="javascript:location.href='ProjectDetail.php?PID=<?php echo $PID;?>';">
			          	<input type="button" name="Remind" value="取消" class="input_bot" onclick="javascript:window.open ('ProjectCertificateRemind.php?PID=<?php echo $PID;?>&PCID=<?php echo $PCID;?>','SelCustomer','height=340,width=700,top=200,left=200,scrollbars=yes,status=yes');">
			          </td>
			        </tr>
			        <?php
            			$tmp++;
			      			}
            	mysqli_free_result($result_ProjectCertificate);
			        ?>
			    	</table>
			      <table width="750" border="0" cellpadding="5" cellspacing="2" class="s2">
			        <tr align="center">
			          <td bgcolor="#E8F0C2" class="h4"><?php Page_show($Sql_str,$page_rows,$php_Self,$link,$page,$url_str,$button_css);?></td>
			        </tr>
			      </table>
    			</td>
    		</tr>
    	</table>
    </td>
	</tr>
</table>
<?php include "down.php";?>
</body>
</html>
<?php
mysqli_close($link);
?>