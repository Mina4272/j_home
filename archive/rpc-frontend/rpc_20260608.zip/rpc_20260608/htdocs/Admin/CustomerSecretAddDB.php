﻿<?php
include "CheckPermission.php";
include "CheckCustomer.php";
if (trim(strstr($_SESSION["reg_MPer"],'P')) == "" && trim(strstr($_SESSION["reg_MPer"],'Q')) == "") exit;
include "../global.php";
include "include/function.php";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $PageAdminTitle;?></title>
</head>
<body>
<?php
$CID = $_POST['CID'];
$CSMode = $_POST['CSMode'];
$CSContent = $_POST['CSContent'];

if(trim($_FILES['CSFile']['tmp_name']) != "")
		{
		if($_FILES['CSFile']['size'] > 20971520)
				{
				?>
				<script type="text/JavaScript">
					<!--
					alert ("您上傳的檔案 Size 超過 20 M，請重新上傳！");
					history.go(-1);
					//-->
				</script>
				<?php
				exit();
				}
		$PFIntro1 = empty($_POST['PFIntro1'])?"":$_POST['PFIntro1'];
		$CSFile = "CSFile_".$CID.date("ymdHis",mktime()).rand_string(5, 'ABCDEFGHIJKLMNPQRSTUVWXYZ23456789abcdefghijklmnopqrstuvwxyz').".".strtolower(substr($_FILES['CSFile']['name'],strrpos($_FILES['CSFile']['name'],".")+1,strlen($_FILES['CSFile']['name'])+1));
		@copy($_FILES['CSFile']['tmp_name'],$_SERVER["DOCUMENT_ROOT"]."\\Admin\\CFile\\".$CSFile);
		}

if (trim($CID) == "" || trim($CSMode) == "" || trim($CSContent) == "")
		{
		mysqli_close($link);
		?>
		<script type="text/JavaScript">
			<!--
			alert ("您輸入的資料不足，請重新輸入！");
			self.close();
			//-->
		</script>
		<?php
		exit;
		}

$now_time = date("Y-m-d H:i:s",mktime());
$sql_insert = "insert into CustomerSecret (CID,CSMode,CSContent,CSFile,AddUser,AddDate,AddIP) values ('".$CID."','".$CSMode."','".$CSContent."','".$CSFile."','".$_SESSION["reg_MUID"]."','".$now_time."','".$_SERVER["REMOTE_ADDR"]."');";
$result_insert=mysqli_query($link,$sql_insert) or die ("無法執行新增");

mysqli_close($link);
?>
<script type="text/JavaScript">
	<!--
	alert ("新增成功！");
	opener.location.reload();
	self.close();
	//-->
</script>

</body>
</html>
