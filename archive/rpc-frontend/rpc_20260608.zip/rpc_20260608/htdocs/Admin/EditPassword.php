﻿<?php
include "CheckPermission.php";
include "../global.php";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $PageAdminTitle;?></title>
<link href="../type.css" rel="stylesheet" type="text/css" />
<style type="text/css">
<!--
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
}
-->
</style>
<Script type="text/javascript" language="javascript" src="../script/CheckForm.js"></Script>
<script type="text/JavaScript">
<!--
function jsCheck() 
		{
		if (ChkImp('MPassword',document.form1.MPassword.value,'密碼') == false) return false;
		if (ChkImp('MPasswordCheck',document.form1.MPasswordCheck.value,'確認密碼') == false) return false;
		if (jsTrim(document.form1.MPassword.value) != jsTrim(document.form1.MPasswordCheck.value))
				{
				alert ('您輸入的密碼與確認密碼不相同，請重新輸入！');
				document.form1.MPassword.value = '';
				document.form1.MPasswordCheck.value = '';
				document.form1.MPassword.focus();
				return false;
				}
		}
//-->
</script>
</head>
<body>
<?php include "top.php";?>
<?php
$SQL_Manager="select MUID,MPassword,MName,EMail,MIntro,MPer,ISEngineer from Manager where Deltag='N' and MUID = '".$_SESSION["reg_MUID"]."';";
$result_Manager=mysqli_query($link,$SQL_Manager) or die ("無法執行查詢");
if (mysqli_num_rows($result_Manager) == 0)
		{
		mysqli_free_result($result_Manager);
		mysqli_close($link);
		?>
		<SCRIPT language=javascript>
		<!--
		alert ("查無資料，請冾網站管理人員！"); 
		history.go(-1);
		//-->
		</SCRIPT>
		<?php 	
		exit;
		}
list($MUID,$MPassword,$MName,$EMail,$MIntro,$MPer,$ISEngineer)=mysqli_fetch_row($result_Manager);
mysqli_free_result($result_Manager);

?>
<table width="100%" border="0" cellspacing="0" cellpadding="5">
	<tr>
    <td width="160" height="600" align="left" valign="top">
			<?php include "menu.php";?>
    </td>
    <td valign="top">
    	<table width="100%" border="0" cellpadding="0" cellspacing="0">
    		<tr>
    			<td>
			    	<table width="750" border="0" cellpadding="0" cellspacing="0">
			    		<tr height="30">
			    			<td class="c2"><b>修改密碼</b></td>
			    		</tr>
			    	</table>
			    	<table width="750" border="0" cellpadding="0" cellspacing="0">
			        <form name="form1" method="post" action="EditPasswordDB.php" onSubmit="return jsCheck();">
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td width="150" align="right" class="c3">帳 號：</td>
			          <td class="h3"><?php echo $MUID;?></td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">姓 名：</td>
			          <td class="h3"><?php echo $MName;?></td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">密 碼：</td>
			          <td class="h3"><input type="password" name="MPassword" size="20" value="<?php echo $MPassword;?>"></td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">密碼確認：</td>
			          <td class="h3"><input type="password" name="MPasswordCheck" size="20" value="<?php echo $MPassword;?>"></td>
			        </tr>
			        <tr height="40" align="center">
			          <td colspan="2" class="h3"><input type="submit" name="submit" class="input_bot" value="送 出"></td>
			        </tr>
				      </form>
			      </table>
    			</td>
    		</tr>
    	</table>
    </td>
	</tr>
</table>
<?php include "down.php";?>
</body>
</html>
<?php
mysqli_close($link);
?>