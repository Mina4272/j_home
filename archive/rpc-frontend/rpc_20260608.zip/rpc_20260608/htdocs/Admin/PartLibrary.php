﻿<?php
include "CheckPermission.php";
include "CheckPartLibrary.php";
include "../global.php";
include "include/page_function.php";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $PageAdminTitle;?></title>
<link href="../type.css" rel="stylesheet" type="text/css" />
<style type="text/css">
<!--
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
}
-->
</style></head>

<body>
<?php include "top.php";?>
<table width="100%" border="0" cellspacing="0" cellpadding="5">
	<tr>
    <td width="160" height="600" align="left" valign="top">
			<?php include "menu.php";?>
    </td>
    <td valign="top">
    	<table width="100%" border="0" cellpadding="0" cellspacing="0">
    		<tr>
    			<td>
			    	<table width="750" border="0" cellpadding="0" cellspacing="0">
			    		<tr height="30">
			    			<td class="c2">零組件/檔案查詢</td>
			    		</tr>
			    	</table>
						<?php
					$SqlTxt="";
			    	$QPLCID = empty($_POST['QPLCID'])?"":$_POST['QPLCID'];
			    	if (trim($QPLCID) == "") $QPLCID = empty($_GET['QPLCID'])?"":$_GET['QPLCID'];
			    	if (trim($QPLCID) != "") $SqlTxt = $SqlTxt." and PLCID = '".$QPLCID."' ";
			    	$KeyWord = empty($_POST['KeyWord'])?"":$_POST['KeyWord'];
			    	if (trim($KeyWord) == "") $KeyWord = empty($_GET['KeyWord'])?"":$_GET['KeyWord'];
			    	if (trim($KeyWord) != "") $SqlTxt = $SqlTxt." and (PartName like '%".$KeyWord."%' or Firm like '%".$KeyWord."%' or Model like '%".$KeyWord."%' or Spec like '%".$KeyWord."%' or Standard like '%".$KeyWord."%' or Mark like '%".$KeyWord."%')";

						$SQL_PartLibraryClass="select PLCID,PLCName from PartLibraryClass where Deltag='N' order by PLCID;";
						$result_PartLibraryClass=mysqli_query($link,$SQL_PartLibraryClass) or die ("無法執行查詢");
						?>
			    	<table width="750" border="0" cellpadding="0" cellspacing="0">
			    		<form name="form1" action="PartLibrary.php" method="post">
			    		<tr>
			    			<td width="300" class="h3">類別名稱：
			    				<select name="QPLCID">
			    					<option value="">不限</option>
			    					<?php while(list($PLCIDTmp,$PLCNameTmp)=mysqli_fetch_row($result_PartLibraryClass)){?>
			    					<option value="<?php echo $PLCIDTmp;?>"<?php if (trim($PLCIDTmp) == trim($QPLCID)) echo " selected";?>><?php echo $PLCNameTmp;?></option>
			    					<?php }?>
			    				</select>
			    			</td>
			    			<td align="left" class="h3">關鍵字：<input type="text" name="KeyWord" size="20" value="<?php echo $KeyWord;?>"> <input type="submit" name="search" class="input_bot" value="查詢"></td>
			    			<td align="right" class="h3"><input type="button" name="PartLibraryClass" value="類別編輯" class="input_bot" onclick="javascript:window.open ('PartLibraryClass.php','PartLibraryClass','height=400,width=600,top=200,left=200,scrollbars=yes,status=yes');"></td>
			    			<td width="60" align="right" class="h3"><input type="button" name="add" value="新 增" class="input_bot" onclick="javascript:location.href='PartLibraryAdd.php';"></td>
			    		</tr>
			    		</form>
			    	</table>
						<?php
						mysqli_free_result($result_PartLibraryClass);
						$page = empty($_GET['page'])?"":$_GET['page'];
						if (trim($page) == "") $page = 1;
						$page_rows=15;  //每頁筆數
						$php_Self = "PartLibrary.php";  //分頁web檔名

						$button_css = "h4";
						$limit_txt =" limit ".(($page-1) * $page_rows).",".$page_rows;
						$url_str = "&QPLCID=".$QPLCID."&KeyWord=".urlencode($KeyWord);
						$Sql_str="select PLID,PLCID,(select PLCName from PartLibraryClass where Deltag='N' and PLCID=PartLibrary.PLCID) as PLCName,PartName,Firm,Model,Spec,Standard,Mark,PartCertification from PartLibrary where Deltag='N' ".$SqlTxt." order by PLID desc;";
						$SQL_PartLibrary="select PLID,PLCID,(select PLCName from PartLibraryClass where Deltag='N' and PLCID=PartLibrary.PLCID) as PLCName,PartName,Firm,Model,Spec,Standard,Mark,PartCertification from PartLibrary where Deltag='N' ".$SqlTxt." order by PLID desc ".$limit_txt.";";
						$result_PartLibrary=mysqli_query($link,$SQL_PartLibrary) or die ("無法執行查詢");
						?>
			    	<table width="750" border="0" cellpadding="5" cellspacing="2" class="s2">
			        <tr align="center">
			          <td width="220" background="../images/table_bg.gif" class="t21">類別名稱</td>
			          <td width="260" background="../images/table_bg.gif" class="t21">廠家/檔案種類</td>
			          <td width="260" background="../images/table_bg.gif" class="t21">型號/檔案內容</td>
			        </tr>
		          <?php
		          $tmp = 1;
		          while(list($PLID,$PLCID,$PLCName,$PartName,$Firm,$Model,$Spec,$Standard,$Mark,$PartCertification)=mysqli_fetch_row($result_PartLibrary)){
		        	?>
		        	<tr<?php if ($tmp%2 == 0) echo " bgcolor=\"#F6F6F6\"";?>>
			          <td align="center" class="h3"><a href="PartLibraryEdit.php?PLID=<?php echo $PLID;?>&page=<?php echo $page;?><?php echo $url_str;?>"><?php echo $PLCName;?></a></td>
			          <td align="center" class="h3"><?php echo $Firm;?></td>
			          <td align="center" class="h3"><a href="getfile.php?FolderName=Admin\\PartCertification&FileName=<?php echo $PartCertification;?>"><?php echo $Model;?></a></td>
			        </tr>
			        <?php
            			$tmp++;
			      			}
            	mysqli_free_result($result_PartLibrary);
			        ?>
			      </table>
			      <table width="750" border="0" cellpadding="5" cellspacing="2" class="s2">
			        <tr align="center">
			          <td bgcolor="#E8F0C2" class="h4"><?php Page_show($Sql_str,$page_rows,$php_Self,$link,$page,$url_str,$button_css);?></td>
			        </tr>
			      </table>
    			</td>
    		</tr>
    	</table>
    </td>
	</tr>
</table>
<?php include "down.php";?>
</body>
</html>
<?php
mysqli_close($link);
?>