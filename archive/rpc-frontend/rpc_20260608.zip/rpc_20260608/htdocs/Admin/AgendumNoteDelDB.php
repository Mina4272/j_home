﻿<?php
include "CheckPermission.php";
include "CheckAgendum.php";
include "../global.php";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $PageAdminTitle;?></title>
</head>
<body>
<?php
$AID = $_GET['AID'];
$ANID = $_GET['ANID'];
$page = $_GET['page'];

if (trim($AID) == "" || trim($ANID) == "")
		{
		mysqli_close($link);
		?>
		<script type="text/JavaScript">
			<!--
			alert ("您輸入的資料不足，請重新輸入！");
			history.go(-1);
			//-->
		</script>
		<?php
		exit;
		}
$SQL_AgendumNote="select AddUser from AgendumNote where Deltag='N' and AID = '".$AID."' and ANID = '".$ANID."';";
$result_AgendumNote=mysqli_query($link,$SQL_AgendumNote) or die ("無法執行查詢");
if (mysqli_num_rows($result_AgendumNote) == 0)
		{
		mysqli_free_result($result_AgendumNote);
		mysqli_close($link);
		?>
		<SCRIPT language=javascript>
		<!--
		alert ("查無資料，請冾網站管理人員！"); 
		history.go(-1);
		//-->
		</SCRIPT>
		<?php 	
		exit;
		}
list($AddUser)=mysqli_fetch_row($result_AgendumNote);
mysqli_free_result($result_AgendumNote);

if (trim(strtolower($_SESSION["reg_MUID"])) != trim(strtolower($AddUser)))
		{
		mysqli_close($link);
		?>
		<script type="text/JavaScript">
			<!--
			alert ("您無權限刪除！");
			history.go(-1);
			//-->
		</script>
		<?php
		exit;
		}

$now_time = date("Y-m-d H:i:s",mktime());
$sql_insert = "INSERT INTO AgendumNoteHistory(ANID,AID,AContent,AddUser,AddDate,AddIP,Deltag,ProcUser,ProcDate,ProcIP,UpdateUser,UpdateDate,UpdateIP) SELECT ANID,AID,AContent,AddUser,AddDate,AddIP,Deltag,ProcUser,ProcDate,ProcIP,'".$_SESSION["reg_MUID"]."','".$now_time."','".$_SERVER["REMOTE_ADDR"]."' FROM AgendumNote where Deltag='N' and AID = '".$AID."' and ANID = '".$ANID."';";
$result_insert=mysqli_query($link,$sql_insert) or die ("無法執行新增");
$sql_update = "update AgendumNote set Deltag = 'Y',ProcUser = '".$_SESSION["reg_MUID"]."',ProcDate = '".$now_time."',ProcIP = '".$_SERVER["REMOTE_ADDR"]."' where Deltag='N' and AID = '".$AID."' and ANID = '".$ANID."';";
$result_update=mysqli_query($link,$sql_update) or die ("無法執行修改");

mysqli_close($link);
?>
<script type="text/JavaScript">
	<!--
	alert ("刪除成功！");
	location.href="AgendumNote.php?AID=<?php echo $AID;?>&page=<?php echo $page;?>";
	//-->
</script>

</body>
</html>
