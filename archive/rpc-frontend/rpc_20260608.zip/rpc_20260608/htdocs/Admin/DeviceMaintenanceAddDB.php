<?php
include "CheckPermission.php";
//include "CheckAgendum.php";
include "../global.php";
include "include/page_function.php";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $PageAdminTitle;?></title>
<link href="../type.css" rel="stylesheet" type="text/css" />
<style type="text/css">
<!--
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
}
-->
</style></head>

<body>
<?php
$device_no = $_POST['device_no'];
$DMYear = $_POST['DMYear'];
$DMMonth = $_POST['DMMonth'];
$DMDay = $_POST['DMDay'];
if (trim($DMYear) != "" || trim($DMMonth) != "" || trim($DMDay) != "") if (checkdate($DMMonth,$DMDay ,$DMYear)) $DM_date = $DMYear."-".$DMMonth."-".$DMDay;
$DM_clean = $_POST['DM_clean'];
$DM_function = $_POST['DM_function'];


if (trim($DM_date) == "" || trim($DM_clean) == "" || trim($DM_function) == "")
{
	mysqli_close($link);
		
?>
<script type="text/JavaScript">
<!--
	alert ("您輸入的資料不足，請重新輸入！");
	history.go(-1);
	//-->
</script>
<?php
	exit;
}


$sql_insert = "insert into devicemaintenance (D_no,DM_date,DM_clean,DM_function) values ('".$device_no."','".$DM_date."','".$DM_clean."','".$DM_function."');";
//echo $sql_insert;
$result_insert=mysqli_query($link,$sql_insert) or die ("無法執行新增");
mysqli_close($link);
	
?>
<script type="text/JavaScript">
	
	alert("新增成功！");
	opener.location.reload();
	self.close();
	
</script>
</body>
</html>
<?php
mysqli_close($link);
?>