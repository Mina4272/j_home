<?php
if (trim(strstr($_SESSION["reg_MPer"],'G')) == "") exit;
?>