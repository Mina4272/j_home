﻿<?php
include "CheckPermission.php";
include "CheckManager.php";
include "../global.php";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $PageAdminTitle;?></title>
</head>
<body>
<?php
$MID = $_GET['MID'];
$MFID = $_GET['MFID'];
$page = $_GET['page'];
if (trim($MID) == "" || trim($MFID) == "")
		{
		mysqli_close($link);
		?>
		<script type="text/JavaScript">
			<!--
			alert ("您輸入的資料不足，請重新輸入！");
			self.close();
			//-->
		</script>
		<?php
		exit;
		}
$SQL_ManagerFile="select MFID from ManagerFile where Deltag='N' and MID = '".$MID."' and MFID = '".$MFID."';";
$result_ManagerFile=mysqli_query($link,$SQL_ManagerFile) or die ("無法執行查詢");
if (mysqli_num_rows($result_ManagerFile) == 0)
		{
		mysqli_free_result($result_ManagerFile);
		mysqli_close($link);
		?>
		<SCRIPT language=javascript>
		<!--
		alert ("查無資料，請冾網站管理人員！"); 
		self.close();
		//-->
		</SCRIPT>
		<?php 	
		exit;
		}
mysqli_free_result($result_ManagerFile);

$now_time = date("Y-m-d H:i:s",mktime());
$sql_insert = "INSERT INTO ManagerFileHistory(MFID,MID,MTitle,MFile,AddUser,AddDate,AddIP,Deltag,ProcUser,ProcDate,ProcIP,UpdateUser,UpdateDate,UpdateIP) SELECT MFID,MID,MTitle,MFile,AddUser,AddDate,AddIP,Deltag,ProcUser,ProcDate,ProcIP,'".$_SESSION["reg_MUID"]."','".$now_time."','".$_SERVER["REMOTE_ADDR"]."' FROM ManagerFile where Deltag='N' and MID = '".$MID."' and MFID = '".$MFID."';";
$result_insert=mysqli_query($link,$sql_insert) or die ("無法執行新增");
$sql_update = "update ManagerFile set Deltag = 'Y',ProcUser = '".$_SESSION["reg_MUID"]."',ProcDate = '".$now_time."',ProcIP = '".$_SERVER["REMOTE_ADDR"]."' where Deltag='N' and MID = '".$MID."' and MFID = '".$MFID."';";
$result_update=mysqli_query($link,$sql_update) or die ("無法執行修改");

mysqli_close($link);
?>
<script type="text/JavaScript">
	<!--
	alert ("刪除成功！");
	location.href="ManagerFile.php?MID=<?php echo $MID;?>&page=<?php echo $page;?>";
	//-->
</script>

</body>
</html>
