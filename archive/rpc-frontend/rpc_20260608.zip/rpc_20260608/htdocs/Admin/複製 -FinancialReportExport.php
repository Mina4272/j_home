<?php
include "CheckPermission.php";
include "CheckAccountingReport.php";
include "../global.php";

$QSCAYear = $_POST['QSCAYear'];
$QSCAMonth = $_POST['QSCAMonth'];
$QECAYear = $_POST['QECAYear'];
$QECAMonth = $_POST['QECAMonth'];
$QCAType = $_POST['QCAType'];
$KeyWord = $_POST['KeyWord'];

if (trim($QCAType) != "") $QqlType = " and CAType='".$QCAType."' ";

if (trim($QSCAYear) != "" && trim($QSCAMonth) != "") {
		$QSCADate = $QSCAYear."-".$QSCAMonth."-01";
		$QSMonth = $QSCAYear."-".$QSCAMonth;
		}
if (trim($QECAYear) != "" && trim($QECAMonth) != "") {
		$QECADate = $QECAYear."-".$QECAMonth."-31";
		$QEMonth = $QECAYear."-".$QECAMonth;
		}

if (trim($QSCADate) != "" && trim($QECADate) != "") {
		$SqlTxt1 = " AND date_format( AddDate, '%Y-%m-%d' ) BETWEEN '".$QSCADate."' AND '".$QECADate."' ";
		$SqlTxt2 = " AND CADate BETWEEN '".$QSCADate."' AND '".$QEMonth."-01' ";
		}
else if (trim($QSCADate) != "" && trim($QECADate) == "") {
		$SqlTxt1 = " AND date_format( AddDate, '%Y-%m' ) = '".$QSMonth."' ";
		$SqlTxt2 = " AND CADate = '".$QSCADate."' ";
		}
else if (trim($QSCADate) == "" && trim($QECADate) != "") {
		$SqlTxt1 = " AND date_format( AddDate, '%Y-%m' ) = '".$QEMonth."' ";
		$SqlTxt2 = " AND CADate = '".$QEMonth."-01' ";
		}

//echo "QSCADate=$QSCADate<br>";
//echo "QECADate=$QECADate<br>";
//exit;
//if (trim($QCAYear) != "" && trim($QCAMonth) != "") {
//		$QMonth = $QCAYear."-".$QCAMonth;
//		$QCADate = $QCAYear."-".$QCAMonth."-01";
//		}

//echo "QCADate=$QCADate<br>";
//if (trim($QCADate) == "") {
//		$QMonth = date("Y-m",mktime());
//		$QCADate = date("Y-m",mktime())."-01";
//		}
$SQL_Project="select PID,PUID,CID,CName,CTel,CFax,Contact,CMobile,CEMail,CAddress,PStatus,PName,ModelName,SeriesModel,PE,Quote,ApplyItem,Canon,SNote,PlanDate,CloseDate,PNote,QuoteDate,ReturnDate,IFlorin,OFlorin,InvoiceDate,InvoiceCUID,(select CUID from Customer where Deltag='N' and CID = Project.CID) as CUID,date_format( AddDate, '%Y-%m' ) date_month,PTax from Project where Deltag='N' ".$SqlTxt1." order by PID desc;";
$result_Project=mysql_query($SQL_Project,$link) or die ("無法執行查詢");
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $PageAdminTitle;?></title>
<link href="style.css" rel="stylesheet" type="text/css" />
<body>
<table winth="1000" border="0">
	<tr>
		<td colspan="2"><font color=blue>若您無法正常觀看此報表！請下載此 <a href="owc11.zip" target="_File"><font color=red><b>元件</b></font></a> <font color=blue>安裝至您的電腦。</font></td>
	</tr>
</table>
<object id=ProjectAccounting classid=CLSID:0002E559-0000-0000-C000-000000000046 style="width:100%;height:90%"></object>
<script language=vbscript>
	Sub Window_OnLoad()
	Set chConstants = ProjectAccounting.Constants
	ProjectAccounting.ActiveSheet.Cells.Clear
	ProjectAccounting.Worksheets(1).Select
	ProjectAccounting.ActiveSheet.Name ="ProjectAccounting"

	ProjectAccounting.ActiveSheet.Cells(1,1).Value ="所屬月份"
	ProjectAccounting.ActiveSheet.Cells(1,2).Value ="<?php echo $QSMonth;?> ～ <?php echo $QEMonth;?>"
	ProjectAccounting.ActiveSheet.Cells(1,3).Value =""
	ProjectAccounting.ActiveSheet.Cells(1,4).Value =""
	ProjectAccounting.ActiveSheet.Cells(1,5).Value =""
	ProjectAccounting.ActiveSheet.Cells(1,6).Value =""
<?php  
$ECount=2;
$TolCharges=0;
$TolInputCharges=0;
$TolInputChargesTax=0;
$TolOutputCharges=0;
$TolOutputChargesTax=0;
while(list($PID,$PUID,$CID,$CName,$CTel,$CFax,$Contact,$CMobile,$CEMail,$CAddress,$PStatus,$PName,$ModelName,$SeriesModel,$PE,$Quote,$ApplyItem,$Canon,$SNote,$PlanDate,$CloseDate,$PNote,$QuoteDate,$ReturnDate,$IFlorin,$OFlorin,$PInvoiceDate,$InvoiceCUID,$CUID,$date_month,$PTax)=mysql_fetch_row($result_Project)){
  	if (trim($ModelName) == "") $ModelName = "NA";
  	if (trim($PStatus) == "A") $PStatus="新開案";
  	else if (trim($PStatus) == "B") $PStatus="報價中";
  	else if (trim($PStatus) == "C") $PStatus="案件處理中";
  	else if (trim($PStatus) == "D") $PStatus="審查中";
  	else if (trim($PStatus) == "E") $PStatus="補件中";
  	else if (trim($PStatus) == "F") $PStatus="待印證";
  	else if (trim($PStatus) == "G") $PStatus="案件取消";
  	else if (trim($PStatus) == "H") $PStatus="已結案";
		?>
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,1).Value ="<?php echo $PUID;?>"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,2).Value ="<?php echo str_replace('"','\'',$PName);?> - <?php echo $ApplyItem;?>"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,3).Value ="<?php echo $CName;?>"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,4).Value ="<?php echo $PStatus;?>"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,5).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,6).Value =""
		<?php
		if (trim($TitleLine) == "") $TitleLine = $ECount;
		else $TitleLine = $TitleLine.",".$ECount;
		$ECount++;
		?>
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,1).Value ="收入/支出"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,2).Value ="項目"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,3).Value ="費用"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,4).Value ="稅金"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,5).Value ="匯率"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,6).Value ="外幣別"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,7).Value ="外幣費用"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,8).Value ="狀態"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,9).Value ="時間"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,10).Value ="發票日期"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,11).Value ="發票號碼"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,12).Value ="供應商"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,13).Value ="備註"
		<?php
		$ECount++;
		$SQL_ProjectAccounting="select PAID,PAMode,PAItem,Charges,Rate,ChargesOther,PATax,PAStatus,PADate,PANote,InvoiceDate,Invoice,CName from ProjectAccounting where Deltag='N' and PID = '".$PID."' and (PAStatus = 'W' or PAStatus = 'S') order by PAMode asc,PAID asc;";
		$result_ProjectAccounting=mysql_query($SQL_ProjectAccounting,$link) or die ("無法執行查詢");
		$SumCharges=0;
		$SumInput=0;
		$SumInputTax=0;
		$SumOutput=0;
		$SumOutputTax=0;
  	$PATaxPrice=0;
    while(list($PAID,$PAMode,$PAItem,$Charges,$Rate,$ChargesOther,$PATax,$PAStatus,$PADate,$PANote,$InvoiceDate,$Invoice,$PCName)=mysql_fetch_row($result_ProjectAccounting)){
      	if (trim($PATax) == "") $PATax = $PTax;
      	$PATaxPrice=0;
      	if (trim($PATax) == "Y") $PATaxPrice = round($Charges*0.05);
      	if (trim($PAStatus) == "W") {
      			if (trim($PAMode) == "I") $PAStatus="待收"; else if (trim($PAMode) == "O") $PAStatus="未付";
      			}
      	else if (trim($PAStatus) == "S") $PAStatus="結清";
      	else if (trim($PAStatus) == "C") $PAStatus="取消";
      	$FlorinTxt="";
      	if (trim($PAMode) == "I") $FlorinTxt=$IFlorin;
      	else if (trim($PAMode) == "O") $FlorinTxt=$OFlorin;
      	
      	if (trim($PAMode) == "I") {
      			$SumInput=$SumInput+$Charges;
		      	if (trim($PATax) == "Y") $SumInputTax = $SumInputTax + round($Charges*0.05);
      			$SumCharges=$SumCharges+$Charges;
		      	$DateMonthI[$date_month]=$DateMonthI[$date_month]+$Charges;
		      	$DateMonthITax[$date_month]=$DateMonthITax[$date_month]+round($Charges*0.05);
      			}
      	else if (trim($PAMode) == "O") {
      			$SumOutput=$SumOutput+$Charges;
		      	if (trim($PATax) == "Y") $SumOutputTax = $SumOutputTax + round($Charges*0.05);
      			$SumCharges=$SumCharges-$Charges;
		      	$DateMonthO[$date_month]=$DateMonthO[$date_month]+$Charges;
		      	$DateMonthOTax[$date_month]=$DateMonthOTax[$date_month]+round($Charges*0.05);
      			}
      	
      	if (trim($PAMode) == "I") $PAMode="收入";
      	else if (trim($PAMode) == "O") $PAMode="支出";
				?>
				ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,1).Value ="<?php echo $PAMode;?>"
				ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,2).Value ="<?php echo $PAItem;?>"
				ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,3).Value ="<?php echo $Charges;?>"
				ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,4).Value ="<?php echo $PATaxPrice;?>"
				ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,5).Value ="<?php echo $Rate;?>"
				ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,6).Value ="<?php echo $FlorinTxt;?>"
				ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,7).Value ="<?php echo $ChargesOther;?>"
				ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,8).Value ="<?php echo $PAStatus;?>"
				ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,9).Value ="'<?php echo $PADate;?>"
				ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,10).Value ="'<?php echo $InvoiceDate;?>"
				ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,11).Value ="<?php echo $Invoice;?>"
				ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,12).Value ="<?php echo $PCName;?>"
				ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,13).Value ="<?php echo $PANote;?>"
				<?php
				$PATaxPrice=0;
				$ECount++;
				}
		mysql_free_result($result_ProjectAccounting);
		?>
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,1).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,2).Value ="收入"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,3).Value ="稅金(收入)"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,4).Value ="支出"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,5).Value ="稅金(支出)"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,6).Value ="小計"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,7).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,8).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,9).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,10).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,11).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,12).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,13).Value =""
		<?php
		if (trim($SumLine) == "") $SumLine = $ECount;
		else $SumLine = $SumLine.",".$ECount;
		$ECount++;
		?>
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,1).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,2).Value ="<?php echo $SumInput;?>"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,3).Value ="<?php echo $SumInputTax?>"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,4).Value ="<?php echo $SumOutput;?>"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,5).Value ="<?php echo $SumOutputTax?>"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,6).Value ="<?php echo $SumCharges;?>"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,7).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,8).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,9).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,10).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,11).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,12).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,13).Value =""
		<?php
		$TolCharges = $TolCharges + $SumCharges;
		$TolInputCharges = $TolInputCharges + $SumInput;
		$TolInputChargesTax = $TolInputChargesTax + $SumInputTax;
		$TolOutputCharges = $TolOutputCharges + $SumOutput;
		$TolOutputChargesTax = $TolOutputChargesTax + $SumOutputTax;
		if (trim($SumLine) == "") $SumLine = $ECount;
		else $SumLine = $SumLine.",".$ECount;
		
		$ECount++;
		$ECount++;
		}
mysql_free_result($result_Project);
?>
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,1).Value ="一般帳務列表"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,2).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,3).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,4).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,5).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,6).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,7).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,8).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,9).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,10).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,11).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,12).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,13).Value =""
		<?php
		if (trim($TitleLine) == "") $TitleLine = $ECount;
		else $TitleLine = $TitleLine.",".$ECount;
		$ECount++;
		?>
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,1).Value ="項目"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,2).Value ="金額"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,3).Value ="狀態"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,4).Value ="時間"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,5).Value ="備註"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,6).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,7).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,8).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,9).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,10).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,11).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,12).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,13).Value =""
		<?php
		$ECount++;
		$SQL_CommonAccounting="select CAID,CADate,CAItem,Amount,InvoiceDate,Invoice,CAStatus,PayDate,CANote from CommonAccounting where Deltag='N' and (CAStatus = 'W' or CAStatus = 'S') ".$SqlTxt2." order by CAID asc;";
		$result_CommonAccounting=mysql_query($SQL_CommonAccounting,$link) or die ("無法執行查詢");
		$SumAmount=0;
		while(list($CAID,$CADate,$CAItem,$Amount,$InvoiceDate,$Invoice,$CAStatus,$PayDate,$CANote)=mysql_fetch_row($result_CommonAccounting)){
				$SumAmount = $SumAmount + $Amount;
				if (trim($PayDate) == "0000-00-00") $PayDate = "";
      	if (trim($CAStatus) == "W") $CAStatus="未付";
      	else if (trim($CAStatus) == "S") $CAStatus="結清";
      	else if (trim($CAStatus) == "C") $CAStatus="取消";
				?>
				ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,1).Value ="<?php echo $CAItem;?>"
				ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,2).Value ="<?php echo $Amount;?>"
				ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,3).Value ="<?php echo $CAStatus;?>"
				ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,4).Value ="'<?php echo $PayDate;?>"
				ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,5).Value ="<?php echo $CANote;?>"
				ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,6).Value =""
				ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,7).Value =""
				ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,8).Value =""
				ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,9).Value =""
				ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,10).Value =""
				ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,11).Value =""
				ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,12).Value =""
				ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,13).Value =""
				<?php
				$ECount++;
				}
		mysql_free_result($result_CommonAccounting);
		mysql_close($link);
		?>
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,1).Value ="小計"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,2).Value ="<?php echo $SumAmount;?>"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,3).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,4).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,5).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,6).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,7).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,8).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,9).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,10).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,11).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,12).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,13).Value =""
		<?php
		if (trim($SumLine) == "") $SumLine = $ECount;
		else $SumLine = $SumLine.",".$ECount;
		$ECount++;
		$ECount++;
		$ECount++;
		foreach($DateMonthI as $key => $value) {
				?>
				ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,1).Value ="<?php echo $key;?> 收入小計"
				ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,2).Value ="<?php echo $DateMonthI[$key];?>"
				ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,3).Value ="<?php echo $DateMonthITax[$key];?>"
				ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,4).Value ="<?php echo $DateMonthO[$key];?>"
				ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,5).Value ="<?php echo $DateMonthOTax[$key];?>"
				ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,6).Value ="<?php echo ($DateMonthI[$key]-$DateMonthO[$key]);?>"
				ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,7).Value =""
				ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,8).Value =""
				ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,9).Value =""
				ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,10).Value =""
				ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,11).Value =""
				ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,12).Value =""
				ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,13).Value =""
				<?php
				if (trim($SumLine) == "") $SumLine = $ECount;
				else $SumLine = $SumLine.",".$ECount;
				$ECount++;
				}
		$ECount++;
		?>

		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,1).Value ="收入小計"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,2).Value ="<?php echo $TolInputCharges;?>"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,3).Value ="<?php echo $TolInputChargesTax;?>"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,4).Value ="<?php echo $TolOutputCharges;?>"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,5).Value ="<?php echo $TolOutputChargesTax;?>"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,6).Value ="<?php echo $TolCharges;?>"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,7).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,8).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,9).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,10).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,11).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,12).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,13).Value =""
		<?php
		if (trim($SumLine) == "") $SumLine = $ECount;
		else $SumLine = $SumLine.",".$ECount;
		$ECount++;
		?>
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,1).Value ="支出小計"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,2).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,3).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,4).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,5).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,6).Value ="<?php echo $SumAmount;?>"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,7).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,8).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,9).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,10).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,11).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,12).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,13).Value =""
		<?php
		if (trim($SumLine) == "") $SumLine = $ECount;
		else $SumLine = $SumLine.",".$ECount;
		$ECount++;
		?>
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,1).Value ="總計"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,2).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,3).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,4).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,5).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,6).Value ="<?php echo ($TolCharges-$SumAmount);?>"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,7).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,8).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,9).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,10).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,11).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,12).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,13).Value =""

		ProjectAccounting.ActiveSheet.Range("A1:L<?php echo $ECount;?>").Font.Color="blue"
		ProjectAccounting.ActiveSheet.Range("A1:L<?php echo $ECount;?>").Font.Name="Courier New"
		ProjectAccounting.ActiveSheet.Range("A1:L<?php echo $ECount;?>").Font.Size="11"
		ProjectAccounting.ActiveSheet.Range("A1:L<?php echo $ECount;?>").Columns.AutoFit
		ProjectAccounting.ActiveSheet.Range("A1:L<?php echo $ECount;?>").NumberFormat ="General"

		ProjectAccounting.ActiveSheet.Range("A<?php echo $ECount;?>:L<?php echo $ECount;?>").Font.Bold=true

		ProjectAccounting.ActiveSheet.Range("A1:I1").Font.Bold=true
		<?php
		$TitleLineArr = split(",",$TitleLine);
		$count_i=count($TitleLineArr);
		for ($tmp=0;$tmp<=$count_i-1;$tmp++){
				?>
				ProjectAccounting.ActiveSheet.Range("A<?php echo $TitleLineArr[$tmp];?>:L<?php echo $TitleLineArr[$tmp];?>").Font.Color="#000000"
				ProjectAccounting.ActiveSheet.Range("A<?php echo $TitleLineArr[$tmp];?>:L<?php echo $TitleLineArr[$tmp];?>").Font.Bold=true
				ProjectAccounting.ActiveSheet.Range("A<?php echo $TitleLineArr[$tmp]+1;?>:L<?php echo $TitleLineArr[$tmp]+1;?>").Font.Bold=true
				<?php
				}

		$SumLineArr = split(",",$SumLine);
		$count_i=count($SumLineArr);
		for ($tmp=0;$tmp<=$count_i-1;$tmp++){
				?>
				ProjectAccounting.ActiveSheet.Range("A<?php echo $SumLineArr[$tmp];?>:J<?php echo $SumLineArr[$tmp];?>").Font.Bold=true
				<?php
				}
		?>
	End Sub
	</script>
</body>
</html>
