﻿<?php
include "CheckPermission.php";
include "CheckProject.php";
include "../global.php";
include "include/page_function.php";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $PageAdminTitle;?></title>
<link href="../type.css" rel="stylesheet" type="text/css" />
<style type="text/css">
<!--
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
}
-->
</style></head>

<body>
<?php
$PID = $_GET['PID'];

$SQL_ProjectAccountingAdd="select PAAID,PAADate,PAAReason,PAACheck,AddUser,(select MName from Manager where MUID=ProjectAccountingAdd.AddUser) MName,(select MEName from Manager where MUID=ProjectAccountingAdd.AddUser) MEName,AddDate,ProcUser,ProcDate from ProjectAccountingAdd where PID = '".$PID."' order by PAAID desc;";
$result_ProjectAccountingAdd=mysqli_query($link,$SQL_ProjectAccountingAdd) or die ("無法執行查詢");
?>
<table width="100%" border="0" cellpadding="0" cellspacing="0">
	<tr height="30">
		<td width="10"></td>
		<td width="200" class="c2">加測記錄列表</td>
		<td width="20"></td>
	</tr>
</table>
<table width="100%" border="0" cellpadding="5" cellspacing="2" class="s2">
  <tr>
    <td width="100" align="center" background="../images/table_bg.gif" class="t21">加測日期</td>
    <td width="230" align="center" background="../images/table_bg.gif" class="t21">加測原因</td>
    <td width="120" align="center" background="../images/table_bg.gif" class="t21">是否加測完成</td>
    <td width="100" align="center" background="../images/table_bg.gif" class="t21">加測人員</td>
    <td width="180" align="center" background="../images/table_bg.gif" class="t21">最後處理時間</td>
  </tr>
  <?php
  $tmp = 1;
  while(list($PAAID,$PAADate,$PAAReason,$PAACheck,$AddUser,$MName,$MEName,$AddDate,$ProcUser,$ProcDate)=mysqli_fetch_row($result_ProjectAccountingAdd)){
	?>
	<tr<?php if ($tmp%2 == 0) echo " bgcolor=\"#F6F6F6\"";?>>
    <td class="h3" align="center"><?php echo $PAADate;?></td>
    <td class="h3" align="center"><?php echo $PAAReason;?></td>
    <td class="h3" align="center">
    	<?php
    	if (trim($PAACheck)=="Y") echo "已完成";
    	else if (trim($PAACheck)=="N") echo "未完成";
    	?>
    </td>
    <td class="h3" align="center"><?php echo $MEName.$MName;?></td>
    <td align="center"><?php echo $ProcDate;?></td>
  </tr>
  <?php
			$tmp++;
			}
	mysqli_free_result($result_ProjectAccountingAdd);
  ?>
</table>
</body>
</html>
<?php
mysqli_close($link);
?>