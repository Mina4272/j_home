﻿<?php
include "CheckPermission.php";
include "CheckAgendum.php";
include "../global.php";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $PageAdminTitle;?></title>
</head>
<body>
<?php
$AID = $_GET['AID'];
$page = $_GET['page'];
$KeyWord = $_GET['KeyWord'];
$QAStatus = $_GET['QAStatus'];
$QASID = $_GET['QASID'];
$QARID = $_GET['QARID'];
$QACID = $_GET['QACID'];
$Late = $_GET['Late'];

if (trim($AID) == "")
		{
		mysqli_close($link);
		?>
		<script type="text/JavaScript">
			<!--
			alert ("您輸入的資料不足，請重新輸入！");
			history.go(-1);
			//-->
		</script>
		<?php
		exit;
		}

$now_time = date("Y-m-d H:i:s",mktime());
$SQL_select="select AID from Agendum where Deltag='N' and AID = '".$AID."';";
$result_select=mysqli_query($link,$SQL_select) or die ("無法執行查詢");

if (mysqli_num_rows($result_select) == 0)
		{
		mysqli_free_result($result_select);
		mysqli_close($link);
		?>
		<script type="text/JavaScript">
			<!--
			alert ("查無資料，請冾網站管理人員！");
			history.go(-1);
			//-->
		</script>
		<?php
		exit;
		}
mysqli_free_result($result_select);

$sql_insert = "INSERT INTO AgendumHistory(AID,AUID,ASID,ARID,ACID,CheckProc,ADate,AEDate,ACDate,AStatus,ReviewID,ReviewDate,ReviewIP,ReceiveID,ReceiveDate,ReceiveIP,FinishID,FinishDate,FinishIP,CheckID,CheckDate,CheckIP,AItem,Attribute,PID,CID,CName,CTel,CFax,Contact,CMobile,CEMail,CAddress,AFile,ANote,AddUser,AddDate,AddIP,Deltag,ProcUser,ProcDate,ProcIP,UpdateUser,UpdateDate,UpdateIP) SELECT AID,AUID,ASID,ARID,ACID,CheckProc,ADate,AEDate,ACDate,AStatus,ReviewID,ReviewDate,ReviewIP,ReceiveID,ReceiveDate,ReceiveIP,FinishID,FinishDate,FinishIP,CheckID,CheckDate,CheckIP,AItem,Attribute,PID,CID,CName,CTel,CFax,Contact,CMobile,CEMail,CAddress,AFile,ANote,AddUser,AddDate,AddIP,Deltag,ProcUser,ProcDate,ProcIP,'".$_SESSION["reg_MUID"]."','".$now_time."','".$_SERVER["REMOTE_ADDR"]."' FROM Agendum where Deltag='N' and AID = '".$AID."';";
$result_insert=mysqli_query($link,$sql_insert) or die ("無法執行新增");
$sql_update = "update Agendum set Deltag = 'Y',ProcUser = '".$_SESSION["reg_MUID"]."',ProcDate = '".$now_time."',ProcIP = '".$_SERVER["REMOTE_ADDR"]."' where Deltag='N' and AID = '".$AID."';";
$result_update=mysqli_query($link,$sql_update) or die ("無法執行修改");

mysqli_close($link);
?>
<script type="text/JavaScript">
	<!--
	alert ("刪除成功！");
	location.href='AgendumList.php?page=<?php echo $page;?>&QAStatus=<?php echo $QAStatus;?>&QASID=<?php echo $QASID;?>&QARID=<?php echo $QARID;?>&QACID=<?php echo $QACID;?>&Late=<?php echo $Late;?>&KeyWord=<?php echo urlencode($KeyWord);?>';
	//-->
</script>

</body>
</html>
