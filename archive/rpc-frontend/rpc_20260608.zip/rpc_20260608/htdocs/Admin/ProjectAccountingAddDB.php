﻿<?php
include "CheckPermission.php";
include "CheckProjectAccounting.php";
include "../global.php";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $PageAdminTitle;?></title>
</head>
<body>
<?php
$PID = $_POST['PID'];
$spage = $_POST['spage'];
$KeyWord = $_POST['KeyWord'];
$QPStatus = $_POST['QPStatus'];
$QAcc = $_POST['QAcc'];
$PAMode = $_POST['PAMode'];
if (trim($PAMode) == "") $PAMode = "I";
$PAItem = $_POST['PAItem'];
$Charges = $_POST['Charges'];
$ChargesOtherText = $_POST['ChargesOtherText'];
$ChargesOther = $_POST['ChargesOther'];
$Rate = $_POST['Rate'];
if (trim($Rate) == "") $Rate = "0";
if (trim($Rate) == "0") $ChargesOther = "0";
$PANote = $_POST['PANote'];
$PANote = str_replace("\r\n","<br>",$PANote);
$PAPDate = "";
$PAPYear = $_POST['PAPYear'];
$PAPMonth = $_POST['PAPMonth'];
$PAPDay = $_POST['PAPDay'];
if (trim($PAPYear) != "" || trim($PAPMonth) != "" || trim($PAPDay) != "") if (checkdate($PAPMonth,$PAPDay ,$PAPYear)) $PAPDate = $PAPYear."-".$PAPMonth."-".$PAPDay;

$InvoiceYear = $_POST['InvoiceYear'];
$InvoiceMonth = $_POST['InvoiceMonth'];
$InvoiceDay = $_POST['InvoiceDay'];
if (trim($InvoiceYear) != "" && trim($InvoiceMonth) != "" && trim($InvoiceDay) != "") if (checkdate($InvoiceMonth,$InvoiceDay ,$InvoiceYear)) $InvoiceDate = $InvoiceYear."-".$InvoiceMonth."-".$InvoiceDay;
$Invoice = $_POST['Invoice'];

$CID = $_POST['CID'];
$CName = $_POST['CName'];
$CTel = $_POST['CTel'];
$CFax = $_POST['CFax'];
$CAddress = $_POST['CAddress'];
$PA_Mode = $_POST['PA_Mode'];
$PATax = $_POST['PATax'];

if (trim($PID) == "" || trim($PAMode) == "" || trim($PAItem) == "" || trim($Charges) == "")
		{
		mysqli_close($link);
		?>
		<script type="text/JavaScript">
			<!--
			alert ("您輸入的資料不足，請重新輸入！");
			history.go(-1);
			//-->
		</script>
		<?php
		exit;
		}

$SQL_Project="select PUID,PName from Project where Deltag='N' and PID = '".$PID."';";
$result_Project=mysqli_query($link,$SQL_Project) or die ("無法執行查詢");
if (mysqli_num_rows($result_Project) == 0)
		{
		mysqli_free_result($result_Project);
		mysqli_close($link);
		?>
		<SCRIPT language=javascript>
		<!--
		alert ("查無資料，請冾網站管理人員！"); 
		history.go(-1);
		//-->
		</SCRIPT>
		<?php 	
		exit;
		}
mysqli_free_result($result_Project);

if (trim($InvoiceDate)=="") $InvoiceDate = "NULL";
else $InvoiceDate = "'$InvoiceDate'";
$now_time = date("Y-m-d H:i:s",mktime());
if (trim($CID) == "") $CID = 0;
if (trim($PAPDate)=="") $PAPDate = "NULL";
else $PAPDate = "'$PAPDate'";

$sql_insert = "insert into ProjectAccounting (PID,PAMode,PAItem,Charges,Rate,ChargesOther,PATax,PAPDate,InvoiceDate,Invoice,PANote,CID,CName,CTel,CFax,CAddress,AddUser,AddDate,AddIP) values ('".$PID."','".$PAMode."','".addslashes($PAItem)."','".$Charges."','".$Rate."','".$ChargesOther."','".$PATax."',".$PAPDate.",".$InvoiceDate.",'".$Invoice."','".addslashes($PANote)."','".$CID."','".$CName."','".$CTel."','".$CFax."','".$CAddress."','".$_SESSION["reg_MUID"]."','".$now_time."','".$_SERVER["REMOTE_ADDR"]."');";
$result_insert=mysqli_query($link,$sql_insert) or die ("無法執行新增");

mysqli_close($link);
?>
<script type="text/JavaScript">
	<!--
	alert ("新增成功！");
	location.href='ProjectAccountingList.php?PID=<?php echo $PID;?>&page=<?php echo $spage;?>&QPStatus=<?php echo $QPStatus;?>&QAcc=<?php echo $QAcc;?>&KeyWord=<?php echo urlencode($KeyWord);?>&PA_Mode=<?php echo $PA_Mode;?>';
	//-->
</script>

</body>
</html>
