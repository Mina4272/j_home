﻿<?php
session_start();
include "../global.php";
?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $PageAdminTitle;?></title>
</head>
<body>
<?php
$MUID = $_POST['MUID'];
$MPassword = $_POST['MPassword'];

if (trim($MUID) == "" || trim($MPassword) == "")
		{
		?>
		<SCRIPT language=javascript>
		<!--
		alert ("您輸入的帳號或密碼空白，請重新輸入！"); 
		history.go(-1);
		//-->
		</SCRIPT>
		<?php	
		exit;
		}

//skip the offline(1 minute) check!!
//$SQL_select="select MName,EMail,MPer,MLoginTime from manager where IsLeft = 'N' and DelTag = 'N' and (DATE_ADD( MLoginTime, INTERVAL 1 MINUTE ) < now( ) or MLoginTime is null) and MUID = '".$MUID."' and MPassword = '".$MPassword."';";
$SQL_select="select MID,MName,MUID,MPer,MLoginTime,ifnull((SELECT sum(EVCount) FROM EmployeeVacation WHERE Deltag = 'N' AND MID=Manager.MID ),0) EVCount from manager where IsLeft = 'N' and DelTag = 'N' and MUID = '".$MUID."' and MPassword = '".$MPassword."';";
//echo $SQL_select;
//exit;
$result_select=mysqli_query($link,$SQL_select) or die ("Cannot execute query.");

if (mysqli_num_rows($result_select) != 0)
		{
		list($MID,$MName,$MUID,$MPer,$MLoginTime,$EVCount)=mysqli_fetch_row($result_select);
		$_SESSION["reg_MID"] = $MID;
		$_SESSION["reg_MName"] = $MName;
		$_SESSION["reg_MUID"] = $MUID;
		$_SESSION["reg_MPer"] = $MPer;
		$_SESSION["reg_MLoginTime"] = $MLoginTime;
		$_SESSION["reg_EVCount"] = $EVCount;

		$now_time = date("Y-m-d H:i:s",mktime());
		$sql_update = "update manager set MLoginTime = '".$now_time."' where DelTag = 'N' and MUID = '".$MUID."' and MPassword = '".$MPassword."';";
		
		$result_update=mysqli_query($link,$sql_update) or die ("無法執行修改");
		mysqli_free_result($result_select);
		mysqli_close($link);
		?>
		<SCRIPT language=javascript>
				<!--
				location.href = 'index_new.php';
				//-->
		</SCRIPT>
		<?	
		}
else
		{
		mysqli_free_result($result_select);
		mysqli_close($link);
		session_unset(void);
		?>
		<SCRIPT language=javascript>
				<!--
				alert ("您輸入的帳號或密碼錯誤，請稍後重新輸入！"); 
				history.go(-1);
				//-->
		</SCRIPT>
		<?php	
		}
		?>
</body>
</html>
