﻿<?php
include "CheckPermission.php";
include "CheckProjectAccounting.php";
include "../global.php";
include "include/page_function.php";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $PageAdminTitle;?></title>
<link href="../type.css" rel="stylesheet" type="text/css" />
<Script type="text/javascript" language="javascript" src="../script/CheckForm.js"></Script>
</head>

<body>
<table width="520" border="0" align="center" cellpadding="2" cellspacing="0">
  <tr>
    <td align="left"><span class="c2"><b>案件報價記錄</b></span>
    </td>
  </tr>
  <tr>
    <td align="left">
			<?php
			$page = $_GET['page'];
			if (trim($page) == "") $page = 1;
			$page_rows=15;  //每頁筆數
			$php_Self = "ProjectQuotationRecord.php";  //分頁web檔名

			$button_css = "h4";
			$limit_txt =" limit ".(($page-1) * $page_rows).",".$page_rows;
			$url_str = "";
			$Sql_str="select PQRID,PQRUID,QuoteDate,AddUser from ProjectQuotationRecord order by PQRID desc;";
			$SQL_ProjectQuotationRecord="select PQRID,PQRUID,QuoteDate,AddUser,Deltag from ProjectQuotationRecord order by PQRID desc ".$limit_txt.";";
			$result_ProjectQuotationRecord=mysqli_query($link,$SQL_ProjectQuotationRecord) or die ("無法執行查詢");
			?>
    	<table width="100%" border="0" cellpadding="2" cellspacing="2" class="s2">
        <tr align="center">
          <td width="200" background="../images/table_bg.gif" class="t2">報價日期</td>
          <td width="100" background="../images/table_bg.gif" class="t2">報價人員</td>
          <td background="../images/table_bg.gif" class="t2">報價單內容</td>
        </tr>
        <?php
        $tmp = 1;
        while(list($PQRID,$PQRUID,$QuoteDate,$AddUser,$Deltag)=mysqli_fetch_row($result_ProjectQuotationRecord)){
      	?>
	    	<tr<?php if ($tmp%2 == 0) echo " bgcolor=\"#F6F6F6\"";?>>
          <td align="center" class="h3"><?php echo $QuoteDate;?><?php if (trim($Deltag) == "N") echo "<font color=red>(最新報價)</font>";?></td>
          <td align="center" class="h3"><?php echo $AddUser;?></td>
          <td align="center" class="h3"><input type="button" name="Quotation" value="報價單內容" class="input_bot" onclick="javascript:window.open ('ProjectQuotationView.php?PQRUID=<?php echo $PQRUID;?>','ProjectQuotationView','');"></td>
        </tr>
        <?php
      			$tmp++;
      			}
      	mysqli_free_result($result_ProjectQuotationRecord);
        ?>
      </table>
      <table width="100%" border="0" cellpadding="2" cellspacing="2" class="s2">
        <tr align="center">
          <td bgcolor="#E8F0C2" class="h4"><?php Page_show($Sql_str,$page_rows,$php_Self,$link,$page,$url_str,$button_css);?></td>
        </tr>
      </table>

    </td>
  </tr>
</table>
</body>
</html>
<?php
mysqli_close($link);
?>