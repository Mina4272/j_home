﻿<?php
include "CheckPermission.php";
include "CheckProject.php";
include "../global.php";
include "include/function.php";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $PageAdminTitle;?></title>
</head>
<body>
<?php
$PID = $_POST['PID'];
$PSType = $_POST['PSType'];
$PSYear = $_POST['PSYear'];
$PSMonth = $_POST['PSMonth'];
$PSDay = $_POST['PSDay'];
if (trim($PSYear) != "" || trim($PSMonth) != "" || trim($PSDay) != "") if (checkdate($PSMonth,$PSDay ,$PSYear)) $PSDate = $PSYear."-".$PSMonth."-".$PSDay;
$PSCount = $_POST['PSCount'];
$PSMode = $_POST['PSMode'];
$PSPersonnel = $_POST['PSPersonnel'];
$SPlace = $_POST['SPlace'];
$IPlace = $_POST['IPlace'];
$PSend = $_POST['PSend'];
$PSNote = $_POST['PSNote'];
if (trim($PID) == "" || trim($PSType) == "" || trim($PSDate) == "" || trim($PSCount) == "")
		{
		mysqli_close($link);
		?>
		<script type="text/JavaScript">
			<!--
			alert ("您輸入的資料不足，請重新輸入！");
			self.close();
			//-->
		</script>
		<?php
		exit;
		}

if(trim($_FILES['PSFile']['tmp_name']) != "")
		{
		if($_FILES['PSFile']['size'] > 20971520)
				{
				?>
				<script type="text/JavaScript">
					<!--
					alert ("您上傳的檔案 Size 超過 20 M，請重新上傳！");
					history.go(-1);
					//-->
				</script>
				<?php
				exit();
				}
		$PFIntro1 = $_POST['PFIntro1'];
		$PSFile = "PSFile_".$PID.date("ymdHis",mktime()).rand_string(5, 'ABCDEFGHIJKLMNPQRSTUVWXYZ23456789abcdefghijklmnopqrstuvwxyz').".".strtolower(substr($_FILES['PSFile']['name'],strrpos($_FILES['PSFile']['name'],".")+1,strlen($_FILES['PSFile']['name'])+1));
		@copy($_FILES['PSFile']['tmp_name'],$_SERVER["DOCUMENT_ROOT"]."\\Admin\\PSFile\\".$PSFile);
		}

$now_time = date("Y-m-d H:i:s",mktime());
$sql_insert = "insert into ProjectSample (PID,PSType,PSDate,PSCount,PSMode,PSPersonnel,SPlace,IPlace,PSend,PSNote,PSFile,AddUser,AddDate,AddIP) values ('".$PID."','".$PSType."','".$PSDate."','".$PSCount."','".$PSMode."','".$PSPersonnel."','".$SPlace."','".$IPlace."','".$PSend."','".$PSNote."','".$PSFile."','".$_SESSION["reg_MUID"]."','".$now_time."','".$_SERVER["REMOTE_ADDR"]."');";
$result_insert=mysqli_query($link,$sql_insert) or die ("無法執行新增");

mysqli_close($link);
?>
<script type="text/JavaScript">
	<!--
	alert ("新增成功！");
	opener.location.reload();
	self.close();
	//-->
</script>

</body>
</html>
