﻿<?php
include "CheckPermission.php";
include "CheckCustomer.php";
include "../global.php";
include "include/page_function.php";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $PageAdminTitle;?></title>
<link href="../type.css" rel="stylesheet" type="text/css" />
<style type="text/css">
<!--
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
}
-->
</style></head>

<body>
<?php
$SqlTxt="";
$CID = empty($_GET['CID'])?"":$_GET['CID'];
$page = empty($_GET['page'])?"":$_GET['page'];
if (trim($page) == "") $page = 1;
$page_rows=10;  //每頁筆數
$php_Self = "CustomerContact.php";  //分頁web檔名

$button_css = "h4";
$limit_txt =" limit ".(($page-1) * $page_rows).",".$page_rows;
$url_str = "&CID=".$CID;
$Sql_str="select CCID,Contact,CMobile,CEMail,AddUser,AddDate,ProcUser,ProcDate,CDep,CNote from CustomerContact where Deltag='N' and CID = '".$CID."' ".$SqlTxt." order by CCID desc;";
$SQL_CustomerContact="select CCID,Contact,CMobile,CEMail,AddUser,AddDate,ProcUser,ProcDate,CDep,CNote from CustomerContact where Deltag='N' and CID = '".$CID."' ".$SqlTxt." order by CCID desc ".$limit_txt.";";
$result_CustomerContact=mysqli_query($link,$SQL_CustomerContact) or die ("無法執行查詢");
?>
<table width="100%" border="0" cellpadding="5" cellspacing="2" class="s2">
  <tr>
    <td width="15%" align="center" background="../images/table_bg.gif" class="t21"><input type="button" name="add" value="新 增" class="input_bot" onclick="javascript:window.open ('CustomerContactAdd.php?CID=<?php echo $CID;?>','CustomerContactAdd','height=230,width=550,top=200,left=200,scrollbars=yes,status=yes');"><br>聯絡人</td>
    <td width="10%" align="center" background="../images/table_bg.gif" class="t21">部 門</td>
    <td width="15%" align="center" background="../images/table_bg.gif" class="t21">電 話</td>
    <td width="30%" align="center" background="../images/table_bg.gif" class="t21">E-Mail</td>
    <td width="20%" align="center" background="../images/table_bg.gif" class="t21">聯絡事項</td>
    <td width="5%" align="center" background="../images/table_bg.gif" class="t21">修 改</td>
    <td width="5%" align="center" background="../images/table_bg.gif" class="t21">刪 除</td>
  </tr>
  <?php
  $tmp = 1;
  while(list($CCID,$Contact,$CMobile,$CEMail,$AddUser,$AddDate,$ProcUser,$ProcDate,$CDep,$CNote)=mysqli_fetch_row($result_CustomerContact)){
	?>
	<tr<?php if ($tmp%2 == 0) echo " bgcolor=\"#F6F6F6\"";?>>
    <td class="h3" align="center"><?php echo $Contact;?></td>
    <td class="h3" align="center"><?php echo $CDep;?></td>
    <td class="h3" align="center"><?php echo $CMobile;?></td>
    <td class="h3" align="center"><?php echo $CEMail;?></td>
    <td class="h3" align="center"><?php echo $CNote;?></td>
    <td align="center"><input type="button" name="edit" value="修 改" class="input_bot" onclick="javascript:window.open ('CustomerContactEdit.php?CID=<?php echo $CID;?>&CCID=<?php echo $CCID;?>','CustomerContactEdit','height=280,width=550,top=200,left=200,scrollbars=yes,status=yes');"></td>
    <td align="center"><input type="button" name="edit" value="刪 除" class="input_bot" onclick="javascript:if (confirm('您是否確定要刪除？')) location.href='CustomerContactDelDB.php?CID=<?php echo $CID;?>&CCID=<?php echo $CCID;?>&page=<?php echo $page;?>';"></td>
  </tr>
  <?php
			$tmp++;
			}
	mysqli_free_result($result_CustomerContact);
  ?>
</table>
<table width="100%" border="0" cellpadding="5" cellspacing="2" class="s2">
  <tr align="center">
    <td bgcolor="#E8F0C2" class="h4"><?php Page_show($Sql_str,$page_rows,$php_Self,$link,$page,$url_str,$button_css);?></td>
  </tr>
</table>
</body>
</html>
<?php
mysqli_close($link);
?>