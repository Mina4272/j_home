﻿<?php
include "CheckPermission.php";
include "CheckProjectAccounting.php";
include "../global.php";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $PageAdminTitle;?></title>
</head>
<body>
<?php
$PID = $_GET['PID'];
$PAID = $_GET['PAID'];
$spage = $_GET['spage'];
$KeyWord = $_GET['KeyWord'];
$QPStatus = $_GET['QPStatus'];
$QAcc = $_GET['QAcc'];
$PA_Mode = $_GET['PA_Mode'];

if (trim($PID) == "" || trim($PAID) == "")
		{
		mysqli_close($link);
		?>
		<script type="text/JavaScript">
			<!--
			alert ("您輸入的資料不足，請重新輸入！");
			history.go(-1);
			//-->
		</script>
		<?php
		exit;
		}

$SQL_Project="select QuoteDate from Project where Deltag='N' and PID = '".$PID."';";
$result_Project=mysqli_query($link,$SQL_Project) or die ("無法執行查詢");
if (mysqli_num_rows($result_Project) == 0)
		{
		mysqli_free_result($result_Project);
		mysqli_close($link);
		?>
		<SCRIPT language=javascript>
		<!--
		alert ("查無資料，請冾網站管理人員！"); 
		history.go(-1);
		//-->
		</SCRIPT>
		<?php 	
		exit;
		}
list($QuoteDate)=mysqli_fetch_row($result_Project);
mysqli_free_result($result_Project);
if (trim($QuoteDate) == "0000-00-00") $QuoteDate = "";
if (trim($QuoteDate) != "") $QuoteCheck = "True";

$SQL_ProjectAccounting="select PAStatus,PAMode from ProjectAccounting where Deltag='N' and PID = '".$PID."' and PAID = '".$PAID."';";
$result_ProjectAccounting=mysqli_query($link,$SQL_ProjectAccounting) or die ("無法執行查詢");
if (mysqli_num_rows($result_ProjectAccounting) == 0)
		{
		mysqli_free_result($result_ProjectAccounting);
		mysqli_close($link);
		?>
		<SCRIPT language=javascript>
		<!--
		alert ("查無資料，請冾網站管理人員！"); 
		history.go(-1);
		//-->
		</SCRIPT>
		<?php 	
		exit;
		}
list($CheckStatus,$PAMode)=mysqli_fetch_row($result_ProjectAccounting);		
mysqli_free_result($result_ProjectAccounting);

$now_time = date("Y-m-d H:i:s",mktime());
$sql_insert = "INSERT INTO ProjectAccountingHistory(PAID,PID,PANo,PAMode,PAItem,Charges,Rate,ChargesOther,PATax,PAStatus,PAPDate,PADate,PARecord,PARecordDate,PARecordIP,CID,CName,CTel,CFax,CAddress,InvoiceDate,Invoice,PANote,AddUser,AddDate,AddIP,Deltag,ProcUser,ProcDate,ProcIP,UpdateUser,UpdateDate,UpdateIP) SELECT PAID,PID,PANo,PAMode,PAItem,Charges,Rate,ChargesOther,PATax,PAStatus,PAPDate,PADate,PARecord,PARecordDate,PARecordIP,CID,CName,CTel,CFax,CAddress,InvoiceDate,Invoice,PANote,AddUser,AddDate,AddIP,Deltag,ProcUser,ProcDate,ProcIP,'".$_SESSION["reg_MUID"]."','".$now_time."','".$_SERVER["REMOTE_ADDR"]."' FROM ProjectAccounting where Deltag='N' and PID = '".$PID."' and PAID = '".$PAID."';";
$result_insert=mysqli_query($link,$sql_insert) or die ("無法執行新增");
$sql_update = "update ProjectAccounting set PAStatus = 'W',PADate=NULL,ProcUser = '".$_SESSION["reg_MUID"]."',ProcDate = '".$now_time."',ProcIP = '".$_SERVER["REMOTE_ADDR"]."' where Deltag='N' and PID = '".$PID."' and PAID = '".$PAID."';";
$result_update=mysqli_query($link,$sql_update) or die ("無法執行修改");

mysqli_close($link);
?>
<script type="text/JavaScript">
	<!--
	alert ("清除成功！");
	location.href='ProjectAccountingList.php?PID=<?php echo $PID;?>&page=<?php echo $spage;?>&QPStatus=<?php echo $QPStatus;?>&QAcc=<?php echo $QAcc;?>&KeyWord=<?php echo urlencode($KeyWord);?>&PA_Mode=<?php echo $PA_Mode;?>';
	//-->
</script>

</body>
</html>
