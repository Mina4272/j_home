<?php
include "CheckPermission.php";
//include "CheckManager.php";
include "../global.php";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $PageAdminTitle;?></title>
</head>
<body>
<?php
$MJID = $_POST['MJID'];

if (!is_array($MJID))
		{
		mysqli_close($link);
		?>
		<script type="text/JavaScript">
			<!--
			alert ("您輸入的資料不足，請重新輸入@@！");
			history.go(-1);
			//-->
		</script>
		<?php
		exit;
		}
 
foreach($MJID as $v){
	$sql_job = "update managerjob set MID = '".$_SESSION["reg_MID"]."',receivemid=''  where MJID='".$v."'";
	$result_job=mysqli_query($link,$sql_job) or die ("無法執行更新");
	
}
mysqli_close($link);
?>
<script type="text/JavaScript">
	<!--
	alert ("更新成功！");
	location.href='ManagerJobcheck.php?MID=<?php echo $_SESSION["reg_MID"]; ?>';
	//-->
</script>

</body>
</html>
