﻿<?php

include "CheckPermission.php";
include "CheckTraining.php";
include "../global.php";
include "include/function.php";
require_once("../include/chinese_party.class.php");
require("class.phpmailer.php");


?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $PageAdminTitle;?></title>
<link href="../type.css" rel="stylesheet" type="text/css" />
</head>

<body>
<?php
//echo "TFile=".$HTTP_POST_FILES['TFile']['name']."<br>";
//echo "TFile=".$HTTP_POST_FILES['TFile']['tmp_name']."<br>";
//exit;


if(isset($_POST['code'])) {
if($_POST['code'] == $_SESSION['code']){
	
	$_SESSION['code']+=1;

$TYear = $_POST['TYear'];
$TMonth = $_POST['TMonth'];
$TDay = $_POST['TDay'];
if (trim($TYear) != "" || trim($TMonth) != "" || trim($TDay) != "") if (checkdate($TMonth,$TDay ,$TYear)) $TDate = $TYear."-".$TMonth."-".$TDay;
$TCID = $_POST['TCID'];
$TTitle = $_POST['TTitle'];
$Lecturer = $_POST['Lecturer'];
$TLocation = $_POST['TLocation'];
if($TLocation == "other"){
	$othertext = $_POST['othertext'];
}else{
	$othertext = "NULL";
}
$TTrain = $_POST['TTrain'];
if($TTrain == "out"){
	$outtext = $_POST['outtext'];
}else{
	$outtext = "NULL";
}
$THour = $_POST['THour'];
$TExam = $_POST['TExam'];
if($TExam =="other"){
	$othernote = $_POST['othernote'];
}else{
	$othernote = "NULL";
}
$TContent = $_POST['TContent'];
$TContent = str_replace("\r\n","<br>",$TContent);
//print_r($_FILES);
//exit;
$now_time = date("Y-m-d H:i:s",mktime());
if(trim($_FILES['TFile']['tmp_name']) != "")
		{
		if($_FILES['TFile']['size'] > 20971520)
				{
				?>
				<script type="text/JavaScript">
					<!--
					alert ("您上傳的檔案 Size 超過 20 M，請重新上傳！");
					history.go(-1);
					//-->
				</script>
				<?php
				exit();
				}
		$TFile = "TFile_".date("ymdHis",mktime()).rand_string(5, 'ABCDEFGHIJKLMNPQRSTUVWXYZ23456789abcdefghijklmnopqrstuvwxyz').".".strtolower(substr($_FILES['TFile']['name'],strrpos($_FILES['TFile']['name'],".")+1,strlen($_FILES['TFile']['name'])+1));
		@copy($_FILES['TFile']['tmp_name'],$_SERVER["DOCUMENT_ROOT"]."\\Admin\\TFile\\".$TFile);
		}
$now_time = date("Y-m-d H:i:s",mktime());
if(trim($_FILES['TTrainRecord']['tmp_name']) != "")
		{
		if($_FILES['TTrainRecord']['size'] > 20971520)
				{
				?>
				<script type="text/JavaScript">
					<!--
					alert ("您上傳的檔案 Size 超過 20 M，請重新上傳！");
					history.go(-1);
					//-->
				</script>
				<?php
				exit();
				}
		$TTrainRecord = "TTrainRecord_".date("ymdHis",mktime()).rand_string(5, 'ABCDEFGHIJKLMNPQRSTUVWXYZ23456789abcdefghijklmnopqrstuvwxyz').".".strtolower(substr($_FILES['TTrainRecord']['name'],strrpos($_FILES['TTrainRecord']['name'],".")+1,strlen($_FILES['TTrainRecord']['name'])+1));
		@copy($_FILES['TTrainRecord']['tmp_name'],$_SERVER["DOCUMENT_ROOT"]."\\Admin\\TTFile\\".$TTrainRecord);
		}
$TMid = $_POST['TMid'];
if (trim($TDate) == "" || trim($TTitle) == "" || trim($Lecturer) == "" || !is_array($TMid))
		{
		mysqli_close($link);
		?>
		<script type="text/JavaScript">
			<!--
			alert ("您輸入的資料不足，請重新輸入！");
			history.go(-1);
			//-->
		</script>
		<?php
		exit;
		}

$sql_insert = "insert into Training (TDate,TCID,TTitle,Lecturer,TLocation,othertext,TTrain,outtext,THour,TExam,othernote,TFile,TContent,TTrainRecord,AddUser,AddDate,AddIP) values ('".$TDate."','".$TCID."','".$TTitle."','".$Lecturer."','".$TLocation."','".$othertext."','".$TTrain."','".$outtext."','".$THour."','".$TExam."','".$othernote."','".$TFile."','".$TContent."','".$TTrainRecord."','".$_SESSION["reg_MUID"]."','".$now_time."','".$_SERVER["REMOTE_ADDR"]."');";
$result_insert=mysqli_query($link,$sql_insert) or die ("無法執行新增");
$select = "select Tid from Training order by Tid desc limit 1,1";
$result_select=mysqli_query($link,$select) or die ("無法執行新增");
list($Tid)=mysqli_fetch_row($result_select);

foreach($TMid as $v){
	//echo $v;
	//echo "<br/>";
	$sql = "insert into trainingexam (TID,MID,Grade,checkGrade,TEFile,Deltag,AddUser,AddDate,AddIP) values('".($Tid+1)."','".$v."','','Y','','N','".$_SESSION["reg_MUID"]."','".$now_time."','".$_SERVER["REMOTE_ADDR"]."')";
	$result=mysqli_query($link,$sql) or die ("無法執行新增");
}
$EMAILFN = "Training.htm";
$subject="教育訓練資訊通知 ！！";
$fp=fopen($EMAILFN,"r");
$content="";
while($line=fgets($fp,512)){
	$content.=$line;
	}
fclose($fp);

$content = str_replace("{TDate}",$TDate,$content);
$content = str_replace("{TTitle}",$TTitle,$content);
$content = str_replace("{Lecturer}",$Lecturer,$content);
$content = str_replace("{TContent}",$TContent,$content);

//$cconv =& new chinese_party();
//$cconv = new chinese_party();
//$content = $cconv->u82tchi($content);
//$subject = $cconv->u82tchi($subject);

//$SQL_Manager="SELECT EMail FROM Manager WHERE Deltag = 'N';";
$SQL_Manager="SELECT EMail FROM Manager WHERE IsLeft ='N' and Deltag = 'N';";
$result_Manager=mysqli_query($link,$SQL_Manager) or die ("無法執行查詢");



$mail = new PHPMailer();
$mail->IsSMTP();
$mail->SMTPAuth = true; //設定SMTP需要驗證
$mail->SMTPSecure = "ssl"; // Gmail的SMTP主機需要使用SSL連線
$mail->Host = "smtp.gmail.com"; //Gamil的SMTP主機
$mail->Port = 465; //Gamil的SMTP主機的埠號(Gmail為465)。
$mail->CharSet = "utf-8"; //郵件編碼
$mail->Username = "benson@rpclab.com"; //Gamil帳號
$mail->Password = "benson6567"; //Gmail密碼
$mail->From     = "Benson@rpclab.com";
$mail->FromName = $subject;
$mail->WordWrap = 50;
$mail->IsHTML(true);                               // send as HTML
//$mail->CharSet = "big5";
$mail->Subject  = $subject;
$mail->Body     =  $content;
while(list($EMail)=mysqli_fetch_row($result_Manager)){
	$mail->AddAddress($EMail,"");
}
$mail->AddReplyTo("Benson@rpclab.com");
if(!$mail->Send())
{
		    //echo "There has been a mail error sending to " . $SendEMail . "<br>";
		    //echo "Mailer Error: " . $mail->ErrorInfo . "<br>";
}
else
{
				//echo $SendEMail . " sending !!<br>";
}		
$mail->ClearAddresses();
$mail->ClearReplyTos();
$mail->SmtpClose();

mysqli_free_result($result_Manager);

mysqli_close($link);
}
}
?>

<script type="text/JavaScript">

	alert ("教育訓練訊息新增完成！");
	location.href='TrainingList.php';

</script>

</body>
</html>
