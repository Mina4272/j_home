﻿<?php	
include "CheckPermission.php";
include "../global.php";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $PageAdminTitle;?></title>
<link href="../type.css" rel="stylesheet" type="text/css" />
<style type="text/css">
<!--
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
}
-->
</style>
<link href="../script/DatePicker.css" rel="stylesheet" type="text/css" />
<Script LANGUAGE="Javascript" SRC="../script/DatePicker.js"></Script>
<Script type="text/javascript" language="javascript" src="../script/CheckForm.js"></Script>
<script type="text/JavaScript">
<!--
function jsCheck() 
		{
		//if (ChkImp('IFlorin',document.form1.IFlorin.value,'收入貨幣種類') == false) return false;
		//if (ChkImp('OFlorin',document.form1.OFlorin.value,'支出貨幣種類') == false) return false;
		}
//-->
</script>
</head>
<body>
<?php
$PID = $_GET['PID'];
if (trim($PID) == "")
		{
		mysqli_close($link);
		?>
		<script type="text/JavaScript">
			<!--
			alert ("查無資料，請冾網站管理人員！");
			self.close();
			//-->
		</script>
		<?php
		exit;
		}

$SQL_Project="select IFlorin,OFlorin from Project where Deltag='N' and PID = '".$PID."';";
$result_Project=mysqli_query($link,$SQL_Project) or die ("無法執行查詢");
if (mysqli_num_rows($result_Project) == 0)
		{
		mysqli_free_result($result_Project);
		mysqli_close($link);
		?>
		<SCRIPT language=javascript>
		<!--
		alert ("查無資料，請冾網站管理人員！"); 
		history.go(-1);
		//-->
		</SCRIPT>
		<?php 	
		exit;
		}
list($IFlorin,$OFlorin)=mysqli_fetch_row($result_Project);
mysqli_free_result($result_Project);
?>
<table width="100%" border="0" cellpadding="0" cellspacing="0">
	<tr>
		<td>
    	<table width="100%" border="0" cellpadding="0" cellspacing="0">
    		<tr height="40">
					<td width="15" background="../images/table_bg.gif"></td>
    			<td class="c3" background="../images/table_bg.gif"><b>設定案件使用貨幣</b></td>
    		</tr>
    	</table>
    	<table width="100%" border="0" cellpadding="0" cellspacing="0">
        <form name="form1" method="post" action="ProjectFlorinDB.php" onSubmit="return jsCheck();">
        <tr height="40" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
          <td class="c3" align="right" colspan="2">收入貨幣種類：</td>
          <td class="c3">
            <input name="IFlorin" type="text" size="15" value="<?php echo $IFlorin;?>" />
          </td>
        </tr>
        <tr height="40" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
          <td class="c3" align="right" colspan="2">支出貨幣種類：</td>
          <td class="h3">
            <input name="OFlorin" type="text" size="15" value="<?php echo $OFlorin;?>" />
          </td>
        </tr>
        <tr height="20" align="center">
          <td colspan="3" class="h3"><font color=red>若未輸入貨幣種類，系統將自動歸類為新台幣。</font>
          </td>
        </tr>
        <tr height="40" align="center">
          <td colspan="3" class="h3">
          	<input type="submit" name="submit" class="input_bot" value="送 出">
          	<input name="PID" type="hidden" id="PID" value="<?php echo $PID;?>" />
          </td>
        </tr>
	      </form>
      </table>
		</td>
	</tr>
</table>
</body>
</html>
<?php
mysqli_close($link);
?>