﻿<?php
include "CheckPermission.php";
include "CheckEmployeePay.php";
include "../global.php";
$QEEPDate="";
$SqlTxt="";
$SqlMID = "";
$limit_txt = "";
$QSEPYear = $_POST['QSEPYear'];
$QSEPMonth = $_POST['QSEPMonth'];
$QSEPDay = $_POST['QSEPDay'];
if (trim($QSEPYear) != "" || trim($QSEPMonth) != "") if (checkdate($QSEPMonth,$QSEPDay ,$QSEPYear)) $QSEPDate = $QSEPYear."-".$QSEPMonth."-".$QSEPDay;
$QEEPYear = $_POST['QEEPYear'];
$QEEPMonth = $_POST['QEEPMonth'];
$QEEPDay = $_POST['QEEPDay'];
if (trim($QEEPYear) != "" || trim($QEEPMonth) != "") if (checkdate($QEEPMonth,$QEEPDay ,$QEEPYear)) $QEEPDate = $QEEPYear."-".$QEEPMonth."-".$QEEPDay;
$KeyWord = $_POST['KeyWord'];
if (trim($KeyWord) == "") $KeyWord = empty($_GET['KeyWord'])?"":$_GET['KeyWord'];
$IsLeft = $_POST['IsLeft'];
if (trim($IsLeft) == "") $IsLeft = empty($_GET['IsLeft'])?"":$_GET['IsLeft'];

if (trim($QSEPDate) != "" && trim($QEEPDate) != "") $SqlTxt = $SqlTxt." and (EPDate >= '".$QSEPDate."') and (EPDate <= '".$QEEPDate."') ";
else if (trim($QSEPDate) != "" && trim($QEEPDate) == "") $SqlTxt = $SqlTxt." and (EPDate >= '".$QSEPDate."') ";
else if (trim($QSEPDate) == "" && trim($QEEPDate) != "") $SqlTxt = $SqlTxt." and (EPDate <= '".$QEEPDate."') ";

if (trim($KeyWord) != "") {
		$SQL_Manager="select MID from Manager where EmployeeNo like '%".$KeyWord."%' or MName like '%".$KeyWord."%' order by MID;";
		$result_Manager=mysqli_query($link,$SQL_Manager) or die ("無法執行查詢");
		
		while(list($MMID)=mysqli_fetch_row($result_Manager)){
				if (trim($SqlMID) == "") $SqlMID = $MMID;
				else $SqlMID = $SqlMID.",".$MMID;
				}
		mysqli_free_result($result_Manager);
		}
if (trim($SqlMID) != "") $SqlMID = " a.MID in (".$SqlMID.")";
if (trim($KeyWord) != "") {
		if (trim($SqlMID) == "") $SqlTxt = $SqlTxt." and (a.EPay like '%".$KeyWord."%' or a.Salary like '%".$KeyWord."%' or a.Allowance like '%".$KeyWord."%' or a.Other like '%".$KeyWord."%')";
		else $SqlTxt = $SqlTxt." and (a.EPay like '%".$KeyWord."%' or a.Salary like '%".$KeyWord."%' or a.Allowance like '%".$KeyWord."%' or a.Other like '%".$KeyWord."%' or ".$SqlMID.")";
		}

if (trim($SqlTxt) == "") $SqlTxt = " and (EPDate = '".date("Y-m",mktime())."-1') ";
if (trim($IsLeft) != "") $SqlTxt .= " and b.IsLeft = '".$IsLeft."'";
$SQL_EmployeePay="select a.EPID,a.MID,
									(select BCode from Manager where MID=a.MID) BCode,
									(select BAccount from Manager where MID=a.MID) BAccount,
									(select MName from Manager where MID=a.MID) MName,
									(select EmployeeNo from Manager where MID=a.MID) EmployeeNo,
									(select MPID from Manager where MID=a.MID) MPID,
									(select EMail from Manager where MID=a.MID) EMail,
									(select Departments from Manager where MID=a.MID) Departments,
									a.EPDate,date_format(a.EPDate,'%Y'),date_format(a.EPDate,'%m'),a.EPay,a.Salary,a.Allowance,a.Overtime,a.Transportation1,a.Transportation2,a.Bonus,a.CRetirement,a.CLabor,a.CHealth,a.ELabor,a.EHealth,a.PLeave,a.SickLeave,a.EVAmount,a.Other,a.OtherDesc 
									from EmployeePay a,Manager b where a.MID=b.MID and a.Deltag='N' and b.Deltag='N' ".$SqlTxt." order by a.MID,a.EPID asc ".$limit_txt.";";
$result_EmployeePay=mysqli_query($link,$SQL_EmployeePay) or die ("無法執行查詢");
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $PageAdminTitle;?></title>
<link href="style.css" rel="stylesheet" type="text/css" />
<body>
<table winth="1000" border="0">
	<tr>
		<td colspan="2"><font color=blue>若您無法正常觀看此報表！請下載此 <a href="owc11.zip" target="_File"><font color=red><b>元件</b></font></a> <font color=blue>安裝至您的電腦。</font></td>
	</tr>
</table>
<object id=EmployeePay classid=CLSID:0002E559-0000-0000-C000-000000000046 style="width:100%;height:90%"></object>
<script language=vbscript>
	Sub Window_OnLoad()
	Set chConstants = EmployeePay.Constants
	EmployeePay.ActiveSheet.Cells.Clear
	EmployeePay.Worksheets(1).Select
	EmployeePay.ActiveSheet.Name ="EmployeePay"

	EmployeePay.ActiveSheet.Cells(1,1).Value ="帳號"
	EmployeePay.ActiveSheet.Cells(1,2).Value ="交易金額"
	EmployeePay.ActiveSheet.Cells(1,3).Value ="行庫代號"
	EmployeePay.ActiveSheet.Cells(1,4).Value ="身份證號"
	EmployeePay.ActiveSheet.Cells(1,5).Value ="email帳號"
	EmployeePay.ActiveSheet.Cells(1,6).Value ="受扣款用戶編號"
	EmployeePay.ActiveSheet.Cells(1,7).Value ="全威驗證科技有限公司"
	EmployeePay.ActiveSheet.Cells(1,8).Value ="部門別"
	EmployeePay.ActiveSheet.Cells(1,9).Value ="本薪"
	EmployeePay.ActiveSheet.Cells(1,10).Value ="職務加給"
	EmployeePay.ActiveSheet.Cells(1,11).Value ="加班費"
	EmployeePay.ActiveSheet.Cells(1,12).Value ="交通費-公里數計算"
	EmployeePay.ActiveSheet.Cells(1,13).Value ="交通費-實報實銷"
	EmployeePay.ActiveSheet.Cells(1,14).Value ="績效獎金"
	EmployeePay.ActiveSheet.Cells(1,15).Value ="勞退公司提撥"
	EmployeePay.ActiveSheet.Cells(1,16).Value ="勞保費-公司負擔"
	EmployeePay.ActiveSheet.Cells(1,17).Value ="健保費-公司負擔"
	EmployeePay.ActiveSheet.Cells(1,18).Value ="受款名目(金額10)"
	EmployeePay.ActiveSheet.Cells(1,19).Value ="勞保費-員工負擔"
	EmployeePay.ActiveSheet.Cells(1,20).Value ="健保費-員工負擔"
	EmployeePay.ActiveSheet.Cells(1,21).Value ="事假"
	EmployeePay.ActiveSheet.Cells(1,22).Value ="病假"
	EmployeePay.ActiveSheet.Cells(1,23).Value ="勞退公司提撥"
	EmployeePay.ActiveSheet.Cells(1,24).Value ="勞保費-公司負擔 "
	EmployeePay.ActiveSheet.Cells(1,25).Value ="健保費-公司負擔 "
	EmployeePay.ActiveSheet.Cells(1,26).Value ="受款名目(金額18)"
	EmployeePay.ActiveSheet.Cells(1,27).Value ="受款名目(金額19)"
	EmployeePay.ActiveSheet.Cells(1,28).Value ="受款名目(金額20)"
	EmployeePay.ActiveSheet.Cells(1,29).Value ="應稅金額"
	EmployeePay.ActiveSheet.Cells(1,30).Value ="勞退新制雇主提撥金"
	EmployeePay.ActiveSheet.Cells(1,31).Value ="備註"
<?php  
$ECount=2;
while(list($EPID,$MID,$BCode,$BAccount,$MName,$EmployeeNo,$MPID,$EMail,$Departments,$EPDate,$EPYear,$EPDay,$EPay,$Salary,$Allowance,$Overtime,$Transportation1,$Transportation2,$Bonus,$CRetirement,$CLabor,$CHealth,$ELabor,$EHealth,$PLeave,$SickLeave,$EVAmount,$Other,$OtherDesc)=mysqli_fetch_row($result_EmployeePay)){
  	if (trim($Departments) == "A") $Departments="工程部";
  	else if (trim($Departments) == "B") $Departments="國際認證部";
  	else if (trim($Departments) == "C") $Departments="業務部";
		?>
		EmployeePay.ActiveSheet.Cells(<?php echo $ECount;?>,1).Value ="'<?php echo $BAccount;?>"
		EmployeePay.ActiveSheet.Cells(<?php echo $ECount;?>,2).Value ="<?php echo $EPay;?>"
		EmployeePay.ActiveSheet.Cells(<?php echo $ECount;?>,3).Value ="<?php echo $BCode;?>"
		EmployeePay.ActiveSheet.Cells(<?php echo $ECount;?>,4).Value ="<?php echo $MPID;?>"
		EmployeePay.ActiveSheet.Cells(<?php echo $ECount;?>,5).Value ="<?php echo $EMail;?>"
		EmployeePay.ActiveSheet.Cells(<?php echo $ECount;?>,6).Value ="<?php echo $EmployeeNo;?>"
		EmployeePay.ActiveSheet.Cells(<?php echo $ECount;?>,7).Value ="全威驗證科技有限公司"
		EmployeePay.ActiveSheet.Cells(<?php echo $ECount;?>,8).Value ="<?php echo $Departments;?>"
		EmployeePay.ActiveSheet.Cells(<?php echo $ECount;?>,9).Value ="<?php echo $Salary;?>"
		EmployeePay.ActiveSheet.Cells(<?php echo $ECount;?>,10).Value ="<?php echo $Allowance;?>"
		EmployeePay.ActiveSheet.Cells(<?php echo $ECount;?>,11).Value ="'<?php echo $Overtime;?>"
		EmployeePay.ActiveSheet.Cells(<?php echo $ECount;?>,12).Value ="<?php echo $Transportation1;?>"
		EmployeePay.ActiveSheet.Cells(<?php echo $ECount;?>,13).Value ="<?php echo $Transportation2;?>"
		EmployeePay.ActiveSheet.Cells(<?php echo $ECount;?>,14).Value ="<?php echo $Bonus;?>"
		EmployeePay.ActiveSheet.Cells(<?php echo $ECount;?>,15).Value ="<?php echo $CRetirement;?>"
		EmployeePay.ActiveSheet.Cells(<?php echo $ECount;?>,16).Value ="<?php echo $CLabor;?>"
		EmployeePay.ActiveSheet.Cells(<?php echo $ECount;?>,17).Value ="<?php echo $CHealth;?>"
		EmployeePay.ActiveSheet.Cells(<?php echo $ECount;?>,18).Value ="<?php echo ($EVAmount+$Other);?>"
		EmployeePay.ActiveSheet.Cells(<?php echo $ECount;?>,19).Value ="<?php echo $ELabor;?>"
		EmployeePay.ActiveSheet.Cells(<?php echo $ECount;?>,20).Value ="<?php echo $EHealth;?>"
		EmployeePay.ActiveSheet.Cells(<?php echo $ECount;?>,21).Value ="<?php echo $PLeave;?>"
		EmployeePay.ActiveSheet.Cells(<?php echo $ECount;?>,22).Value ="<?php echo $SickLeave;?>"
		EmployeePay.ActiveSheet.Cells(<?php echo $ECount;?>,23).Value ="<?php echo $CRetirement;?>"
		EmployeePay.ActiveSheet.Cells(<?php echo $ECount;?>,24).Value ="<?php echo $CLabor;?>"
		EmployeePay.ActiveSheet.Cells(<?php echo $ECount;?>,25).Value ="<?php echo $CHealth;?>"
		EmployeePay.ActiveSheet.Cells(<?php echo $ECount;?>,26).Value =""
		EmployeePay.ActiveSheet.Cells(<?php echo $ECount;?>,27).Value =""
		EmployeePay.ActiveSheet.Cells(<?php echo $ECount;?>,28).Value =""
		EmployeePay.ActiveSheet.Cells(<?php echo $ECount;?>,29).Value =""
		EmployeePay.ActiveSheet.Cells(<?php echo $ECount;?>,30).Value ="<?php echo $CRetirement;?>"
		EmployeePay.ActiveSheet.Cells(<?php echo $ECount;?>,31).Value =""
		<?php
		$ECount++;
		}
mysqli_free_result($result_EmployeePay);
mysqli_close($link);
?>

		EmployeePay.ActiveSheet.Range("A1:AE<?php echo $ECount;?>").Font.Color="blue"
		EmployeePay.ActiveSheet.Range("A1:AE<?php echo $ECount;?>").Font.Name="Courier New"
		EmployeePay.ActiveSheet.Range("A1:AE<?php echo $ECount;?>").Font.Size="11"
		EmployeePay.ActiveSheet.Range("A1:AE<?php echo $ECount;?>").Columns.AutoFit
		EmployeePay.ActiveSheet.Range("A1:AE<?php echo $ECount;?>").NumberFormat ="General"

		EmployeePay.ActiveSheet.Range("A1:AE1").Font.Bold=true
		EmployeePay.ActiveSheet.Range("A1:AE1").Font.Color="#000000"
		EmployeePay.ActiveSheet.Range("A1:AE1").Font.Bold=true
		EmployeePay.ActiveSheet.Range("A1:AE1").Font.Bold=true
		EmployeePay.ActiveSheet.Range("A1:AE1").Font.Bold=true

	End Sub
	</script>
</body>
</html>
