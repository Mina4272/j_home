﻿<?php
include "CheckPermission.php";
include "../global.php";
include "include/page_function.php";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $PageAdminTitle;?></title>
<link href="../type.css" rel="stylesheet" type="text/css" />
<Script type="text/javascript" language="javascript" src="../script/CheckForm.js"></Script>
<script type="text/JavaScript">
<!--
function SelCustomer(CName) {
		opener.document.form1.KeyWord.value=CName;
		opener.document.form1.submit();
		self.close();
		}
//-->
</script>
</head>

<body>
<table width="770" border="0" align="center" cellpadding="2" cellspacing="0">
  <tr>
    <td align="left"><span class="c2"><b>連絡人查詢</b></span>
    </td>
  </tr>
  <tr>
    <td align="left">
    	<table width="100%" border="0" cellpadding="0" cellspacing="0">
    		<form name="form1" action="SelCustomerContact.php" method="post">
    		<tr>
    			<td align="left" class="h3">關鍵字：<input type="text" name="KeyWord" size="20"> <input type="submit" name="search" value="查詢"></td>
    		</tr>
    		</form>
    	</table>
			<?php
		$SqlTxt ="";
    	$KeyWord = empty($_POST['KeyWord'])?"":$_POST['KeyWord'];
    	if (trim($KeyWord) == "") $KeyWord = empty($_GET['KeyWord'])?"":$_GET['KeyWord'];
    	if (trim($KeyWord) != "") $SqlTxt = $SqlTxt." and (a.CName like '%".$KeyWord."%' or b.Contact like '%".$KeyWord."%' or b.CMobile like '%".$KeyWord."%' or b.CEMail like '%".$KeyWord."%' or b.CNote like '%".$KeyWord."%')";
			$page = empty($_GET['page'])?"":$_GET['page'];
			if (trim($page) == "") $page = 1;
			$page_rows=15;  //每頁筆數
			$php_Self = "SelCustomerContact.php";  //分頁web檔名

			$button_css = "h4";
			$limit_txt =" limit ".(($page-1) * $page_rows).",".$page_rows;
			$url_str = "&KeyWord=".urlencode($KeyWord);
			//$Sql_str="select CID,CUID,CPWD,CName,CTel,CFax,CAddress,CNote from Customer where Deltag='N' ".$SqlTxt." order by CID desc;";
			//$SQL_Customer="select CID,CUID,CPWD,CName,CTel,CFax,CAddress,CNote from Customer where Deltag='N' ".$SqlTxt." order by CID desc ".$limit_txt.";";
			$Sql_str="select a.CID,a.CName,b.Contact,b.CMobile,b.CEMail,b.CDep,b.CNote 
											from Customer a,CustomerContact b
											where a.CID=b.CID
											and a.Deltag='N'
											and b.Deltag='N' ".$SqlTxt."
											order by a.CID;";
			$SQL_Customer="select a.CID,a.CName,b.Contact,b.CMobile,b.CEMail,b.CDep,b.CNote 
											from Customer a,CustomerContact b
											where a.CID=b.CID
											and a.Deltag='N'
											and b.Deltag='N' ".$SqlTxt."
											order by a.CID ".$limit_txt.";";
			$result_Customer=mysqli_query($link,$SQL_Customer) or die ("無法執行查詢");
			?>
    	<table width="100%" border="0" cellpadding="2" cellspacing="2" class="s2">
        <tr align="center" height="40">
          <td width="200" background="../images/table_bg.gif" class="t21">公司名稱<br>連絡人</td>
          <td width="250" background="../images/table_bg.gif" class="t21">電 話<br>E-Mail</td>
          <td width="300" background="../images/table_bg.gif" class="t21">聯絡事項</td>
        </tr>
        <?php
        $tmp = 1;
        while(list($CID,$CName,$Contact,$CMobile,$CEMail,$CDep,$CNote)=mysqli_fetch_row($result_Customer)){
      	?>
    	  <form name="CForm<?php echo $CID;?>" method="post">
	    	<tr<?php if ($tmp%2 == 0) echo " bgcolor=\"#F6F6F6\"";?>>
          <td class="h3"><?php echo $CName;?><br><font color=blue><b><?php echo $Contact;?></b></font></td>
          <td align="center" class="h3"><?php echo $CMobile;?><br><?php echo $CEMail;?></td>
          <td class="h4"><?php echo $CNote;?>
          	<input type="button" name="button" class="input_bot" value="選擇" onclick="javascript:SelCustomer('<?php echo $CName;?>');">
          </td>
        </tr>
    		</form>
        <?php
      			$tmp++;
      			}
      	mysqli_free_result($result_Customer);
        ?>
      </table>
      <table width="100%" border="0" cellpadding="2" cellspacing="2" class="s2">
        <tr align="center">
          <td bgcolor="#E8F0C2" class="h4"><?php Page_show($Sql_str,$page_rows,$php_Self,$link,$page,$url_str,$button_css);?></td>
        </tr>
      </table>

    </td>
  </tr>
</table>
</body>
</html>
<?php
mysqli_close($link);
?>