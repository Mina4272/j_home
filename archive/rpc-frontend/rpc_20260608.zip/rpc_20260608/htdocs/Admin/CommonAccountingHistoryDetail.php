﻿<?php	
include "CheckPermission.php";
include "CheckCommonAccounting.php";
include "../global.php";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $PageAdminTitle;?></title>
<link href="../type.css" rel="stylesheet" type="text/css" />
<style type="text/css">
<!--
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
}
-->
</style>
<Script type="text/javascript" language="javascript" src="../script/rpc.js"></Script>
<Script type="text/javascript" language="javascript" src="../script/CheckForm.js"></Script>
</head>
<body>
<?php
$PayYear ="";
$PayMonth = "";
$PayDay = "";
$CAYear="";
$CAMonth="";
$CAHID = $_GET['CAHID'];
$CAID = $_GET['CAID'];
$page = $_GET['page'];
if (trim($CAID) == "" || trim($CAHID) == "")
		{
		mysqli_close($link);
		?>
		<script type="text/JavaScript">
			<!--
			alert ("查無資料，請冾網站管理人員！");
			history.go(-1);
			//-->
		</script>
		<?php
		exit;
		}
$SQL_CommonAccounting="select CADate from CommonAccounting where Deltag='N' and CAID = '".$CAID."';";
$result_CommonAccounting=mysqli_query($link,$SQL_CommonAccounting) or die ("無法執行查詢");
if (mysqli_num_rows($result_CommonAccounting) == 0)
		{
		mysqli_free_result($result_CommonAccounting);
		mysqli_close($link);
		?>
		<SCRIPT language=javascript>
		<!--
		alert ("查無資料，請冾網站管理人員！"); 
		history.go(-1);
		//-->
		</SCRIPT>
		<?php 	
		exit;
		}
mysqli_free_result($result_CommonAccounting);

$SQL_CommonAccounting="select CAUID,CADate,CAItem,CAType,Amount,InvoiceDate,Invoice,CAStatus,PayDate,CANote,AddUser,AddDate,ProcUser,ProcDate from CommonAccountingHistory where Deltag='N' and CAHID = '".$CAHID."';";
$result_CommonAccounting=mysqli_query($link,$SQL_CommonAccounting) or die ("無法執行查詢");
if (mysqli_num_rows($result_CommonAccounting) == 0)
		{
		mysqli_free_result($result_CommonAccounting);
		mysqli_close($link);
		?>
		<SCRIPT language=javascript>
		<!--
		alert ("查無資料，請冾網站管理人員！"); 
		history.go(-1);
		//-->
		</SCRIPT>
		<?php 	
		exit;
		}
list($CAUID,$CADate,$CAItem,$CAType,$Amount,$InvoiceDate,$Invoice,$CAStatus,$PayDate,$CANote,$AddUser,$AddDate,$ProcUser,$ProcDate)=mysqli_fetch_row($result_CommonAccounting);
mysqli_free_result($result_CommonAccounting);

?>
    	<table width="100%" border="0" cellpadding="0" cellspacing="0">
    		<tr>
    			<td>
			    	<table width="750" border="0" cellpadding="0" cellspacing="0">
			    		<tr height="30">
			    			<td class="c2" background="../images/table_bg.gif">一般帳務管理歷史資料</td>
			    		</tr>
			    	</table>
			    	<table width="750" border="0" cellpadding="0" cellspacing="0">
			        <form name="form1" method="post" action="CommonAccountingEditDB.php" onSubmit="return jsCheck();">
			        <tr height="35" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td width="120" align="right" class="c3">帳目编號：</td>
			          <td class="h3"><?php echo $CAUID;?></td>
			        </tr>
			        <tr height="35" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">所屬月份：</td>
			          <td class="h3"><?php echo $CAYear;?> 年 <?php echo $CAMonth;?> 月</td>
			        </tr>
			        <tr height="35" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">項 目：</td>
			          <td class="h3"><?php echo $CAItem;?></td>
			        </tr>
			        <tr height="35" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">類 別：</td>
			          <td class="h3">
			          	<?php
			          	if (trim($CAType) == "C") echo "公司";
			          	else if (trim($CAType) == "P") echo "個人";
			          	?>
			          </td>
			        </tr>
			        <tr height="35" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">金 額：</td>
			          <td class="h3"><?php echo $Amount;?></td>
			        </tr>
			        <tr height="35" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">發票號碼：</td>
			          <td class="h3"><?php echo $Invoice;?></td>
			        </tr>
			        <?php
							if (trim($InvoiceDate) == "0000-00-00") $InvoiceDate = "";
							?>
			        <tr height="35" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">發票日期：</td>
			          <td class="h3"><?php echo $InvoiceDate;?></td>
			        </tr>
			        <?php
							if (trim($PayYear) == "0000") $PayYear = "";
							if (trim($PayMonth) == "00") $PayMonth = "";
							if (trim($PayDay) == "00") $PayDay = "";
							?>
			        <tr height="35" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">狀 況：</td>
			          <td class="h3">
			          	<?php
			          	if (trim($CAStatus) == "W") echo "未付";
			          	else if (trim($CAStatus) == "S") echo "<font color=blue>結清</font><br>".$PayDate;
			          	else if (trim($CAStatus) == "C") echo "<font color=red>取消</font>";
			          	?>
			          </td>
			        </tr>
			        <tr height="35" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">備 註：</td>
			          <td class="h3"><?php echo $CANote;?></td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">新增人員：</td>
			          <td class="h3"><?php echo $AddUser;?>　<?php echo $AddDate;?></td>
			        </tr>
			        <?php if (trim($ProcUser) != "") {?>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">最後更新：</td>
			          <td class="h3"><?php echo $ProcUser;?>　<?php echo $ProcDate;?> 
			          </td>
			        </tr>
			        <?php }?>
			        <tr height="40" align="center">
			          <td colspan="2" class="h3"><input type="button" name="button" class="input_bot" value="回列表" onclick="javascript:location.href='CommonAccountingHistory.php?CAID=<?php echo $CAID;?>&page=<?php echo $page;?>';"></td>
			        </tr>
				      </form>
			      </table>
    			</td>
    		</tr>
    	</table>
</body>
</html>
<?php
mysqli_close($link);
?>