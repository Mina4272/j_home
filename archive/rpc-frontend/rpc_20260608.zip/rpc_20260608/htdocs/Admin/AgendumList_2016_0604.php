﻿<?php
include "CheckPermission.php";
include "CheckAgendum.php";
include "../global.php";
include "include/page_function.php";
include "include/utf8.php";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $PageAdminTitle;?></title>
<link href="../type.css" rel="stylesheet" type="text/css" />
<style type="text/css">
<!--
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
}
-->
</style></head>

<body>
<?php include "top.php";?>
<table width="100%" border="0" cellspacing="0" cellpadding="5">
	<tr>
    <td width="160" height="600" align="left" valign="top">
			<?php include "menu.php";?>
    </td>
    <td valign="top">
    	<table width="100%" border="0" cellpadding="0" cellspacing="0">
    		<tr>
    			<td>
			    	<table width="750" border="0" cellpadding="0" cellspacing="0">
			    		<tr height="30">
			    			<td class="c2">事項處理</td>
			    		</tr>
			    	</table>
			    	<table width="750" border="0" cellpadding="0" cellspacing="0">
			    		<form name="form1" action="AgendumList.php" method="post">
			    		<tr>
			    			<?php
								$SQL_Manager="select MUID,MName,MEName from Manager where Deltag='N' and IsLeft='N';";
								$result_Manager=mysql_query($SQL_Manager,$link) or die ("無法執行查詢");
			    			?>
			    			<td align="left" class="h3">派案人：
			    				<select name="QASID">
			    					<option value="">不限</option>
			          		<?php while(list($MUID,$MName,$MEName)=mysql_fetch_row($result_Manager)){?>
			          		<option value="<?php echo $MUID;?>"<?php if (trim($MUID) == trim($QASID)) echo " selected";?>><?php echo $MEName.$MName;?></option>
			          		<?php }?>
			    				</select>
			    			</td>
				        <?php mysql_free_result($result_Manager);?>
			    			<?php
								$SQL_Manager="select MUID,MName,MEName from Manager where Deltag='N' and IsLeft='N';";
								$result_Manager=mysql_query($SQL_Manager,$link) or die ("無法執行查詢");
			    			?>
			    			<td align="left" class="h3">接案人：
			    				<select name="QARID">
			    					<option value="">不限</option>
			          		<?php while(list($MUID,$MName,$MEName)=mysql_fetch_row($result_Manager)){?>
			          		<option value="<?php echo $MUID;?>"<?php if (trim($MUID) == trim($QARID)) echo " selected";?>><?php echo $MEName.$MName;?></option>
			          		<?php }?>
			    				</select>
			    			</td>
				        <?php mysql_free_result($result_Manager);?>
			    			<?php
								$SQL_Manager="select MUID,MName,MEName from Manager where Deltag='N' and IsLeft='N';";
								$result_Manager=mysql_query($SQL_Manager,$link) or die ("無法執行查詢");
			    			?>
			    			<td align="left" class="h3">審核人：
			    				<select name="QACID">
			    					<option value="">不限</option>
			          		<?php while(list($MUID,$MName,$MEName)=mysql_fetch_row($result_Manager)){?>
			          		<option value="<?php echo $MUID;?>"<?php if (trim($MUID) == trim($QACID)) echo " selected";?>><?php echo $MEName.$MName;?></option>
			          		<?php }?>
			    				</select>
			    			</td>
				        <?php mysql_free_result($result_Manager);?>
			    		</tr>
			    		<tr>
			    			<td width="230" align="left" class="h3">關鍵字：<input type="text" name="KeyWord" size="15" value="<?php echo $KeyWord;?>"></td>
			    			<td align="left" class="h3">狀態：
			    				<select name="QAStatus">
			    					<option value="">不限</option>
			    					<option value="A"<?php if (trim($QAStatus) == "A") echo " selected";?>>案件指派</option>
			    					<option value="B"<?php if (trim($QAStatus) == "B") echo " selected";?>>簽核完成</option>
			    					<option value="C"<?php if (trim($QAStatus) == "C") echo " selected";?>>接案處理中</option>
			    					<option value="D"<?php if (trim($QAStatus) == "D") echo " selected";?>>完成回報</option>
			    					<option value="E"<?php if (trim($QAStatus) == "E") echo " selected";?>>驗收</option>
			    				</select> <input type="checkbox" id="Late" name="Late" value="1"<?php if (trim($Late) == "1") echo " checked";?>>逾期未完成 
			    				<input type="submit" class="input_bot" name="search" value="查詢">
			    			</td>
			    			<td class="h3">
			    				<input type="button" name="button" class="input_bot" value="全部列出" onclick="javascript:location.href='AgendumList.php';"> 
			    				<input type="button" name="add" value="新 增" class="input_bot" onclick="javascript:location.href='AgendumAdd.php';"></td>
			    		</tr>
			    		</form>
			    	</table>
						<?php
			    	$KeyWord = $_POST['KeyWord'];
			    	if (trim($KeyWord) == "") $KeyWord = $_GET['KeyWord'];
			    	$QAStatus = $_POST['QAStatus'];
			    	if (trim($QAStatus) == "") $QAStatus = $_GET['QAStatus'];
			    	$QASID = $_POST['QASID'];
			    	if (trim($QASID) == "") $QASID = $_GET['QASID'];
			    	$QARID = $_POST['QARID'];
			    	if (trim($QARID) == "") $QARID = $_GET['QARID'];
			    	$QACID = $_POST['QACID'];
			    	if (trim($QACID) == "") $QACID = $_GET['QACID'];
			    	$Late = $_POST['Late'];
			    	if (trim($Late) == "") $Late = $_GET['Late'];
			    	
			    	if (trim($KeyWord) != "") {
					    	$SQL_AgendumNote="select AID from AgendumNote where Deltag='N' and AContent like '%".$KeyWord."%'";
					    	$result_AgendumNote=mysql_query($SQL_AgendumNote,$link) or die ("無法執行查詢");
					    	while(list($AID)=mysql_fetch_row($result_AgendumNote)){
					    			if (trim($AIDStr) == "") $AIDStr = $AID;
					    			else $AIDStr = $AIDStr.",".$AID;
					    			}
								mysql_free_result($result_AgendumNote);
								if (trim($AIDStr) != "") $SqlAID = " or AID in (".$AIDStr.") ";
			    			$SqlTxt = $SqlTxt." and (AUID like '%".$KeyWord."%' or AItem like '%".$KeyWord."%' or CName like '%".$KeyWord."%' or CTel like '%".$KeyWord."%' or CFax like '%".$KeyWord."%' or Contact like '%".$KeyWord."%' or CMobile like '%".$KeyWord."%' or CEMail like '%".$KeyWord."%' or CAddress like '%".$KeyWord."%' ".$SqlAID.")";
			    			}
			    	if (trim($QAStatus) != "") $SqlTxt = $SqlTxt." and AStatus='".$QAStatus."' ";
			    	if (trim($QASID) != "") $SqlTxt = $SqlTxt." and ASID='".$QASID."' ";
			    	if (trim($QARID) != "") $SqlTxt = $SqlTxt." and ARID='".$QARID."' ";
			    	if (trim($QACID) != "") $SqlTxt = $SqlTxt." and ACID='".$QACID."' ";
			    	if (trim($Late) == "1") $SqlTxt = $SqlTxt." and AStatus <> 'E' AND AEDate < now( ) ";
						
						$page = $_GET['page'];
						if (trim($page) == "") $page = 1;
						$page_rows=15;  //每頁筆數
						$php_Self = "AgendumList.php";  //分頁web檔名

						$button_css = "h4";
						$limit_txt =" limit ".(($page-1) * $page_rows).",".$page_rows;
						$url_str = "&QAStatus=".$QAStatus."&QASID=".$QASID."&QARID=".$QARID."&QACID=".$QACID."&Late=".$Late."&KeyWord=".urlencode($KeyWord);
						$Sql_str="select AID,AUID,ASID,ARID,ACID,CheckProc,ADate,AEDate,ACDate,AStatus,AItem,Attribute,AUID,CID,CName,CTel,CFax,Contact,CMobile,CEMail,CAddress,AFile from Agendum where Deltag='N' ".$SqlTxt." order by AStatus asc,AID desc;";
						$SQL_Agendum="select AID,AUID,ASID,ARID,ACID,CheckProc,ADate,AEDate,ACDate,AStatus,AItem,Attribute,AUID,CID,CName,CTel,CFax,Contact,CMobile,CEMail,CAddress,AFile,CASE WHEN AStatus <> 'E' AND AEDate < now( ) THEN 'r' ELSE '' END ChkAE from Agendum where Deltag='N' ".$SqlTxt." order by AStatus asc,AID desc ".$limit_txt.";";
						$result_Agendum=mysql_query($SQL_Agendum,$link) or die ("無法執行查詢");
						?>
			    	<table width="750" border="0" cellpadding="5" cellspacing="2" class="s2">
			        <tr align="center">
			          <td width="80" align="center" background="../images/table_bg.gif" class="t21">派案編號</td>
			          <td background="../images/table_bg.gif" class="t21">項目 / 測試項目</td>
			          <td width="100" background="../images/table_bg.gif" class="t21">派案人<br>接案人<br>審核人</td>
			          <td width="120" background="../images/table_bg.gif" class="t21">狀態</td>
			          <td width="60" background="../images/table_bg.gif" class="t21">案件屬性</td>
			          <td width="50" background="../images/table_bg.gif" class="t21">修改<br>刪除</td>
			        </tr>
		          <?php
		          $tmp = 1;
		          while(list($AID,$AUID,$ASID,$ARID,$ACID,$CheckProc,$ADate,$AEDate,$ACDate,$AStatus,$AItem,$Attribute,$AUID,$CID,$CName,$CTel,$CFax,$Contact,$CMobile,$CEMail,$CAddress,$AFile,$ChkAE)=mysql_fetch_row($result_Agendum)){
	          	if (utf8_strlen(strip_tags($CName)) > 4) $CName = utf8_substr(strip_tags($CName),0,4);
	          	else $CName = strip_tags($CName);

							$SQL_Manager="select MName,MEName from Manager where MUID = '".$ASID."';";
							$result_Manager=mysql_query($SQL_Manager,$link) or die ("無法執行查詢");
							list($ASName,$ASEName)=mysql_fetch_row($result_Manager);
							mysql_free_result($result_Manager);

							$SQL_Manager="select MName,MEName from Manager where MUID = '".$ARID."';";
							$result_Manager=mysql_query($SQL_Manager,$link) or die ("無法執行查詢");
							list($ARName,$AREName)=mysql_fetch_row($result_Manager);
							mysql_free_result($result_Manager);

							$SQL_Manager="select MName,MEName from Manager where MUID = '".$ACID."';";
							$result_Manager=mysql_query($SQL_Manager,$link) or die ("無法執行查詢");
							list($ACName,$ACEName)=mysql_fetch_row($result_Manager);
							mysql_free_result($result_Manager);
							?>
		        	<tr<?php if ($tmp%2 == 0) echo " bgcolor=\"#F6F6F6\"";?>>
			          <td align="center" class="h3<?php echo $ChkAE;?>"><?php echo $AUID;?></td>
			          <td class="h3<?php echo $ChkAE;?>"><?php echo $AItem;?></td>
			          <td align="center" class="h3<?php echo $ChkAE;?>"><?php echo $ASEName.$ASName;?><br><?php echo $AREName.$ARName;?><br><?php echo $ACEName.$ACName;?></td>
			          <td align="center" class="h3<?php echo $ChkAE;?>">
			          	<?php
			          	if (trim($AStatus) == "A") {
			          			if (trim($CheckProc) == "N") echo "案件未確認指派";
			          			else if (trim($CheckProc) == "Y") {
			          					echo "案件指派中";
									if ($_SESSION["reg_MUID"] == "benson"){
										echo $_SESSION["reg_MUID"];
										echo "<input type=\"button\" name=\"receive\" value=\"簽 核\" class=\"input_bot\" onclick=\"javascript:if (confirm('您是否確定要簽核？')) location.href='AgendumReviewDB.php?AID=".$AID."&page=".$page.$url_str."';\">";
										}
			          					if (trim(strtolower($_SESSION["reg_MUID"])) == trim(strtolower($ACID))) echo "<input type=\"button\" name=\"receive\" value=\"簽 核\" class=\"input_bot\" onclick=\"javascript:if (confirm('您是否確定要簽核？')) location.href='AgendumReviewDB.php?AID=".$AID."&page=".$page.$url_str."';\">";
									}
							}
			          	else if (trim($AStatus) == "B") {
			          			echo "簽核完成";
		        					if (trim(strtolower($_SESSION["reg_MUID"])) == trim(strtolower($ARID))) echo "<input type=\"button\" name=\"receive\" value=\"接 案\" class=\"input_bot\" onclick=\"javascript:if (confirm('您是否確定要接案？')) location.href='AgendumReceiveDB.php?AID=".$AID."&page=".$page.$url_str."';\">";
			          			}
			          	else if (trim($AStatus) == "C") {
			          			echo "接案處理中";
			          			if (trim(strtolower($_SESSION["reg_MUID"])) == trim(strtolower($ARID))) echo "<input type=\"button\" name=\"finish\" value=\"完成回報\" class=\"input_bot\" onclick=\"javascript:if (confirm('您是否確定要回報完成？')) location.href='AgendumFinishDB.php?AID=".$AID."&page=".$page.$url_str."';\">";
			          			}
			          	else if (trim($AStatus) == "D") {
			          			echo "已完成回報";
			          			if (trim(strtolower($_SESSION["reg_MUID"])) == trim(strtolower($ACID))) echo "<input type=\"button\" name=\"check\" value=\"驗 收\" class=\"input_bot\" onclick=\"javascript:if (confirm('您是否確定要驗收？')) location.href='AgendumCheckDB.php?AID=".$AID."&page=".$page.$url_str."';\">";
			          			}
			          	else if (trim($AStatus) == "E") echo "驗收";
			          	?>
			          </td>
			          <td align="center" class="h3<?php echo $ChkAE;?>">
			          	<?php
			          	if (trim($Attribute) == "A") echo "測試";
			          	else if (trim($Attribute) == "B") echo "事項處理";
			          	else if (trim($Attribute) == "C") echo "採購";
			          	?>
			          </td>
			          <td align="center">
			          	<input type="button" name="edit" value="修改" class="input_bot" onclick="javascript:location.href='AgendumEdit.php?AID=<?php echo $AID;?>&page=<?php echo $page;?><?php echo $url_str;?>';"><br>
			          	<input type="button" name="edit" value="刪除" class="input_bot" onclick="javascript:if (confirm('您是否確定要刪除？')) location.href='AgendumDelDB.php?AID=<?php echo $AID;?>&page=<?php echo $page;?><?php echo $url_str;?>';"<?php if (trim($AStatus) != "A") echo " disabled";?>>
			          </td>
			        </tr>
			        <?php
            			$tmp++;
			      			}
            	mysql_free_result($result_Agendum);
			        ?>
			      </table>
			      <table width="750" border="0" cellpadding="5" cellspacing="2" class="s2">
			        <tr align="center">
			          <td bgcolor="#E8F0C2" class="h4"><?php Page_show($Sql_str,$page_rows,$php_Self,$link,$page,$url_str,$button_css);?></td>
			        </tr>
			      </table>
    			</td>
    		</tr>
    	</table>
    </td>
	</tr>
</table>
<?php include "down.php";?>
</body>
</html>
<?php
mysql_close($link);
?>