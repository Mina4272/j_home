﻿<?php
include "CheckPermission.php";
include "CheckAccountingReport.php";
include "../global.php";
require_once 'PHPExcel.php';

$CID = $_POST['CID'];

$QSYear = $_POST['QSYear'];
$QSMonth = $_POST['QSMonth'];
$QEYear = $_POST['QEYear'];
$QEMonth = $_POST['QEMonth'];

if (trim($QSYear) != "" && trim($QSMonth) != "") {
		$QSDate = $QSYear."-".$QSMonth."-01";
		$QSMonth = $QSYear."-".$QSMonth;
		}
if (trim($QEYear) != "" && trim($QEMonth) != "") {
		$QEDay = date("t",strtotime($QEYear."-".$QEMonth."-01"));
		$QEDate = $QEYear."-".$QEMonth."-".$QEDay;
		$QEMonth = $QEYear."-".$QEMonth;
		}

if (trim($QSDate) != "" && trim($QEDate) != "") {
		$SqlTxt = " AND date_format( AddDate, '%Y-%m-%d' ) BETWEEN '".$QSDate."' AND '".$QEDate."' ";
		}
else if (trim($QSDate) != "" && trim($QEDate) == "") {
		$SqlTxt = " AND date_format( AddDate, '%Y-%m' ) = '".$QSMonth."' ";
		}
else if (trim($QSDate) == "" && trim($QEDate) != "") {
		$SqlTxt = " AND date_format( AddDate, '%Y-%m' ) = '".$QEMonth."' ";
		}


$SQL_Project="select PID,PUID,CID,CName,CTel,CFax,Contact,CMobile,CEMail,CAddress,PStatus,PName,ModelName,SeriesModel,PE,Quote,ApplyItem,Canon,SNote,PlanDate,CloseDate,PNote,QuoteDate,ReturnDate,(SELECT sum(Charges) AS SumICharges FROM projectaccounting WHERE PID=Project.PID AND PAMode = 'I' AND (PAStatus = 'W' OR PAStatus = 'S') AND Deltag = 'N') as SumICharges,(SELECT sum(Charges) AS SumOCharges FROM projectaccounting WHERE PID=Project.PID AND PAMode = 'O' AND (PAStatus = 'W' OR PAStatus = 'S') AND Deltag = 'N') as SumOCharges from Project where Deltag='N' and CID = '".$CID."' ".$SqlTxt." order by PID;";
$result_Project=mysqli_query($link,$SQL_Project) or die ("無法執行查詢");
//echo $SQL_Project;
//exit;
$objPHPExcel = new PHPExcel();
$objPHPExcel->setActiveSheetIndex(0);

$objPHPExcel->getActiveSheet()->setCellValue('A1',"合約編號");
$objPHPExcel->getActiveSheet()->setCellValue('B1',"公司名稱");
$objPHPExcel->getActiveSheet()->setCellValue('C1',"產品名稱");
$objPHPExcel->getActiveSheet()->setCellValue('D1',"型號");
$objPHPExcel->getActiveSheet()->setCellValue('E1',"系列型號");
$objPHPExcel->getActiveSheet()->setCellValue('F1',"申請項目");
$objPHPExcel->getActiveSheet()->setCellValue('G1',"規範");
$objPHPExcel->getActiveSheet()->setCellValue('H1',"案件狀態");
$objPHPExcel->getActiveSheet()->setCellValue('I1',"案件價格");
$objPHPExcel->getActiveSheet()->setCellValue('J1',"測試費用");
$objPHPExcel->getActiveSheet()->setCellValue('K1',"案件盈收");
$objPHPExcel->getActiveSheet()->setCellValue('L1',"案件盈收比例");

$objPHPExcel->getActiveSheet()->getStyle("A1")->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("B1")->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("C1")->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("D1")->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("E1")->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("F1")->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("G1")->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("H1")->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("I1")->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("J1")->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("K1")->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("L1")->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);

$Ecount=2;
$TolCharges=0;             
$SumIChargesTol=0;
$SumOChargesTol=0;
$sum=0;

while(list($PID,$PUID,$CID,$CName,$CTel,$CFax,$Contact,$CMobile,$CEMail,$CAddress,$PStatus,$PName,$ModelName,$SeriesModel,$PE,$Quote,$ApplyItem,$Canon,$SNote,$PlanDate,$CloseDate,$PNote,$QuoteDate,$ReturnDate,$SumICharges,$SumOCharges)=mysqli_fetch_row($result_Project)){
		if (trim($SumICharges) == "") $SumICharges = 0;
		if (trim($SumOCharges) == "") $SumOCharges = 0;
		if (trim($ModelName) == "") $ModelName = "NA";
  	if (trim($PStatus) == "A") $PStatus="新開案";
  	else if (trim($PStatus) == "B") $PStatus="報價中";
  	else if (trim($PStatus) == "C") $PStatus="案件處理中";
  	else if (trim($PStatus) == "D") $PStatus="審查中";
  	else if (trim($PStatus) == "E") $PStatus="補件中";
  	else if (trim($PStatus) == "F") $PStatus="待印證";
  	else if (trim($PStatus) == "G") $PStatus="案件取消";
  	else if (trim($PStatus) == "H") $PStatus="已結案";
		$SumIChargesTol=$SumIChargesTol+$SumICharges;
		$SumOChargesTol=$SumOChargesTol+$SumOCharges;
	
	if (trim($SumICharges) != 0) $sum =(($SumICharges-$SumOCharges)/$SumICharges);echo $sum = "0";
			
	$objPHPExcel->getActiveSheet()->setCellValue('A'.$Ecount,$PUID);
	$objPHPExcel->getActiveSheet()->setCellValue('B'.$Ecount,$CName);
	$objPHPExcel->getActiveSheet()->setCellValue('C'.$Ecount,$PName);
	$objPHPExcel->getActiveSheet()->setCellValue('D'.$Ecount,$ModelName);
	$objPHPExcel->getActiveSheet()->setCellValue('E'.$Ecount,$SeriesModel);
	$objPHPExcel->getActiveSheet()->setCellValue('F'.$Ecount,$ApplyItem);
	$objPHPExcel->getActiveSheet()->setCellValue('G'.$Ecount,$Canon);
	$objPHPExcel->getActiveSheet()->setCellValue('H'.$Ecount,$PStatus);
	$objPHPExcel->getActiveSheet()->setCellValue('I'.$Ecount,$SumICharges);
	$objPHPExcel->getActiveSheet()->setCellValue('J'.$Ecount,$SumOCharges);
	$objPHPExcel->getActiveSheet()->setCellValue('K'.$Ecount,($SumICharges-$SumOCharges));
	$objPHPExcel->getActiveSheet()->setCellValue('L'.$Ecount,$sum);

	
	$objPHPExcel->getActiveSheet()->getStyle('A'.$Ecount)->getFont()->setSize(12);
	$objPHPExcel->getActiveSheet()->getStyle('B'.$Ecount)->getFont()->setSize(12);
	$objPHPExcel->getActiveSheet()->getStyle('C'.$Ecount)->getFont()->setSize(12);
	$objPHPExcel->getActiveSheet()->getStyle('D'.$Ecount)->getFont()->setSize(12);
	$objPHPExcel->getActiveSheet()->getStyle('E'.$Ecount)->getFont()->setSize(12);
	$objPHPExcel->getActiveSheet()->getStyle('F'.$Ecount)->getFont()->setSize(12);
	$objPHPExcel->getActiveSheet()->getStyle('G'.$Ecount)->getFont()->setSize(12);
	$objPHPExcel->getActiveSheet()->getStyle('H'.$Ecount)->getFont()->setSize(12);
	$objPHPExcel->getActiveSheet()->getStyle('I'.$Ecount)->getFont()->setSize(12);
	$objPHPExcel->getActiveSheet()->getStyle('J'.$Ecount)->getFont()->setSize(12);
	$objPHPExcel->getActiveSheet()->getStyle('K'.$Ecount)->getFont()->setSize(12);
	$objPHPExcel->getActiveSheet()->getStyle('L'.$Ecount)->getFont()->setSize(12);

	$Ecount++;
}
mysqli_free_result($result_Project);

$s=0;

if (trim($SumIChargesTol) != 0) $s=(($SumIChargesTol-$SumOChargesTol)/$SumIChargesTol); else $s = "0";

$objPHPExcel->getActiveSheet()->setCellValue('A'.$Ecount,"");
$objPHPExcel->getActiveSheet()->setCellValue('B'.$Ecount,"");
$objPHPExcel->getActiveSheet()->setCellValue('C'.$Ecount,"");
$objPHPExcel->getActiveSheet()->setCellValue('D'.$Ecount,"");
$objPHPExcel->getActiveSheet()->setCellValue('E'.$Ecount,"");
$objPHPExcel->getActiveSheet()->setCellValue('F'.$Ecount,"");
$objPHPExcel->getActiveSheet()->setCellValue('G'.$Ecount,"");
$objPHPExcel->getActiveSheet()->setCellValue('H'.$Ecount,"總計");
$objPHPExcel->getActiveSheet()->setCellValue('I'.$Ecount,$SumIChargesTol);
$objPHPExcel->getActiveSheet()->setCellValue('J'.$Ecount,$SumOChargesTol);
$objPHPExcel->getActiveSheet()->setCellValue('K'.$Ecount,($SumIChargesTol-$SumOChargesTol));
$objPHPExcel->getActiveSheet()->setCellValue('L'.$Ecount,$s);

$objPHPExcel->getActiveSheet()->getStyle("A".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("B".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("C".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("D".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("E".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("F".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("G".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("H".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("I".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("J".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("K".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("L".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);

$objPHPExcel->getActiveSheet()->setTitle('CustomerSurveyExport');

ob_end_clean();

header('Content-Type: application/vnd.ms-excel');
header('Content-Disposition: attachment;filename="CustomerSurveyExport.xls"');
header('Cache-Control: max-age=0');
$objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel5');
$objWriter->save('php://output');
exit;
		
		
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $PageAdminTitle;?></title>
<link href="style.css" rel="stylesheet" type="text/css" />
<body>
<table winth="1000" border="0">
	<tr>
		<td colspan="2"><font color=blue>若您無法正常觀看此報表！請下載此 <a href="owc11.zip" target="_File"><font color=red><b>元件</b></font></a> <font color=blue>安裝至您的電腦。</font></td>
	</tr>
</table>
<object id=ProjectAccounting classid=CLSID:0002E559-0000-0000-C000-000000000046 style="width:100%;height:90%"></object>
<script language=vbscript>
	Sub Window_OnLoad()
	Set chConstants = ProjectAccounting.Constants
	ProjectAccounting.ActiveSheet.Cells.Clear
	ProjectAccounting.Worksheets(1).Select
	ProjectAccounting.ActiveSheet.Name ="ProjectAccounting"

	ProjectAccounting.ActiveSheet.Cells(1,1).Value ="合約編號"
	ProjectAccounting.ActiveSheet.Cells(1,2).Value ="公司名稱"
	ProjectAccounting.ActiveSheet.Cells(1,3).Value ="產品名稱"
	ProjectAccounting.ActiveSheet.Cells(1,4).Value ="型號"
	ProjectAccounting.ActiveSheet.Cells(1,5).Value ="系列型號"
	ProjectAccounting.ActiveSheet.Cells(1,6).Value ="申請項目"
	ProjectAccounting.ActiveSheet.Cells(1,7).Value ="規範"
	ProjectAccounting.ActiveSheet.Cells(1,8).Value ="案件狀態"
	ProjectAccounting.ActiveSheet.Cells(1,9).Value ="案件價格"
	ProjectAccounting.ActiveSheet.Cells(1,10).Value ="測試費用"
	ProjectAccounting.ActiveSheet.Cells(1,11).Value ="案件盈收"
	ProjectAccounting.ActiveSheet.Cells(1,12).Value ="案件盈收比例"
<?php  
$ECount=2;
$TolCharges=0;             
$SumIChargesTol=0;
$SumOChargesTol=0;
while(list($PID,$PUID,$CID,$CName,$CTel,$CFax,$Contact,$CMobile,$CEMail,$CAddress,$PStatus,$PName,$ModelName,$SeriesModel,$PE,$Quote,$ApplyItem,$Canon,$SNote,$PlanDate,$CloseDate,$PNote,$QuoteDate,$ReturnDate,$SumICharges,$SumOCharges)=mysqli_fetch_row($result_Project)){
		if (trim($SumICharges) == "") $SumICharges = 0;
		if (trim($SumOCharges) == "") $SumOCharges = 0;
		if (trim($ModelName) == "") $ModelName = "NA";
  	if (trim($PStatus) == "A") $PStatus="新開案";
  	else if (trim($PStatus) == "B") $PStatus="報價中";
  	else if (trim($PStatus) == "C") $PStatus="案件處理中";
  	else if (trim($PStatus) == "D") $PStatus="審查中";
  	else if (trim($PStatus) == "E") $PStatus="補件中";
  	else if (trim($PStatus) == "F") $PStatus="待印證";
  	else if (trim($PStatus) == "G") $PStatus="案件取消";
  	else if (trim($PStatus) == "H") $PStatus="已結案";
		$SumIChargesTol=$SumIChargesTol+$SumICharges;
		$SumOChargesTol=$SumOChargesTol+$SumOCharges;
		?>
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,1).Value ="<?php echo $PUID;?>"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,2).Value ="<?php echo $CName;?>"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,3).Value ="<?php echo $PName;?>"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,4).Value ="<?php echo $ModelName;?>"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,5).Value ="<?php echo $SeriesModel;?>"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,6).Value ="<?php echo $ApplyItem;?>"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,7).Value ="<?php echo $Canon;?>"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,8).Value ="<?php echo $PStatus;?>"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,9).Value ="<?php echo $SumICharges;?>"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,10).Value ="<?php echo $SumOCharges;?>"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,11).Value ="<?php echo ($SumICharges-$SumOCharges);?>"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,12).Value ="<?php if (trim($SumICharges) != 0) echo (($SumICharges-$SumOCharges)/$SumICharges); else echo "0";?>"
		<?php
		$ECount++;
		}
mysqli_free_result($result_Project);
?>
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,1).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,2).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,3).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,4).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,5).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,6).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,7).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,8).Value ="總計"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,9).Value ="<?php echo $SumIChargesTol;?>"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,10).Value ="<?php echo $SumOChargesTol;?>"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,11).Value ="<?php echo ($SumIChargesTol-$SumOChargesTol);?>"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,12).Value ="<?php if (trim($SumIChargesTol) != 0) echo (($SumIChargesTol-$SumOChargesTol)/$SumIChargesTol); else echo "0";?>"

		ProjectAccounting.ActiveSheet.Range("A1:L<?php echo $ECount;?>").Font.Color="blue"
		ProjectAccounting.ActiveSheet.Range("A1:L<?php echo $ECount;?>").Font.Name="Courier New"
		ProjectAccounting.ActiveSheet.Range("A1:L<?php echo $ECount;?>").Font.Size="11"
		ProjectAccounting.ActiveSheet.Range("A1:L<?php echo $ECount;?>").Columns.AutoFit
		ProjectAccounting.ActiveSheet.Range("A1:L<?php echo $ECount;?>").NumberFormat ="General"

	End Sub
	</script>
</body>
</html>
