﻿<?php
include "CheckPermission.php";
include "CheckProjectAccounting.php";
include "../global.php";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $PageAdminTitle;?></title>
</head>
<body>
<?php
$Invoice = $_POST['Invoice'];
//$InvoiceYear = $_POST['InvoiceYear'];
//$InvoiceMonth = $_POST['InvoiceMonth'];
//$InvoiceDay = $_POST['InvoiceDay'];
//if (trim($InvoiceYear) != "" && trim($InvoiceMonth) != "" && trim($InvoiceDay) != "") if (checkdate($InvoiceMonth,$InvoiceDay ,$InvoiceYear)) $InvoiceDate = $InvoiceYear."-".$InvoiceMonth."-".$InvoiceDay;
$PAYear = $_POST['PAYear'];
$PAMonth = $_POST['PAMonth'];
$PADay = $_POST['PADay'];
if (trim($PAYear) != "" || trim($PAMonth) != "" || trim($PADay) != "") if (checkdate($PAMonth,$PADay ,$PAYear)) $PADate = $PAYear."-".$PAMonth."-".$PADay;
$PANo = $_POST['PANo'];
$PANote = $_POST['PANote'];
$PAStatus = "S";

if (trim($Invoice) == "" || trim($PADate) == "")
		{
		mysqli_close($link);
		?>
		<script type="text/JavaScript">
			<!--
			alert ("您輸入的資料不足，請重新輸入！");
			history.go(-1);
			//-->
		</script>
		<?php
		exit;
		}

$SQL_ProjectAccounting="select PAStatus from ProjectAccounting where Deltag='N' and PAStatus='W' and Invoice = '".$Invoice."';";
$result_ProjectAccounting=mysqli_query($link,$SQL_ProjectAccounting) or die ("無法執行查詢");
if (mysqli_num_rows($result_ProjectAccounting) == 0)
		{
		mysqli_free_result($result_ProjectAccounting);
		mysqli_close($link);
		?>
		<SCRIPT language=javascript>
		<!--
		alert ("查無資料，請冾網站管理人員！"); 
		history.go(-1);
		//-->
		</SCRIPT>
		<?php 	
		exit;
		}
mysqli_free_result($result_ProjectAccounting);

$now_time = date("Y-m-d H:i:s",mktime());
$sql_insert = "INSERT INTO ProjectAccountingHistory(PAID,PID,PANo,PAMode,PAItem,Charges,Rate,ChargesOther,PATax,PAStatus,PAPDate,PADate,PARecord,PARecordDate,PARecordIP,CID,CName,CTel,CFax,CAddress,InvoiceDate,Invoice,PANote,AddUser,AddDate,AddIP,Deltag,ProcUser,ProcDate,ProcIP,UpdateUser,UpdateDate,UpdateIP) SELECT PAID,PID,PANo,PAMode,PAItem,Charges,Rate,ChargesOther,PATax,PAStatus,PAPDate,PADate,PARecord,PARecordDate,PARecordIP,CID,CName,CTel,CFax,CAddress,InvoiceDate,Invoice,PANote,AddUser,AddDate,AddIP,Deltag,ProcUser,ProcDate,ProcIP,'".$_SESSION["reg_MUID"]."','".$now_time."','".$_SERVER["REMOTE_ADDR"]."' FROM ProjectAccounting where Deltag='N' and PAStatus='W' and Invoice = '".$Invoice."';";
$result_insert=mysqli_query($link,$sql_insert) or die ("無法執行新增");

$sql_update = "update ProjectAccounting set PADate = '".$PADate."',PAStatus = '".$PAStatus."',PANo = '".$PANo."',PANote = '".$PANote."',ProcUser = '".$_SESSION["reg_MUID"]."',ProcDate = '".$now_time."',ProcIP = '".$_SERVER["REMOTE_ADDR"]."' where Deltag='N' and PAStatus='W' and Invoice = '".$Invoice."';";
$result_update=mysqli_query($link,$sql_update) or die ("無法執行修改");

mysqli_close($link);
?>
<script type="text/JavaScript">
	<!--
	alert ("帳務結清完成！");
	location.href='ProjectAccounting.php?KeyWord=<?php echo urlencode($Invoice);?>';
	//-->
</script>

</body>
</html>
