﻿<?php	
include "CheckPermission.php";
include "CheckProject.php";
include "../global.php";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $PageAdminTitle;?></title>
<link href="../type.css" rel="stylesheet" type="text/css" />
<style type="text/css">
<!--
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
}
-->
</style>
<link href="../script/DatePicker.css" rel="stylesheet" type="text/css" />
<Script LANGUAGE="Javascript" SRC="../script/DatePicker.js"></Script>
<Script type="text/javascript" language="javascript" src="../script/CheckForm.js"></Script>
<script type="text/JavaScript">
<!--
//判斷是否有輸入資料
function jsCheck() 
		{
		if (jsTrim(document.form1.PUID.value) != "")
				{
				if (isBig5(document.form1.PUID.value))
						{
						alert ('您輸入的案件編號不得含有中文字及其他符號！');
						document.form1.PUID.focus();
						document.form1.PUID.select();
						return false;
						}
				}
		if (jsTrim(document.form1.CName.value) == "")
				{
				alert ('請選擇案件所屬客戶！');
				document.form1.SelCID.focus();
				return false;
				}
		if (ChkImp('PName',document.form1.PName.value,'產品名稱') == false) return false;
		if (ChkImp('PE',document.form1.PE.value,'案件工程師') == false) return false;
		if (ChkImp('ApplyItem',document.form1.ApplyItem.value,'申請項目') == false) return false;
		//if (jsTrim(document.form1.StartYear.value) != "" || jsTrim(document.form1.StartMonth.value) != "" || jsTrim(document.form1.StartDay.value) != "") if (ChkDate('StartYear',document.form1.StartYear.value,document.form1.StartMonth.value,document.form1.StartDay.value,'案件開始日期') == false) return false;
		if (ChkDate('PlanYear',document.form1.PlanYear.value,document.form1.PlanMonth.value,document.form1.PlanDay.value,'預計完成時間') == false) return false;
		if (jsTrim(document.form1.PNoteYear.value) != "" || jsTrim(document.form1.PNoteMonth.value) != "" || jsTrim(document.form1.PNoteDay.value) != "") if (ChkDate('PNoteYear',document.form1.PNoteYear.value,document.form1.PNoteMonth.value,document.form1.PNoteDay.value,'Safety 申請日期') == false) return false;
		if (jsTrim(document.form1.PAYear.value) != "" || jsTrim(document.form1.PAMonth.value) != "" || jsTrim(document.form1.PADay.value) != "") if (ChkDate('PAYear',document.form1.PAYear.value,document.form1.PAMonth.value,document.form1.PADay.value,'EMC 申請日期') == false) return false;
		}
//-->
</script>
</head>
<body>
<?php include "top.php";?>
<table width="100%" border="0" cellspacing="0" cellpadding="5">
	<tr>
    <td width="160" height="600" align="left" valign="top">
			<?php include "menu.php";?>
    </td>
    <td valign="top">
    	<table width="100%" border="0" cellpadding="0" cellspacing="0">
    		<tr>
    			<td>
			    	<table width="750" border="0" cellpadding="0" cellspacing="0">
			    		<tr height="30">
			    			<td class="c2"><b>新增案件資料</b></td>
			    		</tr>
			    	</table>
			    	<table width="750" border="0" cellpadding="0" cellspacing="0">
			        <form name="form1" method="post" action="ProjectAddDB.php" onSubmit="return jsCheck();">
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td width="230" align="right" class="c3">案件編號：</td>
			          <td class="h3"><input type="text" id="PUID" name="PUID" size="10"><font color=red>若未輸入則系統自行產生</font></td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3"><font color=red><b>*</b></font>客戶名稱：</td>
			          <td class="h3">
			          	<table width="100%" border="0" cellpadding="0" cellspacing="0">
			          		<tr>
			          			<td><div id="CNamePreview" style="display:none"></div></td>
			          			<td>
						          	<input type="hidden" id="CID" name="CID">
						          	<input type="hidden" id="CName" name="CName">
						          	<input type="button" id="SelCID" name="SelCID" class="input_bot" value="選 擇" onclick="javascript:window.open ('SelCustomer.php','SelCustomer','height=300,width=550,top=200,left=200,scrollbars=yes,status=yes');">
			          			</td>
			          		</tr>
			          	</table>
			          	
			          </td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">客戶電話：</td>
			          <td class="h3">
			          	<table width="100%" border="0" cellpadding="0" cellspacing="0">
			          		<tr>
			          			<td width="150">
			          				<div id="CTelPreview" style="display:none"></div>
						          	<input type="hidden" id="CTel" name="CTel">
			          			</td>
			          			<td width="60" align="right" class="c3">傳真：</td>
			          			<td>
			          				<div id="CFaxPreview" style="display:none"></div>
			          				<input type="hidden" id="CFax" name="CFax">
			          			</td>
			          		</tr>
			          	</table>
			          </td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">客戶地址：</td>
			          <td class="h3">
			          	<div id="CAddressPreview" style="display:none"></div>
			          	<input type="hidden" id="CAddress" name="CAddress">
			          </td>
			        </tr>
			        <tr height="60" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">連絡人：</td>
			          <td class="h3">
			          	<table width="100%" border="0" cellpadding="0" cellspacing="0">
			          		<tr height="30">
			          			<td width="75" align="right">姓名：</td>
			          			<td width="180"><input type="text" id="Contact" name="Contact" size="20"></td>
			          			<td width="60" align="right">電話：</td>
			          			<td><input type="text" id="CMobile" name="CMobile" size="20"></td>
			          		</tr>
			          		<tr height="30">
			          			<td width="75" align="right">E-MAil：</td>
			          			<td colspan="3"><input type="text" id="CEMail" name="CEMail" size="60"></td>
			          		</tr>
			          	</table>
			          </td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3"><font color=red><b>*</b></font>產品名稱：</td>
			          <td class="h3"><input type="text" id="PName" name="PName" size="60"></td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">主型式：</td>
			          <td class="h3"><input type="text" id="ModelName" name="ModelName" size="60"></td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">系列型式：</td>
			          <td class="h3"><input type="text" id="SeriesModel" name="SeriesModel" size="60"></td>
			        </tr>
			        <?php
							$SQL_Manager="select MUID,MName,MEName from Manager where Deltag='N' and ISEngineer = 'Y' and IsLeft='N';";
							$result_Manager=mysqli_query($link,$SQL_Manager) or die ("無法執行查詢");
			        ?>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3"><font color=red><b>*</b></font>案件工程師：</td>
			          <td class="h3">
			          	<select id="PE" name="PE">
			          		<?php while(list($MUID,$MName,$MEName)=mysqli_fetch_row($result_Manager)){?>
			          		<option value="<?php echo $MUID;?>"><?php echo $MEName.$MName;?></option>
			          		<?php }?>
			          	</select>
			          </td>
			        </tr>
					<?php
							$Manager="select MUID,MName,MEName from Manager where Deltag='N' and ISEngineer = 'Y' and IsLeft='N';";
							$result=mysqli_query($link,$Manager) or die ("無法執行查詢");
			        ?>
					 <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">測試工程師：</td>
			          <td class="h3">
			          	<select id="test" name="test">
							<option value=""></option>
			          		<?php while(list($MUID,$MName,$MEName)=mysqli_fetch_row($result)){?>
			          		<option value="<?php echo $MUID;?>"><?php echo $MEName.$MName;?></option>
			          		<?php }?>
			          	</select>
			          </td>
			        </tr>
			        <?php mysqli_free_result($result_Manager);?>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3"><font color=red><b>*</b></font>申請項目：</td>
			          <td class="h3"><input type="text" id="ApplyItem" name="ApplyItem" size="60"></td>
			        </tr>
					<tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">代理商：</td>
			          <td class="h3">
					    <!--<input type="radio" name="Agent" value="">無-->
						<input type="radio" name="Agent" value="FCCL">富士州
						<input type="radio" name="Agent" value="RPC1">全威
					  </td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">規範：</td>
			          <td class="h3"><input type="text" id="Canon" name="Canon" size="60"></td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">商品分類號列(C.C.C.Code)：</td>
			          <td class="h3"><input type="text" id="CCCCode" name="CCCCode" size="60"></td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3"><font color=red></font>案件開始日期：</td>
			          <td class="h3">
		              <input id="StartYear" name="StartYear" type="text" size="4" /> 年 
		              <input id="StartMonth" name="StartMonth" type="text" size="2" /> 月 
		              <input id="StartDay" name="StartDay" type="text" size="2" /> 日 
		              <img src="../images/icon.gif" width="16" height="18" style="cursor: hand" onclick="javascript:displayDatePicker('StartYear','StartMonth','StartDay');"/>
			          </td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3"><font color=red><b>*</b></font>預計完成時間：</td>
			          <td class="h3">
		              <input id="PlanYear" name="PlanYear" type="text" size="4" /> 年 
		              <input id="PlanMonth" name="PlanMonth" type="text" size="2" /> 月 
		              <input id="PlanDay" name="PlanDay" type="text" size="2" /> 日 
		              <img src="../images/icon.gif" width="16" height="18" style="cursor: hand" onclick="javascript:displayDatePicker('PlanYear','PlanMonth','PlanDay');"/>
			          </td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">本案特別備註：</td>
			          <td class="h3"><input type="text" id="SNote" name="SNote" size="60"></td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">Safety：</td>
			          <td class="h3"><input type="text" id="PNote" name="PNote" size="60"></td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">Safety 申請日期：</td>
			          <td class="h3">
		              <input id="PNoteYear" name="PNoteYear" type="text" size="4" /> 年 
		              <input id="PNoteMonth" name="PNoteMonth" type="text" size="2" /> 月 
		              <input id="PNoteDay" name="PNoteDay" type="text" size="2" /> 日 
		              <img src="../images/icon.gif" width="16" height="18" style="cursor: hand" onclick="javascript:displayDatePicker('PNoteYear','PNoteMonth','PNoteDay');"/>
			          </td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">EMC：</td>
			          <td class="h3"><input type="text" id="EMC" name="EMC" size="60"></td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">EMC 申請日期：</td>
			          <td class="h3">
		              <input id="PAYear" name="PAYear" type="text" size="4" /> 年 
		              <input id="PAMonth" name="PAMonth" type="text" size="2" /> 月 
		              <input id="PADay" name="PADay" type="text" size="2" /> 日 
		              <img src="../images/icon.gif" width="16" height="18" style="cursor: hand" onclick="javascript:displayDatePicker('PAYear','PAMonth','PADay');"/>
			          </td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">其他：</td>
			          <td class="h3"><input type="text" id="POther" name="POther" size="60"></td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">備 註：</td>
			          <td class="h3"><input type="text" id="PNote1" name="PNote1" size="60"></td>
			        </tr>
			        <tr height="40" align="center">
			          <td colspan="2" class="h3"><input type="submit" name="submit" class="input_bot" value="送 出"></td>
					  <?php						
						
						$code = 0;  
						$_SESSION['code'] = $code;
						
						
					  ?>
					  <td><input type="hidden" name="code" value="0"></td>
					</tr>
				      </form>
			      </table>
    			</td>
    		</tr>
    	</table>
    </td>
	</tr>
</table>
<?php include "down.php";?>
</body>
</html>
<?php
mysqli_close($link);
?>