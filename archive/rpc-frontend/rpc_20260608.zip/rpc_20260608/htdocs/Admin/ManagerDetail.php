﻿<?php
include "CheckPermission.php";
include "../global.php";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $PageAdminTitle;?></title>
<link href="../type.css" rel="stylesheet" type="text/css" />
<style type="text/css">
<!--
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
}
-->
</style>
</head>
<body>
<?php include "top.php";?>
<?php
$MID = $_GET['MID'];
$page = $_GET['page'];
if (trim($MID) == "")
		{
		mysqli_close($link);
		?>
		<script type="text/JavaScript">
			<!--
			alert ("查無資料，請冾網站管理人員！");
			history.go(-1);
			//-->
		</script>
		<?php
		exit;
		}
$SQL_Manager="select MUID,MPassword,MName,MEName,EmployeeNo,MPID,Salary,Allowance,FullAttendance,Bonus,CLabor,CHealth,ELabor,EHealth,CRetirement,CRetirementEmployee,Departments,Title,Ext,EMail,MIntro,MPer,ISEngineer,ISBusiness,RDate,DATEDIFF(NOW(),RDate) RDateCount,BirthDay,Address,RAddress,Tel,Mobile,BCode,BAccount,ifnull((SELECT sum(EVCount) FROM EmployeeVacation WHERE Deltag = 'N' AND MID=Manager.MID ),0) EVCount,IsLeft,LeftDate from Manager where Deltag='N' and MID = '".$MID."';";
//echo $SQL_Manager;
$result_Manager=mysqli_query($link,$SQL_Manager) or die ("無法執行查詢");

if (mysqli_num_rows($result_Manager) == 0)
		{
		mysqli_free_result($result_Manager);
		mysqli_close($link);
		?>
		<SCRIPT language=javascript>
		<!--
		alert ("查無資料，請冾網站管理人員！"); 
		history.go(-1);
		//-->
		</SCRIPT>
		<?php 	
		exit;
		}
list($MUID,$MPassword,$MName,$MEName,$EmployeeNo,$MPID,$Salary,$Allowance,$FullAttendance,$Bonus,$CLabor,$CHealth,$ELabor,$EHealth,$CRetirement,$CRetirementEmployee,$Departments,$Title,$Ext,$EMail,$MIntro,$MPer,$ISEngineer,$ISBusiness,$RDate,$RDateCount,$BirthDay,$Address,$RAddress,$Tel,$Mobile,$BCode,$BAccount,$EVCount,$IsLeft,$LeftDate)=mysqli_fetch_row($result_Manager);
mysqli_free_result($result_Manager);

?>
<table width="100%" border="0" cellspacing="0" cellpadding="5">
	<tr>
    <td width="160" height="600" align="left" valign="top">
			<?php include "menu.php";?>
    </td>
    <td valign="top">
    	<table width="100%" border="0" cellpadding="0" cellspacing="0">
    		<tr>
    			<td>
			    	<table width="750" border="0" cellpadding="0" cellspacing="0">
			    		<tr height="30">
			    			<td class="c2"><b>員工詳細資訊</b></td>
						
						<?php if (trim(strstr($_SESSION["reg_MPer"],'G')) != ""){?>
		  					<td align="center"><input type="button" name="edit" value="修改" class="input_bot" onclick="javascript:location.href='ManagerEdit.php?MID=<?php echo $MID;?>&page=<?php echo $page;?>';"></td>
							<td align="center"><input type="button" name="edit" value="刪除" class="input_bot" onclick="javascript:if (confirm('您是否確定要刪除(<?php echo $MName;?>)？')) location.href='ManagerDelDB.php?MID=<?php echo $MID;?>&page=<?php echo $page;?>';"></td>
						<?php }?>
						
			    		</tr>
			    	</table>
			    	<table width="750" border="0" cellpadding="0" cellspacing="0">
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td width="160" align="right" class="c3">中文姓名：</td>
			          <td class="h3"><?php echo $MName;?>
			          	<input type="hidden" name="MID" value="<?php echo $MID;?>">
			          	<input type="hidden" name="page" value="<?php echo $page;?>">
			          </td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">英文姓名：</td>
			          <td class="h3"><?php echo $MEName;?></td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">員工編號：</td>
			          <td class="h3"><?php echo $EmployeeNo;?></td>
			        </tr>
			        <?php if (trim($_SESSION["reg_MUID"]) == "Benson" || trim($_SESSION["reg_MUID"]) == "amanda" || trim($_SESSION["reg_MUID"]) == "jacky") {?>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">身份證號：</td>
			          <td class="h3"><?php echo $MPID;?></td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">本薪：</td>
			          <td class="h3"><?php echo $Salary;?></td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">職務加給：</td>
			          <td class="h3"><?php echo $Allowance;?></td>
			        </tr>
					<tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">全勤獎金:</td>
			          <td class="h3"><?php echo $FullAttendance;?></td>
			        </tr>
					<tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">績效獎金：</td>
			          <td class="h3"><?php echo $Bonus;?></td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">勞保費-公司負擔：</td>
			          <td class="h3"><?php echo $CLabor;?></td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">勞保費-員工負擔：</td>
			          <td class="h3"><?php echo $ELabor;?></td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">健保費-公司負擔：</td>
			          <td class="h3"><?php echo $CHealth;?></td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">健保費-員工負擔：</td>
			          <td class="h3"><?php echo $EHealth;?></td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">勞退提撥-公司負擔：</td>
			          <td class="h3"><?php echo $CRetirement;?></td>
			        </tr>
					<tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">自願勞退提撥-員工負擔：</td>
			          <td class="h3"><?php echo $CRetirementEmployee;?></td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">行庫代號：</td>
			          <td class="h3"><?php echo $BCode;?></td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">銀行帳號：</td>
			          <td class="h3"><?php echo $BAccount;?></td>
			        </tr>
			        <?php }?>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">部門別：</td>
			          <td class="h3">
			          	<?php
			          	if (trim($Departments) == "A") echo "工程部";
			          	else if (trim($Departments) == "B") echo "行政品質部";
			          	else if (trim($Departments) == "C") echo "客服部";
			          	?>
			          </td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">職稱：</td>
			          <td class="h3"><?php echo $Title;?></td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">分機號碼：</td>
			          <td class="h3"><?php echo $Ext;?></td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">E-Mail：</td>
			          <td class="h3"><?php echo $EMail;?></td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">是否為案件工程師：</td>
			          <td class="h3">
			          	<?php
			          	if (trim($ISEngineer) == "Y") echo "是";
			          	else if (trim($ISEngineer) == "N") echo "否";
			          	?>
			          </td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">是否為客服：</td>
			          <td class="h3">
			          	<?php
			          	if (trim($ISBusiness) == "Y") echo "是";
			          	else if (trim($ISBusiness) == "N") echo "否";
			          	?>
			          </td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">到職日：</td>
			          <td class="h3"><?php echo $RDate;?> </td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">特別休假：</td>
			          <td class="h3">
		              <?php
		              //$SDate = (floor($RDateCount / 365));
		              //if ($SDate < 1) $VDate = 0;
		              //else if ($SDate >= 1 && $SDate < 3) $VDate = 7;
		              //else if ($SDate >= 3 && $SDate < 5) $VDate = 10;
		              //else if ($SDate >= 5 && $SDate < 10) $VDate = 14;
		              //else if ($SDate >= 10) {
		              //		$VDate = 14 + ($SDate-10);
		              //		if ($VDate > 30) $VDate = 30;
		              //		}
		              echo "<font color=blue><b>".$EVCount."</b></font> 天";
		              ?>
			          </td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">生日：</td>
			          <td class="h3"><?php echo $BirthDay;?></td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">連絡地址：</td>
			          <td class="h3"><?php echo $Address;?></td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">戶籍地址：</td>
			          <td class="h3"><?php echo $RAddress;?></td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">聯絡電話：</td>
			          <td class="h3"><?php echo $Tel;?></td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">手機號碼：</td>
			          <td class="h3"><?php echo $Mobile;?></td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">是否離職：</td>
			          <td class="h3">
			          	<?php
			          	if (trim($IsLeft) == "Y") echo "是";
			          	else if (trim($IsLeft) == "N") echo "否";
			          	?>
			          </td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">離職日期	：</td>
			          <td class="h3"><?php echo $LeftDate;?></td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">備註：</td>
			          <td class="h3"><?php echo $MIntro;?></td>
			        </tr>
			        <tr height="40" align="center">
			          <td colspan="2" class="h3"><input type="button" name="button" class="input_bot" value="回列表" onclick="javascript:location.href='ManagerList.php?page=<?php echo $page;?>';"></td>
			        </tr>
			      </table>
    			</td>
    		</tr>
    	</table>
    </td>
	</tr>
</table>
<?php include "down.php";?>
</body>
</html>
<?php
mysqli_close($link);
?>