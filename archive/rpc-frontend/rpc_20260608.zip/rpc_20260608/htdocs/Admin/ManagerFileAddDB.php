﻿<?php
include "CheckPermission.php";
include "CheckManager.php";
include "../global.php";
include "include/function.php";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $PageAdminTitle;?></title>
</head>
<body>
<?php
$MID = $_POST['MID'];
$MTitle = $_POST['MTitle'];

if(trim($_FILES['MFile']['tmp_name']) != "")
		{
		if($_FILES['MFile']['size'] > 20971520)
				{
				?>
				<script type="text/JavaScript">
					<!--
					alert ("您上傳的檔案 Size 超過 20 M，請重新上傳！");
					history.go(-1);
					//-->
				</script>
				<?php
				exit();
				}
		$PFIntro1 = $_POST['PFIntro1'];
		$MFile = "MFile_".$MID.date("ymdHis",mktime()).rand_string(5, 'ABCDEFGHIJKLMNPQRSTUVWXYZ23456789abcdefghijklmnopqrstuvwxyz').".".strtolower(substr($_FILES['MFile']['name'],strrpos($_FILES['MFile']['name'],".")+1,strlen($_FILES['MFile']['name'])+1));
		@copy($_FILES['MFile']['tmp_name'],$_SERVER["DOCUMENT_ROOT"]."\\Admin\\MFile\\".$MFile);
		}

if (trim($MID) == "" || trim($MTitle) == "" || trim($MFile) == "")
		{
		mysqli_close($link);
		?>
		<script type="text/JavaScript">
			<!--
			alert ("您輸入的資料不足，請重新輸入！");
			self.close();
			//-->
		</script>
		<?php
		exit;
		}

$now_time = date("Y-m-d H:i:s",mktime());
$sql_insert = "insert into ManagerFile (MID,MTitle,MFile,AddUser,AddDate,AddIP) values ('".$MID."','".$MTitle."','".$MFile."','".$_SESSION["reg_MUID"]."','".$now_time."','".$_SERVER["REMOTE_ADDR"]."');";
$result_insert=mysqli_query($link,$sql_insert) or die ("無法執行新增");

mysqli_close($link);
?>
<script type="text/JavaScript">
	<!--
	alert ("新增成功！");
	opener.location.reload();
	self.close();
	//-->
</script>

</body>
</html>
