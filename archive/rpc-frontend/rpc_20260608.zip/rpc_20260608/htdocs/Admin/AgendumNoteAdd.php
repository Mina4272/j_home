﻿<?php	
include "CheckPermission.php";
include "CheckAgendum.php";
include "../global.php";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $PageAdminTitle;?></title>
<link href="../type.css" rel="stylesheet" type="text/css" />
<style type="text/css">
<!--
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
}
-->
</style>
<link href="../script/DatePicker.css" rel="stylesheet" type="text/css" />
<Script LANGUAGE="Javascript" SRC="../script/DatePicker.js"></Script>
<Script type="text/javascript" language="javascript" src="../script/CheckForm.js"></Script>
<script type="text/JavaScript">
<!--
function jsCheck() 
		{
		if (ChkImp('AContent',document.form1.AContent.value,'聯絡事項內容') == false) return false;
		}
//-->
</script>
</head>
<body>
<?php
$AID = $_GET['AID'];
if (trim($AID) == "")
		{
		mysqli_close($link);
		?>
		<script type="text/JavaScript">
			<!--
			alert ("查無資料，請冾網站管理人員！");
			self.close();
			//-->
		</script>
		<?php
		exit;
		}
?>
<table width="100%" border="0" cellpadding="0" cellspacing="0">
	<tr>
		<td>
    	<table width="100%" border="0" cellpadding="0" cellspacing="0">
    		<tr height="30">
					<td width="15" background="../images/table_bg.gif"></td>
    			<td class="c3" background="../images/table_bg.gif"><b>新增內容及聯絡事項</b></td>
    		</tr>
    	</table>
    	<table width="100%" border="0" cellpadding="0" cellspacing="0">
        <form name="form1" method="post" action="AgendumNoteAddDB.php" onSubmit="return jsCheck();">
        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
					<td width="15"></td>
          <td class="c3">聯絡事項內容：</td>
        </tr>
        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
					<td width="15"></td>
          <td class="h3">
          	<textarea id="AContent" name="AContent" cols="60" rows="10" class="h3"></textarea>
          	<input name="AID" type="hidden" id="AID" value="<?php echo $AID;?>" />
          </td>
        </tr>
        <tr height="40" align="center">
			<td width="15"></td>
          <td class="h3"><input type="submit" name="submit" class="input_bot" value="送 出"></td>
        </tr>
	      </form>
      </table>
		</td>
	</tr>
</table>
</body>
</html>
<?php
mysqli_close($link);
?>