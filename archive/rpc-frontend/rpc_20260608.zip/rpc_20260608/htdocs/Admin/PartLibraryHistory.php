﻿<?php
include "CheckPermission.php";
include "CheckPartLibrary.php";
include "../global.php";
include "include/page_function.php";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $PageAdminTitle;?></title>
<link href="../type.css" rel="stylesheet" type="text/css" />
<style type="text/css">
<!--
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
}
-->
</style></head>

<body>
<?php
$PLID = $_GET['PLID'];
if (trim($PLID) == "")
		{
		mysqli_close($link);
		?>
		<script type="text/JavaScript">
			<!--
			alert ("查無資料，請冾網站管理人員！");
			history.go(-1);
			//-->
		</script>
		<?php
		exit;
		}
$SQL_PartLibrary="select PLCID,PartName,Firm,Model,Spec,Standard,Mark,PartCertification,AddUser,AddDate,ProcUser,ProcDate from PartLibrary where Deltag='N' and PLID = '".$PLID."';";
$result_PartLibrary=mysqli_query($link,$SQL_PartLibrary) or die ("無法執行查詢");
if (mysqli_num_rows($result_PartLibrary) == 0)
		{
		mysqli_free_result($result_PartLibrary);
		mysqli_close($link);
		?>
		<SCRIPT language=javascript>
		<!--
		alert ("查無資料，請冾網站管理人員！"); 
		history.go(-1);
		//-->
		</SCRIPT>
		<?php 	
		exit;
		}
mysqli_free_result($result_PartLibrary);

?>
<table width="100%" border="0" cellpadding="0" cellspacing="0">
	<tr>
		<td>
			<?php
			$page = empty($_GET['page'])?"":$_GET['page'];
			if (trim($page) == "") $page = 1;
			$page_rows=15;  //每頁筆數
			$php_Self = "PartLibraryHistory.php";  //分頁web檔名

			$button_css = "h4";
			$limit_txt =" limit ".(($page-1) * $page_rows).",".$page_rows;
			$url_str = "&PLID=".$PLID;
			$Sql_str="select PLCID,PartName,Firm,Model,Spec,Standard,Mark,PartCertification,AddUser,AddDate,ProcUser,ProcDate from PartLibraryHistory where Deltag='N' and PLID = '".$PLID."' order by PLHID desc;";
			$SQL_PartLibrary="select PLCID,(select PLCName from PartLibraryClass where Deltag='N' and PLCID=PartLibraryHistory.PLCID) as PLCName,PartName,Firm,Model,Spec,Standard,Mark,PartCertification,AddUser,AddDate,ProcUser,ProcDate from PartLibraryHistory where Deltag='N' and PLID = '".$PLID."' order by PLHID desc ".$limit_txt.";";
			$result_PartLibrary=mysqli_query($link,$SQL_PartLibrary) or die ("無法執行查詢");
			?>
    	<table width="100%" border="0" cellpadding="5" cellspacing="2" class="s2">
        <tr align="center">
          <td width="100" align="center" background="../images/table_bg.gif" class="t21">類別名稱</td>
          <td background="../images/table_bg.gif" class="t21">零件名稱</td>
          <td background="../images/table_bg.gif" class="t21">廠家/檔案種類</td>
          <td background="../images/table_bg.gif" class="t21">型號/檔案內容</td>
          <td background="../images/table_bg.gif" class="t21">規格</td>
          <td background="../images/table_bg.gif" class="t21">標準</td>
          <td background="../images/table_bg.gif" class="t21">認證符號</td>
          <td background="../images/table_bg.gif" class="t21">證書檔案</td>
          <td width="150" background="../images/table_bg.gif" class="t21">最後更新</td>
        </tr>
        <?php
        $tmp = 1;
        while(list($PLCID,$PLCName,$PartName,$Firm,$Model,$Spec,$Standard,$Mark,$PartCertification,$AddUser,$AddDate,$ProcUser,$ProcDate)=mysqli_fetch_row($result_PartLibrary)){
      	?>
      	<tr<?php if ($tmp%2 == 0) echo " bgcolor=\"#F6F6F6\"";?>>
          <td align="center" class="h3"><?php echo $PLCName;?></td>
          <td align="center" class="h3"><?php echo $PartName;?></td>
          <td align="center" class="h3"><?php echo $Firm;?></td>
          <td align="center" class="h3"><?php echo $Model;?></td>
          <td align="center" class="h3"><?php echo $Spec;?></td>
          <td align="center" class="h3"><?php echo $Standard;?></td>
          <td align="center" class="h3"><?php echo $Mark;?></td>
          <td align="center" class="h3"><a href="PartCertification/<?php echo $PartCertification;?>" target="_PartLibraryHistory">檔案</a></td>
          <td align="center" class="h3">
          	<?php
          	if (trim($ProcUser) == "") echo $AddUser."<br>".$AddDate;
          	else echo $ProcUser."<br>".$ProcDate;
          	?>
          </td>
        </tr>
        <?php
      			$tmp++;
      			}
      	mysqli_free_result($result_PartLibrary);
        ?>
      </table>
      <table width="100%" border="0" cellpadding="5" cellspacing="2" class="s2">
        <tr align="center">
          <td bgcolor="#E8F0C2" class="h4"><?php Page_show($Sql_str,$page_rows,$php_Self,$link,$page,$url_str,$button_css);?></td>
        </tr>
      </table>
		</td>
	</tr>
</table>
</body>
</html>
<?php
mysqli_close($link);
?>