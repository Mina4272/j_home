﻿<?php
include "CheckPermission.php";
include "CheckAgendum.php";
include "../global.php";
include "include/page_function.php";
include "include/utf8.php";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $PageAdminTitle;?></title>
<link href="../type.css" rel="stylesheet" type="text/css" />
<style type="text/css">
<!--
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
}
-->
</style></head>

<body>
<?php
$AID = $_GET['AID'];
if (trim($AID) == "")
		{
		mysqli_close($link);
		?>
		<script type="text/JavaScript">
			<!--
			alert ("查無資料，請冾網站管理人員！");
			history.go(-1);
			//-->
		</script>
		<?php
		exit;
		}
$SQL_Agendum="select AUID from AgendumHistory where AID = '".$AID."';";
$result_Agendum=mysqli_query($link,$SQL_Agendum) or die ("無法執行查詢");
if (mysqli_num_rows($result_Agendum) == 0)
		{
		mysqli_free_result($result_Agendum);
		mysqli_close($link);
		?>
		<SCRIPT language=javascript>
		<!--
		alert ("查無資料，請冾網站管理人員！"); 
		history.go(-1);
		//-->
		</SCRIPT>
		<?php 	
		exit;
		}
mysqli_free_result($result_Agendum);

?>
<table width="100%" border="0" cellpadding="0" cellspacing="0">
	<tr>
		<td>
			<?php
			$page = empty($_GET['page'])?"":$_GET['page'];
			if (trim($page) == "") $page = 1;
			$page_rows=15;  //每頁筆數
			$php_Self = "AgendumHistory.php";  //分頁web檔名

			$button_css = "h4";
			$limit_txt =" limit ".(($page-1) * $page_rows).",".$page_rows;
			$url_str = "&AID=".$AID;
			$Sql_str="select AHID from AgendumHistory where Deltag='N' and AID = '".$AID."' order by AHID desc;";
			$SQL_Agendum="select AHID,AUID,ASID,ARID,ADate,date_format(ADate,'%Y'),date_format(ADate,'%m'),date_format(ADate,'%d'),AEDate,date_format(AEDate,'%Y'),date_format(AEDate,'%m'),date_format(AEDate,'%d'),ACDate,date_format(ACDate,'%Y'),date_format(ACDate,'%m'),date_format(ACDate,'%d'),AStatus,AItem,Attribute,PID,CID,CName,CTel,CFax,Contact,CMobile,CEMail,CAddress,AFile,ANote,AddUser,AddDate,ProcUser,ProcDate,(select CLevel from Customer where CID=AgendumHistory.CID) CLevel,(select CFees from Customer where CID=AgendumHistory.CID) CFees,(select CRecord from Customer where CID=AgendumHistory.CID) CRecord,(select CRecordTxt from Customer where CID=AgendumHistory.CID) CRecordTxt from AgendumHistory where Deltag='N' and AID = '".$AID."';";
			$result_Agendum=mysqli_query($link,$SQL_Agendum) or die ("無法執行查詢");
			?>
    	<table width="100%" border="0" cellpadding="5" cellspacing="2" class="s2">
        <tr align="center">
          <td background="../images/table_bg.gif" class="t21">派案編號</td>
          <td background="../images/table_bg.gif" class="t21">項目 / 測試項目</td>
          <td background="../images/table_bg.gif" class="t21">派案人</td>
          <td background="../images/table_bg.gif" class="t21">狀態</td>
          <td background="../images/table_bg.gif" class="t21">接案人</td>
          <td background="../images/table_bg.gif" class="t21">案件屬性</td>
          <td background="../images/table_bg.gif" class="t21">詳細</td>
          <td width="150" background="../images/table_bg.gif" class="t21">最後更新</td>
        </tr>
        <?php
        $tmp = 1;
				while(list($AHID,$AUID,$ASID,$ARID,$ADate,$AYear,$AMonth,$ADay,$AEDate,$AEYear,$AEMonth,$AEDay,$ACDate,$ACYear,$ACMonth,$ACDay,$AStatus,$AItem,$Attribute,$PID,$CID,$CName,$CTel,$CFax,$Contact,$CMobile,$CEMail,$CAddress,$AFile,$ANote,$AddUser,$AddDate,$ProcUser,$ProcDate,$CLevel,$CFees,$CRecord,$CRecordTxt)=mysqli_fetch_row($result_Agendum)){
      	if (utf8_strlen(strip_tags($CName)) > 4) $CName = utf8_substr(strip_tags($CName),0,4);
      	else $CName = strip_tags($CName);

				$SQL_Manager="select MName,MEName from Manager where MUID = '".$ASID."';";
				$result_Manager=mysqli_query($link,$SQL_Manager) or die ("無法執行查詢");
				list($ASName,$ASEName)=mysqli_fetch_row($result_Manager);
				mysqli_free_result($result_Manager);

				$SQL_Manager="select MName,MEName from Manager where MUID = '".$ARID."';";
				$result_Manager=mysqli_query($link,$SQL_Manager) or die ("無法執行查詢");
				list($ARName,$AREName)=mysqli_fetch_row($result_Manager);
				mysqli_free_result($result_Manager);
      	?>
      	<tr<?php if ($tmp%2 == 0) echo " bgcolor=\"#F6F6F6\"";?>>
          <td align="center" class="h3"><?php echo $AUID;?></td>
          <td class="h3"><?php echo $AItem;?></td>
          <td class="h3"><?php echo $ASEName.$ASName;?></td>
          <td align="center" class="h3">
          	<?php
          	if (trim($AStatus) == "A") echo "案件指派";
          	else if (trim($AStatus) == "B") echo "接案處理中";
          	else if (trim($AStatus) == "C") echo "完成回報";
          	else if (trim($AStatus) == "D") echo "驗收";
          	?>
          </td>
          <td align="center" class="h3"><?php echo $AREName.$ARName;?></td>
          <td align="center" class="h3">
          	<?php
          	if (trim($AStatus) == "A") echo "測試";
          	else if (trim($AStatus) == "B") echo "事項處理";
          	else if (trim($AStatus) == "C") echo "採購";
          	?>
          </td>
          <td align="center" class="h3"><input type="button" name="detail" value="詳細" class="input_bot" onclick="javascript:location.href='AgendumHistoryDetail.php?AHID=<?php echo $AHID;?>&AID=<?php echo $AID;?>&page=<?php echo $page;?>';"></td>
          <td align="center" class="h3">
          	<?php
          	if (trim($ProcUser) == "") echo $AddUser."<br>".$AddDate;
          	else echo $ProcUser."<br>".$ProcDate;
          	?>
          </td>
        </tr>
        <?php
      			$tmp++;
      			}
      	mysqli_free_result($result_Agendum);
        ?>
      </table>
      <table width="100%" border="0" cellpadding="5" cellspacing="2" class="s2">
        <tr align="center">
          <td bgcolor="#E8F0C2" class="h4"><?php Page_show($Sql_str,$page_rows,$php_Self,$link,$page,$url_str,$button_css);?></td>
        </tr>
      </table>
		</td>
	</tr>
</table>
</body>
</html>
<?php
mysqli_close($link);
?>