﻿<?php
include "CheckPermission.php";
include "CheckCustomer.php";
include "../global.php";
include "include/page_function.php";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $PageAdminTitle;?></title>
<link href="../type.css" rel="stylesheet" type="text/css" />
<style type="text/css">
<!--
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
}
-->
</style></head>

<body>
<?php include "top.php";?>
<table width="100%" border="0" cellspacing="0" cellpadding="5">
	<tr>
    <td width="160" height="600" align="left" valign="top">
			<?php include "menu.php";?>
    </td>
    <td valign="top">
    	<table width="100%" border="0" cellpadding="0" cellspacing="0">
    		<tr>
    			<td>
			    	<table width="750" border="0" cellpadding="0" cellspacing="0">
			    		<form name="form1" action="CustomerList.php" method="post">
			    		<tr>
			    			<td width="180" align="left" class="h3">客戶種類：
			    				<select name="QCType">
			    					<option value="">不限</option>
			    					<option value="N"<?php if (trim(empty($_POST['QCType'])?"":$_POST['QCType']) == "N") echo " selected";?>>一般客戶</option>
			    					<option value="P"<?php if (trim(empty($_POST['QCType'])?"":$_POST['QCType']) == "P") echo " selected";?>>供應商</option>
			    				</select>
			    			</td>
			    			<td align="left" class="h3">關鍵字：<input type="text" name="KeyWord" size="14"><input type="submit" name="search" class="input_bot" value="查詢"></td>
			    			<td align="right" class="h3">
			    				<input type="button" id="SelCID" name="SelCID" class="input_bot" value="連絡人查詢" onclick="javascript:window.open ('SelCustomerContact.php','SelCustomerContact','height=400,width=800,top=200,left=200,scrollbars=yes,status=yes');">
			    				<input type="button" name="edit" value="已刪除客戶記錄" class="input_bot" onclick="javascript:window.open ('CustomerDelHistory.php','CustomerDelHistory','height=500,width=800,top=200,left=200,scrollbars=yes,status=yes');">
			    				<input type="button" name="add" value="新 增" class="input_bot" onclick="javascript:location.href='CustomerAdd.php';">
			    			</td>
			    		</tr>
			    		</form>
			    	</table>
						<?php
					$SqlTxt="";
			    	$QCType = empty($_POST['QCType'])?"":$_POST['QCType'];
			    	if (trim($QCType) == "") $QCType = empty($_GET['QCType'])?"":$_GET['QCType'];
			    	$KeyWord = empty($_POST['KeyWord'])?"":$_POST['KeyWord'];
			    	if (trim($KeyWord) == "") $KeyWord = empty($_GET['KeyWord'])?"":$_GET['KeyWord'];
						if (trim($QCType) != "") $SqlTxt = $SqlTxt." and CType like '%".$QCType."%' ";
			    	if (trim($KeyWord) != "") {
								$SQL_CustomerContact="select CID from CustomerContact where Deltag='N' and (Contact like '%".$KeyWord."%' or CMobile like '%".$KeyWord."%' or CEMail like '%".$KeyWord."%') group by CID order by CID;";
								$result_CustomerContact=mysqli_query($link,$SQL_CustomerContact) or die ("無法執行查詢");
								$SqlCID = "";
								while(list($CCID)=mysqli_fetch_row($result_CustomerContact)){
										//if (trim($SqlCID) == "") $SqlCID = "CID='".$CCID."'";
										//else $SqlCID = $SqlCID." or CID='".$CCID."'";
										if (trim($SqlCID) == "") $SqlCID = $CCID;
										else $SqlCID = $SqlCID.",".$CCID;
										}
								mysqli_free_result($result_CustomerContact);

								if (trim($SqlCID) != "") 
										$SqlTxt = $SqlTxt." and (CUID like '%".$KeyWord."%' or CName like '%".$KeyWord."%' or EName like '%".$KeyWord."%' or Contact like '%".$KeyWord."%' or CAddress like '%".$KeyWord."%' or CTel like '%".$KeyWord."%' or CFax like '%".$KeyWord."%' or CMobile like '%".$KeyWord."%' or CEMail like '%".$KeyWord."%' or CID in (".$SqlCID."))";
								else $SqlTxt = $SqlTxt." and (CUID like '%".$KeyWord."%' or CName like '%".$KeyWord."%' or EName like '%".$KeyWord."%' or Contact like '%".$KeyWord."%' or CAddress like '%".$KeyWord."%' or CTel like '%".$KeyWord."%' or CFax like '%".$KeyWord."%' or CMobile like '%".$KeyWord."%' or CEMail like '%".$KeyWord."%')";
			    			}

						$page = empty($_GET['page'])?"":$_GET['page'];
						if (trim($page) == "") $page = 1;
						$page_rows=15;  //每頁筆數
						$php_Self = "CustomerList.php";  //分頁web檔名

						$button_css = "h4";
						$limit_txt =" limit ".(($page-1) * $page_rows).",".$page_rows;
						$url_str = "&KeyWord=".urlencode($KeyWord);
						$Sql_str="select CID,CUID,CPWD,CName,CTel,Contact,CMobile,CEMail,CAddress,CNote,CLevel,CFees,CRecord,CRecordTxt from Customer where Deltag='N' ".$SqlTxt." order by CID desc;";
						$SQL_Customer="select CID,CUID,CPWD,CName,CTel,Contact,CMobile,CEMail,CAddress,CustomerFile,CNote,CLevel,CFees,CRecord,CRecordTxt from Customer where Deltag='N' ".$SqlTxt." order by CID desc ".$limit_txt.";";
						$result_Customer=mysqli_query($link,$SQL_Customer) or die ("無法執行查詢");
						?>
			    	<table width="750" border="0" cellpadding="5" cellspacing="2" class="s2">
			        <tr align="center">
			          <td width="50" align="center" background="../images/table_bg.gif" class="t2">序</td>
			          <td width="300" background="../images/table_bg.gif" class="t2">公司名稱</td>
			          <td width="100" background="../images/table_bg.gif" class="t2">電 話</td>
			          <td width="175" background="../images/table_bg.gif" class="t2">備 註</td>
			          <td width="60" background="../images/table_bg.gif" class="t2">修 改</td>
			          <td width="60" background="../images/table_bg.gif" class="t2">刪 除</td>
			        </tr>
		          <?php
		          $tmp = 1;
		          while(list($CID,$CUID,$CPWD,$CName,$CTel,$Contact,$CMobile,$CEMail,$CAddress,$CustomerFile,$CNote,$CLevel,$CFees,$CRecord,$CRecordTxt)=mysqli_fetch_row($result_Customer)){
		        	?>
		        	<tr<?php if ($tmp%2 == 0) echo " bgcolor=\"#F6F6F6\"";?>>
			          <td width="50" align="center" class="h3"><?php echo $CID;?></td>
			          <td width="300" class="h3"><a href="getfile.php?FolderName=Admin\\CustomerFile&FileName=<?php echo $CustomerFile;?>"><?php echo $CName;?></a>
			          	<?php
			          	if (trim($CLevel) == "C") $CLevel="B";
			          	if (trim($CLevel) == "A") $CLevelAlt="優(結案後直接給證書)";
			          	else if (trim($CLevel) == "B") $CLevelAlt="良(結案付款後給證書)";
			          	if (trim($CFees) == "A") $CFeesAlt="是(收據抬頭開全威)";
			          	else if (trim($CFees) == "B") $CFeesAlt="是(收據抬頭開申請人)";
			          	else if (trim($CFees) == "C") $CFeesAlt="否(不代送審)";
			          	if (trim($CRecord) == "A") $CRecordAlt="優(結案後月結60天)";
			          	else if (trim($CRecord) == "B") $CRecordAlt="良(月結30天)";
			          	else if (trim($CRecord) == "C") $CRecordAlt="付款開案";
			          	else if (trim($CRecord) == "D") $CRecordAlt="其他(".$CRecordTxt.")";
			          	?>
			          	<img src="../images/<?php echo $CLevel;?>1.gif" alt="<?php echo $CLevelAlt;?>"> 
			          	<img src="../images/<?php echo $CFees;?>1.gif" alt="<?php echo $CFeesAlt;?>"> 
			          	<img src="../images/<?php echo $CRecord;?>2.gif" alt="<?php echo $CRecordAlt;?>">
			          </td>
			          <td width="100" align="center" class="h3"><?php echo $CTel;?></td>
			          <td width="175" class="h4"><?php echo $CNote;?></td>
			          <td width="60" align="center"><input type="button" name="edit" value="修 改" class="input_bot" onclick="javascript:location.href='CustomerEdit.php?CID=<?php echo $CID;?>&page=<?php echo $page;?><?php echo $url_str;?>';"></td>
			          <td width="60" align="center"><input type="button" name="edit" value="刪 除" class="input_bot" onclick="javascript:if (confirm('您是否確定要刪除？')) location.href='CustomerDelDB.php?CID=<?php echo $CID;?>&page=<?php echo $page;?><?php echo $url_str;?>';"></td>
			        </tr>
			        <?php
            			$tmp++;
			      			}
            	mysqli_free_result($result_Customer);
			        ?>
			      </table>
			      <table width="750" border="0" cellpadding="5" cellspacing="2" class="s2">
			        <tr align="center">
			          <td bgcolor="#E8F0C2" class="h4"><?php Page_show($Sql_str,$page_rows,$php_Self,$link,$page,$url_str,$button_css);?></td>
			        </tr>
			      </table>
    			</td>
    		</tr>
    	</table>
    </td>
	</tr>
</table>
<?php include "down.php";?>
</body>
</html>
<?php
mysqli_close($link);
?>