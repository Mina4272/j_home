<?php
include "../global.php";
?>
<html xmlns:v>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $PageAdminTitle;?></title>
<link href="../type.css" rel="stylesheet" type="text/css" />
<Script type="text/javascript" language="javascript" src="../script/CheckForm.js"></Script>
<style type="text/css">
<!--
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
}
v\:* {
	behavior: url(#default#VML);
	background-position: center;
	margin: 5px;
	padding: 5px;
	border-top-style: none;
	border-right-style: none;
	border-bottom-style: none;
	border-left-style: none;
	}
-->
</style>
<script type="text/JavaScript">
<!--
function jsCheck() 
		{
		if (ChkImp('MUID',document.form1.MUID.value,'帳號') == false)
				{
				document.form1.MUID.focus();
				document.form1.MUID.select();
				return false;
				}
		if (ChkImp('MPassword',document.form1.MPassword.value,'密碼') == false)
				{
				document.form1.MPassword.focus();
				document.form1.MPassword.select();
				return false;
				}
		}
//-->
</script>
</head>

<body>
<?php
include "top.php";
?>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
	<tr>
    <td height="30"></td>
	</tr>
</table>
<table width="70%" border="0" align="center" cellpadding="2" cellspacing="3">
  <tr align="left">
    <td align="center"><v:RoundRect style="position:relative; width:400; height:200px;">
      <v:shadow on="T" type="single" color="#F0F0F0" offset="5px,5px"/>
      <v:textbox style="font-size:12px">
        <table width="99%" border="0" align="center" cellpadding="0" cellspacing="0" bordercolor="#CCCCCC" bgcolor="#FFFFFF">
          <form name="form1" action="loginDB.php" method="post" onSubmit="return jsCheck();">
          <tr height="30">
            <td background="../images/table_bg.gif" colspan="2" align="center" class="t2">全威驗證系統管理平台</td>
          </tr>
          <tr height="30">
            <td bgcolor="#FFFFFF" colspan="2">&nbsp;</td>
          </tr>
          <tr height="30" bgcolor="#FFFFFF" class="h3">
            <td align="right">帳號：</td>
          	<td><input type="text" name="MUID"></td>
          </tr>
          <tr height="30" class="h3">
            <td align="right">密碼：</td>
            <td><input type="password" name="MPassword"></td>
          </tr>
          <tr height="40" bgcolor="#FFFFFF" class="w1">
            <td align="center" colspan="2"><input name="Submit" type="submit" class="input_bot" value="登入"></td>
          </tr>
          </form>
        </table>
      </v:textbox>
    </v:RoundRect></td>
  </tr>
</table>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
	<tr>
    <td height="60"></td>
	</tr>
</table>
<?php
include "down.php";
?>
</body>
</html>
<?php
mysqli_close($link);
?>