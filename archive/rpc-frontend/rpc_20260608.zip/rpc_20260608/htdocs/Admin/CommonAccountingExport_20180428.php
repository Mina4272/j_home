﻿<?php
include "CheckPermission.php";
include "CheckCommonAccounting.php";
include "../global.php";

$SqlTxt="";
$QSCADate = empty($_POST['QSCADate'])?"":$_POST['QSCADate'];
if (trim($QSCADate) == "") $QSCADate = empty($_GET['QSCADate'])?"":$_GET['QSCADate'];
$QECADate = empty($_POST['QECADate'])?"":$_POST['QECADate'];
if (trim($QECADate) == "") $QECADate = empty($_GET['QECADate'])?"":$_GET['QECADate'];
if (trim($QSCADate) == "") {
		$QSCAYear = $_POST['QSCAYear'];
		$QSCAMonth = $_POST['QSCAMonth'];
		$QSCADay = $_POST['QSCADay'];
		if (trim($QSCAYear) != "" || trim($QSCAMonth) != "") if (checkdate($QSCAMonth,$QSCADay ,$QSCAYear)) $QSCADate = $QSCAYear."-".$QSCAMonth."-".$QSCADay;
		}
if (trim($QECADate) == "") {
		$QECAYear = $_POST['QECAYear'];
		$QECAMonth = $_POST['QECAMonth'];
		$QECADay = $_POST['QECADay'];
		if (trim($QECAYear) != "" || trim($QECAMonth) != "") if (checkdate($QECAMonth,$QECADay ,$QECAYear)) $QECADate = $QECAYear."-".$QECAMonth."-".$QECADay;
		}
$QCAType = empty($_POST['QCAType'])?"":$_POST['QCAType'];
if (trim($QCAType) == "") $QCAType = empty($_GET['QCAType'])?"":$_GET['QCAType'];
$KeyWord = empty($_POST['KeyWord'])?"":$_POST['KeyWord'];
if (trim($KeyWord) == "") $KeyWord = empty($_GET['KeyWord'])?"":$_GET['KeyWord'];

if (trim($QSCADate) != "" && trim($QECADate) != "") $SqlTxt = $SqlTxt." and (CADate >= '".$QSCADate."') and (CADate <= '".$QECADate."') ";
else if (trim($QSCADate) != "" && trim($QECADate) == "") $SqlTxt = $SqlTxt." and (CADate >= '".$QSCADate."') ";
else if (trim($QSCADate) == "" && trim($QECADate) != "") $SqlTxt = $SqlTxt." and (CADate <= '".$QECADate."') ";
if (trim($QCAType) != "") $SqlTxt = $SqlTxt." and CAType='".$QCAType."' ";
if (trim($KeyWord) != "") $SqlTxt = $SqlTxt." and (CAUID like '%".$KeyWord."%' or CAItem like '%".$KeyWord."%' or Invoice like '%".$KeyWord."%' or Amount like '%".$KeyWord."%' or CANote like '%".$KeyWord."%')";

if (trim($SqlTxt) == "") $SqlTxt = " and (CADate = '".date("Y-m",mktime())."-1') ";

$Sql_sum="select sum(Amount) from CommonAccounting where Deltag='N' ".$SqlTxt.";";
$result_sum=mysqli_query($link,$Sql_sum) or die ("無法執行查詢");
list($Amount_sum)=mysqli_fetch_row($result_sum);
mysqli_free_result($result_sum);
$SQL_CommonAccounting="select CAUID,CADate,date_format(CADate,'%Y'),date_format(CADate,'%m'),CAItem,CAType,Amount,InvoiceDate,date_format(InvoiceDate,'%Y'),date_format(InvoiceDate,'%m'),date_format(InvoiceDate,'%d'),Invoice,CAStatus,PayDate,date_format(PayDate,'%Y'),date_format(PayDate,'%m'),date_format(PayDate,'%d'),CARecord,CARecordDate,CARecordIP,CANote,AddUser,AddDate,ProcUser,ProcDate from CommonAccounting where Deltag='N' ".$SqlTxt." order by CAID asc;";
$result_CommonAccounting=mysqli_query($link,$SQL_CommonAccounting) or die ("無法執行查詢");
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $PageAdminTitle;?></title>
<link href="style.css" rel="stylesheet" type="text/css" />
<body>
<table winth="1000" border="0">
	<tr>
		<td colspan="2"><font color=blue>若您無法正常觀看此報表！請下載此 <a href="owc11.zip" target="_File"><font color=red><b>元件</b></font></a> <font color=blue>安裝至您的電腦。</font></td>
	</tr>
</table>
<object id=ProjectAccounting classid=CLSID:0002E559-0000-0000-C000-000000000046 style="width:100%;height:90%"></object>
<script language=vbscript>
	Sub Window_OnLoad()
	Set chConstants = ProjectAccounting.Constants
	ProjectAccounting.ActiveSheet.Cells.Clear
	ProjectAccounting.Worksheets(1).Select
	ProjectAccounting.ActiveSheet.Name ="ProjectAccounting"

	ProjectAccounting.ActiveSheet.Cells(1,1).Value ="帳目编號"
	ProjectAccounting.ActiveSheet.Cells(1,2).Value ="所屬月份"
	ProjectAccounting.ActiveSheet.Cells(1,3).Value ="項 目"
	ProjectAccounting.ActiveSheet.Cells(1,4).Value ="類 別"
	ProjectAccounting.ActiveSheet.Cells(1,5).Value ="金 額"
	ProjectAccounting.ActiveSheet.Cells(1,6).Value ="發票號碼"
	ProjectAccounting.ActiveSheet.Cells(1,7).Value ="發票日期"
	ProjectAccounting.ActiveSheet.Cells(1,8).Value ="狀 態"
	ProjectAccounting.ActiveSheet.Cells(1,9).Value ="付款日"
	ProjectAccounting.ActiveSheet.Cells(1,10).Value ="處理人員"
	ProjectAccounting.ActiveSheet.Cells(1,11).Value ="備 註"
<?php  
$ECount=2;
while(list($CAUID,$CADate,$CAYear,$CAMonth,$CAItem,$CAType,$Amount,$InvoiceDate,$InvoiceYear,$InvoiceMonth,$InvoiceDay,$Invoice,$CAStatus,$PayDate,$PayYear,$PayMonth,$PayDay,$CARecord,$CARecordDate,$CARecordIP,$CANote,$AddUser,$AddDate,$ProcUser,$ProcDate)=mysqli_fetch_row($result_CommonAccounting)){
		if (trim($CAType) == "C") $CAType="公司";
		else if (trim($CAType) == "P") $CAType="個人";
		if (trim($CAStatus) == "W") $CAStatus="未付";
		else if (trim($CAStatus) == "S") $CAStatus="結清";
		else if (trim($CAStatus) == "C") $CAStatus="取消";
		?>
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,1).Value ="<?php echo $CAUID;?>"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,2).Value ="'<?php echo $CAYear."年".$CAMonth."月";?>"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,3).Value ="<?php echo $CAItem;?>"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,4).Value ="<?php echo $CAType;?>"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,5).Value ="<?php echo $Amount;?>"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,6).Value ="<?php echo $Invoice;?>"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,7).Value ="<?php if (trim($InvoiceDate) != "0000-00-00") echo $InvoiceYear."年".$InvoiceMonth."月".$InvoiceDay."日";?>"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,8).Value ="<?php echo $CAStatus;?>"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,9).Value ="<?php if (trim($PayDate) != "0000-00-00") echo $PayYear."年".$PayMonth."月".$PayDay."日";?>"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,10).Value ="<?php echo $CARecord;?>"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,11).Value ="<?php echo $CANote;?>"
		<?php
		$ECount++;
		}
mysqli_free_result($result_CommonAccounting);
mysqli_close($link);
?>
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,1).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,2).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,3).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,4).Value ="小計"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,5).Value ="<?php echo $Amount_sum;?>"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,6).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,7).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,8).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,9).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,10).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,11).Value =""
		<?php $ECount++; ?>
		ProjectAccounting.ActiveSheet.Range("A1:R<?php echo $ECount;?>").Font.Color="blue"
		ProjectAccounting.ActiveSheet.Range("A1:R<?php echo $ECount;?>").Font.Name="Courier New"
		ProjectAccounting.ActiveSheet.Range("A1:R<?php echo $ECount;?>").Font.Size="11"
		ProjectAccounting.ActiveSheet.Range("A1:R<?php echo $ECount;?>").Columns.AutoFit
		ProjectAccounting.ActiveSheet.Range("A1:R<?php echo $ECount;?>").NumberFormat ="General"

		ProjectAccounting.ActiveSheet.Range("A1:R1").Font.Bold=true
		ProjectAccounting.ActiveSheet.Range("A1:R1").Font.Color="#000000"
		ProjectAccounting.ActiveSheet.Range("A1:R1").Font.Bold=true
		ProjectAccounting.ActiveSheet.Range("A1:R1").Font.Bold=true
		ProjectAccounting.ActiveSheet.Range("A1:R1").Font.Bold=true

	End Sub
	</script>
</body>
</html>
