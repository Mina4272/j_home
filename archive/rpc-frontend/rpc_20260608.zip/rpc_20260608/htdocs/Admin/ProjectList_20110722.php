<?php
include "CheckPermission.php";
include "CheckProject.php";
include "../global.php";
include "include/page_function.php";
include "include/utf8.php";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $PageAdminTitle;?></title>
<link href="../type.css" rel="stylesheet" type="text/css" />
<style type="text/css">
<!--
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
}
-->
</style>
<script type="text/JavaScript">
<!--
function ProjectExport() 
		{
		document.form_exp.KeyWord.value = document.form1.KeyWord.value;
		document.form_exp.QPE.value = document.form1.QPE.value;
		document.form_exp.QBMUID.value = document.form1.QBMUID.value;
		document.form_exp.QPStatus.value = document.form1.QPStatus.value;
		document.form_exp.ISINo.value = document.form1.ISINo.value;
		document.form_exp.ISAdd.value = document.form1.ISAdd.value;
		document.form_exp.submit();
		}
//-->
</script>
</head>

<body>
<?php include "top.php";?>
<table width="100%" border="0" cellspacing="0" cellpadding="5">
	<tr>
    <td width="160" height="600" align="left" valign="top">
			<?php include "menu.php";?>
    </td>
    <td valign="top">
    	<table width="100%" border="0" cellpadding="0" cellspacing="0">
    		<tr>
    			<td>
			    	<table width="750" border="0" cellpadding="0" cellspacing="0">
			    		<tr height="30">
			    			<td class="c2">客戶案件管理　<input type="button" name="edit" value="已刪除案件記錄" class="input_bot" onclick="javascript:window.open ('ProjectDelHistory.php','ProjectDelHistory','height=500,width=900,top=200,left=200,scrollbars=yes,status=yes');"></td>
			    			<td align="right"><!--<input type="button" name="report" class="input_bot" value="績效報表" onclick="javascript:ProjectExport();">--></td>
			    		</tr>
			    	</table>
			    	<table width="750" border="0" cellpadding="0" cellspacing="0">
			    		<form name="form1" action="ProjectList.php" method="post">
			    		<tr>
			    			<td width="200" align="left" class="h3">關鍵字：<input type="text" name="KeyWord" size="15" value="<?php echo $KeyWord;?>"></td>
			    			<td align="left" class="h3" colspan="2">工程師：
				    			<?php
									$SQL_Manager="select MUID,MName,MEName from Manager where Deltag='N' and ISEngineer = 'Y' and IsLeft='N';";
									$result_Manager=mysql_query($SQL_Manager,$link) or die ("無法執行查詢");
				    			?>
			    				<select name="QPE">
			    					<option value="">不限</option>
			          		<?php while(list($MUID,$MName,$MEName)=mysql_fetch_row($result_Manager)){?>
			          		<option value="<?php echo $MUID;?>"<?php if (trim($MUID) == trim($QPE)) echo " selected";?>><?php echo $MEName.$MName;?></option>
			          		<?php }?>
			    				</select>
					        <?php
					        mysql_free_result($result_Manager);
									$SQL_Manager="select MUID,MName,MEName from Manager where Deltag='N' and ISBusiness = 'Y' and IsLeft='N';";
									$result_Manager=mysql_query($SQL_Manager,$link) or die ("無法執行查詢");
					        ?>
			    				　承辦業務：
			    				<select name="QBMUID">
			    					<option value="">不限</option>
			          		<?php while(list($MUID,$MName,$MEName)=mysql_fetch_row($result_Manager)){?>
			          		<option value="<?php echo $MUID;?>"<?php if (trim($MUID) == trim($QBMUID)) echo " selected";?>><?php echo $MEName.$MName;?></option>
			          		<?php }?>
			    				</select>
					        <?php
					        mysql_free_result($result_Manager);
					        ?>
			    			</td>
			    		</tr>
			    		<tr>
			    			<td align="left" class="h3">狀態：
			    				<select name="QPStatus">
			    					<option value="">不限</option>
			    					<option value="A"<?php if (trim($QPStatus) == "A") echo " selected";?>>新開案</option>
			    					<option value="B"<?php if (trim($QPStatus) == "B") echo " selected";?>>報價中</option>
			    					<option value="C"<?php if (trim($QPStatus) == "C") echo " selected";?>>案件處理中</option>
			    					<option value="D"<?php if (trim($QPStatus) == "D") echo " selected";?>>審查中</option>
			    					<option value="E"<?php if (trim($QPStatus) == "E") echo " selected";?>>補件中</option>
			    					<option value="F"<?php if (trim($QPStatus) == "F") echo " selected";?>>待印證</option>
			    					<option value="G"<?php if (trim($QPStatus) == "G") echo " selected";?>>案件取消</option>
			    					<option value="H"<?php if (trim($QPStatus) == "H") echo " selected";?>>已結案</option>
			    				</select>
			    			</td>
			    			<td align="left" class="h3">請款狀態：
			    				<select name="ISINo">
			    					<option value="">不限</option>
			    					<option value="Y"<?php if (trim($ISINo) == "Y") echo " selected";?>>已開發票</option>
			    					<option value="N"<?php if (trim($ISINo) == "N") echo " selected";?>>未開發票</option>
			    				</select>
			    				　是否加測：
			    				<select name="ISAdd">
			    					<option value="">不限</option>
			    					<option value="Y"<?php if (trim($ISAdd) == "Y") echo " selected";?>>是</option>
			    					<option value="N"<?php if (trim($ISAdd) == "N") echo " selected";?>>否</option>
			    				</select>
			    				　<input type="submit" class="input_bot" name="search" value="查詢">　<input type="button" name="button" class="input_bot" value="全部列出" onclick="javascript:location.href='ProjectList.php';">
			    			</td>
			    			<td align="right" class="h3"><input type="button" name="add" value="新 增" class="input_bot" onclick="javascript:location.href='ProjectAdd.php';"></td>
			    		</tr>
			    		</form>
			    	</table>
						<?php
			    	$KeyWord = $_POST['KeyWord'];
			    	if (trim($KeyWord) == "") $KeyWord = $_GET['KeyWord'];
			    	$QPStatus = $_POST['QPStatus'];
			    	if (trim($QPStatus) == "") $QPStatus = $_GET['QPStatus'];
			    	$QPE = $_POST['QPE'];
			    	if (trim($QPE) == "") $QPE = $_GET['QPE'];
			    	$QBMUID = $_POST['QBMUID'];
			    	if (trim($QBMUID) == "") $QBMUID = $_GET['QBMUID'];
			    	$ISINo = $_POST['ISINo'];
			    	if (trim($ISINo) == "") $ISINo = $_GET['ISINo'];
			    	$ISAdd = $_POST['ISAdd'];
			    	if (trim($ISAdd) == "") $ISAdd = $_GET['ISAdd'];
						
						echo "KeyWord=$KeyWord<br>";
						if (trim($KeyWord) != "") {
								$SQL_ProjectCertificate="select PID from ProjectCertificate where Deltag='N' and PCNo like '%".$KeyWord."%' group by PID order by PID;";
								$result_ProjectCertificate=mysql_query($SQL_ProjectCertificate,$link) or die ("無法執行查詢");
								$SqlPID = "";
								while(list($PC_PID)=mysql_fetch_row($result_ProjectCertificate)){
										//if (trim($SqlPID) == "") $SqlPID = "PID='".$PC_PID."'";
										//else $SqlPID = $SqlPID." or PID='".$PC_PID."'";
										if (trim($SqlPID) == "") $SqlPID = $PC_PID;
										else $SqlPID = $SqlPID.",".$PC_PID;
										}
								mysql_free_result($result_ProjectCertificate);
								}
						if (trim($SqlPID) != "") $SqlPID = " PID in (".$SqlPID.")";
			    	if (trim($KeyWord) != "") {
			    			if (trim($SqlPID) == "") $SqlTxt = $SqlTxt." and (PUID like '%".$KeyWord."%' or CName like '%".$KeyWord."%' or CTel like '%".$KeyWord."%' or CFax like '%".$KeyWord."%' or Contact like '%".$KeyWord."%' or CMobile like '%".$KeyWord."%' or CEMail like '%".$KeyWord."%' or CAddress like '%".$KeyWord."%' or PName like '%".$KeyWord."%' or ModelName like '%".$KeyWord."%' or SeriesModel like '%".$KeyWord."%' or PE like '%".$KeyWord."%' or PNote like '%".$KeyWord."%' or ApplyItem like '%".$KeyWord."%' or EMC like '%".$KeyWord."%' or Canon like '%".$KeyWord."%')";
			    			else $SqlTxt = $SqlTxt." and (PUID like '%".$KeyWord."%' or CName like '%".$KeyWord."%' or CTel like '%".$KeyWord."%' or CFax like '%".$KeyWord."%' or Contact like '%".$KeyWord."%' or CMobile like '%".$KeyWord."%' or CEMail like '%".$KeyWord."%' or CAddress like '%".$KeyWord."%' or PName like '%".$KeyWord."%' or ModelName like '%".$KeyWord."%' or SeriesModel like '%".$KeyWord."%' or PE like '%".$KeyWord."%' or PNote like '%".$KeyWord."%' or ApplyItem like '%".$KeyWord."%' or EMC like '%".$KeyWord."%' or Canon like '%".$KeyWord."%' or ".$SqlPID.")";
			    			
			    			}
			    	if (trim($QPStatus) != "") $SqlTxt = $SqlTxt." and PStatus='".$QPStatus."' ";
			    	if (trim($QPE) != "") $SqlTxt = $SqlTxt." and PE='".$QPE."' ";
			    	if (trim($QBMUID) != "") $SqlTxt = $SqlTxt." and ifnull(BMUID,'vivi')='".$QBMUID."' ";
			    	if (trim($ISINo) != "") {
			    			if (trim($ISINo) == "Y") $SqlTxt = $SqlTxt." and INo <> '' ";
			    			else $SqlTxt = $SqlTxt." and INo = '' ";
			    			}
			    	if (trim($ISAdd) != "") {
			    			if (trim($ISAdd) == "Y") $SqlTxt2 = " WHERE a.PCount > 0";
			    			else $SqlTxt2 = " WHERE a.PCount = 0";
			    			}
						
						$page = $_GET['page'];
						if (trim($page) == "") $page = 1;
						$page_rows=15;  //每頁筆數
						$php_Self = "ProjectList.php";  //分頁web檔名

						$button_css = "h4";
						$limit_txt =" limit ".(($page-1) * $page_rows).",".$page_rows;
						$url_str = "&QPStatus=".$QPStatus."&QPE=".$QPE."&QBMUID=".$QBMUID."&ISINo=".$ISINo."&ISAdd=".$ISAdd."&KeyWord=".urlencode($KeyWord);
						$Sql_str="select a.* from (select PID,PUID,CID,CName,CTel,CFax,Contact,CMobile,CEMail,CAddress,PStatus,PName,ModelName,SeriesModel,PE,Quote,ApplyItem,Canon,SNote,PlanDate,CloseDate,PNote,QuoteDate,ReturnDate,(select count(PAAID) PCount from ProjectAccountingAdd where PAACheck='N' and PID=Project.PID) PCount from Project where Deltag='N' ".$SqlTxt.") as a ".$SqlTxt2." order by a.PStatus asc,a.PID desc;";
						$SQL_Project="select a.* from (select PID,PUID,CID,CName,CTel,CFax,Contact,CMobile,CEMail,CAddress,PStatus,PName,ModelName,SeriesModel,PE,Quote,ApplyItem,Canon,SNote,PlanDate,CloseDate,PNote,QuoteDate,ReturnDate,(select count(PAAID) PCount from ProjectAccountingAdd where PAACheck='N' and PID=Project.PID) PCount from Project where Deltag='N' ".$SqlTxt.") a ".$SqlTxt2." order by a.PStatus asc,a.PID desc ".$limit_txt.";";
						$result_Project=mysql_query($SQL_Project,$link) or die ("無法執行查詢");
						?>
			    	<table width="750" border="0" cellpadding="5" cellspacing="2" class="s2">
			        <tr align="center">
			          <td width="80" align="center" background="../images/table_bg.gif" class="t21">案件編號</td>
			          <td background="../images/table_bg.gif" class="t21">產品名稱 / 型號</td>
			          <td width="80" background="../images/table_bg.gif" class="t21">客戶名稱</td>
			          <td width="80" background="../images/table_bg.gif" class="t21">狀態</td>
			          <td width="50" background="../images/table_bg.gif" class="t21">工程師</td>
			          <td width="130" background="../images/table_bg.gif" class="t21">申請項目</td>
			        </tr>
		          <?php
		          $tmp = 1;
		          while(list($PID,$PUID,$CID,$CName,$CTel,$CFax,$Contact,$CMobile,$CEMail,$CAddress,$PStatus,$PName,$ModelName,$SeriesModel,$PE,$Quote,$ApplyItem,$Canon,$SNote,$PlanDate,$CloseDate,$PNote,$QuoteDate,$ReturnDate)=mysql_fetch_row($result_Project)){
		        	if (trim($ModelName) == "") $ModelName = "NA";
	          	if (utf8_strlen(strip_tags($CName)) > 4) $CName = utf8_substr(strip_tags($CName),0,4);
	          	else $CName = strip_tags($CName);

							//$SQL_Manager="select MName from Manager where Deltag='N' and ISEngineer = 'Y' and MUID = '".$PE."';";
							$SQL_Manager="select MName,MEName from Manager where MUID = '".$PE."';";
							$result_Manager=mysql_query($SQL_Manager,$link) or die ("無法執行查詢");
							list($MName,$MEName)=mysql_fetch_row($result_Manager);
							mysql_free_result($result_Manager);
							
							//開出報價後，超過三天請轉成藍色字體提醒
	          	//if ($QuoteDate < date ("Y-m-d", mktime (0,0,0,date("m"),date("d")-3,date("Y"))) and trim($PStatus) == "B") $cssStr="b";
	          	//else $cssStr="";
		        	?>
		        	<tr<?php if ($tmp%2 == 0) echo " bgcolor=\"#F6F6F6\"";?>>
			          <td align="center" class="h3"><a href="ProjectDetail.php?PID=<?php echo $PID;?>&page=<?php echo $page;?><?php echo $url_str;?>"><?php echo $PUID;?></a></td>
			          <td class="h3<?php echo $cssStr;?>"><?php echo $PName;?> <font color=blue><b>/</b></font> <?php echo $ModelName;?></td>
			          <td class="h3<?php echo $cssStr;?>"><?php echo $CName;?></td>
			          <td align="center" class="h3<?php echo $cssStr;?>">
			          	<?php
			          	if (trim($PStatus) == "A") echo "新開案";
			          	else if (trim($PStatus) == "B") echo "報價中";
			          	else if (trim($PStatus) == "C") echo "案件處理中";
			          	else if (trim($PStatus) == "D") echo "審查中";
			          	else if (trim($PStatus) == "E") echo "補件中";
			          	else if (trim($PStatus) == "F") echo "待印證";
			          	else if (trim($PStatus) == "G") echo "案件取消";
			          	else if (trim($PStatus) == "H") echo "已結案";
			          	?>
			          </td>
			          <td align="center" class="h3<?php echo $cssStr;?>"><?php echo $MEName."<br>".$MName;?></td>
			          <td align="center" class="h3<?php echo $cssStr;?>"><?php echo $ApplyItem;?></td>
			        </tr>
			        <?php
            			$tmp++;
			      			}
            	mysql_free_result($result_Project);
			        ?>
			      </table>
			      <table width="750" border="0" cellpadding="5" cellspacing="2" class="s2">
			        <tr align="center">
			          <td bgcolor="#E8F0C2" class="h4"><?php Page_show($Sql_str,$page_rows,$php_Self,$link,$page,$url_str,$button_css);?></td>
			        </tr>
			      </table>
    			</td>
    		</tr>
    	</table>
    </td>
	</tr>
</table>
<form name="form_exp" action="ProjectExport.php" method="post" target="_ProjectExport">
	<input type="hidden" name="KeyWord">
	<input type="hidden" name="QPE">
	<input type="hidden" name="QBMUID">
	<input type="hidden" name="QPStatus">
	<input type="hidden" name="ISINo">
	<input type="hidden" name="ISAdd">
</form>
<?php include "down.php";?>
</body>
</html>
<?php
mysql_close($link);
?>