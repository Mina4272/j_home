﻿<?php
include "CheckPermission.php";
include "CheckAgendum.php";
include "../global.php";
include "include/page_function.php";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $PageAdminTitle;?></title>
<link href="../type.css" rel="stylesheet" type="text/css" />
<style type="text/css">
<!--
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
}
-->
</style></head>

<body>
<?php
$AID = $_GET['AID'];
$page = $_GET['page'];
if (trim($page) == "") $page = 1;
$page_rows=10;  //每頁筆數
$php_Self = "AgendumNote.php";  //分頁web檔名

$button_css = "h4";
$limit_txt =" limit ".(($page-1) * $page_rows).",".$page_rows;
$url_str = "&AID=".$AID;
$Sql_str="select ANID,AContent,AddUser,AddDate,ProcUser,ProcDate from AgendumNote where Deltag='N' and AID = '".$AID."' ".$SqlTxt." order by ANID desc;";
$SQL_AgendumNote="select ANID,AContent,AddUser,AddDate,ProcUser,ProcDate from AgendumNote where Deltag='N' and AID = '".$AID."' ".$SqlTxt." order by ANID desc ".$limit_txt.";";
$result_AgendumNote=mysqli_query($link,$SQL_AgendumNote) or die ("無法執行查詢");
?>
<table width="100%" border="0" cellpadding="5" cellspacing="2" class="s2">
  <tr>
    <td background="../images/table_bg.gif" class="t21">內容及聯絡事項</td>
    <td width="140" align="center" background="../images/table_bg.gif" class="t21">記錄人員</td>
  </tr>
  <?php
  $tmp = 1;
  while(list($ANID,$AContent,$AddUser,$AddDate,$ProcUser,$ProcDate)=mysqli_fetch_row($result_AgendumNote)){
	?>
	<tr<?php if ($tmp%2 == 0) echo " bgcolor=\"#F6F6F6\"";?>>
    <td class="h3"><?php echo $AContent;?></td>
    <td class="h3" align="center">
    	<?php
    	if (trim($ProcUser) == "") echo $AddUser."<br>".$AddDate;
    	else echo $ProcUser."<br>".$ProcDate;
    	?>	
    </td>
  </tr>
  <?php
			$tmp++;
			}
	mysqli_free_result($result_AgendumNote);
  ?>
</table>
<table width="100%" border="0" cellpadding="5" cellspacing="2" class="s2">
  <tr align="center">
    <td bgcolor="#E8F0C2" class="h4"><?php Page_show($Sql_str,$page_rows,$php_Self,$link,$page,$url_str,$button_css);?></td>
  </tr>
</table>
</body>
</html>
<?php
mysqli_close($link);
?>