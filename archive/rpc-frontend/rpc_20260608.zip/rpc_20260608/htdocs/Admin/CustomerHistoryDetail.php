﻿<?php	
include "CheckPermission.php";
include "../global.php";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $PageAdminTitle;?></title>
<link href="../type.css" rel="stylesheet" type="text/css" />
<style type="text/css">
<!--
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
}
-->
</style>
<Script type="text/javascript" language="javascript" src="../script/rpc.js"></Script>
<Script type="text/javascript" language="javascript" src="../script/CheckForm.js"></Script>
</head>
<body>
<?php
$CHID = $_GET['CHID'];
$CID = $_GET['CID'];
$page = $_GET['page'];
if (trim($CID) == "" || trim($CHID) == "")
		{
		mysqli_close($link);
		?>
		<script type="text/JavaScript">
			<!--
			alert ("查無資料，請冾網站管理人員！");
			history.go(-1);
			//-->
		</script>
		<?php
		exit;
		}
$SQL_Customer="select CUID,CPWD,CName,EName,TrademarkTxt,TrademarkImg,CTel,CFax,Contact,CMobile,CEMail,CAddress,CNote,CType,CLevel,CFees,CRecord,CRecordTxt,BSMI,AddUser,AddDate,ProcUser,ProcDate from CustomerHistory where Deltag='N' and CHID = '".$CHID."';";
$result_Customer=mysqli_query($link,$SQL_Customer) or die ("無法執行查詢");
if (mysqli_num_rows($result_Customer) == 0)
		{
		mysqli_free_result($result_Customer);
		mysqli_close($link);
		?>
		<SCRIPT language=javascript>
		<!--
		alert ("查無資料，請冾網站管理人員！"); 
		history.go(-1);
		//-->
		</SCRIPT>
		<?php 	
		exit;
		}
list($CUID,$CPWD,$CName,$EName,$TrademarkTxt,$TrademarkImg,$CTel,$CFax,$Contact,$CMobile,$CEMail,$CAddress,$CNote,$CType,$CLevel,$CFees,$CRecord,$CRecordTxt,$BSMI,$AddUser,$AddDate,$ProcUser,$ProcDate)=mysqli_fetch_row($result_Customer);
mysqli_free_result($result_Customer);

?>
    	<table width="100%" border="0" cellpadding="0" cellspacing="0">
    		<tr>
    			<td>
			    	<table width="750" border="0" cellpadding="0" cellspacing="0">
			    		<tr height="30">
			    			<td class="c2"><b>客戶歷史資料</b></td>
			    		</tr>
			    	</table>
			    	<table width="750" border="0" cellpadding="0" cellspacing="0">
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td width="120" align="right" class="c3">統一編號：</td>
			          <td class="h3"><?php echo $CUID;?>
			          	<input type="hidden" name="CID" value="<?php echo $CID;?>">
			          	<input type="hidden" name="page" value="<?php echo $page;?>">
			          </td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">客戶種類：</td>
			          <td class="h3">
			          	<?php
				          if (trim(strstr($CType,'N')) != "") echo "一般客戶<br>";
				          if (trim(strstr($CType,'P')) != "") echo "供應商";
			          	?>
			          </td>
			        </tr>
	          	<?php
	          	if (trim($CLevel) == "C") $CLevel="B";
	          	if (trim($CLevel) == "A") $CLevelAlt="優(結案後直接給證書)";
	          	else if (trim($CLevel) == "B") $CLevelAlt="良(結案付款後給證書)";
	          	if (trim($CFees) == "A") $CFeesAlt="是(收據抬頭開全威)";
	          	else if (trim($CFees) == "B") $CFeesAlt="是(收據抬頭開申請人)";
	          	else if (trim($CFees) == "C") $CFeesAlt="否(不代送審)";
	          	if (trim($CRecord) == "A") $CRecordAlt="優(結案後月結60天)";
	          	else if (trim($CRecord) == "B") $CRecordAlt="良(月結30天)";
	          	else if (trim($CRecord) == "C") $CRecordAlt="付款開案";
	          	else if (trim($CRecord) == "D") $CRecordAlt="其他";
	          	?>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">客戶等級：</td>
			          <td class="h3">
			          	<img src="../images/<?php echo $CLevel;?>1.gif" alt="<?php echo $CLevelAlt;?>"> 
			          </td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">規費是否代付：</td>
			          <td class="h3">
			          	<img src="../images/<?php echo $CFees;?>1.gif" alt="<?php echo $CFeesAlt;?>"> 
			          </td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">付款記錄：</td>
			          <td class="h3">
			          	<img src="../images/<?php echo $CRecord;?>2.gif" alt="<?php echo $CRecordAlt;?>">
			          </td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">公司名稱：</td>
			          <td class="h3"><?php echo $CName;?></td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">公司英文名稱：</td>
			          <td class="h3"><?php echo $EName;?></td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">BSMI識別號碼：</td>
			          <td class="h3"><?php echo $BSMI;?></td>
			        </tr>
			        <tr height="60" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">商 標：</td>
			          <td class="h3">
	              	<table width="100%" border="0" cellpadding="0" cellspacing="0">
	              		<tr class="h3">
	              			<td width="40" align="center">圖片</td>
	              			<td width="150" align="center"><div id="TrademarkImgPreview" style="display:none"></div></td>
	              			<td align="center" valign="bottom"><div id="TrademarkImgDel" style="display:none"></div></td>
	              			<td>
				              	<input name="TrademarkImg" type="hidden" id="TrademarkImg" value="<?php echo $TrademarkImg;?>" />
	              			</td>
	              		</tr>
	              		<tr>
	              			<td width="40" align="center" class="h3">文字</td>
	              			<td colspan="3"><?php echo $TrademarkTxt;?></td>
	              		</tr>
	              	</table>
			          </td>
			        </tr>
							<?php
							if (trim($TrademarkImg) != "") {
									?>
									<SCRIPT language=javascript>
									<!--
											document.getElementById('TrademarkImgPreview').style.display = '';
											document.getElementById('TrademarkImgPreview').innerHTML = '<a href="getfile.php?FolderName=Admin\\TrademarkImg&FileName=<?php echo $TrademarkImg;?>"><img src="TrademarkImg/s<?php echo $TrademarkImg;?>" border="0"></a>';
									//-->
									</SCRIPT>
									<?php
									}
							?>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">公司電話：</td>
			          <td class="h3"><?php echo $CTel;?></td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">公司傳真：</td>
			          <td class="h3"><?php echo $CFax;?></td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">公司地址：</td>
			          <td class="h3"><?php echo $CAddress;?></td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">備 註：</td>
			          <td class="h3"><?php echo $CNote;?></td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">新增人員：</td>
			          <td class="h3"><?php echo $AddUser;?>　<?php echo $AddDate;?></td>
			        </tr>
			        <?php if (trim($ProcUser) != "") {?>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">最後更新：</td>
			          <td class="h3"><?php echo $ProcUser;?>　<?php echo $ProcDate;?> 
			          </td>
			        </tr>
			        <?php }?>
			        <tr height="40" align="center">
			          <td colspan="2" class="h3"><input type="button" name="button" class="input_bot" value="回列表" onclick="javascript:location.href='CustomerHistory.php?CID=<?php echo $CID;?>&page=<?php echo $page;?>';"></td>
			        </tr>
			      </table>
    			</td>
    		</tr>
    	</table>
</body>
</html>
<?php
mysqli_close($link);
?>