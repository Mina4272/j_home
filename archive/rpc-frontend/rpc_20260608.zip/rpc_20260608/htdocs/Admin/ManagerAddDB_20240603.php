﻿<?php
include "CheckPermission.php";
include "CheckManager.php";
include "../global.php";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $PageAdminTitle;?></title>
</head>
<body>
<?php
$MUID = $_POST['MUID'];
$MPassword = $_POST['MPassword'];
$MName = $_POST['MName'];
$MEName = $_POST['MEName'];
$EMail = $_POST['EMail'];
$MIntro = $_POST['MIntro'];
$MPer = $_POST['MPer'];
$MPerTxt = join(",", $MPer);
if (trim(strstr($MPerTxt,'D')) != "" && trim(strstr($MPerTxt,'I')) != "") $MPerTxt = str_replace(",D","",$MPerTxt);
$ISEngineer = $_POST['ISEngineer'];

$RYear = $_POST['RYear'];
$RMonth = $_POST['RMonth'];
$RDay = $_POST['RDay'];
if (trim($RYear) != "" || trim($RMonth) != "" || trim($RDay) != "") if (checkdate($RMonth,$RDay ,$RYear)) $RDate = $RYear."-".$RMonth."-".$RDay;

$BirthYear = $_POST['BirthYear'];
$BirthMonth = $_POST['BirthMonth'];
$BirthDay = $_POST['BirthDay'];
if (trim($BirthYear) != "" || trim($BirthMonth) != "" || trim($BirthDay) != "") if (checkdate($BirthMonth,$BirthDay ,$BirthYear)) $BirthDate = $BirthYear."-".$BirthMonth."-".$BirthDay;

$Address = $_POST['Address'];
$RAddress = $_POST['RAddress'];
$Tel = $_POST['Tel'];

$EmployeeNo = $_POST['EmployeeNo'];
$Departments = $_POST['Departments'];
$Title = $_POST['Title'];
$Ext = $_POST['Ext'];
$ISBusiness = $_POST['ISBusiness'];
$Mobile = $_POST['Mobile'];

if (trim($RDate)=="") $RDate = "NULL";
else $RDate = "'$RDate'";
if (trim($BirthDate)=="") $BirthDate = "NULL";
else $BirthDate = "'$BirthDate'";

if (trim($_SESSION["reg_MUID"]) == "Benson" || trim($_SESSION["reg_MUID"]) == "vivi" || trim($_SESSION["reg_MUID"]) == "jacky") {
		$MPID = $_POST['MPID'];
		$BCode = $_POST['BCode'];
		$BAccount = $_POST['BAccount'];

		$Salary = $_POST['Salary'];
		$Allowance = $_POST['Allowance'];
		$FullAttendance = $_POST['FullAttendance'];
		$Bonus = $_POST['Bonus'];
		$CLabor = $_POST['CLabor'];
		$CHealth = $_POST['CHealth'];
		$ELabor = $_POST['ELabor'];
		$EHealth = $_POST['EHealth'];
		$CRetirement = $_POST['CRetirement'];
		$CRetirementEmployee = ($Salary*6%);
		$Salary2 = $Salary - $CRetirementEmployee;
		}
if (trim($Salary) == "") $Salary = "NULL";
if (trim($Allowance) == "") $Allowance = "NULL";
if (trim($FullAttendance) == "") $FullAttendance = "NULL";
if (trim($Bonus) == "") $Bonus = "NULL";
if (trim($CLabor) == "") $CLabor = "NULL";
if (trim($CHealth) == "") $CHealth = "NULL";
if (trim($ELabor) == "") $ELabor = "NULL";
if (trim($EHealth) == "") $EHealth = "NULL";
if (trim($CRetirement) == "") $CRetirement = "NULL";
if (trim($CRetirementEmployee) == "") $CRetirementEmployee = "NULL";
if (trim($MUID) == "" || trim($MPassword) == "" || trim($MName) == "" || trim($MPerTxt) == "")
		{
		mysqli_close($link);
		?>
		<script type="text/JavaScript">
			<!--
			alert ("您輸入的資料不足，請重新輸入！");
			history.go(-1);
			//-->
		</script>
		<?php
		exit;
		}

$now_time = date("Y-m-d H:i:s",mktime());
$SQL_select="select MUID from Manager where DelTag = 'N' and MUID = '".$MUID."';";
$result_select=mysqli_query($link,$SQL_select) or die ("無法執行查詢");

if (mysqli_num_rows($result_select) != 0)
		{
		mysqli_free_result($result_select);
		mysqli_close($link);
		?>
		<script type="text/JavaScript">
			<!--
			alert ("您輸入的帳號已使用中！");
			history.go(-1);
			//-->
		</script>
		<?php
		exit;
		}
mysqli_free_result($result_select);

if (trim($_SESSION["reg_MUID"]) == "Benson" || trim($_SESSION["reg_MUID"]) == "vivi" || trim($_SESSION["reg_MUID"]) == "jacky") 
		$sql_insert = "insert into Manager (MUID,MPassword,MName,MEName,EmployeeNo,MPID,Salary,Allowance,FullAttendance,Bonus,CLabor,CHealth,ELabor,EHealth,CRetirement,CRetirementEmployee,Departments,Title,Ext,EMail,MIntro,MPer,ISEngineer,ISBusiness,RDate,BirthDay,Address,RAddress,Tel,Mobile,BCode,BAccount,AddUser,AddDate,AddIP) values ('".$MUID."','".$MPassword."','".$MName."','".$MEName."','".$EmployeeNo."','".$MPID."',".$Salary2.",".$Allowance.",".$FullAttendance.",".$Bonus.",".$CLabor.",".$CHealth.",".$ELabor.",".$EHealth.",".$CRetirement.",".$CRetirementEmployee.",'".$Departments."','".$Title."','".$Ext."','".$EMail."','".$MIntro."','".$MPerTxt."','".$ISEngineer."','".$ISBusiness."',".$RDate.",".$BirthDate.",'".$Address."','".$RAddress."','".$Tel."','".$Mobile."','".$BCode."','".$BAccount."','".$_SESSION["reg_MUID"]."','".$now_time."','".$_SERVER["REMOTE_ADDR"]."');";
else 
		$sql_insert = "insert into Manager (MUID,MPassword,MName,MEName,EmployeeNo,MPID,Departments,Title,Ext,EMail,MIntro,MPer,ISEngineer,ISBusiness,RDate,BirthDay,Address,RAddress,Tel,Mobile,BCode,BAccount,AddUser,AddDate,AddIP) values ('".$MUID."','".$MPassword."','".$MName."','".$MEName."','".$EmployeeNo."','".$MPID."','".$Departments."','".$Title."','".$Ext."','".$EMail."','".$MIntro."','".$MPerTxt."','".$ISEngineer."','".$ISBusiness."',".$RDate.",".$BirthDate.",'".$Address."','".$RAddress."','".$Tel."','".$Mobile."','".$BCode."','".$BAccount."','".$_SESSION["reg_MUID"]."','".$now_time."','".$_SERVER["REMOTE_ADDR"]."');";
$result_insert=mysqli_query($link,$sql_insert) or die ("無法執行新增");

mysqli_close($link);
?>
<script type="text/JavaScript">
	<!--
	alert ("新增成功！");
	location.href='ManagerList.php';
	//-->
</script>

</body>
</html>
