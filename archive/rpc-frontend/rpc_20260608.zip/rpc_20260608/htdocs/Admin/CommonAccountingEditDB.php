﻿<?php
include "CheckPermission.php";
include "CheckCommonAccounting.php";
include "../global.php";
include "include/function.php";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $PageAdminTitle;?></title>
</head>
<body>
<?php
$PayDate="";
$SqlTxt="";
$SqlTxt2="";
$InvoiceDate="";
$CAID = $_POST['CAID'];
$QCAType = $_POST['QCAType'];
$QSCADate = $_POST['QSCADate'];
$QECADate = $_POST['QECADate'];
$KeyWord = $_POST['KeyWord'];

$CAYear = $_POST['CAYear'];
$CAMonth = $_POST['CAMonth'];
$CADate = $CAYear."-".$CAMonth."-01";
$CAItem = $_POST['CAItem'];
$Amount = empty($_POST['Amount'])?"":$_POST['Amount'];
$Invoice = $_POST['Invoice'];
$InvoiceYear = $_POST['InvoiceYear'];
$InvoiceMonth = $_POST['InvoiceMonth'];
$InvoiceDay = $_POST['InvoiceDay'];
if (trim($InvoiceYear) != "" || trim($InvoiceMonth) != "" || trim($InvoiceDay) != "") if (checkdate($InvoiceMonth,$InvoiceDay ,$InvoiceYear)) $InvoiceDate = $InvoiceYear."-".$InvoiceMonth."-".$InvoiceDay;
$CAStatus = empty($_POST['CAStatus'])?"":$_POST['CAStatus'];
$CANote = empty($_POST['CANote'])?"":$_POST['CANote'];
$PayYear = empty($_POST['PayYear'])?"":$_POST['PayYear'];
$PayMonth = empty($_POST['PayMonth'])?"":$_POST['PayMonth'];
$PayDay = empty($_POST['PayDay'])?"":$_POST['PayDay'];
if (trim($PayYear) != "" || trim($PayMonth) != "" || trim($PayDay) != "") if (checkdate($PayMonth,$PayDay ,$PayYear)) $PayDate = $PayYear."-".$PayMonth."-".$PayDay;
$CAType = $_POST['CAType'];

if (trim($CAID) == "" || trim($CAYear) == "" || trim($CAMonth) == "" || trim($CAItem) == "")
		{
		mysqli_close($link);
		?>
		<script type="text/JavaScript">
			<!--
			alert ("您輸入的資料不足，請重新輸入！");
			history.go(-1);
			//-->
		</script>
		<?php
		exit;
		}
$SQL_CommonAccounting="select CAStatus from CommonAccounting where Deltag='N' and CAID = '".$CAID."';";
$result_CommonAccounting=mysqli_query($link,$SQL_CommonAccounting) or die ("無法執行查詢");
if (mysqli_num_rows($result_CommonAccounting) == 0)
		{
		mysqli_free_result($result_CommonAccounting);
		mysqli_close($link);
		?>
		<SCRIPT language=javascript>
		<!--
		alert ("查無資料，請冾網站管理人員！"); 
		history.go(-1);
		//-->
		</SCRIPT>
		<?php 	
		exit;
		}
list($CheckStatus)=mysqli_fetch_row($result_CommonAccounting);
mysqli_free_result($result_CommonAccounting);

$now_time = date("Y-m-d H:i:s",mktime());
if(trim($_FILES['CAFile']['tmp_name']) != "")
		{
		if($_FILES['CAFile']['size'] > 20971520)
				{
				?>
				<script type="text/JavaScript">
					<!--
					alert ("您上傳的檔案 Size 超過 20 M，請重新上傳！");
					history.go(-1);
					//-->
				</script>
				<?php
				exit();
				}
		$CAFile = "CAFile_".date("ymdHis",mktime()).rand_string(5, 'ABCDEFGHIJKLMNPQRSTUVWXYZ23456789abcdefghijklmnopqrstuvwxyz').".".strtolower(substr($_FILES['CAFile']['name'],strrpos($_FILES['CAFile']['name'],".")+1,strlen($_FILES['CAFile']['name'])+1));
		@copy($_FILES['CAFile']['tmp_name'],$_SERVER["DOCUMENT_ROOT"]."\\Admin\\CAFile\\".$CAFile);
		}
$sql_insert = "INSERT INTO CommonAccountingHistory(CAID,CAUID,CADate,CAItem,CAType,Amount,InvoiceDate,Invoice,CAStatus,PayDate,CARecord,CARecordDate,CARecordIP,CANote,AddUser,AddDate,AddIP,Deltag,ProcUser,ProcDate,ProcIP,UpdateUser,UpdateDate,UpdateIP) SELECT CAID,CAUID,CADate,CAItem,CAType,Amount,InvoiceDate,Invoice,CAStatus,PayDate,CARecord,CARecordDate,CARecordIP,CANote,AddUser,AddDate,AddIP,Deltag,ProcUser,ProcDate,ProcIP,'".$_SESSION["reg_MUID"]."','".$now_time."','".$_SERVER["REMOTE_ADDR"]."' FROM CommonAccounting where Deltag='N' and CAID = '".$CAID."';";
$result_insert=mysqli_query($link,$sql_insert) or die ("無法執行新增");

if($CAFile != ''){
	$SqlTxt2=", CAFile = '".$CAFile."'";
}

if (trim($PayDate) == "") $PayDate = "0000-00-00";
if (trim($InvoiceDate) == "") $InvoiceDate = "0000-00-00";

if (trim($CAStatus) == "S") $SqlTxt = ",PayDate = '".$PayDate."',CARecordDate = '".$now_time."',CARecord = '".$_SESSION["reg_MUID"]."',CARecordIP = '".$now_time."',CARecordIP = '".$_SERVER["REMOTE_ADDR"]."'";
else if (trim($CAStatus) == "C") $SqlTxt = ",CARecord = '".$_SESSION["reg_MUID"]."',CARecordDate = '".$now_time."',CARecordIP = '".$_SERVER["REMOTE_ADDR"]."'";
if (trim($CheckStatus) == "W") $sql_update = "update CommonAccounting set CADate = '".$CADate."',CAItem = '".$CAItem."',CAType = '".$CAType."',Amount = '".$Amount."',InvoiceDate = '".$InvoiceDate."',Invoice = '".$Invoice."',PayDate = '".$PayDate."',CAStatus = '".$CAStatus."'".$SqlTxt."".$SqlTxt2.",CANote = '".$CANote."',ProcUser = '".$_SESSION["reg_MUID"]."',ProcDate = '".$now_time."',ProcIP = '".$_SERVER["REMOTE_ADDR"]."' where Deltag='N' and CAID = '".$CAID."';";
else $sql_update = "update CommonAccounting set CADate = '".$CADate."',CAItem = '".$CAItem."',CAType = '".$CAType."',InvoiceDate = '".$InvoiceDate."',Invoice = '".$Invoice."',CANote = '".$CANote."'".$SqlTxt2.",ProcUser = '".$_SESSION["reg_MUID"]."',ProcDate = '".$now_time."',ProcIP = '".$_SERVER["REMOTE_ADDR"]."' where Deltag='N' and CAID = '".$CAID."';";
$result_update=mysqli_query($link,$sql_update) or die ("無法執行修改");

mysqli_close($link);

?>
<script type="text/JavaScript">
	<!--
	alert ("修改成功！");
	location.href='CommonAccounting.php?QCAType=<?php echo $QCAType;?>&QSCADate=<?php echo $QSCADate;?>&QECADate=<?php echo $QECADate;?>&KeyWord=<?php echo urlencode($KeyWord);?>';
	//-->
</script>

</body>
</html>
