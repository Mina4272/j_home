﻿<?php
include "CheckPermission.php";
include "CheckCustomer.php";
include "../global.php";
include "include/page_function.php";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $PageAdminTitle;?></title>
<link href="../type.css" rel="stylesheet" type="text/css" />
<style type="text/css">
<!--
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
}
-->
</style></head>

<body>
<table width="100%" border="0" cellpadding="0" cellspacing="0">
	<tr>
		<td>
    	<table width="100%" border="0" cellpadding="0" cellspacing="0">
    		<tr height="30">
    			<td class="c2" background="../images/table_bg.gif">已刪除客戶資料列表</td>
    		</tr>
    	</table>
			<?php
			$CID = empty($_GET['CID'])?"":$_GET['CID'];
			$page = empty($_GET['page'])?"":$_GET['page'];
			if (trim($page) == "") $page = 1;
			$page_rows=15;  //每頁筆數
			$php_Self = "CustomerDelHistory.php";  //分頁web檔名

			$button_css = "h4";
			$limit_txt =" limit ".(($page-1) * $page_rows).",".$page_rows;
			$url_str = "&CID=".$CID;
			$Sql_str="select CID from Customer where Deltag='Y' order by CID desc;";
			$SQL_Customer="select CID,CUID,CPWD,CName,CTel,Contact,CMobile,CEMail,CAddress,CNote,CLevel,CRecord,AddUser,AddDate,ProcUser,ProcDate from Customer where Deltag='Y' order by CID desc ".$limit_txt.";";
			$result_Customer=mysqli_query($link,$SQL_Customer) or die ("無法執行查詢");
			?>
    	<table width="780" border="0" cellpadding="5" cellspacing="2" class="s2">
        <tr align="center">
          <td width="30" align="center" background="../images/table_bg.gif" class="t21">序</td>
          <td width="300" background="../images/table_bg.gif" class="t21">公司名稱</td>
          <td width="120" background="../images/table_bg.gif" class="t21">電 話</td>
          <td width="175" background="../images/table_bg.gif" class="t21">備 註</td>
          <td width="50" background="../images/table_bg.gif" class="t21">詳 細</td>
          <td width="100" background="../images/table_bg.gif" class="t21">最後更新</td>
        </tr>
        <?php
        $tmp = 1;
        while(list($CID,$CUID,$CPWD,$CName,$CTel,$Contact,$CMobile,$CEMail,$CAddress,$CNote,$CLevel,$CRecord,$AddUser,$AddDate,$ProcUser,$ProcDate)=mysqli_fetch_row($result_Customer)){
      	?>
      	<tr<?php if ($tmp%2 == 0) echo " bgcolor=\"#F6F6F6\"";?>>
          <td width="30" align="center" class="h3"><?php echo $CID;?></td>
          <td width="300" class="h3"><?php echo $CName;?> 
          	<?php
          	if (trim($CLevel) == "A") $CLevelAlt="客戶等級(好)";
          	else if (trim($CLevel) == "B") $CLevelAlt="客戶等級(中)";
          	else if (trim($CLevel) == "C") $CLevelAlt="客戶等級(差)";
          	if (trim($CRecord) == "A") $CRecordAlt="付款記錄(優良)";
          	else if (trim($CRecord) == "B") $CRecordAlt="付款記錄(尚可)";
          	else if (trim($CRecord) == "C") $CRecordAlt="付款記錄(不好)";
          	?>
          	<img src="../images/<?php echo $CLevel;?>1.gif" alt="<?php echo $CLevelAlt;?>"> 
          	<img src="../images/<?php echo $CRecord;?>2.gif" alt="<?php echo $CRecordAlt;?>">
          </td>
          <td width="120" align="center" class="h3"><?php echo $CTel;?></td>
          <td width="175" class="h4"><?php echo $CNote;?></td>
          <td width="60" align="center">
          	<input type="button" name="detail" value="詳 細" class="input_bot" onclick="javascript:location.href='CustomerDelHistoryDetail.php?CID=<?php echo $CID;?>&page=<?php echo $page;?>';">
          	<input type="button" name="recovery" value="還 原" class="input_bot" onclick="javascript:if (confirm('您是否確定要還原客戶資訊？')) location.href='CustomerRecoveryDB.php?CID=<?php echo $CID;?>&page=<?php echo $page;?>';">
          </td>
          <td width="100 " align="center" class="h3">
          	<?php
          	if (trim($ProcUser) == "") echo $AddUser."<br>".$AddDate;
          	else echo $ProcUser."<br>".$ProcDate;
          	?>
          </td>
        </tr>
        <?php
      			$tmp++;
      			}
      	mysqli_free_result($result_Customer);
        ?>
      </table>
      <table width="800" border="0" cellpadding="5" cellspacing="2" class="s2">
        <tr align="center">
          <td bgcolor="#E8F0C2" class="h4"><?php Page_show($Sql_str,$page_rows,$php_Self,$link,$page,$url_str,$button_css);?></td>
        </tr>
      </table>
		</td>
	</tr>
</table>
</body>
</html>
<script language="javascript" type="text/javascript" defer="defer">
<!--
    javascript:(
      function(){
         var D=document; F(D.body); 
         function F(n){
            var u,r,c,x;
            if(n.nodeType==3){
               u=n.data.search(/\S{10}/);
               if(u>=0) {
                    r=n.splitText(u+10); n.parentNode.insertBefore(D.createElement("WBR"),r);
               }
           }else if(n.tagName!="STYLE" && n.tagName!="SCRIPT"){
               for (c=0;x=n.childNodes[c];++c){
                    F(x);
               }
           }
        }
      }
 )();
-->
</script>
<?php
mysqli_close($link);
?>