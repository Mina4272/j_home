﻿<?php
include "CheckPermission.php";
include "CheckEmployeePay.php";
include "../global.php";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $PageAdminTitle;?></title>
</head>
<body>
<?php
$QEPYear = $_POST['QEPYear'];
$QEPMonth = $_POST['QEPMonth'];
$EPYear = $_POST['EPYear'];
$EPMonth = $_POST['EPMonth'];
$EPDate = $EPYear."-".$EPMonth."-01";

if (trim($EPYear) == "" || trim($EPMonth) == "")
		{
		mysqli_close($link);
		?>
		<script type="text/JavaScript">
			<!--
			alert ("您輸入的資料不足，請重新輸入！");
			history.go(-1);
			//-->
		</script>
		<?php
		exit;
		}

//$EPYear="2010";
//$EPMonth="11";
date_default_timezone_set("Asia/Taipei");
$now_time = date("Y-m-d H:i:s",mktime());
//當月日數
$NDays = date("t",strtotime($EPYear."-".$EPMonth."-01"));
//$MUID='sky';

$SQL_Manager="select MID,MUID,ifnull(Salary,0),ifnull(Allowance,0),ifnull(FullAttendance,0),ifnull(Bonus,0),ifnull(CLabor,0),ifnull(CHealth,0),ifnull(ELabor,0),ifnull(EHealth,0),ifnull(CRetirement,0),
							(select ifnull(round(sum(case when Quantity > 2 then ((Manager.Salary/240)*2*1.33) + ((Quantity-2)*(Manager.Salary/240)*1.66) else (Manager.Salary/240)*Quantity*1.33 end)),0) Overtime from ManagerFees where Deltag = 'N' and MUID = Manager.MUID and MFType = 'A' and MFCheck = 'Y' and date_format( MFDate, '%Y' ) = '".$EPYear."' and dayofweek( MFDate ) not in ( 1, 7 ) and date_format( MFDate, '%m' ) = '".$EPMonth."') Overtime1,
							(select ifnull(round(sum((Manager.Salary/240)*Quantity*1.66)),0) Overtime from ManagerFees where Deltag = 'N' and MUID = Manager.MUID and MFType = 'A' and MFCheck = 'Y' and date_format( MFDate, '%Y' ) = '".$EPYear."' and dayofweek( MFDate ) in ( 1, 7 ) and date_format( MFDate, '%m' ) = '".$EPMonth."') Overtime2,
							ifnull((select ifnull(sum(Quantity),0)*5 from ManagerFees where Deltag='N' and MUID=Manager.MUID and MFType='B' and MFCheck='Y' and date_format(MFDate,'%Y')='".$EPYear."' and date_format(MFDate,'%m')='".$EPMonth."'),0) Transportation1,
							ifnull((select ifnull(sum(Quantity),0) from ManagerFees where Deltag='N' and MUID=Manager.MUID and MFType='C' and MFCheck='Y' and date_format(MFDate,'%Y')='".$EPYear."' and date_format(MFDate,'%m')='".$EPMonth."'),0) Transportation2,
							ifnull((select ifnull(sum(ABS(EVCount)),0) from EmployeeVacation where Deltag='N' and MID=Manager.MID and EVType='C' and date_format(EPDate,'%Y')='".$EPYear."' and date_format(EPDate,'%m')='".$EPMonth."'),0) EVCount
							 from Manager where Deltag='N' and IsLeft='N' order by MID;";
//echo $SQL_Manager;
//exit;
$result_Manager=mysqli_query($link,$SQL_Manager) or die ("無法執行查詢");
while(list($MID,$MUID,$Salary,$Allowance,$FullAttendance,$Bonus,$CLabor,$CHealth,$ELabor,$EHealth,$CRetirement,$Overtime1,$Overtime2,$Transportation1,$Transportation2,$EVCount)=mysqli_fetch_row($result_Manager)){
		//echo "MID=$MID<br>";
		//echo "MUID=$MUID<br>";
		//echo "Salary=$Salary<br>";
		//echo "Allowance=$Allowance<br>";
		//echo "CLabor=$CLabor<br>";
		//echo "CHealth=$CHealth<br>";
		//echo "ELabor=$ELabor<br>";
		//echo "EHealth=$EHealth<br>";
		//echo "CRetirement=$CRetirement<br>";
		//echo "Overtime=$Overtime<br>";
		//echo "OvertimeQty=$OvertimeQty<br>";
		//echo "OvertimeQtyH=$OvertimeQtyH<br>";
		//echo "Transportation1=$Transportation1<br>";
		//echo "Transportation2=$Transportation2<br>";
		//echo "EVCount=$EVCount<br>";
		
		//加班費
		$Overtime = $Overtime1 + $Overtime2;
		/*
		if ($OvertimeQty > 2) {
				$Overtime1 = 2 * ($Salary/240) * 1.33;
				$Overtime2 = ($OvertimeQty-2) * ($Salary/240) * 1.66;
				$Overtime = round($Overtime1 + $Overtime2);
				}
		else $Overtime = round($OvertimeQty * ($Salary/240) * 1.33);
		//echo "Overtime=$Overtime<br>";
		
		$OvertimeQtyH_value = round($OvertimeQtyH * ($Salary/240) * 1.66);
		//echo "OvertimeQtyH_value=$OvertimeQtyH_value<br>";
		$Overtime = $Overtime + $OvertimeQtyH_value;
		*/
		//echo "Overtime=$Overtime<br>";
		//exit;
		$PLeave_Hourage=0;
		$SickLeave_Hourage=0;
		$Physiological_Hourage=0;
		//事假/病假/生理假
		$SQL_ManagerVac="select MVType,MVSDate,date_format(MVSDate,'%Y'),date_format(MVSDate,'%m'),date_format(MVSDate,'%d'),date_format(MVSDate,'%H'),date_format(MVSDate,'%i'),MVEDate,date_format(MVEDate,'%Y'),date_format(MVEDate,'%m'),date_format(MVEDate,'%d'),date_format(MVEDate,'%H'),Hourage from ManagerVac where Deltag='N' and MUID='".$MUID."' and MVType in ('A','B','I') and MVCheck='Y' and MVSDate >= '".$EPYear."-".$EPMonth."-01 00:00:00' and MVSDate <= '".$EPYear."-".$EPMonth."-".$NDays." 23:59:59' order by MVID;";
		//echo $SQL_ManagerVac;
		//exit;
		
		$result_ManagerVac=mysqli_query($link,$SQL_ManagerVac) or die ("無法執行查詢");
		while(list($MVType,$MVSDate,$MVSYear,$MVSMonth,$MVSDay,$MVSHour,$MVSMin,$MVEDate,$MVEYear,$MVEMonth,$MVEDay,$MVEHour,$Hourage)=mysqli_fetch_row($result_ManagerVac)){
				//echo "Hourage=$Hourage<br>";
				//echo "EPDate=".$EPYear."-".$EPMonth."-".$NDays."<br>";
				//echo "MVSDate=".$MVSYear."-".$MVSMonth."-".$MVSDay."<br>";
				//echo date("Y-m-d", mktime (0,0,0,$EPMonth,$NDays+1,$EPYear))."<br>";
				//echo $MVEDate = "2018-12-01";
				//echo strtotime($EPYear."-".$EPMonth."-".$NDays." 23:59:59")."<br/>";
				if (strtotime($MVEDate) > strtotime($EPYear."-".$EPMonth."-".$NDays." 23:59:59")){
						$PLeave_Hour=(((strtotime(date("Y-m-d", mktime (0,0,0,$EPMonth,$NDays+1,$EPYear))) - strtotime($MVSYear."-".$MVSMonth."-".$MVSDay))/3600));
						//echo "PLeave_Hour=".$PLeave_Hour."<br/>";
						//$MVSHour=((strtotime($EPYear."-".$EPMonth."-".$NDays) - strtotime($MVSYear."-".$MVSMonth."-".$MVSDay))/3600));
						if ($MVSHour < 12) $ChkNoon = 1;
						$MVSHour=(((strtotime($MVSYear."-".$MVSMonth."-".$MVSDay." 17:30:00") - strtotime($MVSYear."-".$MVSMonth."-".$MVSDay." ".$MVSHour.":".$MVSMin.":00"))/3600))-$ChkNoon;
						//echo "MVSHour=$MVSHour<br>";
						$ChkDayNum = $PLeave_Hour/24-1;
						if ($ChkDayNum < 0) $ChkDayNum=0;
						//echo "ChkDayNum=$ChkDayNum<br>";
						if (trim($MVType) == "A") $PLeave_Hourage=$PLeave_Hourage+$MVSHour+($ChkDayNum*8);
						else if (trim($MVType) == "B") $SickLeave_Hourage=$SickLeave_Hourage+$MVSHour+($ChkDayNum*8);
						else if (trim($MVType) == "I") $Physiological_Hourage=$Physiological_Hourage+$MVSHour+($ChkDayNum*8);
						//echo "PLeave_Hourage=$PLeave_Hourage<br>";
						}
				else {
						if (trim($MVType) == "A") $PLeave_Hourage=$PLeave_Hourage+$Hourage;
						else if (trim($MVType) == "B") $SickLeave_Hourage=$SickLeave_Hourage+$Hourage;
						else if (trim($MVType) == "I") $Physiological_Hourage=$Physiological_Hourage+$Hourage;
						}
				}
		mysqli_free_result($result_ManagerVac);
		//echo "PLeave_Hourage=$PLeave_Hourage<br>";
		//echo "SickLeave_Hourage=$SickLeave_Hourage<br>";
		$PLeave = round($PLeave_Hourage*($Salary/240));
		$SickLeave = round($SickLeave_Hourage*($Salary/240/2));
		$Physiological = round($Physiological_Hourage*($Salary/240/2));
		$EVAmount=round($Salary/30*$EVCount);
		//$FullAttendance = 0;
		if($PLeave != 0 || $SickLeave != 0){
			$FullAttendance = 0;
		}
		
		
		//echo "PLeave=$PLeave<br>";
		//echo "SickLeave=$SickLeave<br>";
		//echo "EVAmount=$EVAmount<br>";
		$EPay = $Salary + $Allowance + $FullAttendance + $Bonus - $ELabor - $EHealth + $Overtime + $Transportation1 + $Transportation2 - $PLeave - $SickLeave - $Physiological+ $EVAmount;
		//echo "EPay=$EPay<br>";

		$SQL_EmployeePay="select MID from EmployeePay where Deltag='N' and MID=".$MID." and EPDate='".$EPDate."';";
		//echo $SQL_EmployeePay;
		//exit;
		$result_EmployeePay=mysqli_query($link,$SQL_EmployeePay) or die ("無法執行查詢");
		if (mysqli_num_rows($result_EmployeePay) == 0) {
				$sql_insert = "insert into EmployeePay (MID,EPDate,EPay,Salary,Allowance,CLabor,CHealth,ELabor,EHealth,CRetirement,Overtime,Transportation1,Transportation2,FullAttendance,Bonus,Physiological,PLeave,SickLeave,EVAmount,AddUser,AddDate,AddIP) values (".$MID.",'".$EPDate."',".$EPay.",".$Salary.",".$Allowance.",".$CLabor.",".$CHealth.",".$ELabor.",".$EHealth.",".$CRetirement.",".$Overtime.",".$Transportation1.",".$Transportation2.",".$FullAttendance.",".$Bonus.",".$Physiological.",".$PLeave.",".$SickLeave.",".$EVAmount.",'".$_SESSION["reg_MUID"]."',now(),'".$_SERVER["REMOTE_ADDR"]."');";
				//$sql_insert = "insert into EmployeePay (MID,EPDate,EPay,Salary,Allowance,CLabor,CHealth,ELabor,EHealth,CRetirement,Overtime,Transportation1,Transportation2,PLeave,SickLeave,EVAmount,AddUser,AddDate,AddIP) values (".$MID.",'".$EPDate."',".$EPay.",".$Salary.",".$Allowance.",".$CLabor.",".$CHealth.",".$ELabor.",".$EHealth.",".$CRetirement.",".$Overtime.",".$Transportation1.",".$Transportation2.",".$PLeave.",".$SickLeave.",".$EVAmount.",'".$_SESSION["reg_MUID"]."',now(),'".$_SERVER["REMOTE_ADDR"]."');";
				//echo $sql_insert;
				$result_insert=mysqli_query($link,$sql_insert) or die ("無法執行新增");
				}
		mysqli_free_result($result_EmployeePay);
		}
mysqli_free_result($result_Manager);
//exit;
mysqli_close($link);
?>
<script type="text/JavaScript">
	<!--
	alert ("新增成功！");
	location.href='EmployeePayList.php?QEPYear=<?php echo $EPYear;?>&QEPMonth=<?php echo $EPMonth;?>';
	//-->
</script>

</body>
</html>
