﻿<?php	
include "CheckPermission.php";
include "CheckAccountingReport.php";
include "../global.php";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $PageAdminTitle;?></title>
<link href="../type.css" rel="stylesheet" type="text/css" />
<style type="text/css">
<!--
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
}
-->
</style>
</head>
<body>
<?php include "top.php";?>
<table width="100%" border="0" cellspacing="0" cellpadding="5">
	<tr>
    <td width="160" height="600" align="left" valign="top">
			<?php include "menu.php";?>
    </td>
    <td valign="top">
    	<table width="100%" border="0" cellpadding="0" cellspacing="0">
    		<tr>
    			<td>
			    	<table width="750" border="0" cellpadding="0" cellspacing="0">
			    		<tr height="30">
			    			<td class="c2"><b>帳務報表</b></td>
			    		</tr>
			    	</table>
			    	<table width="550" border="0" cellpadding="0" cellspacing="0">
			        <!--<tr height="70" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="center" class="c3"><input type="button" name="button" class="input_button" value="客戶專案帳務報表" onclick="javascript:location.href='ProjectAccountingReport.php';"></td>
			        </tr>-->
			        <tr height="70" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="center" class="c3"><input type="button" name="button" class="input_button" value="業務  績效查核表" onclick="javascript:location.href='ProjectPerformanceSales.php';"></td>
			        </tr>
			        <tr height="70" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="center" class="c3"><input type="button" name="button" class="input_button" value="工程師績效查核表" onclick="javascript:location.href='ProjectPerformance.php';"></td>
			        </tr>
			        <tr height="70" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="center" class="c3"><input type="button" name="button" class="input_button" value="客戶帳務統計報表" onclick="javascript:location.href='CustomerAccountingReport.php';"></td>
			        </tr>
			        <tr height="70" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="center" class="c3"><input type="button" name="button" class="input_button" value="應收應付報表" onclick="javascript:location.href='AccountsPayableReport.php';"></td>
			        </tr>
			        <tr height="70" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="center" class="c3"><input type="button" name="button" class="input_button" value="公司營收報表" onclick="javascript:location.href='FinancialReport.php';"></td>
			        </tr>
			        <tr height="70" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="center" class="c3"><input type="button" name="button" class="input_button" value="顧客消費記錄分析" onclick="javascript:location.href='CustomerSurvey.php';"></td>
			        </tr>
			      </table>
    			</td>
    		</tr>
    	</table>
    </td>
	</tr>
</table>
<?php include "down.php";?>
</body>
</html>
<?php
mysqli_close($link);
?>