<?php
include "CheckPermission.php";
include "../global.php";
include "include/page_function.php";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $PageAdminTitle;?></title>
<link href="../type.css" rel="stylesheet" type="text/css" />
<link href="../script/DatePicker.css" rel="stylesheet" type="text/css" />
<Script LANGUAGE="Javascript" SRC="../script/DatePicker.js"></Script>
<style type="text/css">
<!--
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
}
-->
</style>
<Script type="text/javascript" language="javascript" src="../script/CheckForm.js"></Script>
</head>
<body>
<?php include "top.php";?>
<table width="100%" border="0" cellspacing="0" cellpadding="5">
	<tr>
    <td width="160" height="600" align="left" valign="top">
			<?php include "menu.php";?>
		</td>
    <td valign="top">
    	<table width="100%" border="0" cellpadding="0" cellspacing="0">
    		<tr>
    			<td>
			    	<table width="750" border="0" cellpadding="0" cellspacing="0">
			    		<tr height="30">
			    			<td class="c2">電子發票字軌</td>
			    		</tr>
			    	</table>
			    	<table width="750" border="0" cellpadding="0" cellspacing="0">
			    		<tr>
							<td><input type="button" name="add" value="新 增" class="input_bot" onclick="javascript:location.href='TrackAdd.php';"></td>
			    		</tr>
			    		
			    	</table>
			    	<?php
						$page = empty($_GET['page'])?"":$_GET['page'];
						if (trim($page) == "") $page = 1;
						$page_rows=15;  //每頁筆數
						$php_Self = "Invoice.php";  //分頁web檔名
						$button_css = "h4";
						$limit_txt =" limit ".(($page-1) * $page_rows).",".$page_rows;
						$url_str = "";
						$Sql_str="SELECT * FROM track d where d.deltag = 'N' order by d.id desc;";
						$SQL_Track="SELECT * FROM track d where d.deltag = 'N' order by d.id desc ".$limit_txt.";";
						
						$result_Track=mysqli_query($link,$SQL_Track) or die ("無法執行查詢");
			    	?>
			    	<table width="auto" border="0" cellpadding="5" cellspacing="2" class="s2">
			        <tr align="center">
					  <td width="auto" background="../images/table_bg.gif" class="t21">項次</td>
					  <td width="auto" background="../images/table_bg.gif" class="t21">營業人統編</td>
			          <td width="auto" background="../images/table_bg.gif" class="t21">發票類別代號</td>
			          <td width="auto" background="../images/table_bg.gif" class="t21">發票類別</td>
					  <td width="auto" background="../images/table_bg.gif" class="t21">發票期別</td>
					  <td width="auto" background="../images/table_bg.gif" class="t21">發票字軌名稱</td>
					  <td width="auto" background="../images/table_bg.gif" class="t21">發票起號</td>
					  <td width="auto" background="../images/table_bg.gif" class="t21">發票迄號</td>
					  <td width="auto" background="../images/table_bg.gif" class="t21">修改</td>
			        </tr>
		          <?php
		          $tmp = 1;
		          while(list($id,$ban,$icc,$ic,$ip,$itn,$start,$end)=mysqli_fetch_row($result_Track)){
								//$SQL_Manager="SELECT MName,MEName FROM Manager Where Deltag='N' and MUID='".$PE."'";
								//$result_Manager=mysqli_query($link,$SQL_Manager) or die ("無法執行查詢");
								//list($MName,$MEName)=mysqli_fetch_row($result_Manager);
								//mysqli_free_result($result_Manager);
		        	//if (trim($ExpireDate)=="0000-00-00") $ExpireDate="";
		        	?>
		        	<tr<?php if ($tmp%2 == 0) echo " bgcolor=\"#F6F6F6\"";?>>
					  <td width="auto" class="h3" align="center"><?php echo $id;?></td>
					  <td width="auto" class="h3" align="center"><?php echo $ban;?></td>
					  <td width="auto" class="h3" align="center"><?php echo $icc;?></td>
					  <td width="auto" class="h3" align="center"><?php echo $ic;?></td>
					  <td width="auto" class="h3" align="center"><?php echo $ip;?></td>
					  <td width="auto" class="h3" align="center"><?php echo $itn;?></td>
					  <td width="auto" class="h3" align="center"><?php echo $start;?></td>
					  <td width="auto" class="h3" align="center"><?php echo $end;?></td>
					  <td align="center">
						<!--<input type="button" name="edit" value="修改" class="input_bot" onclick="javascript:location.href='DeviceEdit.php?device_no=<?php echo $device_no;?>';"><br>-->
			          	<input type="button" name="edit" value="刪除" class="input_bot" onclick="javascript:if (confirm('您是否確定要刪除？')) location.href='TrackDelDB.php?id=<?php echo $id;?>';"<?php if (trim($_SESSION["reg_MUID"]) != "amanda") echo " disabled";?>>
			          </td>
			        </tr>
			        <?php
            			$tmp++;
			      			}
            	mysqli_free_result($result_Track);
			        ?>
			    	</table>
			      <table width="880" border="0" cellpadding="5" cellspacing="2" class="s2">
			        <tr align="center">
			          <td bgcolor="#E8F0C2" class="h4"><?php Page_show($Sql_str,$page_rows,$php_Self,$link,$page,$url_str,$button_css);?></td>
			        </tr>
			      </table>
    			</td>
    		</tr>
    	</table>
    </td>
	</tr>
</table>
<?php include "down.php";?>
</body>
</html>
<?php
mysqli_close($link);
?>