﻿<?php
include "CheckPermission.php";
include "CheckProject.php";
include "../global.php";
include "include/function.php";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $PageAdminTitle;?></title>
</head>
<body>
<?php
$PID = $_POST['PID'];
$PCNo = $_POST['PCNo'];
$PCName = $_POST['PCName'];
$PCSYear = $_POST['PCSYear'];
$PCSMonth = $_POST['PCSMonth'];
$PCSDay = $_POST['PCSDay'];
if (trim($PCSYear) != "" || trim($PCSMonth) != "" || trim($PCSDay) != "") if (checkdate($PCSMonth,$PCSDay ,$PCSYear)) $PCSDate = $PCSYear."-".$PCSMonth."-".$PCSDay;
$PCEYear = $_POST['PCEYear'];
$PCEMonth = $_POST['PCEMonth'];
$PCEDay = $_POST['PCEDay'];
if (trim($PCEYear) != "" || trim($PCEMonth) != "" || trim($PCEDay) != "") if (checkdate($PCEMonth,$PCEDay ,$PCEYear)) $PCEDate = $PCEYear."-".$PCEMonth."-".$PCEDay;
$PCNote = $_POST['PCNote'];

$ExpireMonth = $_POST['ExpireMonth'];
if (trim($PCEDate) != "" && is_numeric($ExpireMonth)) {
		$ExpireDate=date ("Y/m/d", mktime (0,0,0,$PCEMonth-$ExpireMonth,$PCEDay,$PCEYear));
		}
else $ExpireDate=$PCEDate;
$PCType = $_POST['PCType'];
$PCTypeName = $_POST['PCTypeName'];

if(trim($_FILES['PCFile']['tmp_name']) != "")
		{
		if($_FILES['PCFile']['size'] > 20971520)
				{
				?>
				<script type="text/JavaScript">
					<!--
					alert ("您上傳的檔案 Size 超過 20 M，請重新上傳！");
					history.go(-1);
					//-->
				</script>
				<?php
				exit();
				}
		$PFIntro1 = empty($_POST['PFIntro1'])?"":$_POST['PFIntro1'];
		$PCFile = "PCFile_".$PID.date("ymdHis",mktime()).rand_string(5, 'ABCDEFGHIJKLMNPQRSTUVWXYZ23456789abcdefghijklmnopqrstuvwxyz').".".strtolower(substr($_FILES['PCFile']['name'],strrpos($_FILES['PCFile']['name'],".")+1,strlen($_FILES['PCFile']['name'])+1));
		@copy($_FILES['PCFile']['tmp_name'],$_SERVER["DOCUMENT_ROOT"]."\\Admin\\PCFile\\".$PCFile);
		}
if (trim($PID) == "" || trim($PCNo) == "" || trim($PCName) == "" || trim($PCFile) == "")
		{
		mysqli_close($link);
		?>
		<script type="text/JavaScript">
			<!--
			alert ("您輸入的資料不足，請重新輸入！");
			self.close();
			//-->
		</script>
		<?php
		exit;
		}

$now_time = date("Y-m-d H:i:s",mktime());
if (trim($PCSDate) == "") $PCSDate = "0000-00-00";
if (trim($PCEDate) == "") $PCEDate = "0000-00-00";
if (trim($ExpireDate) == "") $ExpireDate = "0000-00-00";
$PCEDate2=date("Y-m-d",strtotime('-6 month',strtotime($PCEDate)));
$sql_insert = "insert into ProjectCertificate (PID,PCNo,PCName,PCType,PCTypeName,PCFile,PCSDate,PCEDate,PCEDate2,PCNote,ExpireDate,AddUser,AddDate,AddIP) values ('".$PID."','".$PCNo."','".$PCName."','".$PCType."','".$PCTypeName."','".$PCFile."','".$PCSDate."','".$PCEDate."','".$PCEDate2."','".$PCNote."','".$ExpireDate."','".$_SESSION["reg_MUID"]."','".$now_time."','".$_SERVER["REMOTE_ADDR"]."');";
$result_insert=mysqli_query($link,$sql_insert) or die ("無法執行新增");

mysqli_close($link);
?>
<script type="text/JavaScript">
	<!--
	alert ("新增成功！");
	opener.location.reload();
	self.close();
	//-->
</script>

</body>
</html>
