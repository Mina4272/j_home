<?php
session_start();
set_time_limit(0);
if ($_SESSION["reg_MUID"] == "" || $_SESSION["reg_MName"] == "" || $_SESSION["reg_MPer"] == "")
	{
  	?>
  	<SCRIPT LANGUAGE="JavaScript">
  	<!--
  	location.href = "login.php";
  	-->
  	</script>	
  	<?php
  	exit;
  	}
?>