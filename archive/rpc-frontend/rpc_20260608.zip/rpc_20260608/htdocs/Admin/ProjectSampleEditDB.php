﻿<?php
include "CheckPermission.php";
include "CheckProject.php";
include "../global.php";
include "include/function.php";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $PageAdminTitle;?></title>
</head>
<body>
<?php
$PID = $_POST['PID'];
$PSID = $_POST['PSID'];
$PSType = $_POST['PSType'];
$PSYear = $_POST['PSYear'];
$PSMonth = $_POST['PSMonth'];
$PSDay = $_POST['PSDay'];
if (trim($PSYear) != "" || trim($PSMonth) != "" || trim($PSDay) != "") if (checkdate($PSMonth,$PSDay ,$PSYear)) $PSDate = $PSYear."-".$PSMonth."-".$PSDay;
$PSCount = $_POST['PSCount'];
$PSMode = $_POST['PSMode'];
$PSPersonnel = $_POST['PSPersonnel'];
$SPlace = $_POST['SPlace'];
$IPlace = $_POST['IPlace'];
$PSend = $_POST['PSend'];
$PSNote = $_POST['PSNote'];
if (trim($PID) == "" || trim($PSID) == "" || trim($PSType) == "" || trim($PSDate) == "" || trim($PSCount) == "")
		{
		mysqli_close($link);
		?>
		<script type="text/JavaScript">
			<!--
			alert ("您輸入的資料不足，請重新輸入！");
			self.close();
			//-->
		</script>
		<?php
		exit;
		}
$SQL_ProjectSample="select PSType,PSDate,date_format(PSDate,'%Y'),date_format(PSDate,'%m'),date_format(PSDate,'%d'),PSCount,PSMode,PSPersonnel,PSNote,AddUser,AddDate,ProcUser,ProcDate from ProjectSample where Deltag='N' and PID = '".$PID."' and PSID = '".$PSID."';";
$result_ProjectSample=mysqli_query($link,$SQL_ProjectSample) or die ("無法執行查詢");
if (mysqli_num_rows($result_ProjectSample) == 0)
		{
		mysqli_free_result($result_ProjectSample);
		mysqli_close($link);
		?>
		<SCRIPT language=javascript>
		<!--
		alert ("查無資料，請冾網站管理人員！"); 
		self.close();
		//-->
		</SCRIPT>
		<?php 	
		exit;
		}
mysqli_free_result($result_ProjectSample);

if(trim($_FILES['PSFile']['tmp_name']) != "")
		{
		if($_FILES['PSFile']['size'] > 20971520)
				{
				?>
				<script type="text/JavaScript">
					<!--
					alert ("您上傳的檔案 Size 超過 20 M，請重新上傳！");
					history.go(-1);
					//-->
				</script>
				<?php
				exit();
				}
		$PFIntro1 = $_POST['PFIntro1'];
		$PSFile = "PSFile_".$PID.date("ymdHis",mktime()).rand_string(5, 'ABCDEFGHIJKLMNPQRSTUVWXYZ23456789abcdefghijklmnopqrstuvwxyz').".".strtolower(substr($_FILES['PSFile']['name'],strrpos($_FILES['PSFile']['name'],".")+1,strlen($_FILES['PSFile']['name'])+1));
		@copy($_FILES['PSFile']['tmp_name'],$_SERVER["DOCUMENT_ROOT"]."\\Admin\\PSFile\\".$PSFile);
		}

$now_time = date("Y-m-d H:i:s",mktime());
if (trim($PSFile) != "") $SqlTxt = " ,PSFile = '".$PSFile."' ";
$sql_insert = "INSERT INTO ProjectSampleHistory(PSID,PID,PSType,PSDate,PSCount,PSMode,PSPersonnel,SPlace,IPlace,PSend,PSNote,PSFile,AddUser,AddDate,AddIP,Deltag,ProcUser,ProcDate,ProcIP,UpdateUser,UpdateDate,UpdateIP) SELECT PSID,PID,PSType,PSDate,PSCount,PSMode,PSPersonnel,SPlace,IPlace,PSend,PSNote,PSFile,AddUser,AddDate,AddIP,Deltag,ProcUser,ProcDate,ProcIP,'".$_SESSION["reg_MUID"]."','".$now_time."','".$_SERVER["REMOTE_ADDR"]."' FROM ProjectSample where Deltag='N' and PID = '".$PID."' and PSID = '".$PSID."';";
$result_insert=mysqli_query($link,$sql_insert) or die ("無法執行新增");
$sql_update = "update ProjectSample set PSType = '".$PSType."',PSDate = '".$PSDate."',PSCount = '".$PSCount."',PSMode = '".$PSMode."',PSPersonnel = '".$PSPersonnel."',SPlace = '".$SPlace."',IPlace = '".$IPlace."',PSend = '".$PSend."',PSNote = '".$PSNote."' ".$SqlTxt." ,ProcUser = '".$_SESSION["reg_MUID"]."',ProcDate = '".$now_time."',ProcIP = '".$_SERVER["REMOTE_ADDR"]."' where Deltag='N' and PID = '".$PID."' and PSID = '".$PSID."';";
$result_update=mysqli_query($link,$sql_update) or die ("無法執行修改");

mysqli_close($link);
?>
<script type="text/JavaScript">
	<!--
	alert ("修改成功！");
	opener.location.reload();
	self.close();
	//-->
</script>

</body>
</html>
