﻿<?php
include "CheckPermission.php";
include "CheckAgendum.php";
include "../global.php";
include "include/function.php";
require_once("../include/chinese_party.class.php");
require("class.phpmailer.php");
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $PageAdminTitle;?></title>
</head>
<body>
<?php
if(isset($_POST['code'])) {

	if($_POST['code'] == $_SESSION['code']){
	
	$_SESSION['code']+=1;
	
	//$ASID = $_POST['ASID'];
$ARID = $_POST['ARID'];
$ACID = $_POST['ACID'];
$AYear = $_POST['AYear'];
$AMonth = $_POST['AMonth'];
$ADay = $_POST['ADay'];
if (trim($AYear) != "" || trim($AMonth) != "" || trim($ADay) != "") if (checkdate($AMonth,$ADay ,$AYear)) $ADate = $AYear."-".$AMonth."-".$ADay;
$AEYear = $_POST['AEYear'];
$AEMonth = $_POST['AEMonth'];
$AEDay = $_POST['AEDay'];
if (trim($AEYear) != "" || trim($AEMonth) != "" || trim($AEDay) != "") if (checkdate($AEMonth,$AEDay ,$AEYear)) $AEDate = $AEYear."-".$AEMonth."-".$AEDay;
$ACYear = $_POST['ACYear'];
$ACMonth = $_POST['ACMonth'];
$ACDay = $_POST['ACDay'];
if (trim($ACYear) != "" || trim($ACMonth) != "" || trim($ACDay) != "") if (checkdate($ACMonth,$ACDay ,$ACYear)) $ACDate = $ACYear."-".$ACMonth."-".$ACDay;
$AItem = $_POST['AItem'];
$Attribute = $_POST['Attribute'];
$PID = $_POST['PID'];
if (trim($PID) == "") $PID = 0;
$CID = $_POST['CID'];
if (trim($CID) == "") $CID = 0;
$CName = $_POST['CName'];
$CTel = $_POST['CTel'];
$CFax = $_POST['CFax'];
$CAddress = $_POST['CAddress'];
$Contact = $_POST['Contact'];
$CMobile = $_POST['CMobile'];
$CEMail = $_POST['CEMail'];
$ANote = $_POST['ANote'];
$CheckProc = $_POST['CheckProc'];

if(trim($_FILES['AFile']['tmp_name']) != "")
		{
		if($_FILES['AFile']['size'] > 20971520)
				{
				?>
				<script type="text/JavaScript">
					<!--
					alert ("您上傳的檔案 Size 超過 20 M，請重新上傳！");
					history.go(-1);
					//-->
				</script>
				<?php
				exit();
				}
		$AFile = "AFile_".date("ymdHis",mktime()).rand_string(5, 'ABCDEFGHIJKLMNPQRSTUVWXYZ23456789abcdefghijklmnopqrstuvwxyz').".".strtolower(substr($_FILES['AFile']['name'],strrpos($_FILES['AFile']['name'],".")+1,strlen($_FILES['AFile']['name'])+1));
		@copy($_FILES['AFile']['tmp_name'],$_SERVER["DOCUMENT_ROOT"]."\\Admin\\AFile\\".$AFile);
		}

if (trim($ARID) == "" || trim($ACID) == "" || trim($ADate) == "" || trim($AItem) == "")
		{
		mysqli_close($link);
		?>
		<script type="text/JavaScript">
			<!--
			alert ("您輸入的資料不足，請重新輸入！");
			history.go(-1);
			//-->
		</script>
		<?php
		exit;
		}

$ACDate = date("ymd");
//echo "ACDate=$ACDate<br>";
$now_time = date("Y-m-d H:i:s",mktime());
$SQL_select="select ACount from AgendumCount where ACDate = '".$ACDate."';";
$result_select=mysqli_query($link,$SQL_select) or die ("無法執行查詢");
if (mysqli_num_rows($result_select) == 0)
		{
		$sql_insert = "insert into AgendumCount (ACDate,ACount) values ('".$ACDate."','2');";
		$result_insert=mysqli_query($link,$sql_insert) or die ("無法執行新增");
		$ACount = "1";
		}
else
		{
		$sql_update = "update AgendumCount set ACount = ACount + 1 where ACDate = '".$ACDate."';";
		$result_update=mysqli_query($link,$sql_update) or die ("無法執行新增");
		list($ACount)=mysqli_fetch_row($result_select);
		}
mysqli_free_result($result_select);
		
//echo "ACount=$ACount<br>";
if (strlen($ACount) < 2)
	{
	for ($i=1;$i=2-strlen($ACount);$i++)
		{
		$ACount = "0" . $ACount;
		}
	}
$AUID = "R".$ACDate.$ACount;

if (trim($ACDate)=="") $ACDate = "NULL";
else $ACDate = "'$ACDate'";

$now_time = date("Y-m-d H:i:s",mktime());
$sql_insert = "insert into Agendum (AUID,ASID,ARID,ACID,CheckProc,ADate,AEDate,ACDate,AItem,Attribute,PID,CID,CName,CTel,CFax,CAddress,Contact,CMobile,CEMail,AFile,ANote,AddUser,AddDate,AddIP) values ('".$AUID."','".$_SESSION["reg_MUID"]."','".$ARID."','".$ACID."','".$CheckProc."','".$ADate."','".$AEDate."',".$ACDate.",'".$AItem."','".$Attribute."','".$PID."','".$CID."','".$CName."','".$CTel."','".$CFax."','".$CAddress."','".$Contact."','".$CMobile."','".$CEMail."','".$AFile."','".$ANote."','".$_SESSION["reg_MUID"]."','".$now_time."','".$_SERVER["REMOTE_ADDR"]."');";
//echo $sql_insert;
$result_insert=mysqli_query($link,$sql_insert) or die ("無法執行新增");

if (trim($CheckProc) == "Y") {
		$SQL_Manager="select MName from Manager where Deltag='N' and MUID='".$_SESSION["reg_MUID"]."';";
		$result_Manager=mysqli_query($link,$SQL_Manager) or die ("無法執行查詢");
		list($ASName)=mysqli_fetch_row($result_Manager);
		mysqli_free_result($result_Manager);
		
		$SQL_Manager="select MName,EMail from Manager where Deltag='N' and MUID='".$ARID."';";
		$result_Manager=mysqli_query($link,$SQL_Manager) or die ("無法執行查詢");
		list($ARName,$AREMail)=mysqli_fetch_row($result_Manager);
		mysqli_free_result($result_Manager);

		$SQL_Manager="select MName,EMail from Manager where Deltag='N' and MUID='".$ACID."';";
		$result_Manager=mysqli_query($link,$SQL_Manager) or die ("無法執行查詢");
		list($ACName,$ACEMail)=mysqli_fetch_row($result_Manager);
		mysqli_free_result($result_Manager);
		
		$EMAILFN = "Agendum.htm";
		$subject="全威驗證事項派案通知 ！！";
		$fp=fopen($EMAILFN,"r");
		$content="";
		while($line=fgets($fp,512)){
			$content.=$line;
			}
		fclose($fp);
		
		$content = str_replace("{AUID}",$AUID,$content);
		$content = str_replace("{ASID}",$ASName,$content);
		$content = str_replace("{ARID}",$ARName,$content);
		$content = str_replace("{ACID}",$ACName,$content);
		$content = str_replace("{ADate}",$ADate,$content);
		$content = str_replace("{AEDate}",$AEDate,$content);
		$content = str_replace("{AItem}",$AItem,$content);
		
		//$cconv = new chinese_party();
		//$content = $cconv->u82tchi($content);
		//$subject = $cconv->u82tchi($subject);
		
		$EMailList=array($AREMail,$ACEMail);
		for ($tmp=0;$tmp<=count($EMailList)-1;$tmp++){
				$mail = new PHPMailer();
				$mail->IsSMTP();
				$mail->SMTPAuth = true; //設定SMTP需要驗證
				$mail->SMTPSecure = "ssl"; // Gmail的SMTP主機需要使用SSL連線
				$mail->Host = "smtp.gmail.com"; //Gamil的SMTP主機
				$mail->Port = 465; //Gamil的SMTP主機的埠號(Gmail為465)。
				$mail->CharSet = "utf-8"; //郵件編碼
				$mail->Username = "Benson@rpclab.com"; //Gamil帳號
				$mail->Password = "76197619"; //Gmail密碼
				$mail->From     = "Benson@rpclab.com";
				$mail->FromName = $subject;
				$mail->WordWrap = 50;
				$mail->IsHTML(true);                               // send as HTML
				//$mail->CharSet = "big5";
				$mail->Subject  = $subject;
				$mail->Body     =  $content;
				$mail->AddAddress($EMailList[$tmp],"");
				$mail->AddReplyTo("Benson@rpclab.com");
				if(!$mail->Send())
						{
				    //echo "There has been a mail error sending to " . $SendEMail . "<br>";
				    //echo "Mailer Error: " . $mail->ErrorInfo . "<br>";
				  	}
				else
						{
						//echo $SendEMail . " sending !!<br>";
						}
						
				$mail->ClearAddresses();
				$mail->ClearReplyTos();
				$mail->SmtpClose();
				}
		}

		mysqli_close($link);
	
	
	
	}
}
?>
<script type="text/JavaScript">
	<!--
	alert ("新增成功！");
	location.href='AgendumList.php';
	//-->
</script>

</body>
</html>
