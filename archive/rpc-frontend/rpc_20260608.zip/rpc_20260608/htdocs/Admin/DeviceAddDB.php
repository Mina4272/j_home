﻿<?php
include "CheckPermission.php";
include "CheckAgendum.php";
include "../global.php";
include "include/function.php";
require_once("../include/chinese_party.class.php");
require("class.phpmailer.php");
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $PageAdminTitle;?></title>
</head>
<body>
<?php
if(isset($_POST['code'])) {

	if($_POST['code'] == $_SESSION['code']){
	
	$_SESSION['code']+=1;
	
	//$ASID = $_POST['ASID'];
$device_people = $_POST['device_people'];
$device_name_chinese = $_POST['device_name_chinese'];
$device_name_english = $_POST['device_name_english'];
$device_label = $_POST['device_label'];
$device_model = $_POST['device_model'];
$device_serial = $_POST['device_serial'];
$device_specification = $_POST['device_specification'];
$DYear = $_POST['DYear'];
$DMonth = $_POST['DMonth'];
$DDay = $_POST['DDay'];
if (trim($DYear) != "" || trim($DMonth) != "" || trim($DDay) != "") if (checkdate($DMonth,$DDay ,$DYear)) $device_date = $DYear."-".$DMonth."-".$DDay;
$device_money = $_POST['device_money'];
$supplier = $_POST['CName'];

if (trim($device_people) == "" || trim($device_name_chinese) == "" || trim($device_name_english) == "" || trim($device_label) == "" || trim($device_model) == "" || trim($device_serial) == "" || trim($device_specification) == "" || trim($device_date) == "" || trim($device_money) == "" || trim($supplier) == "")
		{
		mysqli_close($link);
		
		?>
		<script type="text/JavaScript">
			<!--
			alert ("您輸入的資料不足，請重新輸入！");
			history.go(-1);
			//-->
		</script>
		<?php
		exit;
		}


	$sql_insert = "insert into device (device_people,device_name_chinese,device_name_english,device_label,device_model,device_serial,device_specification,device_date,device_money,supplier) values ('".$device_people."','".$device_name_chinese."','".$device_name_english."','".$device_label."','".$device_model."','".$device_serial."','".$device_specification."','".$device_date."','".$device_money."','".$supplier."');";
	$result_insert=mysqli_query($link,$sql_insert) or die ("無法執行新增");
	mysqli_close($link);
	}	
}
?>
<script type="text/JavaScript">
	
	alert("新增成功！");
	location.href='Device.php';
	
</script>

</body>
</html>
