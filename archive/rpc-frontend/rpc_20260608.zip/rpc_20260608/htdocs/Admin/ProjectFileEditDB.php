﻿<?php
include "CheckPermission.php";
include "CheckProject.php";
include "../global.php";
include "include/function.php";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $PageAdminTitle;?></title>
<link href="../type.css" rel="stylesheet" type="text/css" />
</head>

<body>
<?php
$PID = $_POST['PID'];
$PFCID = $_POST['PFCID'];
$PFID = $_POST['PFID'];
$spage = $_POST['spage'];
$page = $_POST['page'];
$KeyWord = $_POST['KeyWord'];
$QPStatus = $_POST['QPStatus'];
$QPE = $_POST['QPE'];
if (trim($PID) == "" || trim($PFCID) == "" || trim($PFID) == "")
		{
		mysqli_close($link);
		?>
		<script type="text/JavaScript">
			<!--
			alert ("查無資料，請冾網站管理人員！");
			history.go(-1);
			//-->
		</script>
		<?php
		exit;
		}

$SQL_Project="select PUID,PName from Project where Deltag='N' and PID = '".$PID."';";
$result_Project=mysqli_query($link,$SQL_Project) or die ("無法執行查詢");
if (mysqli_num_rows($result_Project) == 0)
		{
		mysqli_free_result($result_Project);
		mysqli_close($link);
		?>
		<SCRIPT language=javascript>
		<!--
		alert ("查無資料，請冾網站管理人員！"); 
		history.go(-1);
		//-->
		</SCRIPT>
		<?php 	
		exit;
		}
mysqli_free_result($result_Project);

$SQL_ProjectFileClass="select PFCName from ProjectFileClass where Deltag='N' and PFCID = '".$PFCID."';";
$result_ProjectFileClass=mysqli_query($link,$SQL_ProjectFileClass) or die ("無法執行查詢");
if (mysqli_num_rows($result_ProjectFileClass) == 0)
		{
		mysqli_free_result($result_ProjectFileClass);
		mysqli_close($link);
		?>
		<SCRIPT language=javascript>
		<!--
		alert ("查無資料，請冾網站管理人員！"); 
		history.go(-1);
		//-->
		</SCRIPT>
		<?php 	
		exit;
		}
mysqli_free_result($result_ProjectFileClass);

$SQL_ProjectFile="select PFName,PFileName,PFIntro,AddUser,AddDate,ProcUser,ProcDate from ProjectFile where Deltag='N' and PID = '".$PID."' and PFCID = '".$PFCID."' and PFID = '".$PFID."';";
$result_ProjectFile=mysqli_query($link,$SQL_ProjectFile) or die ("無法執行查詢");
if (mysqli_num_rows($result_ProjectFile) == 0)
		{
		mysqli_free_result($result_ProjectFile);
		mysqli_close($link);
		?>
		<SCRIPT language=javascript>
		<!--
		alert ("查無資料，請冾網站管理人員！"); 
		history.go(-1);
		//-->
		</SCRIPT>
		<?php 	
		exit;
		}
mysqli_free_result($result_ProjectFile);

$now_time = date("Y-m-d H:i:s",mktime());
if(trim($_FILES['PFileName']['tmp_name']) != "")
		{
		if($_FILES['PFileName']['size'] > 20971520)
				{
				?>
				<script type="text/JavaScript">
					<!--
					alert ("您上傳的檔案 Size 超過 20 M，請重新上傳！");
					history.go(-1);
					//-->
				</script>
				<?php
				exit();
				}
		$PFName = $HTTP_POST_FILES['PFileName']['name'];
		$PFileName = "PFile_".$PID.$PFCID.$PFID.date("ymdHis",mktime()).rand_string(5, 'ABCDEFGHIJKLMNPQRSTUVWXYZ23456789abcdefghijklmnopqrstuvwxyz').".".strtolower(substr($_FILES['PFileName']['name'],strrpos($_FILES['PFileName']['name'],".")+1,strlen($_FILES['PFileName']['name'])+1));
		@copy($HTTP_POST_FILES['PFileName']['tmp_name'],$_SERVER["DOCUMENT_ROOT"]."\\Admin\\PFile\\".$PFileName);
		}
		
$PFIntro = $_POST['PFIntro'];
if (trim($PFileName) != "" || trim($PFIntro) != "") {
		if (trim($PFileName) != "") $SqlTxt = ",PFName='".$PFName."',PFileName='".$PFileName."'";
		$sql_insert = "INSERT INTO ProjectFileHistory(PFID,PID,PFCID,PFName,PFileName,PFIntro,AddUser,AddDate,AddIP,Deltag,ProcUser,ProcDate,ProcIP,UpdateUser,UpdateDate,UpdateIP) SELECT PFID,PID,PFCID,PFName,PFileName,PFIntro,AddUser,AddDate,AddIP,Deltag,ProcUser,ProcDate,ProcIP,'".$_SESSION["reg_MUID"]."','".$now_time."','".$_SERVER["REMOTE_ADDR"]."' FROM ProjectFile where Deltag='N' and PID = '".$PID."' and PFCID = '".$PFCID."' and PFID = '".$PFID."';";
		$result_insert=mysqli_query($link,$sql_insert) or die ("無法執行新增");
		$sql_update = "update ProjectFile set PFIntro = '".$PFIntro."' ".$SqlTxt." ,ProcUser = '".$_SESSION["reg_MUID"]."',ProcDate = '".$now_time."',ProcIP = '".$_SERVER["REMOTE_ADDR"]."' where Deltag='N' and PID = '".$PID."' and PFCID = '".$PFCID."' and PFID = '".$PFID."';";
		$result_update=mysqli_query($link,$sql_update) or die ("無法執行修改");
		}
mysqli_close($link);
?>
<script type="text/JavaScript">
	<!--
	alert ("檔案修改成功！");
	location.href='ProjectFileList.php?PID=<?php echo $PID;?>&PFCID=<?php echo $PFCID;?>&spage=<?php echo $spage;?>&page=<?php echo $page;?>&QPStatus=<?php echo $QPStatus;?>&QPE=<?php echo $QPE;?>&KeyWord=<?php echo urlencode($KeyWord);?>';
	//-->
</script>

</body>
</html>
