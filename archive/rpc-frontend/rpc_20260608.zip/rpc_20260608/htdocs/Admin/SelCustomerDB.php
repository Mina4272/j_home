﻿<?php
include "CheckPermission.php";
include "../global.php";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $PageAdminTitle;?></title>
</head>

<body>
<?php
$CID = $_POST['CID'];
$CCID = $_POST['CCID'];

$SQL_Customer="select CName,CTel,CFax,CAddress from Customer where Deltag='N' and CID='".$CID."';";
$result_Customer=mysqli_query($link,$SQL_Customer) or die ("無法執行查詢");
list($CName,$CTel,$CFax,$CAddress)=mysqli_fetch_row($result_Customer);
mysqli_free_result($result_Customer);

$SQL_CustomerContact="select Contact,CMobile,CEMail from CustomerContact where Deltag='N' and CID='".$CID."' and CCID='".$CCID."';";
$result_CustomerContact=mysqli_query($link,$SQL_CustomerContact) or die ("無法執行查詢");
list($Contact,$CMobile,$CEMail)=mysqli_fetch_row($result_CustomerContact);
mysqli_free_result($result_CustomerContact);
?>
<script type="text/JavaScript">
		<!--
		opener.document.form1.CName.value='<?php echo $CName;?>';
		opener.document.form1.CID.value='<?php echo $CID;?>';
		opener.document.form1.CTel.value='<?php echo $CTel;?>';
		opener.document.form1.CFax.value='<?php echo $CFax;?>';
		opener.document.form1.CAddress.value='<?php echo $CAddress;?>';
		opener.document.form1.Contact.value='<?php echo $Contact;?>';
		opener.document.form1.CMobile.value='<?php echo $CMobile;?>';
		opener.document.form1.CEMail.value='<?php echo $CEMail;?>';
		opener.document.getElementById('CNamePreview').style.display = '';
		opener.document.getElementById('CNamePreview').innerHTML = '<?php echo $CName;?>';
		opener.document.getElementById('CTelPreview').style.display = '';
		opener.document.getElementById('CTelPreview').innerHTML = '<?php echo $CTel;?>';
		opener.document.getElementById('CFaxPreview').style.display = '';
		opener.document.getElementById('CFaxPreview').innerHTML = '<?php echo $CFax;?>';
		opener.document.getElementById('CAddressPreview').style.display = '';
		opener.document.getElementById('CAddressPreview').innerHTML = '<?php echo $CAddress;?>';
		self.close();
		//-->
</script>
</body>
</html>
<?php
mysqli_close($link);
?>