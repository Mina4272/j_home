<?php
include "CheckPermission.php";
include "../global.php";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $PageAdminTitle;?></title>
<link href="../type.css" rel="stylesheet" type="text/css" />

</head>

<body>
<table width="520" border="0" align="center" cellpadding="2" cellspacing="0">
  <tr>
    <td align="center"><span class="c2"><b>證書過期清單</b></span>
    </td>
  </tr>
  <tr>
    <td align="left">
			<?php
			//$SQL_Manager="SELECT a.MJID, a.MJPeriod, a.MJTitle, a.MJDescription, a.MJDeputyID, a.MJNote, b.MName as MJDeputy from managerjob a inner join manager b on a.MJDeputyID = b.MID left join managerjobchange c on a.MJID = c.MJID where a.MID='".$_SESSION["reg_MID"]."' and a.Deltag='N' and c.ReceiveStatus='N' order by a.MJID";
			$SQL_Over="select b.PCID,a.PID,b.PCNo,b.PCName,b.PCType,b.PCTypeName,b.PCFile,b.PCSDate,b.PCEDate,b.PCNote,a.PName,a.PE,a.CName,a.PName,a.ModelName,a.SeriesModel,b.ExpireDate,b.ISRemind,b.RemindNote,b.Reminder,b.RemindDate,b.RemindIP,b.ISNotice,b.NoticeNote,b.Notifier,b.NoticeDate,b.NoticeIP from Project a,ProjectCertificate b where a.PID=b.PID and a.Deltag='N' and b.Deltag='N' and b.PCEDate != '' and b.PCEDate >='".date('Y-m-d')."' and b.PCEDate2 != '' and b.PCEDate2 <= '".date('Y-m-d')."' order by b.PCID desc";
			//echo $SQL_Over;
			$result_Over=mysqli_query($link,$SQL_Over) or die ("無法執行查詢");
			?>
    	<table width="100%" border="0" cellpadding="2" cellspacing="2" class="s2">
        <tr align="center">
          <td width="150" align="center" background="../images/table_bg.gif" class="t21">編號<br>種類<br>名稱</td>
		  <td width="150" background="../images/table_bg.gif" class="t21">客戶名稱<br>型號</td>
		  <td width="150" background="../images/table_bg.gif" class="t21">相關案件<br>案件工程師</td>
		  <td width="100" background="../images/table_bg.gif" class="t21">有效日期</td>
        </tr>
        <?php
		$tmp = 1;
         while(list($PCID,$PID,$PCNo,$PCName,$PCType,$PCTypeName,$PCFile,$PCSDate,$PCEDate,$PCNote,$PName,$PE,$CName,$PName,$ModelName,$SeriesModel,$ExpireDate,$ISRemind,$RemindNote,$Reminder,$RemindDate,$RemindIP,$ISNotice,$NoticeNote,$Notifier,$NoticeDate,$NoticeIP)=mysqli_fetch_row($result_Over)){
					$SQL_Manager="SELECT MName,MEName FROM Manager Where Deltag='N' and MUID='".$PE."'";
					$result_Manager=mysqli_query($link,$SQL_Manager) or die ("無法執行查詢");
					list($MName,$MEName)=mysqli_fetch_row($result_Manager);
					mysqli_free_result($result_Manager);
		if (trim($ExpireDate)=="0000-00-00") $ExpireDate="";
      	?>
	    <tr<?php if ($tmp%2 == 0) echo " bgcolor=\"#F6F6F6\"";?>>
			          <td width="150" class="h3" align="center">
									<?php
									echo $PCNo."<br>";
			          	if (trim($PCType) == "A") echo "環保標章";
			          	else if (trim($PCType) == "B") echo "BSMI證書";
			          	else if (trim($PCType) == "C") echo "消防證書";
			          	else if (trim($PCType) == "D") echo $PCTypeName;
									?><br>
			          	<a href="getfile.php?FolderName=Admin\\PCFile&FileName=<?php echo $PCFile;?>"><?php echo $PCName;?></a>
			          </td>
			          <td width="150" class="h3">
			          	<?php
			          	echo $CName."<br>".$ModelName;
			          	?>
			          </td>
			          <td width="150" class="h3"><?php echo $PName;?><br><?php echo $MEName.$MName;?></td>
			          <?php if (trim($PCEDate) == "0000-00-00") echo $PCEDate="";?>
			          <td width="100" class="h3" align="center"><?php echo $PCSDate;?><br> ~ <br><?php echo $PCEDate;?></td>
        </tr>
        <?php
      			$tmp++;
      			}
      	mysqli_free_result($result_Over);
        ?>
      </table>
    </td>
  </tr>
</table>
</body>
</html>
<?php
mysqli_close($link);
?>