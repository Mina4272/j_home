﻿<?php
include "CheckPermission.php";
include "CheckAccountingReport.php";
include "../global.php";

$KeyWord = $_POST['KeyWord'];
$QPStatus = $_POST['QPStatus'];
$QAcR = $_POST['QAcR'];

$KeyWord = $_POST['KeyWord'];
if (trim($KeyWord) == "") $KeyWord = $_GET['KeyWord'];
$QPStatus = $_POST['QPStatus'];
if (trim($QPStatus) == "") $QPStatus = $_GET['QPStatus'];
if (trim($KeyWord) != "") {
		$SQL_ProjectCertificate="select PID from ProjectCertificate where Deltag='N' and PCNo like '%".$KeyWord."%' group by PID order by PID;";
		$result_ProjectCertificate=mysqli_query($link,$SQL_ProjectCertificate) or die ("無法執行查詢");
		$SqlPID = "";
		while(list($PC_PID)=mysqli_fetch_row($result_ProjectCertificate)){
				if (trim($SqlPID) == "") $SqlPID = $PC_PID;
				else $SqlPID = $SqlPID.",".$PC_PID;
				}
		mysqli_free_result($result_ProjectCertificate);

		$SQL_ProjectAccounting="select PID from ProjectAccounting where Deltag='N' and (PAItem like '%".$KeyWord."%' or Invoice like '%".$KeyWord."%' or PANote like '%".$KeyWord."%') group by PID order by PID;";
		$result_ProjectAccounting=mysqli_query($link,$SQL_ProjectAccounting) or die ("無法執行查詢");
		$SqlPID = "";
		while(list($PA_PID)=mysqli_fetch_row($result_ProjectAccounting)){
				if (trim($SqlPID) == "") $SqlPID = $PA_PID;
				else $SqlPID = $SqlPID.",".$PA_PID;
				}
		mysqli_free_result($result_ProjectAccounting);
		}
if (trim($SqlPID) != "") $SqlPID = " PID in (".$SqlPID.")";
if (trim($KeyWord) != "") {
		if (trim($SqlPID) == "") $SqlTxt = $SqlTxt." and (PUID like '%".$KeyWord."%' or CName like '%".$KeyWord."%' or CTel like '%".$KeyWord."%' or CFax like '%".$KeyWord."%' or Contact like '%".$KeyWord."%' or CMobile like '%".$KeyWord."%' or CEMail like '%".$KeyWord."%' or CAddress like '%".$KeyWord."%' or PName like '%".$KeyWord."%' or ModelName like '%".$KeyWord."%' or SeriesModel like '%".$KeyWord."%' or PE like '%".$KeyWord."%' or PNote like '%".$KeyWord."%')";
		else $SqlTxt = $SqlTxt." and (PUID like '%".$KeyWord."%' or CName like '%".$KeyWord."%' or CTel like '%".$KeyWord."%' or CFax like '%".$KeyWord."%' or Contact like '%".$KeyWord."%' or CMobile like '%".$KeyWord."%' or CEMail like '%".$KeyWord."%' or CAddress like '%".$KeyWord."%' or PName like '%".$KeyWord."%' or ModelName like '%".$KeyWord."%' or SeriesModel like '%".$KeyWord."%' or PE like '%".$KeyWord."%' or PNote like '%".$KeyWord."%' or ApplyItem like '%".$KeyWord."%' or ".$SqlPID.")";
		}

if (trim($QAcR) != "") {
		$SQL_QAcR="SELECT DISTINCT a.PID FROM Project a, ProjectAccounting b WHERE a.PID = b.PID AND a.Deltag = 'N' AND b.Deltag = 'N' AND a.InvoiceDate is not null AND b.PAStatus = 'W' ORDER BY a.PID";
		$result_QAcR=mysqli_query($link,$SQL_QAcR) or die ("無法執行查詢");
		$Sql_PID = "";
		while(list($PQ_PID)=mysqli_fetch_row($result_QAcR)){
				if (trim($Sql_PID) == "") $Sql_PID = $PQ_PID;
				else $Sql_PID = $Sql_PID.",".$PQ_PID;
				}
		mysqli_free_result($result_QAcR);
		}
if (trim($Sql_PID) != "") $SqlTxt = $SqlTxt . " and PID in (".$Sql_PID.")";
//if (trim($KeyWord) != "") $SqlTxt = " and (PUID like '%".$KeyWord."%' or CName like '%".$KeyWord."%' or CTel like '%".$KeyWord."%' or CFax like '%".$KeyWord."%' or Contact like '%".$KeyWord."%' or CMobile like '%".$KeyWord."%' or CEMail like '%".$KeyWord."%' or CAddress like '%".$KeyWord."%' or PName like '%".$KeyWord."%' or ModelName like '%".$KeyWord."%' or SeriesModel like '%".$KeyWord."%' or PE like '%".$KeyWord."%')";
if (trim($QPStatus) != "") $SqlTxt = $SqlTxt." and PStatus='".$QPStatus."' ";

$SQL_Project="select PID,PUID,CID,CName,CTel,CFax,Contact,CMobile,CEMail,CAddress,PStatus,PName,ModelName,SeriesModel,PE,Quote,ApplyItem,Canon,SNote,PlanDate,CloseDate,PNote,QuoteDate,ReturnDate,IFlorin,OFlorin,InvoiceDate,InvoiceCUID,(select CUID from Customer where Deltag='N' and CID = Project.CID) as CUID from Project where Deltag='N' ".$SqlTxt." order by PID desc;";
$result_Project=mysqli_query($link,$SQL_Project) or die ("無法執行查詢");
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $PageAdminTitle;?></title>
<link href="style.css" rel="stylesheet" type="text/css" />
<body>
<table winth="1000" border="0">
	<tr>
		<td colspan="2"><font color=blue>若您無法正常觀看此報表！請下載此 <a href="owc11.zip" target="_File"><font color=red><b>元件</b></font></a> <font color=blue>安裝至您的電腦。</font></td>
	</tr>
</table>
<object id=ProjectAccounting classid=CLSID:0002E559-0000-0000-C000-000000000046 style="width:100%;height:90%"></object>
<script language=vbscript>
	Sub Window_OnLoad()
	Set chConstants = ProjectAccounting.Constants
	ProjectAccounting.ActiveSheet.Cells.Clear
	ProjectAccounting.Worksheets(1).Select
	ProjectAccounting.ActiveSheet.Name ="ProjectAccounting"
<?php  
$ECount=1;
$TolCharges=0;             
$TolInputCharges=0;             
$TolOutputCharges=0;             
while(list($PID,$PUID,$CID,$CName,$CTel,$CFax,$Contact,$CMobile,$CEMail,$CAddress,$PStatus,$PName,$ModelName,$SeriesModel,$PE,$Quote,$ApplyItem,$Canon,$SNote,$PlanDate,$CloseDate,$PNote,$QuoteDate,$ReturnDate,$IFlorin,$OFlorin,$InvoiceDate,$InvoiceCUID,$CUID)=mysqli_fetch_row($result_Project)){
  	if (trim($ModelName) == "") $ModelName = "NA";
  	if (trim($PStatus) == "A") $PStatus="新開案";
  	else if (trim($PStatus) == "B") $PStatus="報價中";
  	else if (trim($PStatus) == "C") $PStatus="案件處理中";
  	else if (trim($PStatus) == "D") $PStatus="審查中";
  	else if (trim($PStatus) == "E") $PStatus="補件中";
  	else if (trim($PStatus) == "F") $PStatus="待印證";
  	else if (trim($PStatus) == "G") $PStatus="案件取消";
  	else if (trim($PStatus) == "H") $PStatus="已結案";
		?>
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,1).Value ="<?php echo $PUID;?>"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,2).Value ="<?php echo $PName;?> - <?php echo $ApplyItem;?>"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,3).Value ="<?php echo $CName;?>"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,4).Value ="<?php echo $PStatus;?>"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,5).Value ="<?php if (trim($InvoiceCUID) != "") echo $InvoiceCUID; else echo $CUID;?>"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,6).Value ="'<?php echo $InvoiceDate;?>"
		<?php
		if (trim($TitleLine) == "") $TitleLine = $ECount;
		else $TitleLine = $TitleLine.",".$ECount;
		$ECount++;
		?>
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,1).Value ="收入/支出"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,2).Value ="項目"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,3).Value ="費用"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,4).Value ="匯率"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,5).Value ="外幣別"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,6).Value ="外幣費用"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,7).Value ="狀態"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,8).Value ="預計結清日期"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,9).Value ="收款日/付款日"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,10).Value ="發票日期"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,11).Value ="發票號碼"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,12).Value ="供應商"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,13).Value ="備註"
		<?php
		$ECount++;
		$SQL_ProjectAccounting="select PAID,PAMode,PAItem,Charges,Rate,ChargesOther,PAStatus,PAPDate,PADate,InvoiceDate,Invoice,PANote,CName from ProjectAccounting where Deltag='N' and PID = '".$PID."' and (PAStatus = 'W' or PAStatus = 'S') order by PAMode asc,PAID asc;";
		$result_ProjectAccounting=mysqli_query($link,$SQL_ProjectAccounting) or die ("無法執行查詢");
		$SumCharges=0;             
		$SumInput=0;             
		$SumOutput=0;             
    while(list($PAID,$PAMode,$PAItem,$Charges,$Rate,$ChargesOther,$PAStatus,$PAPDate,$PADate,$IDate,$Invoice,$PANote,$PCName)=mysqli_fetch_row($result_ProjectAccounting)){
      	if (trim($PAStatus) == "W") {
      			if (trim($PAMode) == "I") $PAStatus="待收"; else if (trim($PAMode) == "O") $PAStatus="未付";
      			}
      	else if (trim($PAStatus) == "S") $PAStatus="結清";
      	else if (trim($PAStatus) == "C") $PAStatus="取消";
      	$FlorinTxt="";
      	if (trim($PAMode) == "I") $FlorinTxt=$IFlorin;
      	else if (trim($PAMode) == "O") $FlorinTxt=$OFlorin;
      	
      	if (trim($PAMode) == "I") {
      			$SumInput=$SumInput+$Charges;
      			$SumCharges=$SumCharges+$Charges;
      			}
      	else if (trim($PAMode) == "O") {
      			$SumOutput=$SumOutput+$Charges;
      			$SumCharges=$SumCharges-$Charges;
      			}
      	
      	if (trim($PAMode) == "I") $PAMode="收入";
      	else if (trim($PAMode) == "O") $PAMode="支出";
				?>
				ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,1).Value ="<?php echo $PAMode;?>"
				ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,2).Value ="<?php echo $PAItem;?>"
				ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,3).Value ="<?php echo $Charges;?>"
				ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,4).Value ="<?php echo $Rate;?>"
				ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,5).Value ="<?php echo $FlorinTxt;?>"
				ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,6).Value ="<?php echo $ChargesOther;?>"
				ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,7).Value ="<?php echo $PAStatus;?>"
				ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,8).Value ="'<?php echo $PAPDate;?>"
				ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,9).Value ="'<?php echo $PADate;?>"
				ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,10).Value ="'<?php echo $IDate;?>"
				ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,11).Value ="<?php echo $Invoice;?>"
				ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,12).Value ="<?php echo $PCName;?>"
				ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,13).Value ="<?php echo $PANote;?>"
				<?php
				$ECount++;
				}
		mysqli_free_result($result_ProjectAccounting);
		?>
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,1).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,2).Value ="收入"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,3).Value ="支出"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,4).Value ="小計"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,5).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,6).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,7).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,8).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,9).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,10).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,11).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,12).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,13).Value =""
		<?php
		if (trim($SumLine) == "") $SumLine = $ECount;
		else $SumLine = $SumLine.",".$ECount;
		$ECount++;
		?>
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,1).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,2).Value ="<?php echo $SumInput?>"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,3).Value ="<?php echo $SumOutput?>"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,4).Value ="<?php echo $SumCharges;?>"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,5).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,6).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,7).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,8).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,9).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,10).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,11).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,12).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,13).Value =""
		<?php
		$TolCharges = $TolCharges + $SumCharges;
		$TolInputCharges = $TolInputCharges + $SumInput;
		$TolOutputCharges = $TolOutputCharges + $SumOutput;
		if (trim($SumLine) == "") $SumLine = $ECount;
		else $SumLine = $SumLine.",".$ECount;
		
		$ECount++;
		$ECount++;
		}
mysqli_free_result($result_Project);
mysqli_close($link);
?>
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,1).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,2).Value ="總收入"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,3).Value ="總支出"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,4).Value ="總計"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,5).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,6).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,7).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,8).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,9).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,10).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,11).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,12).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,13).Value =""
		<?php
		if (trim($SumLine) == "") $SumLine = $ECount;
		else $SumLine = $SumLine.",".$ECount;
		$ECount++;
		?>
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,1).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,2).Value ="<?php echo $TolInputCharges;?>"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,3).Value ="<?php echo $TolOutputCharges;?>"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,4).Value ="<?php echo $TolCharges;?>"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,5).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,6).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,7).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,8).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,9).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,10).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,11).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,12).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,13).Value =""

		ProjectAccounting.ActiveSheet.Range("A1:N<?php echo $ECount;?>").Font.Color="blue"
		ProjectAccounting.ActiveSheet.Range("A1:N<?php echo $ECount;?>").Font.Name="Courier New"
		ProjectAccounting.ActiveSheet.Range("A1:N<?php echo $ECount;?>").Font.Size="11"
		ProjectAccounting.ActiveSheet.Range("A1:N<?php echo $ECount;?>").Columns.AutoFit
		ProjectAccounting.ActiveSheet.Range("A1:N<?php echo $ECount;?>").NumberFormat ="General"

		ProjectAccounting.ActiveSheet.Range("A<?php echo $ECount;?>:J<?php echo $ECount;?>").Font.Bold=true
		<?php
		$TitleLineArr = split(",",$TitleLine);
		$count_i=count($TitleLineArr);
		for ($tmp=0;$tmp<=$count_i-1;$tmp++){
				?>
				ProjectAccounting.ActiveSheet.Range("A<?php echo $TitleLineArr[$tmp];?>:N<?php echo $TitleLineArr[$tmp];?>").Font.Color="#000000"
				ProjectAccounting.ActiveSheet.Range("A<?php echo $TitleLineArr[$tmp];?>:N<?php echo $TitleLineArr[$tmp];?>").Font.Bold=true
				ProjectAccounting.ActiveSheet.Range("A<?php echo $TitleLineArr[$tmp]+1;?>:N<?php echo $TitleLineArr[$tmp]+1;?>").Font.Bold=true
				<?php
				}

		$SumLineArr = split(",",$SumLine);
		$count_i=count($SumLineArr);
		for ($tmp=0;$tmp<=$count_i-1;$tmp++){
				?>
				ProjectAccounting.ActiveSheet.Range("A<?php echo $SumLineArr[$tmp];?>:N<?php echo $SumLineArr[$tmp];?>").Font.Bold=true
				<?php
				}
		?>
	End Sub
	</script>
</body>
</html>
