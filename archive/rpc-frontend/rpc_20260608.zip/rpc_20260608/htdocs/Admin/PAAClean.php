﻿<?php
include "CheckPermission.php";
include "CheckProject.php";
include "../global.php";
require_once("../include/chinese_party.class.php");
require("class.phpmailer.php");
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $PageAdminTitle;?></title>
</head>
<body>
<?php
$PID = $_GET['PID'];

if (trim($PID) == "")
		{
		mysqli_close($link);
		?>
		<script type="text/JavaScript">
			<!--
			alert ("您輸入的資料不足，請重新輸入！");
			self.close();
			//-->
		</script>
		<?php
		exit;
		}
$now_time = date("Y-m-d H:i:s",mktime());
$sql_insert = "INSERT INTO ProjectHistory(PID,PUID,CID,CName,CTel,CFax,Contact,CMobile,CEMail,CAddress,PStatus,PName,ModelName,SeriesModel,PE,PENotify,PENotifyMUID,Quote,ApplyItem,Canon,CCCCode,SNote,StartDate,PlanDate,CloseDate,PNote,PNoteDate,EMC,POther,PADate,PNote1,QuoteDate,QRecord,QRecordDate,QRecordIP,ReturnDate,RRecord,RRecordDate,RRecordIP,IFlorin,OFlorin,InvoiceCUID,InvoiceTitle,InvoiceAddress,Leadtime,Trademark,InvoiceDate,IRecord,IRecordDate,IRecordIP,AddUser,AddDate,AddIP,Deltag,ProcUser,ProcDate,ProcIP,UpdateUser,UpdateDate,UpdateIP) SELECT PID,PUID,CID,CName,CTel,CFax,Contact,CMobile,CEMail,CAddress,PStatus,PName,ModelName,SeriesModel,PE,PENotify,PENotifyMUID,Quote,ApplyItem,Canon,CCCCode,SNote,StartDate,PlanDate,CloseDate,PNote,PNoteDate,EMC,POther,PADate,PNote1,QuoteDate,QRecord,QRecordDate,QRecordIP,ReturnDate,RRecord,RRecordDate,RRecordIP,IFlorin,OFlorin,InvoiceCUID,InvoiceTitle,InvoiceAddress,Leadtime,Trademark,InvoiceDate,IRecord,IRecordDate,IRecordIP,AddUser,AddDate,AddIP,Deltag,ProcUser,ProcDate,ProcIP,'".$_SESSION["reg_MUID"]."','".$now_time."','".$_SERVER["REMOTE_ADDR"]."' FROM Project where Deltag='N' and PID = '".$PID."';";
$result_insert=mysqli_query($link,$sql_insert) or die ("無法執行新增");

$sql_insert = "INSERT INTO ProjectAccountingAddHistory(PAAID,PID,PAADate,PAAReason,PAACheck,AddUser,AddDate,AddIP,ProcUser,ProcDate,ProcIP,UpdateUser,UpdateDate,UpdateIP) SELECT PAAID,PID,PAADate,PAAReason,PAACheck,AddUser,AddDate,AddIP,ProcUser,ProcDate,ProcIP,'".$_SESSION["reg_MUID"]."','".$now_time."','".$_SERVER["REMOTE_ADDR"]."' FROM ProjectAccountingAdd where PID = ".$PID.";";
$result_insert=mysqli_query($link,$sql_insert) or die ("無法執行新增");
$sql_update = "update ProjectAccountingAdd set PAACheck = 'N',ProcUser = '".$_SESSION["reg_MUID"]."',ProcDate = '".$now_time."',ProcIP = '".$_SERVER["REMOTE_ADDR"]."' where PID = ".$PID.";";
$result_update=mysqli_query($link,$sql_update) or die ("無法執行修改");

$sql_update = "update Project set PStatus='B',QuoteDate=NULL,QRecord='',QRecordDate=NULL,QRecordIP='',ProcUser = '".$_SESSION["reg_MUID"]."',ProcDate = '".$now_time."',ProcIP = '".$_SERVER["REMOTE_ADDR"]."' where Deltag='N' and PID = '".$PID."';";
$result_update=mysqli_query($link,$sql_update) or die ("無法執行修改");

mysqli_close($link);
?>
<script type="text/JavaScript">
	<!--
	alert ("已清除加測狀態，請重新輸入加測資訊！");
	opener.location.reload();
	self.close();
	//-->
</script>

</body>
</html>
