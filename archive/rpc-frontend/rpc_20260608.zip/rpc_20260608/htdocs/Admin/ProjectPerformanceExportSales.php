﻿<?php
include "CheckPermission.php";
include "CheckAccountingReport.php";
include "../global.php";
require_once 'PHPExcel.php';

function chk_str($chkstr) {
	$chkstr = str_replace('"','〞',$chkstr);
	return $chkstr;
}
$SqlPID = "";
$Sql_PID = "";
$QSDate = "";
$QEDate = "";
$SqlTxt = "";
$QPE = "";
$QSYear = empty($_POST['QSYear'])?"":$_POST['QSYear'];
$QSMonth = empty($_POST['QSMonth'])?"":$_POST['QSMonth'];
$QSDay = empty($_POST['QSDay'])?"":$_POST['QSDay'];
if (trim($QSYear) != "" || trim($QSMonth) != "" || trim($QSDay) != "") if (checkdate($QSMonth,$QSDay ,$QSYear)) $QSDate = $QSYear."-".$QSMonth."-".$QSDay;
$QEYear = empty($_POST['QEYear'])?"":$_POST['QEYear'];
$QEMonth = empty($_POST['QEMonth'])?"":$_POST['QEMonth'];
$QEDay = empty($_POST['QEDay'])?"":$_POST['QEDay'];
if (trim($QEYear) != "" || trim($QEMonth) != "" || trim($QEDay) != "") if (checkdate($QEMonth,$QEDay ,$QEYear)) $QEDate = $QEYear."-".$QEMonth."-".$QEDay;

$QBE = $_POST['QBE'];
$KeyWord = $_POST['KeyWord'];
$QPStatus = $_POST['QPStatus'];
$QAcR = $_POST['QAcR'];

$KeyWord = empty($_POST['KeyWord'])?"":$_POST['KeyWord'];
if (trim($KeyWord) == "") $KeyWord = empty($_GET['KeyWord'])?"":$_GET['KeyWord'];
$QPStatus = empty($_POST['QPStatus'])?"":$_POST['QPStatus'];
if (trim($QPStatus) == "") $QPStatus = empty($_GET['QPStatus'])?"":$_GET['QPStatus'];
if (trim($KeyWord) != "") {
		$SQL_ProjectCertificate="select PID from ProjectCertificate where Deltag='N' and PCNo like '%".$KeyWord."%' group by PID order by PID;";
		$result_ProjectCertificate=mysqli_query($link,$SQL_ProjectCertificate) or die ("無法執行查詢");
		
		while(list($PC_PID)=mysqli_fetch_row($result_ProjectCertificate)){
				if (trim($SqlPID) == "") $SqlPID = $PC_PID;
				else $SqlPID = $SqlPID.",".$PC_PID;
				}
		mysqli_free_result($result_ProjectCertificate);

		$SQL_ProjectAccounting="select PID from ProjectAccounting where Deltag='N' and (PAItem like '%".$KeyWord."%' or Invoice like '%".$KeyWord."%' or PANote like '%".$KeyWord."%') group by PID order by PID;";
		$result_ProjectAccounting=mysqli_query($link,$SQL_ProjectAccounting) or die ("無法執行查詢");
		$SqlPID = "";
		while(list($PA_PID)=mysqli_fetch_row($result_ProjectAccounting)){
				if (trim($SqlPID) == "") $SqlPID = $PA_PID;
				else $SqlPID = $SqlPID.",".$PA_PID;
				}
		mysqli_free_result($result_ProjectAccounting);
		}
if (trim($SqlPID) != "") $SqlPID = " a.PID in (".$SqlPID.")";
if (trim($KeyWord) != "") {
		if (trim($SqlPID) == "") $SqlTxt = $SqlTxt." and (a.PUID like '%".$KeyWord."%' or a.CName like '%".$KeyWord."%' or a.CTel like '%".$KeyWord."%' or a.CFax like '%".$KeyWord."%' or a.Contact like '%".$KeyWord."%' or a.CMobile like '%".$KeyWord."%' or a.CEMail like '%".$KeyWord."%' or a.CAddress like '%".$KeyWord."%' or a.PName like '%".$KeyWord."%' or a.ModelName like '%".$KeyWord."%' or a.SeriesModel like '%".$KeyWord."%' or a.PE like '%".$KeyWord."%' or a.PNote like '%".$KeyWord."%')";
		else $SqlTxt = $SqlTxt." and (a.PUID like '%".$KeyWord."%' or a.CName like '%".$KeyWord."%' or a.CTel like '%".$KeyWord."%' or a.CFax like '%".$KeyWord."%' or a.Contact like '%".$KeyWord."%' or a.CMobile like '%".$KeyWord."%' or a.CEMail like '%".$KeyWord."%' or a.CAddress like '%".$KeyWord."%' or a.PName like '%".$KeyWord."%' or a.ModelName like '%".$KeyWord."%' or a.SeriesModel like '%".$KeyWord."%' or a.PE like '%".$KeyWord."%' or a.PNote like '%".$KeyWord."%' or a.ApplyItem like '%".$KeyWord."%' or ".$SqlPID.")";
		}

if (trim($QAcR) != "") {
		$SQL_QAcR="SELECT DISTINCT a.PID FROM Project a, ProjectAccounting b WHERE a.PID = b.PID AND a.Deltag = 'N' AND b.Deltag = 'N' AND a.InvoiceDate is not null AND b.PAStatus = 'W' ORDER BY a.PID";
		$result_QAcR=mysqli_query($link,$SQL_QAcR) or die ("無法執行查詢");
		
		while(list($PQ_PID)=mysqli_fetch_row($result_QAcR)){
				if (trim($Sql_PID) == "") $Sql_PID = $PQ_PID;
				else $Sql_PID = $Sql_PID.",".$PQ_PID;
				}
		mysqli_free_result($result_QAcR);
		}
if (trim($Sql_PID) != "") $SqlTxt = $SqlTxt . " and a.PID in (".$Sql_PID.")";
//if (trim($KeyWord) != "") $SqlTxt = " and (PUID like '%".$KeyWord."%' or CName like '%".$KeyWord."%' or CTel like '%".$KeyWord."%' or CFax like '%".$KeyWord."%' or Contact like '%".$KeyWord."%' or CMobile like '%".$KeyWord."%' or CEMail like '%".$KeyWord."%' or CAddress like '%".$KeyWord."%' or PName like '%".$KeyWord."%' or ModelName like '%".$KeyWord."%' or SeriesModel like '%".$KeyWord."%' or PE like '%".$KeyWord."%')";
if (trim($QPStatus) != "") $SqlTxt = $SqlTxt." and a.PStatus='".$QPStatus."' ";
if (trim($QSDate) != "" && trim($QEDate) != "") $SqlTxt = $SqlTxt." and (a.AddDate >= '".$QSDate." 00:00:00') and (a.AddDate <= '".$QEDate." 23:59:59') ";
else if (trim($QSDate) != "" && trim($QEDate) == "") $SqlTxt = $SqlTxt." and (a.AddDate >= '".$QSDate." 00:00:00') ";
else if (trim($QSDate) == "" && trim($QEDate) != "") $SqlTxt = $SqlTxt." and (a.AddDate <= '".$QEDate." 23:59:59') ";
if (trim($QPE) != "") $SqlTxt = $SqlTxt." and a.PE='".$QPE."' ";

$SqlTxt2 = str_replace("a.","",$SqlTxt);
//echo "SqlTxt=$SqlTxt<br>";
//echo "SqlTxt2=$SqlTxt2<br>";
//exit;

$SQL_Project="select a.PID,a.PUID,a.CID,a.CName,a.CTel,a.CFax,a.Contact,a.CMobile,a.CEMail,a.CAddress,a.PStatus,a.PName,a.ModelName,a.SeriesModel,a.BMUID,(select MName from Manager where MUID=a.BMUID and DelTag='N') PEName,(select MEName from Manager where MUID=a.BMUID and DelTag='N') PEEName,a.Quote,a.ApplyItem,a.Canon,a.SNote,a.StartDate,a.PlanDate,a.CloseDate,a.PNote,a.QuoteDate,a.ReturnDate,a.IFlorin,a.OFlorin,a.InvoiceDate,a.InvoiceCUID,(select CUID from Customer where Deltag='N' and CID = a.CID) as CUID from Project a where a.Deltag='N' ".$SqlTxt." order by a.BMUID,a.PID desc;";
//2016-0730 報表輸出錯誤 2016-06 月份之後
//$SQL_Project="select PID,PUID,CID,CName,CTel,CFax,Contact,CMobile,CEMail,CAddress,PStatus,PName,ModelName,SeriesModel,BMUID,(select MName from Manager where MUID=BMUID and DelTag='N') PEName,(select MEName from Manager where MUID=BMUID and DelTag='N') PEEName,Quote,ApplyItem,Canon,SNote,StartDate,PlanDate,CloseDate,PNote,QuoteDate,ReturnDate,IFlorin,OFlorin,InvoiceDate,InvoiceCUID,(select CUID from Customer where Deltag='N' and CID = CID) as CUID from Project where Deltag='N' ".$SqlTxt." order by BMUID,PID desc;";
//echo $SQL_Project;

$result_Project=mysqli_query($link,$SQL_Project) or die ("無法執行查詢");

$objPHPExcel = new PHPExcel();
$objPHPExcel->setActiveSheetIndex(0);

$Ecount=1;  
$TolCharges=0;             
$TolInputCharges=0;             
$TolOutputCharges=0;

while(list($PID,$PUID,$CID,$CName,$CTel,$CFax,$Contact,$CMobile,$CEMail,$CAddress,$PStatus,$PName,$ModelName,$SeriesModel,$PE,$PEName,$PEEName,$Quote,$ApplyItem,$Canon,$SNote,$StartDate,$PlanDate,$CloseDate,$PNote,$QuoteDate,$ReturnDate,$IFlorin,$OFlorin,$InvoiceDate,$InvoiceCUID,$CUID)=mysqli_fetch_row($result_Project)){
  	$objPHPExcel->getActiveSheet()->setCellValue('A'.$Ecount,"案件編號");
	$objPHPExcel->getActiveSheet()->setCellValue('B'.$Ecount,"產品名稱");
	$objPHPExcel->getActiveSheet()->setCellValue('C'.$Ecount,"客戶名稱");	
	$objPHPExcel->getActiveSheet()->setCellValue('D'.$Ecount,"案件業務");
	$objPHPExcel->getActiveSheet()->setCellValue('E'.$Ecount,"狀態");
	$objPHPExcel->getActiveSheet()->setCellValue('F'.$Ecount,"案件開始日期");
	$objPHPExcel->getActiveSheet()->setCellValue('G'.$Ecount,"結案日期");

	$objPHPExcel->getActiveSheet()->getStyle("A".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
	$objPHPExcel->getActiveSheet()->getStyle("B".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
	$objPHPExcel->getActiveSheet()->getStyle("C".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
	$objPHPExcel->getActiveSheet()->getStyle("D".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
	$objPHPExcel->getActiveSheet()->getStyle("E".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
	$objPHPExcel->getActiveSheet()->getStyle("F".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
	$objPHPExcel->getActiveSheet()->getStyle("G".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);

	 
	
	$Ecount++;

	if (trim($ModelName) == "") $ModelName = "NA";
  	if (trim($PStatus) == "A") $PStatus="新開案";
  	else if (trim($PStatus) == "B") $PStatus="報價中";
  	else if (trim($PStatus) == "C") $PStatus="案件處理中";
  	else if (trim($PStatus) == "D") $PStatus="審查中";
  	else if (trim($PStatus) == "E") $PStatus="補件中";
  	else if (trim($PStatus) == "F") $PStatus="待印證";
  	else if (trim($PStatus) == "G") $PStatus="案件取消";
  	else if (trim($PStatus) == "H") $PStatus="已結案";
  	if (trim($CloseDate) == "0000-00-00") $CloseDate="";

	$objPHPExcel->getActiveSheet()->setCellValue('A'.$Ecount,$PUID);
	$objPHPExcel->getActiveSheet()->setCellValue('B'.$Ecount,$PName."-".$ApplyItem);
	$objPHPExcel->getActiveSheet()->setCellValue('C'.$Ecount,$CName);
	$objPHPExcel->getActiveSheet()->setCellValue('D'.$Ecount,$PEEName.$PEName);
	$objPHPExcel->getActiveSheet()->setCellValue('E'.$Ecount,$PStatus);
	$objPHPExcel->getActiveSheet()->setCellValue('F'.$Ecount,$StartDate);
	$objPHPExcel->getActiveSheet()->setCellValue('G'.$Ecount,$CloseDate);
	
	$objPHPExcel->getActiveSheet()->getStyle('A'.$Ecount)->getFont()->setSize(12);
	$objPHPExcel->getActiveSheet()->getStyle('B'.$Ecount)->getFont()->setSize(12);
	$objPHPExcel->getActiveSheet()->getStyle('C'.$Ecount)->getFont()->setSize(12);
	$objPHPExcel->getActiveSheet()->getStyle('D'.$Ecount)->getFont()->setSize(12);
	$objPHPExcel->getActiveSheet()->getStyle('E'.$Ecount)->getFont()->setSize(12);
	$objPHPExcel->getActiveSheet()->getStyle('F'.$Ecount)->getFont()->setSize(12);
	$objPHPExcel->getActiveSheet()->getStyle('G'.$Ecount)->getFont()->setSize(12);
	

	$Ecount++;
		
	$objPHPExcel->getActiveSheet()->setCellValue('A'.$Ecount,"收入/支出");
	$objPHPExcel->getActiveSheet()->setCellValue('B'.$Ecount,"項目");
	$objPHPExcel->getActiveSheet()->setCellValue('C'.$Ecount,"費用");
	$objPHPExcel->getActiveSheet()->setCellValue('D'.$Ecount,"匯率");
	$objPHPExcel->getActiveSheet()->setCellValue('E'.$Ecount,"外幣別");
	$objPHPExcel->getActiveSheet()->setCellValue('F'.$Ecount,"外幣費用");
	$objPHPExcel->getActiveSheet()->setCellValue('G'.$Ecount,"狀態");
	$objPHPExcel->getActiveSheet()->setCellValue('H'.$Ecount,"預計結清日期");
	$objPHPExcel->getActiveSheet()->setCellValue('I'.$Ecount,"收款日/付款日");
	$objPHPExcel->getActiveSheet()->setCellValue('J'.$Ecount,"發票日期");
	$objPHPExcel->getActiveSheet()->setCellValue('K'.$Ecount,"發票號碼");
	$objPHPExcel->getActiveSheet()->setCellValue('L'.$Ecount,"供應商");
	$objPHPExcel->getActiveSheet()->setCellValue('M'.$Ecount,"備註");
	
	$objPHPExcel->getActiveSheet()->getStyle("A".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
	$objPHPExcel->getActiveSheet()->getStyle("B".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
	$objPHPExcel->getActiveSheet()->getStyle("C".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
	$objPHPExcel->getActiveSheet()->getStyle("D".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
	$objPHPExcel->getActiveSheet()->getStyle("E".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
	$objPHPExcel->getActiveSheet()->getStyle("F".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
	$objPHPExcel->getActiveSheet()->getStyle("G".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
	$objPHPExcel->getActiveSheet()->getStyle("H".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
	$objPHPExcel->getActiveSheet()->getStyle("I".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
	$objPHPExcel->getActiveSheet()->getStyle("J".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
	$objPHPExcel->getActiveSheet()->getStyle("K".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
	$objPHPExcel->getActiveSheet()->getStyle("L".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
	$objPHPExcel->getActiveSheet()->getStyle("M".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
	
	$Ecount++;
	$SQL_ProjectAccounting="select PAID,PAMode,PAItem,Charges,Rate,ChargesOther,PAStatus,PAPDate,PADate,InvoiceDate,Invoice,PANote,CName from ProjectAccounting where Deltag='N' and PID = '".$PID."' and (PAStatus = 'W' or PAStatus = 'S') order by PAMode asc,PAID asc;";
	$result_ProjectAccounting=mysqli_query($link,$SQL_ProjectAccounting) or die ("無法執行查詢");
	$SumCharges=0;             
	$SumInput=0;             
	$SumOutput=0;             
    while(list($PAID,$PAMode,$PAItem,$Charges,$Rate,$ChargesOther,$PAStatus,$PAPDate,$PADate,$IDate,$Invoice,$PANote,$PCName)=mysqli_fetch_row($result_ProjectAccounting)){
      	if (trim($PAStatus) == "W") {
      			if (trim($PAMode) == "I") $PAStatus="待收"; else if (trim($PAMode) == "O") $PAStatus="未付";
      			}
      	else if (trim($PAStatus) == "S") $PAStatus="結清";
      	else if (trim($PAStatus) == "C") $PAStatus="取消";
      	$FlorinTxt="";
      	if (trim($PAMode) == "I") $FlorinTxt=$IFlorin;
      	else if (trim($PAMode) == "O") $FlorinTxt=$OFlorin;
      	
      	if (trim($PAMode) == "I") {
      			$SumInput=$SumInput+$Charges;
      			$SumCharges=$SumCharges+$Charges;
      			}
      	else if (trim($PAMode) == "O") {
      			$SumOutput=$SumOutput+$Charges;
      			$SumCharges=$SumCharges-$Charges;
      			}
      	
      	if (trim($PAMode) == "I") $PAMode="收入";
      	else if (trim($PAMode) == "O") $PAMode="支出";
				
		$objPHPExcel->getActiveSheet()->setCellValue('A'.$Ecount,$PAMode);
		$objPHPExcel->getActiveSheet()->setCellValue('B'.$Ecount,$PAItem);
		$objPHPExcel->getActiveSheet()->setCellValue('C'.$Ecount,$Charges);
		$objPHPExcel->getActiveSheet()->setCellValue('D'.$Ecount,$Rate);
		$objPHPExcel->getActiveSheet()->setCellValue('E'.$Ecount,$FlorinTxt);
		$objPHPExcel->getActiveSheet()->setCellValue('F'.$Ecount,$ChargesOther);
		$objPHPExcel->getActiveSheet()->setCellValue('G'.$Ecount,$PAStatus);
		$objPHPExcel->getActiveSheet()->setCellValue('H'.$Ecount,$PAPDate);
		$objPHPExcel->getActiveSheet()->setCellValue('I'.$Ecount,$PADate);
		$objPHPExcel->getActiveSheet()->setCellValue('J'.$Ecount,$IDate);
		$objPHPExcel->getActiveSheet()->setCellValue('K'.$Ecount,$Invoice);
		$objPHPExcel->getActiveSheet()->setCellValue('L'.$Ecount,chk_str($PCName));
		$objPHPExcel->getActiveSheet()->setCellValue('M'.$Ecount,chk_str($PANote));
		
		$objPHPExcel->getActiveSheet()->getStyle('A'.$Ecount)->getFont()->setSize(12);
		$objPHPExcel->getActiveSheet()->getStyle('B'.$Ecount)->getFont()->setSize(12);
		$objPHPExcel->getActiveSheet()->getStyle('C'.$Ecount)->getFont()->setSize(12);
		$objPHPExcel->getActiveSheet()->getStyle('D'.$Ecount)->getFont()->setSize(12);
		$objPHPExcel->getActiveSheet()->getStyle('E'.$Ecount)->getFont()->setSize(12);
		$objPHPExcel->getActiveSheet()->getStyle('F'.$Ecount)->getFont()->setSize(12);
		$objPHPExcel->getActiveSheet()->getStyle('G'.$Ecount)->getFont()->setSize(12);
		$objPHPExcel->getActiveSheet()->getStyle('H'.$Ecount)->getFont()->setSize(12);
		$objPHPExcel->getActiveSheet()->getStyle('I'.$Ecount)->getFont()->setSize(12);
		$objPHPExcel->getActiveSheet()->getStyle('J'.$Ecount)->getFont()->setSize(12);
		$objPHPExcel->getActiveSheet()->getStyle('K'.$Ecount)->getFont()->setSize(12);
		$objPHPExcel->getActiveSheet()->getStyle('L'.$Ecount)->getFont()->setSize(12);
		$objPHPExcel->getActiveSheet()->getStyle('M'.$Ecount)->getFont()->setSize(12);
		$Ecount++;
	}
	mysqli_free_result($result_ProjectAccounting);
		
	$objPHPExcel->getActiveSheet()->setCellValue('A'.$Ecount,"");
	$objPHPExcel->getActiveSheet()->setCellValue('B'.$Ecount,"收入");
	$objPHPExcel->getActiveSheet()->setCellValue('C'.$Ecount,"支出");
	$objPHPExcel->getActiveSheet()->setCellValue('D'.$Ecount,"小計");
	$objPHPExcel->getActiveSheet()->setCellValue('E'.$Ecount,"");
	$objPHPExcel->getActiveSheet()->setCellValue('F'.$Ecount,"");
	$objPHPExcel->getActiveSheet()->setCellValue('G'.$Ecount,"");
	$objPHPExcel->getActiveSheet()->setCellValue('H'.$Ecount,"");
	$objPHPExcel->getActiveSheet()->setCellValue('I'.$Ecount,"");
	$objPHPExcel->getActiveSheet()->setCellValue('J'.$Ecount,"");
	$objPHPExcel->getActiveSheet()->setCellValue('K'.$Ecount,"");
	$objPHPExcel->getActiveSheet()->setCellValue('L'.$Ecount,"");
	$objPHPExcel->getActiveSheet()->setCellValue('M'.$Ecount,"");
	
	$objPHPExcel->getActiveSheet()->getStyle("A".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
	$objPHPExcel->getActiveSheet()->getStyle("B".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
	$objPHPExcel->getActiveSheet()->getStyle("C".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
	$objPHPExcel->getActiveSheet()->getStyle("D".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
	$objPHPExcel->getActiveSheet()->getStyle("E".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
	$objPHPExcel->getActiveSheet()->getStyle("F".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
	$objPHPExcel->getActiveSheet()->getStyle("G".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
	$objPHPExcel->getActiveSheet()->getStyle("H".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
	$objPHPExcel->getActiveSheet()->getStyle("I".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
	$objPHPExcel->getActiveSheet()->getStyle("J".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
	$objPHPExcel->getActiveSheet()->getStyle("K".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
	$objPHPExcel->getActiveSheet()->getStyle("L".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
	$objPHPExcel->getActiveSheet()->getStyle("M".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);

	
	$Ecount++;	
		
	$objPHPExcel->getActiveSheet()->setCellValue('A'.$Ecount,"");
	$objPHPExcel->getActiveSheet()->setCellValue('B'.$Ecount,$SumInput);
	$objPHPExcel->getActiveSheet()->setCellValue('C'.$Ecount,$SumOutput);
	$objPHPExcel->getActiveSheet()->setCellValue('D'.$Ecount,$SumCharges);
	$objPHPExcel->getActiveSheet()->setCellValue('E'.$Ecount,"");
	$objPHPExcel->getActiveSheet()->setCellValue('F'.$Ecount,"");
	$objPHPExcel->getActiveSheet()->setCellValue('G'.$Ecount,"");
	$objPHPExcel->getActiveSheet()->setCellValue('H'.$Ecount,"");
	$objPHPExcel->getActiveSheet()->setCellValue('I'.$Ecount,"");
	$objPHPExcel->getActiveSheet()->setCellValue('J'.$Ecount,"");
	$objPHPExcel->getActiveSheet()->setCellValue('K'.$Ecount,"");
	$objPHPExcel->getActiveSheet()->setCellValue('L'.$Ecount,"");
	$objPHPExcel->getActiveSheet()->setCellValue('M'.$Ecount,"");
		
	$objPHPExcel->getActiveSheet()->getStyle('A'.$Ecount)->getFont()->setSize(12);
	$objPHPExcel->getActiveSheet()->getStyle('B'.$Ecount)->getFont()->setSize(12);
	$objPHPExcel->getActiveSheet()->getStyle('C'.$Ecount)->getFont()->setSize(12);
	$objPHPExcel->getActiveSheet()->getStyle('D'.$Ecount)->getFont()->setSize(12);
	$objPHPExcel->getActiveSheet()->getStyle('E'.$Ecount)->getFont()->setSize(12);
	$objPHPExcel->getActiveSheet()->getStyle('F'.$Ecount)->getFont()->setSize(12);
	$objPHPExcel->getActiveSheet()->getStyle('G'.$Ecount)->getFont()->setSize(12);
	$objPHPExcel->getActiveSheet()->getStyle('H'.$Ecount)->getFont()->setSize(12);
	$objPHPExcel->getActiveSheet()->getStyle('I'.$Ecount)->getFont()->setSize(12);
	$objPHPExcel->getActiveSheet()->getStyle('J'.$Ecount)->getFont()->setSize(12);
	$objPHPExcel->getActiveSheet()->getStyle('K'.$Ecount)->getFont()->setSize(12);
	$objPHPExcel->getActiveSheet()->getStyle('L'.$Ecount)->getFont()->setSize(12);
	$objPHPExcel->getActiveSheet()->getStyle('M'.$Ecount)->getFont()->setSize(12);
	
	$TolCharges = $TolCharges + $SumCharges;
	$TolInputCharges = $TolInputCharges + $SumInput;
	$TolOutputCharges = $TolOutputCharges + $SumOutput;
	
	$Ecount++;
}
mysqli_free_result($result_Project);

$objPHPExcel->getActiveSheet()->setCellValue('A'.$Ecount,"");
$objPHPExcel->getActiveSheet()->setCellValue('B'.$Ecount,"總收入");
$objPHPExcel->getActiveSheet()->setCellValue('C'.$Ecount,"總支出");
$objPHPExcel->getActiveSheet()->setCellValue('D'.$Ecount,"總計");
$objPHPExcel->getActiveSheet()->setCellValue('E'.$Ecount,"");
$objPHPExcel->getActiveSheet()->setCellValue('F'.$Ecount,"");
$objPHPExcel->getActiveSheet()->setCellValue('G'.$Ecount,"");
$objPHPExcel->getActiveSheet()->setCellValue('H'.$Ecount,"");
$objPHPExcel->getActiveSheet()->setCellValue('I'.$Ecount,"");
$objPHPExcel->getActiveSheet()->setCellValue('J'.$Ecount,"");
$objPHPExcel->getActiveSheet()->setCellValue('K'.$Ecount,"");
$objPHPExcel->getActiveSheet()->setCellValue('L'.$Ecount,"");
$objPHPExcel->getActiveSheet()->setCellValue('M'.$Ecount,"");
	
$objPHPExcel->getActiveSheet()->getStyle("A".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("B".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("C".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("D".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("E".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("F".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("G".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("H".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("I".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("J".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("K".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("L".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("M".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);

$Ecount++;

$objPHPExcel->getActiveSheet()->setCellValue('A'.$Ecount,"");
$objPHPExcel->getActiveSheet()->setCellValue('B'.$Ecount,$TolInputCharges);
$objPHPExcel->getActiveSheet()->setCellValue('C'.$Ecount,$TolOutputCharges);
$objPHPExcel->getActiveSheet()->setCellValue('D'.$Ecount,$TolCharges);
$objPHPExcel->getActiveSheet()->setCellValue('E'.$Ecount,"");
$objPHPExcel->getActiveSheet()->setCellValue('F'.$Ecount,"");
$objPHPExcel->getActiveSheet()->setCellValue('G'.$Ecount,"");
$objPHPExcel->getActiveSheet()->setCellValue('H'.$Ecount,"");
$objPHPExcel->getActiveSheet()->setCellValue('I'.$Ecount,"");
$objPHPExcel->getActiveSheet()->setCellValue('J'.$Ecount,"");
$objPHPExcel->getActiveSheet()->setCellValue('K'.$Ecount,"");
$objPHPExcel->getActiveSheet()->setCellValue('L'.$Ecount,"");
$objPHPExcel->getActiveSheet()->setCellValue('M'.$Ecount,"");
		
$objPHPExcel->getActiveSheet()->getStyle('A'.$Ecount)->getFont()->setSize(12);
$objPHPExcel->getActiveSheet()->getStyle('B'.$Ecount)->getFont()->setSize(12);
$objPHPExcel->getActiveSheet()->getStyle('C'.$Ecount)->getFont()->setSize(12);
$objPHPExcel->getActiveSheet()->getStyle('D'.$Ecount)->getFont()->setSize(12);
$objPHPExcel->getActiveSheet()->getStyle('E'.$Ecount)->getFont()->setSize(12);
$objPHPExcel->getActiveSheet()->getStyle('F'.$Ecount)->getFont()->setSize(12);
$objPHPExcel->getActiveSheet()->getStyle('G'.$Ecount)->getFont()->setSize(12);
$objPHPExcel->getActiveSheet()->getStyle('H'.$Ecount)->getFont()->setSize(12);
$objPHPExcel->getActiveSheet()->getStyle('I'.$Ecount)->getFont()->setSize(12);
$objPHPExcel->getActiveSheet()->getStyle('J'.$Ecount)->getFont()->setSize(12);
$objPHPExcel->getActiveSheet()->getStyle('K'.$Ecount)->getFont()->setSize(12);
$objPHPExcel->getActiveSheet()->getStyle('L'.$Ecount)->getFont()->setSize(12);
$objPHPExcel->getActiveSheet()->getStyle('M'.$Ecount)->getFont()->setSize(12);

$Ecount++;

$objPHPExcel->getActiveSheet()->setCellValue('A'.$Ecount,"");
$objPHPExcel->getActiveSheet()->setCellValue('B'.$Ecount,"案件業務");
$objPHPExcel->getActiveSheet()->setCellValue('C'.$Ecount,"案件處理數量");
$objPHPExcel->getActiveSheet()->setCellValue('D'.$Ecount,"事項處理數量");
$objPHPExcel->getActiveSheet()->setCellValue('E'.$Ecount,"收入");
$objPHPExcel->getActiveSheet()->setCellValue('F'.$Ecount,"支出");
$objPHPExcel->getActiveSheet()->setCellValue('G'.$Ecount,"小計");
$objPHPExcel->getActiveSheet()->setCellValue('H'.$Ecount,"");
$objPHPExcel->getActiveSheet()->setCellValue('I'.$Ecount,"");
$objPHPExcel->getActiveSheet()->setCellValue('J'.$Ecount,"");
$objPHPExcel->getActiveSheet()->setCellValue('K'.$Ecount,"");
$objPHPExcel->getActiveSheet()->setCellValue('L'.$Ecount,"");
$objPHPExcel->getActiveSheet()->setCellValue('M'.$Ecount,"");
	
$objPHPExcel->getActiveSheet()->getStyle("A".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("B".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("C".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("D".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("E".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("F".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("G".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("H".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("I".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("J".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("K".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("L".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("M".$Ecount)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);

//$Ecount++;

$SQL_Project="
		SELECT a.BMUID, 
		    (SELECT MName FROM Manager WHERE MUID = a.BMUID)SPName,
		    (SELECT MEName FROM Manager WHERE MUID = a.BMUID)SPEName,
		    count( a.BMUID ) PCount,
		    (select count( AID ) ACount 
		    from agendum where Deltag = 'N' 
		    and ARID = a.BMUID $SqlTxt2) ACount,
		    (SELECT sum( Charges  ) ChargesI
		    FROM ProjectAccounting
		    WHERE PAMode = 'I'
				AND Deltag = 'N'
		    AND PID
		    IN (
		    SELECT PID FROM Project
		    WHERE Deltag = 'N'
		    AND BMUID = a.BMUID $SqlTxt2)
		    AND Deltag = 'N') ChargesI,
		    (SELECT sum( Charges  ) ChargesO
		    FROM ProjectAccounting
		    WHERE PAMode = 'O'
				AND Deltag = 'N'
		    AND PID
		    IN (
		    SELECT PID FROM Project
		    WHERE Deltag = 'N'
		    AND BMUID = a.BMUID $SqlTxt2)
		    AND Deltag = 'N') ChargesO
		FROM Project a
		WHERE a.Deltag = 'N' $SqlTxt
		GROUP BY a.BMUID
		ORDER BY a.BMUID DESC ;";
$result_Project=mysqli_query($link,$SQL_Project) or die ("無法執行查詢");
while(list($SPE,$SPName,$SPEName,$PCount,$ACount,$ChargesI,$ChargesO)=mysqli_fetch_row($result_Project)){

	$Ecount++;

	$objPHPExcel->getActiveSheet()->setCellValue('A'.$Ecount,"");
	$objPHPExcel->getActiveSheet()->setCellValue('B'.$Ecount,$SPEName.$SPName);
	$objPHPExcel->getActiveSheet()->setCellValue('C'.$Ecount,$PCount);
	$objPHPExcel->getActiveSheet()->setCellValue('D'.$Ecount,$ACount);
	$objPHPExcel->getActiveSheet()->setCellValue('E'.$Ecount,$ChargesI);
	$objPHPExcel->getActiveSheet()->setCellValue('F'.$Ecount,$ChargesO);
	$objPHPExcel->getActiveSheet()->setCellValue('G'.$Ecount,$ChargesI - $ChargesO);
	$objPHPExcel->getActiveSheet()->setCellValue('H'.$Ecount,"");
	$objPHPExcel->getActiveSheet()->setCellValue('I'.$Ecount,"");
	$objPHPExcel->getActiveSheet()->setCellValue('J'.$Ecount,"");
	$objPHPExcel->getActiveSheet()->setCellValue('K'.$Ecount,"");
	$objPHPExcel->getActiveSheet()->setCellValue('L'.$Ecount,"");
	$objPHPExcel->getActiveSheet()->setCellValue('M'.$Ecount,"");
			
	$objPHPExcel->getActiveSheet()->getStyle('A'.$Ecount)->getFont()->setSize(12);
	$objPHPExcel->getActiveSheet()->getStyle('B'.$Ecount)->getFont()->setSize(12);
	$objPHPExcel->getActiveSheet()->getStyle('C'.$Ecount)->getFont()->setSize(12);
	$objPHPExcel->getActiveSheet()->getStyle('D'.$Ecount)->getFont()->setSize(12);
	$objPHPExcel->getActiveSheet()->getStyle('E'.$Ecount)->getFont()->setSize(12);
	$objPHPExcel->getActiveSheet()->getStyle('F'.$Ecount)->getFont()->setSize(12);
	$objPHPExcel->getActiveSheet()->getStyle('G'.$Ecount)->getFont()->setSize(12);
	$objPHPExcel->getActiveSheet()->getStyle('H'.$Ecount)->getFont()->setSize(12);
	$objPHPExcel->getActiveSheet()->getStyle('I'.$Ecount)->getFont()->setSize(12);
	$objPHPExcel->getActiveSheet()->getStyle('J'.$Ecount)->getFont()->setSize(12);
	$objPHPExcel->getActiveSheet()->getStyle('K'.$Ecount)->getFont()->setSize(12);
	$objPHPExcel->getActiveSheet()->getStyle('L'.$Ecount)->getFont()->setSize(12);
	$objPHPExcel->getActiveSheet()->getStyle('M'.$Ecount)->getFont()->setSize(12);

}
mysqli_free_result($result_Project);
mysqli_close($link);
$objPHPExcel->getActiveSheet()->setTitle('ProjectPerformanceExportSales');

ob_end_clean();

header('Content-Type: application/vnd.ms-excel');
header('Content-Disposition: attachment;filename="ProjectPerformanceExportSales.xls"');
header('Cache-Control: max-age=0');
$objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel5');
$objWriter->save('php://output');
exit;

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $PageAdminTitle;?></title>
<link href="style.css" rel="stylesheet" type="text/css" />
<body>
<table width="1000" border="0">
	<tr>
		<td colspan="2"><font color=blue>若您無法正常觀看此報表！請下載此 <a href="owc11.zip" target="_File"><font color=red><b>元件</b></font></a> <font color=blue>安裝至您的電腦。</font></td>
	</tr>
</table>
<object id=ProjectAccounting classid=CLSID:0002E559-0000-0000-C000-000000000046 style="width:100%;height:90%"></object>
<script language=vbscript>
	Sub Window_OnLoad()
	Set chConstants = ProjectAccounting.Constants
	ProjectAccounting.ActiveSheet.Cells.Clear
	ProjectAccounting.Worksheets(1).Select
	ProjectAccounting.ActiveSheet.Name ="ProjectAccounting"
	ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,1).Value ="案件編號"
	ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,2).Value ="產品名稱"
	ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,3).Value ="客戶名稱"
	ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,4).Value ="案件業務"
	ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,5).Value ="狀態"
	ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,6).Value ="案件開始日期"
	ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,7).Value ="結案日期"
<?php
if (trim($TitleLine) == "") $TitleLine = $ECount;
else $TitleLine = $TitleLine.",".$ECount;
$TolCharges=0;             
$TolInputCharges=0;             
$TolOutputCharges=0;             
while(list($PID,$PUID,$CID,$CName,$CTel,$CFax,$Contact,$CMobile,$CEMail,$CAddress,$PStatus,$PName,$ModelName,$SeriesModel,$PE,$PEName,$PEEName,$Quote,$ApplyItem,$Canon,$SNote,$StartDate,$PlanDate,$CloseDate,$PNote,$QuoteDate,$ReturnDate,$IFlorin,$OFlorin,$InvoiceDate,$InvoiceCUID,$CUID)=mysqli_fetch_row($result_Project)){
  	if (trim($ModelName) == "") $ModelName = "NA";
  	if (trim($PStatus) == "A") $PStatus="新開案";
  	else if (trim($PStatus) == "B") $PStatus="報價中";
  	else if (trim($PStatus) == "C") $PStatus="案件處理中";
  	else if (trim($PStatus) == "D") $PStatus="審查中";
  	else if (trim($PStatus) == "E") $PStatus="補件中";
  	else if (trim($PStatus) == "F") $PStatus="待印證";
  	else if (trim($PStatus) == "G") $PStatus="案件取消";
  	else if (trim($PStatus) == "H") $PStatus="已結案";
  	if (trim($CloseDate) == "0000-00-00") $CloseDate="";
		$ECount++;
		?>
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,1).Value ="<?php echo $PUID;?>"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,2).Value ="<?php echo $PName;?> - <?php echo $ApplyItem;?>"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,3).Value ="<?php echo $CName;?>"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,4).Value ="<?php echo $PEEName.$PEName;?>"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,5).Value ="<?php echo $PStatus;?>"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,6).Value ="<?php echo $StartDate;?>"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,7).Value ="'<?php echo $CloseDate;?>"
		<?php
		if (trim($TitleLine) == "") $TitleLine = $ECount;
		else $TitleLine = $TitleLine.",".$ECount;
		$ECount++;
		?>
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,1).Value ="收入/支出"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,2).Value ="項目"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,3).Value ="費用"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,4).Value ="匯率"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,5).Value ="外幣別"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,6).Value ="外幣費用"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,7).Value ="狀態"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,8).Value ="預計結清日期"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,9).Value ="收款日/付款日"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,10).Value ="發票日期"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,11).Value ="發票號碼"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,12).Value ="供應商"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,13).Value ="備註"
		<?php
		$ECount++;
		$SQL_ProjectAccounting="select PAID,PAMode,PAItem,Charges,Rate,ChargesOther,PAStatus,PAPDate,PADate,InvoiceDate,Invoice,PANote,CName from ProjectAccounting where Deltag='N' and PID = '".$PID."' and (PAStatus = 'W' or PAStatus = 'S') order by PAMode asc,PAID asc;";
		$result_ProjectAccounting=mysqli_query($link,$SQL_ProjectAccounting) or die ("無法執行查詢");
		$SumCharges=0;             
		$SumInput=0;             
		$SumOutput=0;             
    while(list($PAID,$PAMode,$PAItem,$Charges,$Rate,$ChargesOther,$PAStatus,$PAPDate,$PADate,$IDate,$Invoice,$PANote,$PCName)=mysqli_fetch_row($result_ProjectAccounting)){
      	if (trim($PAStatus) == "W") {
      			if (trim($PAMode) == "I") $PAStatus="待收"; else if (trim($PAMode) == "O") $PAStatus="未付";
      			}
      	else if (trim($PAStatus) == "S") $PAStatus="結清";
      	else if (trim($PAStatus) == "C") $PAStatus="取消";
      	$FlorinTxt="";
      	if (trim($PAMode) == "I") $FlorinTxt=$IFlorin;
      	else if (trim($PAMode) == "O") $FlorinTxt=$OFlorin;
      	
      	if (trim($PAMode) == "I") {
      			$SumInput=$SumInput+$Charges;
      			$SumCharges=$SumCharges+$Charges;
      			}
      	else if (trim($PAMode) == "O") {
      			$SumOutput=$SumOutput+$Charges;
      			$SumCharges=$SumCharges-$Charges;
      			}
      	
      	if (trim($PAMode) == "I") $PAMode="收入";
      	else if (trim($PAMode) == "O") $PAMode="支出";
				?>
				ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,1).Value ="<?php echo $PAMode;?>"
				ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,2).Value ="<?php echo $PAItem;?>"
				ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,3).Value ="<?php echo $Charges;?>"
				ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,4).Value ="<?php echo $Rate;?>"
				ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,5).Value ="<?php echo $FlorinTxt;?>"
				ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,6).Value ="<?php echo $ChargesOther;?>"
				ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,7).Value ="<?php echo $PAStatus;?>"
				ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,8).Value ="'<?php echo $PAPDate;?>"
				ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,9).Value ="'<?php echo $PADate;?>"
				ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,10).Value ="'<?php echo $IDate;?>"
				ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,11).Value ="<?php echo $Invoice;?>"
				ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,12).Value ="<?php echo chk_str($PCName);?>"
				ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,13).Value ="<?php echo chk_str($PANote);?>"
				<?php
				$ECount++;
				}
		mysqli_free_result($result_ProjectAccounting);
		?>
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,1).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,2).Value ="收入"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,3).Value ="支出"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,4).Value ="小計"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,5).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,6).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,7).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,8).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,9).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,10).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,11).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,12).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,13).Value =""
		<?php
		if (trim($SumLine) == "") $SumLine = $ECount;
		else $SumLine = $SumLine.",".$ECount;
		$ECount++;
		?>
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,1).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,2).Value ="<?php echo $SumInput?>"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,3).Value ="<?php echo $SumOutput?>"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,4).Value ="<?php echo $SumCharges;?>"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,5).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,6).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,7).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,8).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,9).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,10).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,11).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,12).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,13).Value =""
		<?php
		$TolCharges = $TolCharges + $SumCharges;
		$TolInputCharges = $TolInputCharges + $SumInput;
		$TolOutputCharges = $TolOutputCharges + $SumOutput;
		if (trim($SumLine) == "") $SumLine = $ECount;
		else $SumLine = $SumLine.",".$ECount;
		
		$ECount++;
		$ECount++;
		}
mysqli_free_result($result_Project);

?>
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,1).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,2).Value ="總收入"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,3).Value ="總支出"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,4).Value ="總計"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,5).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,6).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,7).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,8).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,9).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,10).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,11).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,12).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,13).Value =""
		<?php
		if (trim($SumLine) == "") $SumLine = $ECount;
		else $SumLine = $SumLine.",".$ECount;
		$ECount++;
		?>
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,1).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,2).Value ="<?php echo $TolInputCharges;?>"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,3).Value ="<?php echo $TolOutputCharges;?>"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,4).Value ="<?php echo $TolCharges;?>"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,5).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,6).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,7).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,8).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,9).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,10).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,11).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,12).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,13).Value =""
		<?php
		$ECount++;
		$ECount++;
		if (trim($SumLine) == "") $SumLine = $ECount;
		else $SumLine = $SumLine.",".$ECount;
		?>
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,1).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,2).Value ="案件業務"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,3).Value ="案件處理數量"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,4).Value ="事項處理數量"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,5).Value ="收入"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,6).Value ="支出"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,7).Value ="小計"
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,8).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,9).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,10).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,11).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,12).Value =""
		ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,13).Value =""
		<?php
		//$SQL_Project="select a.PID,a.PUID,a.CID,a.CName,a.CTel,a.CFax,a.Contact,a.CMobile,a.CEMail,a.CAddress,a.PStatus,a.PName,a.ModelName,a.SeriesModel,a.PE,(select MName from Manager where MUID=a.PE and DelTag='N') PEName,a.Quote,a.ApplyItem,a.Canon,a.SNote,a.StartDate,a.PlanDate,a.CloseDate,a.PNote,a.QuoteDate,a.ReturnDate,a.IFlorin,a.OFlorin,a.InvoiceDate,a.InvoiceCUID,(select CUID from Customer where Deltag='N' and CID = a.CID) as CUID from Project a where Deltag='N' ".$SqlTxt." order by a.PE,a.PID desc;";
		/*
		    (SELECT count( AID ) ACount
		    FROM Agendum
		    WHERE PID
		    IN (
		    SELECT PID FROM Project
		    WHERE Deltag = 'N'
		    AND PE = a.PE $SqlTxt2)
		    AND Deltag = 'N') ACount,
		*/
		$SQL_Project="
		SELECT a.BMUID, 
		    (SELECT MName FROM Manager WHERE MUID = a.BMUID)SPName,
		    (SELECT MEName FROM Manager WHERE MUID = a.BMUID)SPEName,
		    count( a.BMUID ) PCount,
		    (select count( AID ) ACount 
		    from agendum where Deltag = 'N' 
		    and ARID = a.BMUID $SqlTxt2) ACount,
		    (SELECT sum( Charges  ) ChargesI
		    FROM ProjectAccounting
		    WHERE PAMode = 'I'
				AND Deltag = 'N'
		    AND PID
		    IN (
		    SELECT PID FROM Project
		    WHERE Deltag = 'N'
		    AND BMUID = a.BMUID $SqlTxt2)
		    AND Deltag = 'N') ChargesI,
		    (SELECT sum( Charges  ) ChargesO
		    FROM ProjectAccounting
		    WHERE PAMode = 'O'
				AND Deltag = 'N'
		    AND PID
		    IN (
		    SELECT PID FROM Project
		    WHERE Deltag = 'N'
		    AND BMUID = a.BMUID $SqlTxt2)
		    AND Deltag = 'N') ChargesO
		FROM Project a
		WHERE a.Deltag = 'N' $SqlTxt
		GROUP BY a.BMUID
		ORDER BY a.BMUID DESC ;";
		$result_Project=mysqli_query($link,$SQL_Project) or die ("無法執行查詢");
    while(list($SPE,$SPName,$SPEName,$PCount,$ACount,$ChargesI,$ChargesO)=mysqli_fetch_row($result_Project)){
				$ECount++;
				?>
				ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,1).Value =""
				ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,2).Value ="<?php echo $SPEName.$SPName;?>"
				ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,3).Value ="<?php echo $PCount;?>"
				ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,4).Value ="<?php echo $ACount;?>"
				ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,5).Value ="<?php echo $ChargesI;?>"
				ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,6).Value ="<?php echo $ChargesO;?>"
				ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,7).Value ="<?php echo $ChargesI - $ChargesO;?>"
				ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,8).Value =""
				ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,9).Value =""
				ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,10).Value =""
				ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,11).Value =""
				ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,12).Value =""
				ProjectAccounting.ActiveSheet.Cells(<?php echo $ECount;?>,13).Value =""
				<?php
				}
		mysqli_free_result($result_Project);
		mysqli_close($link);
		?>
		ProjectAccounting.ActiveSheet.Range("A1:N<?php echo $ECount;?>").Font.Color="blue"
		ProjectAccounting.ActiveSheet.Range("A1:N<?php echo $ECount;?>").Font.Name="Courier New"
		ProjectAccounting.ActiveSheet.Range("A1:N<?php echo $ECount;?>").Font.Size="11"
		ProjectAccounting.ActiveSheet.Range("A1:N<?php echo $ECount;?>").Columns.AutoFit
		ProjectAccounting.ActiveSheet.Range("A1:N<?php echo $ECount;?>").NumberFormat ="General"

		ProjectAccounting.ActiveSheet.Range("A<?php echo $ECount;?>:J<?php echo $ECount;?>").Font.Bold=true
		<?php
		$TitleLineArr = split(",",$TitleLine);
		$count_i=count($TitleLineArr);
		for ($tmp=0;$tmp<=$count_i-1;$tmp++){
				?>
				ProjectAccounting.ActiveSheet.Range("A<?php echo $TitleLineArr[$tmp];?>:N<?php echo $TitleLineArr[$tmp];?>").Font.Color="#000000"
				ProjectAccounting.ActiveSheet.Range("A<?php echo $TitleLineArr[$tmp];?>:N<?php echo $TitleLineArr[$tmp];?>").Font.Bold=true
				ProjectAccounting.ActiveSheet.Range("A<?php echo $TitleLineArr[$tmp]+1;?>:N<?php echo $TitleLineArr[$tmp]+1;?>").Font.Bold=true
				<?php
				}

		$SumLineArr = split(",",$SumLine);
		$count_i=count($SumLineArr);
		for ($tmp=0;$tmp<=$count_i-1;$tmp++){
				?>
				ProjectAccounting.ActiveSheet.Range("A<?php echo $SumLineArr[$tmp];?>:N<?php echo $SumLineArr[$tmp];?>").Font.Bold=true
				<?php
				}
		?>
	End Sub
	</script>
</body>
</html>
