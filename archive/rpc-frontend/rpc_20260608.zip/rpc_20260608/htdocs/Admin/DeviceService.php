<?php
include "CheckPermission.php";
//include "CheckAgendum.php";
include "../global.php";
include "include/page_function.php";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $PageAdminTitle;?></title>
<link href="../type.css" rel="stylesheet" type="text/css" />
<style type="text/css">
<!--
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
}
-->
</style></head>

<body>
<?php
$device_no = $_GET['device_no'];
$page = empty($_GET['page'])?"":$_GET['page'];
if (trim($page) == "") $page = 1;
$page_rows=10;  //每頁筆數
$php_Self = "DeviceService.php";  //分頁web檔名

$button_css = "h4";
$limit_txt =" limit ".(($page-1) * $page_rows).",".$page_rows;
$url_str = "&device_no=".$device_no;

$Sql_str="select DS_send_date,DS_take_date,DS_status from deviceservice where D_no = '".$device_no."' order by DS_no desc;";
$SQL_DeviceService="select DS_send_date,DS_take_date,DS_status from deviceservice where D_no = '".$device_no."' order by DS_no desc ".$limit_txt.";";
$result_DeviceService=mysqli_query($link,$SQL_DeviceService) or die ("無法執行查詢");
?>
<table width="100%" border="0" cellpadding="5" cellspacing="2" class="s2">
  <tr>
	<input type="button" name="add" value="新 增" class="input_bot" onclick="javascript:window.open ('DeviceServiceAdd.php?device_no=<?php echo $device_no;?>','AgendumNote','height=300,width=550,top=200,left=200,scrollbars=yes,status=yes');">
    <td background="../images/table_bg.gif" class="t21">
    送修日期
    </td>
    <td width="auto" align="center" background="../images/table_bg.gif" class="t21">取回日期</td>
    <td width="auto" align="center" background="../images/table_bg.gif" class="t21">儀器狀態</td>
  </tr>
  <?php
  $tmp = 1;
  while(list($DS_send_date,$DS_take_date,$DS_status)=mysqli_fetch_row($result_DeviceService)){
	?>
	<tr<?php if ($tmp%2 == 0) echo " bgcolor=\"#F6F6F6\"";?>>
    <td class="h3"><?php echo $DS_send_date;?></td>
    <td class="h3" align="center"><?php echo $DS_take_date;?></td>
    <td align="center" class="h3"><?php echo $DS_status;?></td>
  </tr>
  <?php
			$tmp++;
			}
	mysqli_free_result($result_DeviceService);
  ?>
</table>
<table width="100%" border="0" cellpadding="5" cellspacing="2" class="s2">
  <tr align="center">
    <td bgcolor="#E8F0C2" class="h4"><?php Page_show($Sql_str,$page_rows,$php_Self,$link,$page,$url_str,$button_css);?></td>
  </tr>
</table>
</body>
</html>
<?php
mysqli_close($link);
?>