﻿<?php
include "CheckPermission.php";
include "../global.php";
include "include/page_function.php";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $PageAdminTitle;?></title>
<link href="../type.css" rel="stylesheet" type="text/css" />
<Script type="text/javascript" language="javascript" src="../script/CheckForm.js"></Script>
<script type="text/JavaScript">
<!--
function SelCustomer(CID,CCID) {
		document.Selform.CID.value=CID;
		document.Selform.CCID.value=CCID;
		document.Selform.submit();
		}
//-->
</script>
</head>

<body>
<table width="520" border="0" align="center" cellpadding="2" cellspacing="0">
  <tr>
    <td align="left"><span class="c2"><b>選擇客戶</b></span>
    </td>
  </tr>
  <tr>
    <td align="left">
    	<table width="100%" border="0" cellpadding="0" cellspacing="0">
    		<form name="form1" action="SelCustomer.php" method="post">
    		<tr>
    			<td align="left" class="h3">關鍵字：<input type="text" name="KeyWord" size="20"> <input type="submit" name="search" value="查詢"></td>
    		</tr>
    		</form>
    	</table>
			<?php
		$SqlTxt="";
    	$QCType = empty($_POST['QCType'])?"":$_POST['QCType'];
    	if (trim($QCType) == "") $QCType = empty($_GET['QCType'])?"":$_GET['QCType'];
    	$KeyWord = empty($_POST['KeyWord'])?"":$_POST['KeyWord'];
    	if (trim($KeyWord) == "") $KeyWord = empty($_GET['KeyWord'])?"":$_GET['KeyWord'];
			if (trim($QCType) != "") $SqlTxt = $SqlTxt." and CType like '%".$QCType."%' ";
    	if (trim($KeyWord) != "") $SqlTxt = $SqlTxt." and (CUID like '%".$KeyWord."%' or CName like '%".$KeyWord."%' or EName like '%".$KeyWord."%' or Contact like '%".$KeyWord."%' or CAddress like '%".$KeyWord."%' or CTel like '%".$KeyWord."%' or CFax like '%".$KeyWord."%' or CMobile like '%".$KeyWord."%' or CEMail like '%".$KeyWord."%')";
			$page = empty($_GET['page'])?"":$_GET['page'];
			if (trim($page) == "") $page = 1;
			$page_rows=15;  //每頁筆數
			$php_Self = "SelCustomer.php";  //分頁web檔名

			$button_css = "h4";
			$limit_txt =" limit ".(($page-1) * $page_rows).",".$page_rows;
			$url_str = "&QCType=".$QCType."&KeyWord=".urlencode($KeyWord);
			$Sql_str="select CID,CUID,CPWD,CName,CTel,CFax,CAddress,CNote from Customer where Deltag='N' ".$SqlTxt." order by CID desc;";
			$SQL_Customer="select CID,CUID,CPWD,CName,CTel,CFax,CAddress,CNote from Customer where Deltag='N' ".$SqlTxt." order by CID desc ".$limit_txt.";";
			$result_Customer=mysqli_query($link,$SQL_Customer) or die ("無法執行查詢");
			?>
    	<table width="100%" border="0" cellpadding="2" cellspacing="2" class="s2">
        <tr align="center">
          <td width="200" background="../images/table_bg.gif" class="t2">公司名稱</td>
          <td width="100" background="../images/table_bg.gif" class="t2">電 話</td>
          <td background="../images/table_bg.gif" class="t2">連絡人</td>
        </tr>
        <?php
        $tmp = 1;
        while(list($CID,$CUID,$CPWD,$CName,$CTel,$CFax,$CAddress,$CNote)=mysqli_fetch_row($result_Customer)){
      	?>
    	  <form name="CForm<?php echo $CID;?>" method="post">
	    	<tr<?php if ($tmp%2 == 0) echo " bgcolor=\"#F6F6F6\"";?>>
          <td class="h3"><?php echo $CName;?></td>
          <td align="center" class="h3"><?php echo $CTel;?></td>
          <td class="h4">
          	<?php
    				$SQL_CustomerContact="select CCID,Contact from CustomerContact where Deltag='N' and CID='".$CID."' order by CCID desc;";
						$result_CustomerContact=mysqli_query($link,$SQL_CustomerContact) or die ("無法執行查詢");
          	?>
          	<select name="CCID">
          		<?php while(list($CCID,$Contact)=mysqli_fetch_row($result_CustomerContact)){ ?>
          		<option value="<?php echo $CCID;?>"><?php echo $Contact;?></option>
          		<?php
          		}
          		mysqli_free_result($result_CustomerContact);
          		?>
          	</select>　
          	<input type="button" name="button" class="input_bot" value="選擇" onclick="javascript:SelCustomer(<?php echo $CID;?>,document.CForm<?php echo $CID;?>.CCID.value);">
          </td>
        </tr>
    		</form>
        <?php
      			$tmp++;
      			}
      	mysqli_free_result($result_Customer);
        ?>
      </table>
      <table width="100%" border="0" cellpadding="2" cellspacing="2" class="s2">
        <tr align="center">
          <td bgcolor="#E8F0C2" class="h4"><?php Page_show($Sql_str,$page_rows,$php_Self,$link,$page,$url_str,$button_css);?></td>
        </tr>
      </table>

    </td>
  </tr>
</table>
<form name="Selform" action="SelCustomerDB.php" method="post">
	<input type="hidden" name="CID">
	<input type="hidden" name="CCID">
</form>
</body>
</html>
<?php
mysqli_close($link);
?>