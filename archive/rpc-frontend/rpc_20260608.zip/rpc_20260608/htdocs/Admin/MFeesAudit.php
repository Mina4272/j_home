﻿<?php	
include "CheckPermission.php";
include "CheckMFees.php";
include "../global.php";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $PageAdminTitle;?></title>
<link href="../type.css" rel="stylesheet" type="text/css" />
<style type="text/css">
<!--
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
}
-->
</style>
<link href="../script/DatePicker.css" rel="stylesheet" type="text/css" />
<Script LANGUAGE="Javascript" SRC="../script/DatePicker.js"></Script>
<Script type="text/javascript" language="javascript" src="../script/CheckForm.js"></Script>
<script type="text/JavaScript">
<!--
function jsCheck() 
		{
		//if (ChkImp('MFCNote',document.form1.MFCNote.value,'簽核備註') == false) return false;
		}
//-->
</script>
</head>
<body>
<?php
$MFID = $_GET['MFID'];
if (trim($MFID) == "")
		{
		mysqli_close($link);
		?>
		<script type="text/JavaScript">
			<!--
			alert ("查無資料，請冾網站管理人員！");
			self.close();
			//-->
		</script>
		<?php
		exit;
		}
$SQL_ManagerFees="select MUID,MFType,MFDate,date_format(MFDate,'%Y'),date_format(MFDate,'%m'),date_format(MFDate,'%d'),MFCause,MFComment,Quantity,MFNote,MFCheck,(select MName from Manager where deltag ='N' and MUID=ManagerFees.MUID) MName,(select MEName from Manager where deltag ='N' and MUID=ManagerFees.MUID) MEName from ManagerFees where Deltag='N' and MFID=".$MFID.";";
//echo $SQL_ManagerFees;
$result_ManagerFees=mysqli_query($link,$SQL_ManagerFees) or die ("無法執行查詢");
if (mysqli_num_rows($result_ManagerFees) == 0)
		{
		mysqli_free_result($result_Manager);
		mysqli_close($link);
		?>
		<SCRIPT language=javascript>
		<!--
		alert ("查無資料，請冾網站管理人員！"); 
		self.close();
		//-->
		</SCRIPT>
		<?php 	
		exit;
		}
list($MUID,$MFType,$MFDate,$MFYear,$MFMonth,$MFDay,$MFCause,$MFComment,$Quantity,$MFNote,$MFCheck,$MName,$MEName)=mysqli_fetch_row($result_ManagerFees);
mysqli_free_result($result_ManagerFees);

if (trim($MFCheck) != "W")
		{
		mysqli_close($link);
		?>
		<script type="text/JavaScript">
			<!--
			alert ("此申請單已簽核，不需再作簽核！");
			self.close();
			//-->
		</script>
		<?php
		exit;
		}
?>
<table width="100%" border="0" cellpadding="0" cellspacing="0">
	<tr>
		<td>
    	<table width="100%" border="0" cellpadding="0" cellspacing="0">
    		<tr height="30">
					<td width="15" background="../images/table_bg.gif"></td>
    			<td class="c3" background="../images/table_bg.gif"><b>申請單審核</b></td>
    		</tr>
    	</table>
    	<table width="100%" border="0" cellpadding="0" cellspacing="0">
        <form name="form1" method="post" action="MFeesAuditDB.php" enctype="multipart/form-data" onSubmit="return jsCheck();">
        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
					<td width="15"></td>
          <td width="160" align="right" class="c3">申請人：</td>
          <td class="h3"><?php echo $MEName.$MName;?>
          	<input type="hidden" name="MFID" value="<?php echo $MFID;?>">
          </td>
        </tr>
        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
					<td width="15"></td>
          <td class="c3" align="right">申請項目：</td>
          <td class="h3">
          	<?php
        		if (trim($MFType) == "A") {
        				echo "加班費";
        				$MFUnit="小時";
        				}
        		else if (trim($MFType) == "B") {
        				echo "交通費-公里";
        				$MFUnit="公里";
        				}
        		else if (trim($MFType) == "C"){
					echo "交通費-實報實銷/餐費";
					$MFUnit="元";
				}
          	?>
          </td>
        </tr>
        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
					<td width="15"></td>
          <td class="c3" align="right">申請日期：</td>
          <td class="h3"><?php echo $MFDate;?></td>
        </tr>
        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
					<td width="15"></td>
          <td class="c3" align="right">申請事由：</td>
          <td class="h3"><?php echo $MFCause;?></td>
        </tr>
        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
					<td width="15"></td>
          <td class="c3" align="right">申請說明：</td>
          <td class="h3"><?php echo $MFComment;?></td>
        </tr>
        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
					<td width="15"></td>
          <td class="c3" align="right">申請數量：</td>
          <td class="h3"><?php echo $Quantity;?><?php echo $MFUnit;?></td>
        </tr>
        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
					<td width="15"></td>
          <td class="c3" align="right">備註：</td>
          <td class="h3"><?php echo $MFNote;?></td>
        </tr>
        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
					<td width="15"></td>
          <td class="c3" align="right">是否核準：</td>
          <td class="h3">
            <input name="MFCheckAns" type="radio" value="Y" checked /> 同意<br>
            <input name="MFCheckAns" type="radio" value="N" /> 不同意
          </td>
        </tr>
        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
					<td width="15"></td>
          <td class="c3" align="right">簽核備註：</td>
          <td class="h3">
            <input name="MFCNote" type="text" size="40" />
          </td>
        </tr>
        <tr height="40" align="center">
					<td width="15"></td>
          <td colspan="2" class="h3">
          	<input type="submit" name="submit" class="input_bot" value="送 出">
          </td>
        </tr>
	      </form>
      </table>
		</td>
	</tr>
</table>
</body>
</html>
<?php
mysqli_close($link);
?>