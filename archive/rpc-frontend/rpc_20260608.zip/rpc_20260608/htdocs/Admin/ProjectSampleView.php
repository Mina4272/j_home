﻿<?php
include "CheckPermission.php";
include "CheckProject.php";
include "../global.php";
include "include/page_function.php";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $PageAdminTitle;?></title>
<link href="../type.css" rel="stylesheet" type="text/css" />
<style type="text/css">
<!--
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
}
-->
</style></head>

<body>
<?php
$SqlTxt = "";
$PID = $_GET['PID'];
$page = empty($_GET['page'])?"":$_GET['page'];
if (trim($page) == "") $page = 1;
$page_rows=10;  //每頁筆數
$php_Self = "ProjectSample.php";  //分頁web檔名

$button_css = "h4";
$limit_txt =" limit ".(($page-1) * $page_rows).",".$page_rows;
$url_str = "&PID=".$PID;
$Sql_str="select PSID,PSType,PSDate,PSCount,PSMode,PSPersonnel,SPlace,IPlace,PSend,PSNote,PSFile,AddUser,AddDate,ProcUser,ProcDate from ProjectSample where Deltag='N' and PID = '".$PID."' ".$SqlTxt." order by PSID desc;";
$SQL_ProjectSample="select PSID,PSType,PSDate,PSCount,PSMode,PSPersonnel,SPlace,IPlace,PSend,PSNote,PSFile,AddUser,AddDate,ProcUser,ProcDate from ProjectSample where Deltag='N' and PID = '".$PID."' ".$SqlTxt." order by PSID desc ".$limit_txt.";";
$result_ProjectSample=mysqli_query($link,$SQL_ProjectSample) or die ("無法執行查詢");
?>
<table width="100%" border="0" cellpadding="5" cellspacing="2" class="s2">
  <tr>
    <td width="70" align="center" background="../images/table_bg.gif" class="t21">收樣/送樣</td>
    <td width="60" align="center" background="../images/table_bg.gif" class="t21">日期</td>
    <td width="35" align="center" background="../images/table_bg.gif" class="t21">數量</td>
    <td width="70" align="center" background="../images/table_bg.gif" class="t21">方式</td>
    <td width="60" align="center" background="../images/table_bg.gif" class="t21">收入人<br>收入地</td>
    <td width="60" align="center" background="../images/table_bg.gif" class="t21">送出人<br>送出地</td>
    <td width="60" align="center" background="../images/table_bg.gif" class="t21">相關檔案</td>
    <td align="center" background="../images/table_bg.gif" class="t21">備註</td>
  </tr>
  <?php
  $tmp = 1;
  while(list($PSID,$PSType,$PSDate,$PSCount,$PSMode,$PSPersonnel,$SPlace,$IPlace,$PSend,$PSNote,$PSFile,$AddUser,$AddDate,$ProcUser,$ProcDate)=mysqli_fetch_row($result_ProjectSample)){
	?>
	<tr<?php if ($tmp%2 == 0) echo " bgcolor=\"#F6F6F6\"";?>>
    <td class="h3" align="center"><?php if (trim($PSType) == "I") echo "收入樣品"; else if (trim($PSType) == "O") echo "送出樣品";?></td>
    <td class="h3" align="center"><?php echo $PSDate;?></td>
    <td class="h3" align="center"><?php echo $PSCount;?></td>
    <td class="h3" align="center"><?php echo $PSMode;?></td>
    <td class="h3" align="center"><?php echo $PSPersonnel."<br>".$SPlace;?></td>
    <td class="h3" align="center"><?php echo $PSend."<br>".$IPlace;?></td>
	  <td class="h3" align="center">
    	<?php if (trim($PSFile) != "") {?>
    		<input type="button" name="edit" value="下 載" class="input_bot" onclick="javascript:location.href='getfile.php?FolderName=Admin\\PSFile&FileName=<?php echo $PSFile;?>';">
    	<?php }?>
    </td>
    <td class="h3" align="center"><?php echo $PSNote;?></td>
  </tr>
  <?php
			$tmp++;
			}
	mysqli_free_result($result_ProjectSample);
  ?>
</table>
<table width="100%" border="0" cellpadding="5" cellspacing="2" class="s2">
  <tr align="center">
    <td bgcolor="#E8F0C2" class="h4"><?php Page_show($Sql_str,$page_rows,$php_Self,$link,$page,$url_str,$button_css);?></td>
  </tr>
</table>
</body>
</html>
<?php
mysqli_close($link);
?>