﻿<?php
include "CheckPermission.php";
//include "CheckEmployeePay.php";
include "../global.php";
require_once 'PHPExcel.php';

$SqlTxt="";
$Txt="";
$MID = $_POST['MID'];
if(trim($MID)!=""){
	$SqlTxt .= "and te.MID = '".$MID."'";
	$Txt .="and MID = '".$MID."'";
}
//echo "123456789";

$objPHPExcel = new PHPExcel();
$objPHPExcel->setActiveSheetIndex(0);

$objPHPExcel->getActiveSheet()->mergeCells('A1:H1');
$objPHPExcel->getActiveSheet()->getStyle('A1:H1')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
$objPHPExcel->getActiveSheet()->setCellValue('A1',"全威驗證科技有限公司");
$objPHPExcel->getActiveSheet()->getStyle('A1')->getFont()->setSize(20);
$objPHPExcel->getActiveSheet()->getStyle('A2:H2')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
$objPHPExcel->getActiveSheet()->mergeCells('A2:H2');

$objPHPExcel->getActiveSheet()->setCellValue('A2',"員工教育訓練紀錄表");
$objPHPExcel->getActiveSheet()->getStyle('A2')->getFont()->setSize(15);
$Ecount=3;

$S="SELECT MID,MName FROM manager where Deltag= 'N' and IsLeft = 'N' ".$Txt."";
$r=mysqli_query($link,$S) or die ("無法執行查詢");
while(list($M,$MName)=mysqli_fetch_row($r)){
	
$objPHPExcel->getActiveSheet()->setCellValue('A'.$Ecount,$MName);

$Ecount++;
$objPHPExcel->getActiveSheet()->setCellValue('A'.$Ecount,"課程主要名稱");
$objPHPExcel->getActiveSheet()->setCellValue('B'.$Ecount,"課程名稱");
$objPHPExcel->getActiveSheet()->setCellValue('C'.$Ecount,"課程大綱");
$objPHPExcel->getActiveSheet()->setCellValue('D'.$Ecount,"訓練類別(內訓/外訓)");
$objPHPExcel->getActiveSheet()->setCellValue('E'.$Ecount,"課程講師");
$objPHPExcel->getActiveSheet()->setCellValue('F'.$Ecount,"上課日期");
$objPHPExcel->getActiveSheet()->setCellValue('G'.$Ecount,"上課時數");
$objPHPExcel->getActiveSheet()->setCellValue('H'.$Ecount,"成績");
$objPHPExcel->getActiveSheet()->setCellValue('I'.$Ecount,"合格/不合格");
$Ecount++;

$SQL="SELECT m.MID,m.MName,tc.TCTTitle,t.TTitle,t.TTrain,t.TContent,t.outtext,t.Lecturer,t.TDate,t.THour,te.Grade,te.checkGrade 
		FROM trainingexam te 
		INNER join manager m on te.MID = m.MID and m.Deltag='N' 
		INNER join training t on te.TID = t.TID and t.Deltag='N'
		left join trainingcamp tc on t.TCID = tc.TCID and tc.Deltag='N'
		where te.Deltag='N' ".$SqlTxt." order by t.TDate desc";

$result=mysqli_query($link,$SQL) or die ("無法執行查詢");
while(list($MID,$MName,$TCTTitle,$TTitle,$TTrain,$TContent,$outtext,$Lecturer,$TDate,$THour,$Grade,$checkGrade)=mysqli_fetch_row($result)){
	$T;
	if($TTrain =="in"){
		$T  = "內訓";
	}elseif($TTrain =="out"){
		$T = "外訓";
	}
	
	$CG;
	if($checkGrade == 'Y'){
		$CG="合格";	
	}else{
		$CG="不合格";
	}
	$G;
	if($Grade == "0"){ $G = "N/A";}else{ $G = $Grade;}
	//echo $M;
	//echo "<BR/>";
	//echo $MID;
	//echo "<BR/>";
	//exit;
	if($M == $MID){
		$objPHPExcel->getActiveSheet()->setCellValue('A'.$Ecount,$TCTTitle);
		$objPHPExcel->getActiveSheet()->setCellValue('B'.$Ecount,$TTitle);
		$objPHPExcel->getActiveSheet()->setCellValue('C'.$Ecount,str_replace("<br>"," ",$TContent));
		$objPHPExcel->getActiveSheet()->setCellValue('D'.$Ecount,$T);
		$objPHPExcel->getActiveSheet()->setCellValue('E'.$Ecount,$Lecturer);
		$objPHPExcel->getActiveSheet()->setCellValue('F'.$Ecount,$TDate);
		$objPHPExcel->getActiveSheet()->setCellValue('G'.$Ecount,$THour);
		$objPHPExcel->getActiveSheet()->setCellValue('H'.$Ecount,$G);
		$objPHPExcel->getActiveSheet()->setCellValue('I'.$Ecount,$CG);
		$Ecount++;
	}
	
		
	
}

}
//exit;
mysqli_free_result($r);
mysqli_free_result($result);
mysqli_close($link);

$objPHPExcel->getActiveSheet()->setTitle('TrainingExport');

ob_end_clean();

header('Content-Type: application/vnd.ms-excel');
header('Content-Disposition: attachment;filename="TrainingExport.xls"');
header('Cache-Control: max-age=0');
$objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel5');
$objWriter->save('php://output');
exit;

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $PageAdminTitle;?></title>
<link href="style.css" rel="stylesheet" type="text/css" />
<body>
<table winth="1000" border="0">
	<tr>
		<td colspan="2"><font color=blue>若您無法正常觀看此報表！請下載此 <a href="owc11.zip" target="_File"><font color=red><b>元件</b></font></a> <font color=blue>安裝至您的電腦。</font></td>
	</tr>
</table>
<object id=EmployeePay classid=CLSID:0002E559-0000-0000-C000-000000000046 style="width:100%;height:90%"></object>
<script language=vbscript>
	Sub Window_OnLoad()
	Set chConstants = EmployeePay.Constants
	EmployeePay.ActiveSheet.Cells.Clear
	EmployeePay.Worksheets(1).Select
	EmployeePay.ActiveSheet.Name ="EmployeePay"

	EmployeePay.ActiveSheet.Cells(1,1).Value ="帳號"
	EmployeePay.ActiveSheet.Cells(1,2).Value ="交易金額"
	EmployeePay.ActiveSheet.Cells(1,3).Value ="行庫代號"
	EmployeePay.ActiveSheet.Cells(1,4).Value ="身份證號"
	EmployeePay.ActiveSheet.Cells(1,5).Value ="email帳號"
	EmployeePay.ActiveSheet.Cells(1,6).Value ="受扣款用戶編號"
	EmployeePay.ActiveSheet.Cells(1,7).Value ="全威驗證科技有限公司"
	EmployeePay.ActiveSheet.Cells(1,8).Value ="部門別"
	EmployeePay.ActiveSheet.Cells(1,9).Value ="本薪"
	EmployeePay.ActiveSheet.Cells(1,10).Value ="職務加給"
	EmployeePay.ActiveSheet.Cells(1,11).Value ="加班費"
	EmployeePay.ActiveSheet.Cells(1,12).Value ="交通費-公里數計算"
	EmployeePay.ActiveSheet.Cells(1,13).Value ="交通費-實報實銷"
	EmployeePay.ActiveSheet.Cells(1,14).Value ="績效獎金"
	EmployeePay.ActiveSheet.Cells(1,15).Value ="勞退公司提撥"
	EmployeePay.ActiveSheet.Cells(1,16).Value ="勞保費-公司負擔"
	EmployeePay.ActiveSheet.Cells(1,17).Value ="健保費-公司負擔"
	EmployeePay.ActiveSheet.Cells(1,18).Value ="受款名目(金額10)"
	EmployeePay.ActiveSheet.Cells(1,19).Value ="勞保費-員工負擔"
	EmployeePay.ActiveSheet.Cells(1,20).Value ="健保費-員工負擔"
	EmployeePay.ActiveSheet.Cells(1,21).Value ="事假"
	EmployeePay.ActiveSheet.Cells(1,22).Value ="病假"
	EmployeePay.ActiveSheet.Cells(1,23).Value ="勞退公司提撥"
	EmployeePay.ActiveSheet.Cells(1,24).Value ="勞保費-公司負擔 "
	EmployeePay.ActiveSheet.Cells(1,25).Value ="健保費-公司負擔 "
	EmployeePay.ActiveSheet.Cells(1,26).Value ="受款名目(金額18)"
	EmployeePay.ActiveSheet.Cells(1,27).Value ="受款名目(金額19)"
	EmployeePay.ActiveSheet.Cells(1,28).Value ="受款名目(金額20)"
	EmployeePay.ActiveSheet.Cells(1,29).Value ="應稅金額"
	EmployeePay.ActiveSheet.Cells(1,30).Value ="勞退新制雇主提撥金"
	EmployeePay.ActiveSheet.Cells(1,31).Value ="備註"
<?php  
$ECount=2;
while(list($EPID,$MID,$BCode,$BAccount,$MName,$EmployeeNo,$MPID,$EMail,$Departments,$EPDate,$EPYear,$EPDay,$EPay,$Salary,$Allowance,$Overtime,$Transportation1,$Transportation2,$Bonus,$CRetirement,$CLabor,$CHealth,$ELabor,$EHealth,$PLeave,$SickLeave,$EVAmount,$Other,$OtherDesc)=mysqli_fetch_row($result_EmployeePay)){
  	if (trim($Departments) == "A") $Departments="工程部";
  	else if (trim($Departments) == "B") $Departments="國際認證部";
  	else if (trim($Departments) == "C") $Departments="業務部";
		?>
		EmployeePay.ActiveSheet.Cells(<?php echo $ECount;?>,1).Value ="'<?php echo $BAccount;?>"
		EmployeePay.ActiveSheet.Cells(<?php echo $ECount;?>,2).Value ="<?php echo $EPay;?>"
		EmployeePay.ActiveSheet.Cells(<?php echo $ECount;?>,3).Value ="<?php echo $BCode;?>"
		EmployeePay.ActiveSheet.Cells(<?php echo $ECount;?>,4).Value ="<?php echo $MPID;?>"
		EmployeePay.ActiveSheet.Cells(<?php echo $ECount;?>,5).Value ="<?php echo $EMail;?>"
		EmployeePay.ActiveSheet.Cells(<?php echo $ECount;?>,6).Value ="<?php echo $EmployeeNo;?>"
		EmployeePay.ActiveSheet.Cells(<?php echo $ECount;?>,7).Value ="全威驗證科技有限公司"
		EmployeePay.ActiveSheet.Cells(<?php echo $ECount;?>,8).Value ="<?php echo $Departments;?>"
		EmployeePay.ActiveSheet.Cells(<?php echo $ECount;?>,9).Value ="<?php echo $Salary;?>"
		EmployeePay.ActiveSheet.Cells(<?php echo $ECount;?>,10).Value ="<?php echo $Allowance;?>"
		EmployeePay.ActiveSheet.Cells(<?php echo $ECount;?>,11).Value ="'<?php echo $Overtime;?>"
		EmployeePay.ActiveSheet.Cells(<?php echo $ECount;?>,12).Value ="<?php echo $Transportation1;?>"
		EmployeePay.ActiveSheet.Cells(<?php echo $ECount;?>,13).Value ="<?php echo $Transportation2;?>"
		EmployeePay.ActiveSheet.Cells(<?php echo $ECount;?>,14).Value ="<?php echo $Bonus;?>"
		EmployeePay.ActiveSheet.Cells(<?php echo $ECount;?>,15).Value ="<?php echo $CRetirement;?>"
		EmployeePay.ActiveSheet.Cells(<?php echo $ECount;?>,16).Value ="<?php echo $CLabor;?>"
		EmployeePay.ActiveSheet.Cells(<?php echo $ECount;?>,17).Value ="<?php echo $CHealth;?>"
		EmployeePay.ActiveSheet.Cells(<?php echo $ECount;?>,18).Value ="<?php echo ($EVAmount+$Other);?>"
		EmployeePay.ActiveSheet.Cells(<?php echo $ECount;?>,19).Value ="<?php echo $ELabor;?>"
		EmployeePay.ActiveSheet.Cells(<?php echo $ECount;?>,20).Value ="<?php echo $EHealth;?>"
		EmployeePay.ActiveSheet.Cells(<?php echo $ECount;?>,21).Value ="<?php echo $PLeave;?>"
		EmployeePay.ActiveSheet.Cells(<?php echo $ECount;?>,22).Value ="<?php echo $SickLeave;?>"
		EmployeePay.ActiveSheet.Cells(<?php echo $ECount;?>,23).Value ="<?php echo $CRetirement;?>"
		EmployeePay.ActiveSheet.Cells(<?php echo $ECount;?>,24).Value ="<?php echo $CLabor;?>"
		EmployeePay.ActiveSheet.Cells(<?php echo $ECount;?>,25).Value ="<?php echo $CHealth;?>"
		EmployeePay.ActiveSheet.Cells(<?php echo $ECount;?>,26).Value =""
		EmployeePay.ActiveSheet.Cells(<?php echo $ECount;?>,27).Value =""
		EmployeePay.ActiveSheet.Cells(<?php echo $ECount;?>,28).Value =""
		EmployeePay.ActiveSheet.Cells(<?php echo $ECount;?>,29).Value =""
		EmployeePay.ActiveSheet.Cells(<?php echo $ECount;?>,30).Value ="<?php echo $CRetirement;?>"
		EmployeePay.ActiveSheet.Cells(<?php echo $ECount;?>,31).Value =""
		<?php
		$ECount++;
		}
mysqli_free_result($result_EmployeePay);
mysqli_close($link);
?>

		EmployeePay.ActiveSheet.Range("A1:AE<?php echo $ECount;?>").Font.Color="blue"
		EmployeePay.ActiveSheet.Range("A1:AE<?php echo $ECount;?>").Font.Name="Courier New"
		EmployeePay.ActiveSheet.Range("A1:AE<?php echo $ECount;?>").Font.Size="11"
		EmployeePay.ActiveSheet.Range("A1:AE<?php echo $ECount;?>").Columns.AutoFit
		EmployeePay.ActiveSheet.Range("A1:AE<?php echo $ECount;?>").NumberFormat ="General"

		EmployeePay.ActiveSheet.Range("A1:AE1").Font.Bold=true
		EmployeePay.ActiveSheet.Range("A1:AE1").Font.Color="#000000"
		EmployeePay.ActiveSheet.Range("A1:AE1").Font.Bold=true
		EmployeePay.ActiveSheet.Range("A1:AE1").Font.Bold=true
		EmployeePay.ActiveSheet.Range("A1:AE1").Font.Bold=true

	End Sub
	</script>
</body>
</html>
