﻿<?php	
include "CheckPermission.php";
include "CheckAgendum.php";
include "../global.php";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $PageAdminTitle;?></title>
<link href="../type.css" rel="stylesheet" type="text/css" />
<style type="text/css">
<!--
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
}
-->
</style>
<link href="../script/DatePicker.css" rel="stylesheet" type="text/css" />
<Script LANGUAGE="Javascript" SRC="../script/DatePicker.js"></Script>
<Script type="text/javascript" language="javascript" src="../script/CheckForm.js"></Script>
<script type="text/JavaScript">
<!--
function jsCheck() 
		{
		if (ChkDate('AYear',document.form1.AYear.value,document.form1.AMonth.value,document.form1.ADay.value,'派案時間') == false) return false;
		if (ChkDate('AEYear',document.form1.AEYear.value,document.form1.AEMonth.value,document.form1.AEDay.value,'預計完成時間') == false) return false;
		if (jsTrim(document.form1.ACYear.value) != "" || jsTrim(document.form1.ACMonth.value) != "" || jsTrim(document.form1.ACDay.value) != "") if (ChkDate('ACYear',document.form1.ACYear.value,document.form1.ACMonth.value,document.form1.ACDay.value,'結案時間') == false) return false;
		if (ChkImp('AItem',document.form1.AItem.value,'項目/測試項目') == false) return false;
		if (jsTrim(document.form1.PID.value) == "" && document.form1.Attribute.selectedIndex == 0)
				{
				alert ('請選擇連結案件！');
				document.form1.SelPID.focus();
				return false;
				}
		//if (jsTrim(document.form1.CName.value) == "")
		//		{
		//		alert ('請選擇所屬客戶！');
		//		document.form1.SelCID.focus();
		//		return false;
		//		}
		}
function ChkAttribute() 
		{
		document.getElementById('PNamePreview').style.display = 'none';
		document.getElementById('PNamePreview').innerHTML = '';
		document.form1.PID.value='';
		document.getElementById('CNamePreview').style.display = 'none';
		document.getElementById('CNamePreview').innerHTML = '';
		document.form1.CID.value='';
		document.form1.CName.value='';
		document.getElementById('CTelPreview').style.display = 'none';
		document.getElementById('CTelPreview').innerHTML = '';
		document.form1.CTel.value='';
		document.getElementById('CFaxPreview').style.display = 'none';
		document.getElementById('CFaxPreview').innerHTML = '';
		document.form1.CFax.value='';
		document.getElementById('CAddressPreview').style.display = 'none';
		document.getElementById('CAddressPreview').innerHTML = '';
		document.form1.CAddress.value='';
		document.form1.Contact.value='';
		document.form1.CMobile.value='';
		document.form1.CEMail.value='';
		}
function SelCust() {
		if (document.form1.Attribute.value == "A") window.open ('SelProject.php','SelProject','height=300,width=550,top=200,left=200,scrollbars=yes,status=yes');
		else if (document.form1.Attribute.value == "B" || document.form1.Attribute.value == "C") window.open ('SelCustomer.php','SelCustomer','height=300,width=550,top=200,left=200,scrollbars=yes,status=yes');
		}
//-->
</script>
</head>
<body>
<?php include "top.php";?>
<?php
$AID = $_GET['AID'];
$page = $_GET['page'];
$KeyWord = $_GET['KeyWord'];
$QAStatus = $_GET['QAStatus'];
$QASID = $_GET['QASID'];
$QARID = $_GET['QARID'];
$QACID = $_GET['QACID'];
$Late = $_GET['Late'];
if (trim($AID) == "")
		{
		mysqli_close($link);
		?>
		<script type="text/JavaScript">
			<!--
			alert ("查無資料，請冾網站管理人員！");
			history.go(-1);
			//-->
		</script>
		<?php
		exit;
		}
$SQL_Agendum="select AUID,ASID,ARID,ACID,CheckProc,ADate,date_format(ADate,'%Y'),date_format(ADate,'%m'),date_format(ADate,'%d'),AEDate,date_format(AEDate,'%Y'),date_format(AEDate,'%m'),date_format(AEDate,'%d'),ACDate,date_format(ACDate,'%Y'),date_format(ACDate,'%m'),date_format(ACDate,'%d'),AStatus,AItem,Attribute,PID,CID,CName,CTel,CFax,Contact,CMobile,CEMail,CAddress,AFile,ANote,AddUser,AddDate,ProcUser,ProcDate,(select CLevel from Customer where CID=Agendum.CID) CLevel,(select CFees from Customer where CID=Agendum.CID) CFees,(select CRecord from Customer where CID=Agendum.CID) CRecord,(select CRecordTxt from Customer where CID=Agendum.CID) CRecordTxt from Agendum where Deltag='N' and AID = '".$AID."';";
$result_Agendum=mysqli_query($link,$SQL_Agendum) or die ("無法執行查詢");
if (mysqli_num_rows($result_Agendum) == 0)
		{
		mysqli_free_result($result_Agendum);
		mysqli_close($link);
		?>
		<SCRIPT language=javascript>
		<!--
		alert ("查無資料，請冾網站管理人員！"); 
		history.go(-1);
		//-->
		</SCRIPT>
		<?php 	
		exit;
		}
list($AUID,$ASID,$ARID,$ACID,$CheckProc,$ADate,$AYear,$AMonth,$ADay,$AEDate,$AEYear,$AEMonth,$AEDay,$ACDate,$ACYear,$ACMonth,$ACDay,$AStatus,$AItem,$Attribute,$PID,$CID,$CName,$CTel,$CFax,$Contact,$CMobile,$CEMail,$CAddress,$AFile,$ANote,$AddUser,$AddDate,$ProcUser,$ProcDate,$CLevel,$CFees,$CRecord,$CRecordTxt)=mysqli_fetch_row($result_Agendum);
mysqli_free_result($result_Agendum);
if (trim($PID)=="0") $PID = "";
if (trim($CID)=="0") $CID = "";
?>
<table width="100%" border="0" cellspacing="0" cellpadding="5">
	<tr>
    <td width="160" height="600" align="left" valign="top">
			<?php include "menu.php";?>
    </td>
    <td valign="top">
    	<table width="100%" border="0" cellpadding="0" cellspacing="0">
    		<tr>
    			<td>
			    	<table width="750" border="0" cellpadding="0" cellspacing="0">
			    		<tr height="30">
			    			<td class="c2"><b>修改事項處理</b></td>
			    		</tr>
			    	</table>
			    	<table width="750" border="0" cellpadding="0" cellspacing="0">
			        <form name="form1" method="post" action="AgendumEditDB.php" enctype="multipart/form-data" onSubmit="return jsCheck();">
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td width="150" align="right" class="c3">案件編號：</td>
			          <td class="h3"><font color=blue><?php echo $AUID;?></font>
			          	<input name="AID" type="hidden" id="AID" value="<?php echo $AID;?>" />
			          	<input name="page" type="hidden" id="page" value="<?php echo $page;?>" />
			          	<input name="KeyWord" type="hidden" id="KeyWord" value="<?php echo $KeyWord;?>" />
			          	<input name="QAStatus" type="hidden" id="QAStatus" value="<?php echo $QAStatus;?>" />
			          	<input name="QASID" type="hidden" id="QASID" value="<?php echo $QASID;?>" />
			          	<input name="QARID" type="hidden" id="QARID" value="<?php echo $QARID;?>" />
			          	<input name="QARID" type="hidden" id="QACID" value="<?php echo $QACID;?>" />
			          	<input name="QARID" type="hidden" id="Late" value="<?php echo $Late;?>" />
			         	</td>
			        </tr>
			        <?php
							$SQL_Manager="select MName,MEName from Manager where Deltag='N' and MUID='".$ASID."';";
							$result_Manager=mysqli_query($link,$SQL_Manager) or die ("無法執行查詢");
							list($ASName,$ASEName)=mysqli_fetch_row($result_Manager);
							mysqli_free_result($result_Manager);
			        ?>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3"><font color=red><b>*</b></font>派案人：</td>
			          <td class="h3"><?php echo $ASEName.$ASName;?></td>
			        </tr>
			        <?php
			        if (trim($CheckProc) == "N") {
								$SQL_Manager="select MUID,MName,MEName from Manager where Deltag='N' and IsLeft='N';";
								$result_Manager=mysqli_query($link,$SQL_Manager) or die ("無法執行查詢");
				        ?>
				        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
				          <td align="right" class="c3"><font color=red><b>*</b></font>接案人：</td>
				          <td class="h3">
				          	<select id="ARID" name="ARID">
				          		<?php while(list($MUID,$MName,$MEName)=mysqli_fetch_row($result_Manager)){?>
				          		<option value="<?php echo $MUID;?>"<?php if (trim($MUID) == trim($ARID)) echo " selected";?>><?php echo $MEName.$MName;?></option>
				          		<?php }?>
				          	</select>
				          </td>
				        </tr>
				        <?php mysqli_free_result($result_Manager);?>
				        <?php
								$SQL_Manager="select MUID,MName,MEName from Manager where Deltag='N' and IsLeft='N';";
								$result_Manager=mysqli_query($link,$SQL_Manager) or die ("無法執行查詢");
				        ?>
				        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
				          <td align="right" class="c3"><font color=red><b>*</b></font>審核人：</td>
				          <td class="h3">
				          	<select id="ACID" name="ACID">
				          		<?php while(list($MUID,$MName,$MEName)=mysqli_fetch_row($result_Manager)){?>
				          		<option value="<?php echo $MUID;?>"<?php if (trim($MUID) == trim($ACID)) echo " selected";?>><?php echo $MEName.$MName;?></option>
				          		<?php }?>
				          	</select> 
				          </td>
				        </tr>
				        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
				          <td align="right" class="c3"><font color=red><b>*</b></font>派案確認：</td>
				          <td class="h3"><font color=red>
				          	<input type="radio" id="CheckProc" name="CheckProc" value="N"> 否 
				          	<input type="radio" id="CheckProc" name="CheckProc" value="Y" checked> 是 <br>
				          	(確認後系統會自動 E-Mail 通知接案人，並無法再作修改接案人及審核人)</font>
				          </td>
				        </tr>
			        	<?php
			        	mysqli_free_result($result_Manager);
			        	}
			        else if (trim($CheckProc) == "Y") {
								$SQL_Manager="select MName,MEName from Manager where MUID='".$ARID."' and MUID <> 'jacky' and IsLeft='N';";
								$result_Manager=mysqli_query($link,$SQL_Manager) or die ("無法執行查詢");
				        list($ARName,$AREName)=mysqli_fetch_row($result_Manager);
			        	mysqli_free_result($result_Manager);
			        	?>
				        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
				          <td align="right" class="c3"><font color=red><b>*</b></font>接案人：</td>
				          <td class="h3"><?php echo $AREName.$ARName;?></td>
				        </tr>
			        	<?php
								$SQL_Manager="select MName,MEName from Manager where MUID='".$ACID."' and MUID <> 'jacky' and IsLeft='N';";
								$result_Manager=mysqli_query($link,$SQL_Manager) or die ("無法執行查詢");
				        list($ACName,$ACEName)=mysqli_fetch_row($result_Manager);
			        	mysqli_free_result($result_Manager);
			        	?>
				        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
				          <td align="right" class="c3"><font color=red><b>*</b></font>審核人：</td>
				          <td class="h3"><?php echo $ACEName.$ACName;?></td>
				        </tr>
			        	<?php
			        	}
			        ?>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3"><font color=red><b>*</b></font>派案時間：</td>
			          <td class="h3">
		              <input id="AYear" name="AYear" type="text" size="4" value="<?php echo $AYear;?>" /> 年 
		              <input id="AMonth" name="AMonth" type="text" size="2" value="<?php echo $AMonth;?>" /> 月 
		              <input id="ADay" name="ADay" type="text" size="2" value="<?php echo $ADay;?>" /> 日 
		              <img src="../images/icon.gif" width="16" height="18" style="cursor: hand" onclick="javascript:displayDatePicker('AYear','AMonth','ADay');"/>
			          </td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3"><font color=red><b>*</b></font>預計完成時間：</td>
			          <td class="h3">
		              <input id="AEYear" name="AEYear" type="text" size="4" value="<?php echo $AEYear;?>" /> 年 
		              <input id="AEMonth" name="AEMonth" type="text" size="2" value="<?php echo $AEMonth;?>" /> 月 
		              <input id="AEDay" name="AEDay" type="text" size="2" value="<?php echo $AEDay;?>" /> 日 
		              <img src="../images/icon.gif" width="16" height="18" style="cursor: hand" onclick="javascript:displayDatePicker('AEYear','AEMonth','AEDay');"/>
			          </td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">結案時間：</td>
			          <td class="h3">
		              <input id="ACYear" name="ACYear" type="text" size="4" value="<?php echo $ACYear;?>" /> 年 
		              <input id="ACMonth" name="ACMonth" type="text" size="2" value="<?php echo $ACMonth;?>" /> 月 
		              <input id="ACDay" name="ACDay" type="text" size="2" value="<?php echo $ACDay;?>" /> 日 
		              <img src="../images/icon.gif" width="16" height="18" style="cursor: hand" onclick="javascript:displayDatePicker('ACYear','ACMonth','ACDay');"/>
			          </td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3"><font color=red><b>*</b></font>項目/測試項目：</td>
			          <td class="h3"><input type="text" id="AItem" name="AItem" size="60" value="<?php echo $AItem;?>"></td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">進度：</td>
			          <td class="h3">
			          	<?php
			          	if (trim($AStatus) == "A") echo "案件指派";
									else if (trim($AStatus) == "B") echo "簽核完成";
									else if (trim($AStatus) == "C") echo "接案處理中";
									else if (trim($AStatus) == "D") echo "完成回報";
									else if (trim($AStatus) == "E") echo "驗收";
			          	?>
			          </td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3"><font color=red><b>*</b></font>屬性：</td>
			          <td class="h3">
			          	<select id="Attribute" name="Attribute" onchange="javascript:ChkAttribute();">
			          		<option value="A"<?php if (trim($Attribute) == "A") echo " selected";?>>測試</option>
			          		<option value="B"<?php if (trim($Attribute) == "B") echo " selected";?>>事項處理</option>
			          		<option value="C"<?php if (trim($Attribute) == "C") echo " selected";?>>採購</option>
			          	</select>
			          </td>
			        </tr>
			        <?php
					$PTxt="";
			        if (trim($PID) != "") {
									$SQL_Project="select PUID,PName,ModelName from Project where Deltag='N' and PID=".$PID.";";
									$result_Project=mysqli_query($link,$SQL_Project) or die ("無法執行查詢");
									list($PUID,$PName,$ModelName)=mysqli_fetch_row($result_Project);
									mysqli_free_result($result_Project);
									$PTxt="<a href=\"ProjectDetail.php?PID=$PID\" target=\"_blank\"><font color=blue><b>$PUID</b></font></a> $PName <font color=blue><b>/</b></font> $ModelName";
									}
			        ?>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3"><font color=red></font>連結案件：</td>
			          <td class="h3">
			          	<table width="100%" border="0" cellpadding="0" cellspacing="0">
			          		<tr>
			          			<td><div id="PNamePreview" style="display:"><?php echo $PTxt;?></div></td>
			          			<td>
						          	<input type="hidden" id="PID" name="PID" value="<?php echo $PID;?>">
						          	<input type="button" id="SelPID" name="SelPID" class="input_bot" value="選 擇" onclick="javascript:SelCust();">
			          			</td>
			          		</tr>
			          	</table>
			          </td>
			        </tr>
			        <?php
	          	if (trim($CLevel) == "C") $CLevel="B";
	          	if (trim($CLevel) == "A") $CLevelAlt="優(結案後直接給證書)";
	          	else if (trim($CLevel) == "B") $CLevelAlt="良(結案付款後給證書)";
	          	if (trim($CFees) == "A") $CFeesAlt="是(收據抬頭開全威)";
	          	else if (trim($CFees) == "B") $CFeesAlt="是(收據抬頭開申請人)";
	          	else if (trim($CFees) == "C") $CFeesAlt="否(不代送審)";
	          	if (trim($CRecord) == "A") $CRecordAlt="優(結案後月結60天)";
	          	else if (trim($CRecord) == "B") $CRecordAlt="良(月結30天)";
	          	else if (trim($CRecord) == "C") $CRecordAlt="付款開案";
	          	else if (trim($CRecord) == "D") $CRecordAlt="其他(".$CRecordTxt.")";
			        ?>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3"><font color=red><b>*</b></font>客戶名稱：</td>
			          <td class="h3">
			          	<table width="100%" border="0" cellpadding="0" cellspacing="0">
			          		<tr>
			          			<td>
			          				<div id="CNamePreview" style="display:"><?php echo $CName;?>
						          	<?php if (trim($CID) != "") {?>
						          	<img src="../images/<?php echo $CLevel;?>1.gif" alt="<?php echo $CLevelAlt;?>"> 
						          	<img src="../images/<?php echo $CFees;?>1.gif" alt="<?php echo $CFeesAlt;?>"> 
						          	<?php }?>
			          				</div>
			          			</td>
			          			<td>
						          	<input type="hidden" id="CID" name="CID" value="<?php echo $CID;?>">
						          	<input type="hidden" id="CName" name="CName" value="<?php echo $CName;?>">
						          	<!--<input type="button" id="SelCID" name="SelCID" class="input_bot" value="選 擇" onclick="javascript:window.open ('SelCustomer.php','SelCustomer','height=300,width=550,top=200,left=200,scrollbars=yes,status=yes');">-->
			          			</td>
			          		</tr>
			          	</table>
			          	
			          </td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">客戶電話：</td>
			          <td class="h3">
			          	<table width="100%" border="0" cellpadding="0" cellspacing="0">
			          		<tr>
			          			<td width="150">
			          				<div id="CTelPreview" style="display:"><?php echo $CTel;?></div>
						          	<input type="hidden" id="CTel" name="CTel" value="<?php echo $CTel;?>">
			          			</td>
			          			<td width="60" align="right" class="c3">傳真：</td>
			          			<td>
			          				<div id="CFaxPreview" style="display:"><?php echo $CFax;?></div>
			          				<input type="hidden" id="CFax" name="CFax" value="<?php echo $CFax;?>">
			          			</td>
			          		</tr>
			          	</table>
			          </td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">客戶地址：</td>
			          <td class="h3">
			          	<div id="CAddressPreview" style="display:"><?php echo $CAddress;?></div>
			          	<input type="hidden" id="CAddress" name="CAddress" value="<?php echo $CAddress;?>">
			          </td>
			        </tr>
			        <tr height="60" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">連絡人：</td>
			          <td class="h3">
			          	<table width="100%" border="0" cellpadding="0" cellspacing="0">
			          		<tr height="30">
			          			<td width="75" align="right">姓名：</td>
			          			<td width="180"><input type="text" id="Contact" name="Contact" size="20" value="<?php echo $Contact;?>"></td>
			          			<td width="60" align="right">電話：</td>
			          			<td><input type="text" id="CMobile" name="CMobile" size="20" value="<?php echo $CMobile;?>"></td>
			          		</tr>
			          		<tr height="30">
			          			<td width="75" align="right">E-MAil：</td>
			          			<td colspan="3"><input type="text" id="CEMail" name="CEMail" size="60" value="<?php echo $CEMail;?>"></td>
			          		</tr>
			          	</table>
			          </td>
			        </tr>
			        <tr height="40" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">相關檔案：</td>
			          <td class="h3"><input type="file" id="AFile" name="AFile" size="60">
			          	<?php if (trim($AFile) != "") {?>
			          	<input type="button" name="edit" value="下 載" class="input_bot" onclick="javascript:location.href='getfile.php?FolderName=Admin\\AFile&FileName=<?php echo $AFile;?>';">
			          	<input type="button" name="edit" value="刪除檔案" class="input_bot" onclick="javascript:if (confirm('您是否確定要刪除？')) window.open ('AgendumDelFile.php?AID=<?php echo $AID;?>','AgendumDelFile','height=0,width=0,top=0,left=0,scrollbars=no,status=no');;">
			          	<?php }?>
			          </td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">檔案說明：</td>
			          <td class="h3"><input type="text" id="ANote" name="ANote" size="60" value="<?php echo $ANote;?>"></td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">新增人員：</td>
			          <td class="h3"><?php echo $AddUser;?>　<?php echo $AddDate;?></td>
			        </tr>
			        <?php if (trim($ProcUser) != "") {?>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">最後更新：</td>
			          <td class="h3"><?php echo $ProcUser;?>　<?php echo $ProcDate;?> 
			          	<input type="button" name="edit" value="歷史記錄" class="input_bot" onclick="javascript:window.open ('AgendumHistory.php?AID=<?php echo $AID;?>','AgendumHistory','height=500,width=750,top=200,left=200,scrollbars=yes,status=yes');">
			         	</td>
			        </tr>
			        <?php }?>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td class="c3">內容及聯絡事項：</td>
			          <td class="h3"></td>
			        </tr>
			        <tr height="40" align="center">
			          <td colspan="2" class="h3">
			          	<IFRAME marginWidth="0" marginHeight="0" src="AgendumNote.php?AID=<?php echo $AID;?>" frameBorder="1" width="100%" scrolling="yes" height=250></IFRAME> 
			        </tr>
			        <tr height="40" align="center">
			          <td colspan="2" class="h3">
			          	<input type="button" name="button" class="input_bot" value="回 列 表" onclick="javascript:location.href='AgendumList.php?page=<?php echo $page;?>&QAStatus=<?php echo $QAStatus;?>&QASID=<?php echo $QASID;?>&QARID=<?php echo $QARID;?>&QACID=<?php echo $QACID;?>&Late=<?php echo $Late;?>&KeyWord=<?php echo urlencode($KeyWord);?>';">
			          	<input type="submit" name="submit" class="input_bot" value="送 出">　
			          </td>
			        </tr>
				      </form>
			      </table>
    			</td>
    		</tr>
    	</table>
    </td>
	</tr>
</table>
<script type="text/JavaScript">
<!--
//ChkAttribute();
//-->
</script>
<?php include "down.php";?>
</body>
</html>
<?php
mysqli_close($link);
?>