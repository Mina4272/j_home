﻿<?php
include "CheckPermission.php";
include "CheckEmployeePay.php";
include "../global.php";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $PageAdminTitle;?></title>
</head>
<body>
<?php
$MID = $_POST['MID'];
$EVCount = $_POST['EVCount'];
$EVDesc = $_POST['EVDesc'];
$EPYear = $_POST['EPYear'];
$EPMonth = $_POST['EPMonth'];
$EPDate = $EPYear."-".$EPMonth."-01";

if (trim($MID) == "" || trim($EVCount) == "" || trim($EPYear) == "" || trim($EPMonth) == "")
		{
		mysqli_close($link);
		?>
		<script type="text/JavaScript">
			<!--
			alert ("您輸入的資料不足，請重新輸入！");
			history.go(-1);
			//-->
		</script>
		<?php
		exit;
		}
date_default_timezone_set("Asia/Taipei");
$now_time = date("Y-m-d H:i:s",mktime());
$sql_insert = "insert into EmployeeVacation (MID,EVType,EPDate,EVCount,EVDesc,AddUser,AddDate,AddIP) values ('".$MID."','C','".$EPDate."','-".$EVCount."','".$EVDesc."','".$_SESSION["reg_MUID"]."','".$now_time."','".$_SERVER["REMOTE_ADDR"]."');";
$result_insert=mysqli_query($link,$sql_insert) or die ("無法執行新增");

mysqli_close($link);
?>
<script type="text/JavaScript">
	<!--
	alert ("處理完成！");
	location.href='EmployeeVacationList.php';
	//-->
</script>

</body>
</html>
