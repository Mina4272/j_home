<?php
include "CheckPermission.php";
//include "CheckAgendum.php";
include "../global.php";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $PageAdminTitle;?></title>
</head>
<body>
<?php
$device_no = $_GET['device_no'];

if (trim($device_no) == "")
		{
		mysqli_close($link);
		?>
		<script type="text/JavaScript">
			<!--
			alert ("�z��J����Ƥ����A�Э��s��J�I");
			history.go(-1);
			//-->
		</script>
		<?php
		exit;
		}

$now_time = date("Y-m-d H:i:s",mktime());
$SQL_select="select device_no from Device where Deltag='N' and device_no = '".$device_no."';";
$result_select=mysqli_query($link,$SQL_select) or die ("�L�k����d��");

if (mysqli_num_rows($result_select) == 0)
		{
		mysqli_free_result($result_select);
		mysqli_close($link);
		?>
		<script type="text/JavaScript">
			<!--
			alert ("�d�L��ơA���Ϻ����޲z�H���I");
			history.go(-1);
			//-->
		</script>
		<?php
		exit;
		}
mysqli_free_result($result_select);

$sql_update = "update Device set Deltag = 'Y' where Deltag='N' and device_no = '".$device_no."';";
$result_update=mysqli_query($link,$sql_update) or die ("�L�k����ק�");

mysqli_close($link);
?>
<script type="text/JavaScript">
	<!--
	alert ("�R�����\�I");
	location.href='Device.php';
	//-->
</script>

</body>
</html>
