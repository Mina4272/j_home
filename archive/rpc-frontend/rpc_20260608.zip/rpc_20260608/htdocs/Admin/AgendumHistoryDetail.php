﻿<?php	
include "CheckPermission.php";
include "CheckAgendum.php";
include "../global.php";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $PageAdminTitle;?></title>
<link href="../type.css" rel="stylesheet" type="text/css" />
<style type="text/css">
<!--
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
}
-->
</style>
<link href="../script/DatePicker.css" rel="stylesheet" type="text/css" />
<Script LANGUAGE="Javascript" SRC="../script/DatePicker.js"></Script>
<Script type="text/javascript" language="javascript" src="../script/CheckForm.js"></Script>
</head>
<body>
<?php
$AHID = empty($_GET['AHID'])?"":$_GET['AHID'];
$AID = empty($_GET['AID'])?"":$_GET['AID'];
$page = empty($_GET['page'])?"":$_GET['page'];
$KeyWord = empty($_GET['KeyWord'])?"":$_GET['KeyWord'];
$QAStatus = empty($_GET['QAStatus'])?"":$_GET['QAStatus'];
$QASID = empty($_GET['QASID'])?"":$_GET['QASID'];
$QARID = empty($_GET['QARID'])?"":$_GET['QARID'];

if (trim($AID) == "" || trim($AHID) == "")
		{
		mysqli_close($link);
		?>
		<script type="text/JavaScript">
			<!--
			alert ("查無資料，請冾網站管理人員！");
			history.go(-1);
			//-->
		</script>
		<?php
		exit;
		}
$SQL_Agendum="select AHID,AUID,ASID,ARID,ACID,ADate,date_format(ADate,'%Y'),date_format(ADate,'%m'),date_format(ADate,'%d'),AEDate,date_format(AEDate,'%Y'),date_format(AEDate,'%m'),date_format(AEDate,'%d'),ACDate,date_format(ACDate,'%Y'),date_format(ACDate,'%m'),date_format(ACDate,'%d'),AStatus,AItem,Attribute,PID,CID,CName,CTel,CFax,Contact,CMobile,CEMail,CAddress,AFile,ANote,AddUser,AddDate,ProcUser,ProcDate,(select CLevel from Customer where CID=AgendumHistory.CID) CLevel,(select CFees from Customer where CID=AgendumHistory.CID) CFees,(select CRecord from Customer where CID=AgendumHistory.CID) CRecord,(select CRecordTxt from Customer where CID=AgendumHistory.CID) CRecordTxt from AgendumHistory where Deltag='N' and AHID = '".$AHID."';";
$result_Agendum=mysqli_query($link,$SQL_Agendum) or die ("無法執行查詢");
if (mysqli_num_rows($result_Agendum) == 0)
		{
		mysqli_free_result($result_Agendum);
		mysqli_close($link);
		?>
		<SCRIPT language=javascript>
		<!--
		alert ("查無資料，請冾網站管理人員！"); 
		history.go(-1);
		//-->
		</SCRIPT>
		<?php 	
		exit;
		}
list($AHID,$AUID,$ASID,$ARID,$ACID,$ADate,$AYear,$AMonth,$ADay,$AEDate,$AEYear,$AEMonth,$AEDay,$ACDate,$ACYear,$ACMonth,$ACDay,$AStatus,$AItem,$Attribute,$PID,$CID,$CName,$CTel,$CFax,$Contact,$CMobile,$CEMail,$CAddress,$AFile,$ANote,$AddUser,$AddDate,$ProcUser,$ProcDate,$CLevel,$CFees,$CRecord,$CRecordTxt)=mysqli_fetch_row($result_Agendum);
mysqli_free_result($result_Agendum);
?>
    	<table width="100%" border="0" cellpadding="0" cellspacing="0">
    		<tr>
    			<td>
			    	<table width="750" border="0" cellpadding="0" cellspacing="0">
			    		<tr height="30">
			    			<td class="c2"><b>事項處理歷史資料</b></td>
			    		</tr>
			    	</table>
			    	<table width="750" border="0" cellpadding="0" cellspacing="0">
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td width="150" align="right" class="c3">案件編號：</td>
			          <td class="h3"><font color=blue><?php echo $AUID;?></font>
			          	<input name="AID" type="hidden" id="AID" value="<?php echo $AID;?>" />
			          	<input name="page" type="hidden" id="page" value="<?php echo $page;?>" />
			          	<input name="KeyWord" type="hidden" id="KeyWord" value="<?php echo $KeyWord;?>" />
			          	<input name="QAStatus" type="hidden" id="QAStatus" value="<?php echo $QAStatus;?>" />
			          	<input name="QASID" type="hidden" id="QASID" value="<?php echo $QASID;?>" />
			          	<input name="QARID" type="hidden" id="QARID" value="<?php echo $QARID;?>" />
			         	</td>
			        </tr>
			        <?php
							$SQL_Manager="select MName,MEName from Manager where MUID = '".$ASID."';";
							$result_Manager=mysqli_query($link,$SQL_Manager) or die ("無法執行查詢");
							list($ASName,$ASEName)=mysqli_fetch_row($result_Manager);
							mysqli_free_result($result_Manager);
			        ?>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3"><font color=red><b>*</b></font>派案人：</td>
			          <td class="h3"><?php echo $ASEName.$ASName;?></td>
			        </tr>
			        <?php
							$SQL_Manager="select MName,MEName from Manager where MUID = '".$ARID."';";
							$result_Manager=mysqli_query($link,$SQL_Manager) or die ("無法執行查詢");
							list($ARName,$AREName)=mysqli_fetch_row($result_Manager);
							mysqli_free_result($result_Manager);
			        ?>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3"><font color=red><b>*</b></font>接案人：</td>
			          <td class="h3"><?php echo $AREName.$ARName;?></td>
			        </tr>
			        <?php
							$SQL_Manager="select MName,MEName from Manager where MUID = '".$ACID."';";
							$result_Manager=mysqli_query($link,$SQL_Manager) or die ("無法執行查詢");
							list($ACName,$ACEName)=mysqli_fetch_row($result_Manager);
							mysqli_free_result($result_Manager);
			        ?>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3"><font color=red><b>*</b></font>審核人：</td>
			          <td class="h3"><?php echo $ACName.$ACEName;?></td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3"><font color=red><b>*</b></font>派案時間：</td>
			          <td class="h3"><?php echo $ADate;?></td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3"><font color=red><b>*</b></font>預計完成時間：</td>
			          <td class="h3"><?php echo $AEDate;?></td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">結案時間：</td>
			          <td class="h3"><?php echo $ACDate;?></td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3"><font color=red><b>*</b></font>項目/測試項目：</td>
			          <td class="h3"><?php echo $AItem;?></td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">進度：</td>
			          <td class="h3">
			          	<?php
			          	if (trim($AStatus) == "A") echo "案件指派";
			          	else if (trim($AStatus) == "B") echo "接案處理中";
			          	else if (trim($AStatus) == "C") echo "完成回報";
			          	else if (trim($AStatus) == "D") echo "驗收";
			          	?>
			          </td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3"><font color=red><b>*</b></font>屬性：</td>
			          <td class="h3">
			          	<?php
			          	if (trim($AStatus) == "A") echo "測試";
			          	else if (trim($AStatus) == "B") echo "事項處理";
			          	else if (trim($AStatus) == "C") echo "採購";
			          	?>
			          </td>
			        </tr>
			        <?php
			        if (trim($PID) != "") {
									$SQL_Project="select PUID,PName,ModelName from Project where Deltag='N' and PID=".$PID.";";
									$result_Project=mysqli_query($link,$SQL_Project) or die ("無法執行查詢");
									list($PUID,$PName,$ModelName)=mysqli_fetch_row($result_Project);
									mysqli_free_result($result_Project);
									$PTxt="<font color=blue><b>PUID</b></font> $PName <font color=blue><b>/</b></font> $ModelName";
									}
			        ?>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">連結案件：</td>
			          <td class="h3">
			          	<table width="100%" border="0" cellpadding="0" cellspacing="0">
			          		<tr>
			          			<td><div id="PNamePreview" style="display:"><?php echo $PTxt;?></div></td>
			          			<td>
			          			</td>
			          		</tr>
			          	</table>
			          </td>
			        </tr>
			        <?php
				$CLevelAlt="";
				$CFeesAlt = "";
	          	if (trim($CLevel) == "C") $CLevel="B";
	          	if (trim($CLevel) == "A") $CLevelAlt="優(結案後直接給證書)";
	          	else if (trim($CLevel) == "B") $CLevelAlt="良(結案付款後給證書)";
	          	if (trim($CFees) == "A") $CFeesAlt="是(收據抬頭開全威)";
	          	else if (trim($CFees) == "B") $CFeesAlt="是(收據抬頭開申請人)";
	          	else if (trim($CFees) == "C") $CFeesAlt="否(不代送審)";
	          	if (trim($CRecord) == "A") $CRecordAlt="優(結案後月結60天)";
	          	else if (trim($CRecord) == "B") $CRecordAlt="良(月結30天)";
	          	else if (trim($CRecord) == "C") $CRecordAlt="付款開案";
	          	else if (trim($CRecord) == "D") $CRecordAlt="其他(".$CRecordTxt.")";
			        ?>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3"><font color=red><b>*</b></font>客戶名稱：</td>
			          <td class="h3">
			          	<table width="100%" border="0" cellpadding="0" cellspacing="0">
			          		<tr>
			          			<td>
			          				<div id="CNamePreview" style="display:"><?php echo $CName;?>
						          	<img src="../images/<?php echo $CLevel;?>1.gif" alt="<?php echo $CLevelAlt;?>"> 
						          	<img src="../images/<?php echo $CFees;?>1.gif" alt="<?php echo $CFeesAlt;?>"> 
			          				</div>
			          			</td>
			          			<td>
						          	<input type="hidden" name="CID" value="<?php echo $CID;?>">
						          	<input type="hidden" name="CName" value="<?php echo $CName;?>">
			          			</td>
			          		</tr>
			          	</table>
			          	
			          </td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">客戶電話：</td>
			          <td class="h3">
			          	<table width="100%" border="0" cellpadding="0" cellspacing="0">
			          		<tr>
			          			<td width="150">
			          				<div id="CTelPreview" style="display:"><?php echo $CTel;?></div>
						          	<input type="hidden" name="CTel" value="<?php echo $CTel;?>">
			          			</td>
			          			<td width="60" align="right" class="c3">傳真：</td>
			          			<td>
			          				<div id="CFaxPreview" style="display:"><?php echo $CFax;?></div>
			          				<input type="hidden" name="CFax" value="<?php echo $CFax;?>">
			          			</td>
			          		</tr>
			          	</table>
			          </td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">客戶地址：</td>
			          <td class="h3">
			          	<div id="CAddressPreview" style="display:"><?php echo $CAddress;?></div>
			          	<input type="hidden" name="CAddress" value="<?php echo $CAddress;?>">
			          </td>
			        </tr>
			        <tr height="60" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">連絡人：</td>
			          <td class="h3">
			          	<table width="100%" border="0" cellpadding="0" cellspacing="0">
			          		<tr height="30">
			          			<td width="70" align="right">姓名：</td>
			          			<td width="180"><?php echo $Contact;?></td>
			          			<td width="60" align="right">電話：</td>
			          			<td><?php echo $CMobile;?></td>
			          		</tr>
			          		<tr height="30">
			          			<td width="70" align="right">E-MAil：</td>
			          			<td colspan="3"><?php echo $CEMail;?></td>
			          		</tr>
			          	</table>
			          </td>
			        </tr>
			        <tr height="40" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">相關檔案：</td>
			          <td class="h3">
			          	<?php if (trim($AFile) != "") {?>
			          	<input type="button" name="edit" value="下 載" class="input_bot" onclick="javascript:location.href='getfile.php?FolderName=Admin\\AFile&FileName=<?php echo $AFile;?>';">
			          	<?php }?>
			          </td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">檔案說明：</td>
			          <td class="h3"><?php echo $ANote;?></td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">新增人員：</td>
			          <td class="h3"><?php echo $AddUser;?>　<?php echo $AddDate;?></td>
			        </tr>
			        <?php if (trim($ProcUser) != "") {?>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">最後更新：</td>
			          <td class="h3"><?php echo $ProcUser;?>　<?php echo $ProcDate;?> 
			         	</td>
			        </tr>
			        <?php }?>
			        <!--<tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td class="c3">內容及聯絡事項：</td>
			          <td class="h3"></td>
			        </tr>
			        <tr height="40" align="center">
			          <td colspan="2" class="h3">
			          	<IFRAME marginWidth="0" marginHeight="0" src="AgendumNote.php?AID=<?php echo $AID;?>" frameBorder="1" width="100%" scrolling="yes" height=250></IFRAME> 
			        </tr>-->
			        <tr height="40" align="center">
			          <td colspan="2" class="h3">
			          	<input type="button" name="button" class="input_bot" value="回 列 表" onclick="javascript:location.href='AgendumHistory.php?page=<?php echo $page;?>&AID=<?php echo $AID;?>';">
			          </td>
			        </tr>
			      </table>
    			</td>
    		</tr>
    	</table>
</body>
</html>
<?php
mysqli_close($link);
?>