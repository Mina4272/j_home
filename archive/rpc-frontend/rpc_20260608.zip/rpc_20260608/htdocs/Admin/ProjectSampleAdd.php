﻿<?php	
include "CheckPermission.php";
include "CheckProject.php";
include "../global.php";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $PageAdminTitle;?></title>
<link href="../type.css" rel="stylesheet" type="text/css" />
<style type="text/css">
<!--
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
}
-->
</style>
<link href="../script/DatePicker.css" rel="stylesheet" type="text/css" />
<Script LANGUAGE="Javascript" SRC="../script/DatePicker.js"></Script>
<Script type="text/javascript" language="javascript" src="../script/CheckForm.js"></Script>
<script type="text/JavaScript">
<!--
function jsCheck() 
		{
		if (document.form1.PSType[0].checked == false && document.form1.PSType[1].checked == false)
				{
				alert ('請選擇種類 !!');
				form1.PSType[0].focus();
				return false ; 
				}
		if (ChkDate('PSYear',document.form1.PSYear.value,document.form1.PSMonth.value,document.form1.PSDay.value,'日期') == false) return false;
		if (ChkImp('PSCount',document.form1.PSCount.value,'數量') == false) return false;
		if (ChkImp('PSMode',document.form1.PSMode.value,'方式') == false) return false;
		if (ChkImp('PSPersonnel',document.form1.PSPersonnel.value,'收入人') == false) return false;
		}
//-->
</script>
</head>
<body>
<?php
$PID = $_GET['PID'];
if (trim($PID) == "")
		{
		mysqli_close($link);
		?>
		<script type="text/JavaScript">
			<!--
			alert ("查無資料，請冾網站管理人員！");
			self.close();
			//-->
		</script>
		<?php
		exit;
		}
?>
<table width="100%" border="0" cellpadding="0" cellspacing="0">
	<tr>
		<td>
    	<table width="100%" border="0" cellpadding="0" cellspacing="0">
    		<tr height="30">
					<td width="15" background="../images/table_bg.gif"></td>
    			<td class="c3" background="../images/table_bg.gif"><b>新增樣品記錄</b></td>
    		</tr>
    	</table>
    	<table width="100%" border="0" cellpadding="0" cellspacing="0">
        <form name="form1" method="post" action="ProjectSampleAddDB.php" enctype="multipart/form-data" onSubmit="return jsCheck();">
        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
					<td width="15"></td>
          <td width="90" class="c3" align="right">種類：</td>
          <td class="c3">
          	<input type="radio" name="PSType" value="I" /> 收入樣品 
          	<input type="radio" name="PSType" value="O" /> 送出樣品
          </td>
        </tr>
        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
					<td width="15"></td>
          <td class="c3" align="right">日期：</td>
          <td class="h3">
            <input name="PSYear" type="text" size="4" /> 年 
            <input name="PSMonth" type="text" size="2" /> 月 
            <input name="PSDay" type="text" size="2" /> 日 
            <img src="../images/icon.gif" width="16" height="18" style="cursor: hand" onclick="javascript:displayDatePicker('PSYear','PSMonth','PSDay');"/>
          </td>
        </tr>
        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
					<td width="15"></td>
          <td class="c3" align="right">數量：</td>
          <td class="h3">
            <input name="PSCount" type="text" size="10" />
          </td>
        </tr>
        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
					<td width="15"></td>
          <td class="c3" align="right">方式：</td>
          <td class="h3">
            <input name="PSMode" type="text" size="20" />
          </td>
        </tr>
        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
					<td width="15"></td>
          <td class="c3" align="right">收入人：</td>
          <td class="h3">
            <input name="PSPersonnel" type="text" size="20" />
          </td>
        </tr>
        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
					<td width="15"></td>
          <td class="c3" align="right">收入地：</td>
          <td class="h3">
            <input name="SPlace" type="text" size="20" />
          </td>
        </tr>
        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
					<td width="15"></td>
          <td class="c3" align="right">送出人：</td>
          <td class="h3">
            <input name="PSend" type="text" size="20" />
          </td>
        </tr>
        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
					<td width="15"></td>
          <td class="c3" align="right">送出地：</td>
          <td class="h3">
            <input name="IPlace" type="text" size="20" />
          </td>
        </tr>
        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
					<td width="15"></td>
          <td class="c3" align="right">備註：</td>
          <td class="h3">
            <input name="PSNote" type="text" size="40" />
          </td>
        </tr>
        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
					<td width="15"></td>
          <td class="c3" align="right">相關檔案：</td>
          <td class="c3">
          	<input name="PSFile" type="file" size="40" />
          </td>
        </tr>
        <tr height="40" align="center">
					<td width="15"></td>
          <td colspan="2" class="h3">
          	<input type="submit" name="submit" class="input_bot" value="送 出">
          	<input name="PID" type="hidden" id="PID" value="<?php echo $PID;?>" />
          </td>
        </tr>
	      </form>
      </table>
		</td>
	</tr>
</table>
</body>
</html>
<?php
mysqli_close($link);
?>