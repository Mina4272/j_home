﻿<?php
include "CheckPermission.php";
include "../global.php";
include "include/page_function.php";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $PageAdminTitle;?></title>
<link href="../type.css" rel="stylesheet" type="text/css" />
<style type="text/css">
<!--
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
}
-->
</style></head>

<body>
<?php
$Invoice="";
$PID = $_GET['PID'];
$PAID = $_GET['PAID'];
if (trim($PID) == "" || trim($PAID) == "")
		{
		mysqli_close($link);
		?>
		<script type="text/JavaScript">
			<!--
			alert ("查無資料，請冾網站管理人員！");
			history.go(-1);
			//-->
		</script>
		<?php
		exit;
		}
$SQL_Project="select PUID,PName,QuoteDate,IFlorin,OFlorin,PTax from Project where Deltag='N' and PID = '".$PID."';";
$result_Project=mysqli_query($link,$SQL_Project) or die ("無法執行查詢");
if (mysqli_num_rows($result_Project) == 0)
		{
		mysqli_free_result($result_Project);
		mysqli_close($link);
		?>
		<SCRIPT language=javascript>
		<!--
		alert ("查無資料，請冾網站管理人員！"); 
		history.go(-1);
		//-->
		</SCRIPT>
		<?php 	
		exit;
		}
mysqli_free_result($result_Project);

$SQL_ProjectAccounting="select PAMode from ProjectAccounting where Deltag='N' and PID = '".$PID."' and PAID = '".$PAID."';";
$result_ProjectAccounting=mysqli_query($link,$SQL_ProjectAccounting) or die ("無法執行查詢");
if (mysqli_num_rows($result_ProjectAccounting) == 0)
		{
		mysqli_free_result($result_ProjectAccounting);
		mysqli_close($link);
		?>
		<SCRIPT language=javascript>
		<!--
		alert ("查無資料，請冾網站管理人員！"); 
		history.go(-1);
		//-->
		</SCRIPT>
		<?php 	
		exit;
		}
mysqli_free_result($result_ProjectAccounting);
?>
<table width="100%" border="0" cellpadding="0" cellspacing="0">
	<tr>
		<td>
			<?php
			$page = empty($_GET['page'])?"":$_GET['page'];
			if (trim($page) == "") $page = 1;
			$page_rows=15;  //每頁筆數
			$php_Self = "ProjectAccountingHistory.php";  //分頁web檔名

			$button_css = "h4";
			$limit_txt =" limit ".(($page-1) * $page_rows).",".$page_rows;
			$url_str = "&PID=".$PID."&PAID=".$PAID;
			$Sql_str="select PAHID from ProjectAccountingHistory where Deltag='N' and PID = '".$PID."' and PAID = '".$PAID."' order by PAHID desc;";
			$SQL_ProjectAccounting="select PAHID,PANo,PAMode,PAItem,Charges,Rate,ChargesOther,PATax,PAStatus,PAPDate,PADate,PARecord,PARecordDate,PARecordIP,CID,CName,CTel,CFax,CAddress,PANote,AddUser,AddDate,ProcUser,ProcDate from ProjectAccountingHistory where Deltag='N' and PID = '".$PID."' and PAID = '".$PAID."' order by PAHID desc ".$limit_txt.";";
			$result_ProjectAccounting=mysqli_query($link,$SQL_ProjectAccounting) or die ("無法執行查詢");
			?>
    	<table width="100%" border="0" cellpadding="5" cellspacing="2" class="s2">
        <tr align="center">
          <td align="center" background="../images/table_bg.gif" class="t21">收入/支出</td>
          <td background="../images/table_bg.gif" class="t21">項 目</td>
          <td background="../images/table_bg.gif" class="t21">費 用</td>
          <td background="../images/table_bg.gif" class="t21">是否<br>含稅</td>
          <td background="../images/table_bg.gif" class="t21">狀 態<br>發票號碼</td>
          <td background="../images/table_bg.gif" class="t21">備 註<br>對帳編號</td>
          <td background="../images/table_bg.gif" class="t21">詳細</td>
          <td width="150" background="../images/table_bg.gif" class="t21">最後更新</td>
        </tr>
        <?php
        $tmp = 1;
        while(list($PAHID,$PANo,$PAMode,$PAItem,$Charges,$Rate,$ChargesOther,$PATax,$PAStatus,$PAPDate,$PADate,$PARecord,$PARecordDate,$PARecordIP,$CID,$CName,$CTel,$CFax,$CAddress,$PANote,$AddUser,$AddDate,$ProcUser,$ProcDate)=mysqli_fetch_row($result_ProjectAccounting)){
      	?>
      	<tr<?php if ($tmp%2 == 0) echo " bgcolor=\"#F6F6F6\"";?>>
          <td align="center" class="h3">
          	<?php
          	if (trim($PAMode) == "I") echo "<font color=blue>收入</font>";
          	else if (trim($PAMode) == "O") echo "<font color=red>支出</font>";
          	?>
          </td>
          <td class="h3"><?php echo $PAItem;?></td>
          <td class="h3" align="center"><?php echo $Charges;?>
          	<?php
			$IFlorin = "";
			$OFlorin = "";
          	if (trim($Rate) != "0") {
          			echo "<br><font color=blue>匯率：".$Rate."</font>";
          			if (trim($PAMode) == "I") echo "<br><font color=blue>".$IFlorin."：".$ChargesOther."</font>";
          			else if (trim($PAMode) == "O") echo "<br><font color=blue>".$OFlorin."：".$ChargesOther."</font>";
          			}
          	?>
          </td>
          <td class="h3" align="center">
          	<?php
          	if (trim($PATax) == "Y") echo "是";
          	else if (trim($PATax) == "N") echo "否";
          	?>
          </td>
          <td align="center" class="h3">
          	<?php
          	if (trim($PAStatus) == "W") {
          			if (trim($PAMode) == "I") echo "待收"; else if (trim($PAMode) == "O") echo "未付";
          			}
          	else if (trim($PAStatus) == "S") echo "<font color=blue>結清</font><br>".$PADate;
          	else if (trim($PAStatus) == "C") echo "<font color=red>取消</font>";
          	if (trim($Invoice) != "") echo "<br><font color=blue>".$Invoice."</font>";
          	?>
          </td>
          <td class="h3"><?php echo $PANote;if (trim($PANo) != "") echo "<br>".$PANo;?></td>
          <td align="center" class="h3"><input type="button" name="detail" value="詳細" class="input_bot" onclick="javascript:location.href='ProjectAccountingHistoryDetail.php?PAHID=<?php echo $PAHID;?>&PID=<?php echo $PID;?>&PAID=<?php echo $PAID;?>&page=<?php echo $page;?>';"></td>
          <td align="center" class="h3">
          	<?php
          	if (trim($ProcUser) == "") echo $AddUser."<br>".$AddDate;
          	else echo $ProcUser."<br>".$ProcDate;
          	?>
          </td>
        </tr>
        <?php
      			$tmp++;
      			}
      	mysqli_free_result($result_ProjectAccounting);
        ?>
      </table>
      <table width="100%" border="0" cellpadding="5" cellspacing="2" class="s2">
        <tr align="center">
          <td bgcolor="#E8F0C2" class="h4"><?php Page_show($Sql_str,$page_rows,$php_Self,$link,$page,$url_str,$button_css);?></td>
        </tr>
      </table>
		</td>
	</tr>
</table>
</body>
</html>
<?php
mysqli_close($link);
?>