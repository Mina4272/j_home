﻿<?php
ob_start();
require_once('tcpdf/examples/lang/eng.php');
require_once('tcpdf/tcpdf.php');

$DBUSER="root";
$DBNAME="rpcdb";
$DBPSWD="a123456789";
$PageTitle="全威驗證廠商案件查詢平台";
$PageAdminTitle="全威驗證系統管理平台";
//$CryptKey = "VampCryptKeyPrint";

$link = mysqli_connect ("localhost", $DBUSER, $DBPSWD) or die("無法連接資料庫: " . mysql_error( ));  
mysqli_select_db($link,$DBNAME)or die("無法選擇資料庫");

$SQL_select="SET CHARACTER SET utf8";
$result_select=mysqli_query($link,$SQL_select) or die ("無法執行查詢");

$SQL_select="SET NAMES 'utf8'";
$result_select=mysqli_query($link,$SQL_select) or die ("無法執行查詢");


// create new PDF document
$pdf = new TCPDF(PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false); 
// ---------------------------------------------------------
$pdf->setPrintHeader(false); //不要頁首
// set font
$pdf->SetFont('msungstdlight','',12);
$pdf->AddPage();
$pdf->Cell(0,10,'教育訓練紀錄', 0, 0, 'C', 0, '', 0);

$pdf->SetLineWidth(0.1);//線段寬
$pdf->Line(10, 30, 200, 30);//畫線

$pdf->Ln(25);


$TID = $_GET['TID'];



$select = "select TTitle,Lecturer,TDate,TLocation,othertext,TContent from training where deltag ='N' and TID ='".$TID."'";
$result_select=mysqli_query($link,$select) or die ("無法執行新增");
while(list($TTitle,$Lecturer,$TDate,$TLocation,$othertext,$TContent)=mysqli_fetch_row($result_select)){
	
	$T;
	
	if($TLocation =="meetingroom"){
		$T = "會議室";
	}else if($TLocation=="other"){
		$T = $othertext;
	}


$tbl = <<<EOD
<table cellspacing="0" cellpadding="1" border="1">
    <tr>
        <td>課程名稱:</td>
        <td colspan="3">$TTitle</td>
        <td>參與部門</td>
		<td></td>
    </tr>
    <tr>
       <td>講師:</td>
	   <td>$Lecturer</td>
	   <td>上課時間:</td>
	   <td>$TDate</td>
	   <td>地點:</td>
	   <td>$T</td>
    </tr>
    <tr>
       <td>訓練內容:</td>
	   <td colspan="5">$TContent</td>
    </tr>

</table>
EOD;
}

$pdf->writeHTML($tbl, true, false, false, false, '');


$pdf->Ln(2.5);





$tbl = '<table border="1"  cellpadding="0" cellspacing="1" align="center" fontsize="10">
	<tr width="auto">
        <td>人員</td>
        <td>簽到</td>
        <td>測試方法</td>
		<td>分數</td>
		<td>審核與授權</td>
		<td>備註</td>
    </tr>';
$select = "select m.MName,m.MEName from Trainingexam te inner join manager m on te.mid = m.mid and m.deltag='N' where te.deltag='N' and te.TID='".$TID."'";
$result_select=mysqli_query($link,$select) or die ("無法執行新增");
while(list($MName)=mysqli_fetch_row($result_select)){


  $tbl .="<tr>
       <td>".$MName."</td>
	   <td></td>
	   <td>無/筆試/<br/>口試/實作</td>
	   <td></td>
	   <td>符合/<br/>不符合</td>
	   <td></td>
    </tr>";
 }

$tbl .= '
	<tr>
		<td></td>
		<td></td>
	   <td>講師簽名:</td>
	   <td></td>
	   <td>審核人員:</td>
	   <td></td>
    </tr></table>';

$pdf->writeHTML($tbl, true, false, false, false, '');

$pdf->Cell(0,0,'*註.筆試需留下相關文件同時保存', 0, 0, '', 0, '', 0);


//$pdf->Ln(125);

//$pdf->SetLineWidth(0.1);//線段寬
//$pdf->Line(100, 300, 200, 300);//畫線
   
//$pdf->Cell(0,0,'文件編號:RCP-OD-103');
//$pdf->Cell(0,0,$pdf->pageNO(),0,0,'L');
//Close and output PDF document
$pdf->Output('TraningRecord.pdf', 'D');
ob_end_flush(); 