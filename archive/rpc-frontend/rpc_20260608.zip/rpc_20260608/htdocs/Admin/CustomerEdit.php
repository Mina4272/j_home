﻿<?php	
include "CheckPermission.php";
include "../global.php";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $PageAdminTitle;?></title>
<link href="../type.css" rel="stylesheet" type="text/css" />
<style type="text/css">
<!--
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
}
-->
</style>
<Script type="text/javascript" language="javascript" src="../script/rpc.js"></Script>
<Script type="text/javascript" language="javascript" src="../script/CheckForm.js"></Script>
<script type="text/JavaScript">
<!--
function jsCheck() 
		{
		if (ChkImp('CPWD',document.form1.CPWD.value,'密碼') == false) return false;
		if (ChkImp('CPWDCheck',document.form1.CPWDCheck.value,'確認密碼') == false) return false;
		if (jsTrim(document.form1.CPWD.value) != jsTrim(document.form1.CPWDCheck.value))
				{
				alert ('您輸入的密碼與確認密碼不相同，請重新輸入！');
				document.form1.CPWD.value = '';
				document.form1.CPWDCheck.value = '';
				document.form1.CPWD.focus();
				return false;
				}
		if (document.form1.CRecord[3].checked && jsTrim(document.form1.CRecordTxt.value) == "") {
				alert ('請輸入付款記錄其他說明！');
				document.form1.CRecordTxt.focus();
				document.form1.CRecordTxt.select();
				return false;
				}
		if (ChkImp('CName',document.form1.CName.value,'公司名稱') == false) return false;
		if (ChkImp('CTel',document.form1.CTel.value,'公司電話') == false) return false;
		//if (jsTrim(document.form1.CEMail.value) != "") if (ChkEmail('CEMail',document.form1.CEMail.value,'聯絡人E-Mail') == false) return false;
		if (ChkImp('CAddress',document.form1.CAddress.value,'公司地址') == false) return false;
		}

function DelTrademarkImg() {
		if (confirm('您確定要刪除此圖像嗎？')) {
				document.form1.TrademarkImg.value='';
				document.getElementById('TrademarkImgPreview').style.display = 'none';
				document.getElementById('TrademarkImgPreview').innerHTML = '';
				document.getElementById('TrademarkImgDel').style.display = 'none';
				document.getElementById('TrademarkImgDel').innerHTML = '';
				}
		}

function cpa_click1() {
		if (document.form1.cpa1.checked == true) document.form1.TAddress.value=document.form1.CAddress.value;
		}
function cpa_click2() {
		if (document.form1.cpa2.checked == true) document.form1.LAddress.value=document.form1.TAddress.value;
		}
//-->
</script>
</head>
<body>
<?php include "top.php";?>
<?php
$CID = $_GET['CID'];
$page = $_GET['page'];
if (trim($CID) == "")
		{
		mysqli_close($link);
		?>
		<script type="text/JavaScript">
			<!--
			alert ("查無資料，請冾網站管理人員！");
			history.go(-1);
			//-->
		</script>
		<?php
		exit;
		}
$SQL_Customer="select CustomerFile,CUID,CPWD,CName,EName,TrademarkTxt,TrademarkImg,CTel,CFax,Contact,CMobile,CEMail,CAddress,CNote,CType,CLevel,CFees,CRecord,CRecordTxt,BSMI,AddUser,AddDate,ProcUser,ProcDate,Principal,TAddress,LAddress,GUI from Customer where Deltag='N' and CID = '".$CID."';";
$result_Customer=mysqli_query($link,$SQL_Customer) or die ("無法執行查詢");
if (mysqli_num_rows($result_Customer) == 0)
		{
		mysqli_free_result($result_Customer);
		mysqli_close($link);
		?>
		<SCRIPT language=javascript>
		<!--
		alert ("查無資料，請冾網站管理人員！"); 
		history.go(-1);
		//-->
		</SCRIPT>
		<?php 	
		exit;
		}
list($CustomerFile,$CUID,$CPWD,$CName,$EName,$TrademarkTxt,$TrademarkImg,$CTel,$CFax,$Contact,$CMobile,$CEMail,$CAddress,$CNote,$CType,$CLevel,$CFees,$CRecord,$CRecordTxt,$BSMI,$AddUser,$AddDate,$ProcUser,$ProcDate,$Principal,$TAddress,$LAddress,$GUI)=mysqli_fetch_row($result_Customer);
mysqli_free_result($result_Customer);

?>
<table width="100%" border="0" cellspacing="0" cellpadding="5">
	<tr>
    <td width="160" height="600" align="left" valign="top">
			<?php include "menu.php";?>
    </td>
    <td valign="top">
    	<table width="100%" border="0" cellpadding="0" cellspacing="0">
    		<tr>
    			<td>
			    	<table width="750" border="0" cellpadding="0" cellspacing="0">
			    		<tr height="30">
			    			<td class="c2"><b>修改客戶資料</b></td>
			    		</tr>
			    	</table>
			    	<table width="750" border="0" cellpadding="0" cellspacing="0">
			        <form name="form1" method="post" action="CustomerEditDB.php" enctype="multipart/form-data" onSubmit="return jsCheck();">
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td width="130" align="right" class="c3">統一編號：</td>
			          <td class="h3"><?php echo $CUID;?>
			          	<input type="hidden" name="CID" value="<?php echo $CID;?>">
			          	<input type="hidden" name="page" value="<?php echo $page;?>">
			          </td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">密 碼：</td>
			          <td class="h3"><input type="password" name="CPWD" size="20" value="<?php echo $CPWD;?>"></td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">密碼確認：</td>
			          <td class="h3"><input type="password" name="CPWDCheck" size="20" value="<?php echo $CPWD;?>"></td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">客戶種類：</td>
			          <td class="h3">
			          	<input type="checkbox" name="CType[]" value="N"<?php if (trim(strstr($CType,'N')) != "") echo " checked";?>> 一般客戶 
			          	<input type="checkbox" name="CType[]" value="P"<?php if (trim(strstr($CType,'P')) != "") echo " checked";?>> 供應商
			          </td>
			        </tr>
			        <?php if (trim($CLevel) == "C") $CLevel="B";?>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">客戶等級：</td>
			          <td class="h3">
			          	<input type="radio" name="CLevel" value="A"<?php if (trim($CLevel) == "A") echo " checked";?> <?php if(!empty($CustomerFile) && !(trim($_SESSION["reg_MUID"]) == "vivi")){ echo 'disabled';}?>><img src="../images/A1.gif" border="0"> 優(結案後直接給證書)　
			          	<input type="radio" name="CLevel" value="B"<?php if (trim($CLevel) == "B") echo " checked";?> <?php if(!empty($CustomerFile) && !(trim($_SESSION["reg_MUID"]) == "vivi")){ echo 'disabled';}?>><img src="../images/B1.gif" border="0"> 良(結案付款後給證書)
			          </td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">規費是否代付：</td>
			          <td class="h3">
			          	<input type="radio" name="CFees" value="A"<?php if (trim($CFees) == "A") echo " checked";?> <?php if(!empty($CustomerFile) && !(trim($_SESSION["reg_MUID"]) == "vivi")){ echo 'disabled';}?>><img src="../images/A1.gif" border="0"> 是(收據抬頭開全威)　
			          	<input type="radio" name="CFees" value="B"<?php if (trim($CFees) == "B") echo " checked";?> <?php if(!empty($CustomerFile) && !(trim($_SESSION["reg_MUID"]) == "vivi")){ echo 'disabled';}?>><img src="../images/B1.gif" border="0"> 是(收據抬頭開申請人)　
			          	<input type="radio" name="CFees" value="C"<?php if (trim($CFees) == "C") echo " checked";?> <?php if(!empty($CustomerFile) && !(trim($_SESSION["reg_MUID"]) == "vivi")){ echo 'disabled';}?>><img src="../images/C1.gif" border="0"> 否(不代送審)
			          </td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">付款記錄：</td>
			          <td class="h3">
			          	<input type="radio" name="CRecord" value="A"<?php if (trim($CRecord) == "A") echo " checked";?> <?php if(!empty($CustomerFile) && !(trim($_SESSION["reg_MUID"]) == "vivi")){ echo 'disabled';}?>><img src="../images/A2.gif" border="0"> 優(結案後月結60天)　
			          	<input type="radio" name="CRecord" value="B"<?php if (trim($CRecord) == "B") echo " checked";?> <?php if(!empty($CustomerFile) && !(trim($_SESSION["reg_MUID"]) == "vivi")){ echo 'disabled';}?>><img src="../images/B2.gif" border="0"> 良(月結30天)　
			          	<input type="radio" name="CRecord" value="C"<?php if (trim($CRecord) == "C") echo " checked";?> <?php if(!empty($CustomerFile) && !(trim($_SESSION["reg_MUID"]) == "vivi")){ echo 'disabled';}?>><img src="../images/C2.gif" border="0"> 付款開案<br>
			          	<input type="radio" name="CRecord" value="D"<?php if (trim($CRecord) == "D") echo " checked";?> <?php if(!empty($CustomerFile) && !(trim($_SESSION["reg_MUID"]) == "vivi")){ echo 'disabled';}?>><img src="../images/D2.gif" border="0"> 其他 
			          	<input type="text" name="CRecordTxt" size="20" value="<?php echo $CRecordTxt;?>" <?php if(!empty($CustomerFile) && !(trim($_SESSION["reg_MUID"]) == "vivi")){ echo 'disabled';}?>>
			          </td>
			        </tr>
					<tr height="40" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">上傳檔案：</td>
			          <td class="h3"><input type="file" id="CustomerFile" name="CustomerFile" size="60" <?php if(!empty($CustomerFile) && !(trim($_SESSION["reg_MUID"]) == "vivi")){ echo 'disabled';}?>></td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">公司名稱：</td>
			          <td class="h3"><input type="text" name="CName" size="60" value="<?php echo $CName;?>"></td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">公司英文名稱：</td>
			          <td class="h3"><input type="text" name="EName" size="60" value="<?php echo $EName;?>"></td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">BSMI識別號碼：</td>
			          <td class="h3"><input type="text" name="BSMI" size="20" value="<?php echo $BSMI;?>"></td>
			        </tr>
			        <tr height="60" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">商 標：</td>
			          <td class="h3">
	              	<table width="100%" border="0" cellpadding="0" cellspacing="0">
	              		<tr class="h3">
	              			<td width="40" align="center">圖片</td>
	              			<td align="center"><div id="TrademarkImgPreview" style="display:none"></div></td>
	              			<td align="center" valign="bottom"><div id="TrademarkImgDel" style="display:none"></div></td>
	              			<td>
				              	<input name="TrademarkImg" type="hidden" id="TrademarkImg" value="<?php echo $TrademarkImg;?>" />
				              	<input name="TrademarkImgUpload" type="button" class="input_bot" value="上傳" onclick="MM_openBrWindow('TrademarkImgUpload.php','_TrademarkImgUpload','scrollbars=no,resizable=no,width=450,height=180,top=200,left=200');" /> 
				              	<font color="blue">*上傳圖片限 gif 或 jpg 格式</font>
	              			</td>
	              		</tr>
	              		<tr>
	              			<td width="40" align="center" class="h3">文字</td>
	              			<td colspan="3">
				              	<input type="text" name="TrademarkTxt" size="40" value="<?php echo $TrademarkTxt;?>">
	              			</td>
	              		</tr>
	              	</table>
			          </td>
			        </tr>
							<?php
							if (trim($TrademarkImg) != "") {
									?>
									<SCRIPT language=javascript>
									<!--
											document.getElementById('TrademarkImgPreview').style.display = '';
											document.getElementById('TrademarkImgPreview').innerHTML = '<a href="getfile.php?FolderName=Admin\\TrademarkImg&FileName=<?php echo $TrademarkImg;?>"><img src="TrademarkImg/s<?php echo $TrademarkImg;?>" border="0"></a>';
											document.getElementById('TrademarkImgDel').style.display = '';
											document.getElementById('TrademarkImgDel').innerHTML = '<a href="javascript:;" onclick="javascript:DelTrademarkImg();">刪除</a>';
									//-->
									</SCRIPT>
									<?php
									}
							?>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">負責人：</td>
			          <td class="h3"><input type="text" name="Principal" size="60" value="<?php echo $Principal;?>"></td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">公司電話：</td>
			          <td class="h3"><input type="text" name="CTel" size="20" value="<?php echo $CTel;?>"></td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">公司傳真：</td>
			          <td class="h3"><input type="text" name="CFax" size="20" value="<?php echo $CFax;?>"></td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">發票地址：</td>
			          <td class="h3"><input type="text" name="CAddress" size="60" value="<?php echo $CAddress;?>"></td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">營登地址：</td>
			          <td class="h3"><input type="text" name="TAddress" size="60" value="<?php echo $TAddress;?>">
			          	 <input type="checkbox" name="cpa1" value="1" onclick="javascript:cpa_click1();"> 同上
			          </td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">聯絡地址：</td>
			          <td class="h3"><input type="text" name="LAddress" size="60" value="<?php echo $LAddress;?>">
			          	 <input type="checkbox" name="cpa2" value="1" onclick="javascript:cpa_click2();"> 同上
			          </td>
			        </tr>
			        <?php if (trim($GUI) == "") $GUI=$CUID;?>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">發票用統一編號：</td>
			          <td class="h3"><input type="text" name="GUI" size="60" value="<?php echo $GUI;?>"></td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">備 註：</td>
			          <td class="h3"><input type="text" name="CNote" size="60" value="<?php echo $CNote;?>"></td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">新增人員：</td>
			          <td class="h3"><?php echo $AddUser;?>　<?php echo $AddDate;?></td>
			        </tr>
			        <?php if (trim($ProcUser) != "") {?>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">最後更新：</td>
			          <td class="h3"><?php echo $ProcUser;?>　<?php echo $ProcDate;?> 
			          	<input type="button" name="edit" value="歷史記錄" class="input_bot" onclick="javascript:window.open ('CustomerHistory.php?CID=<?php echo $CID;?>','CustomerHistory','height=500,width=750,top=200,left=200,scrollbars=yes,status=yes');">
			          </td>
			        </tr>
			        <?php }?>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td class="c3">備註：</td>
			          <td class="h3"></td>
			        </tr>
			        <tr height="40" align="center">
			          <td colspan="2" class="h3">
			          	<IFRAME marginWidth="0" marginHeight="0" src="CustomerNote.php?CID=<?php echo $CID;?>" frameBorder="1" width="100%" scrolling="yes" height=250></IFRAME> 
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td class="c3">聯絡人：</td>
			          <td class="h3"></td>
			        </tr>
			        <tr height="40" align="center">
			          <td colspan="2" class="h3">
			          	<IFRAME marginWidth="0" marginHeight="0" src="CustomerContact.php?CID=<?php echo $CID;?>" frameBorder="1" width="100%" scrolling="yes" height=250></IFRAME> 
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td class="c3">相關檔案：</td>
			          <td class="h3"></td>
			        </tr>
			        <tr height="40" align="center">
			          <td colspan="2" class="h3">
			          	<IFRAME marginWidth="0" marginHeight="0" src="CustomerFile.php?CID=<?php echo $CID;?>" frameBorder="1" width="100%" scrolling="yes" height=250></IFRAME> 
			        </tr>
			        <?php if (trim(strstr($_SESSION["reg_MPer"],'P')) != "" || trim(strstr($_SESSION["reg_MPer"],'Q')) != "") {?>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td colspan="2" class="c3">報價/機密約定事項：</td>
			        </tr>
			        <tr height="40" align="center">
			          <td colspan="2" class="h3">
			          	<IFRAME marginWidth="0" marginHeight="0" src="CustomerSecret.php?CID=<?php echo $CID;?>" frameBorder="1" width="100%" scrolling="yes" height=250></IFRAME> 
			        </tr>
			        <?php }?>
			        <tr height="40" align="center">
			          <td colspan="2" class="h3"><input type="submit" name="submit" class="input_bot" value="送 出"></td>
			        </tr>
				      </form>
			      </table>
    			</td>
    		</tr>
    	</table>
    </td>
	</tr>
</table>
<?php include "down.php";?>
</body>
</html>
<?php
mysqli_close($link);
?>