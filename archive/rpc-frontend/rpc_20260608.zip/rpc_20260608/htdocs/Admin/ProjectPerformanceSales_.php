﻿<?php
include "CheckPermission.php";
include "CheckAccountingReport.php";
include "../global.php";
include "include/page_function.php";
$QAcR = $_POST['QAcR'];
if (trim($QAcR) == "") $QAcR = $_GET['QAcR'];
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $PageAdminTitle;?></title>
<link href="../type.css" rel="stylesheet" type="text/css" />
<link href="../script/DatePicker.css" rel="stylesheet" type="text/css" />
<Script LANGUAGE="Javascript" SRC="../script/DatePicker.js"></Script>
<Script type="text/javascript" language="javascript" src="../script/CheckForm.js"></Script>
<style type="text/css">
<!--
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
}
-->
</style>
<script type="text/JavaScript">
<!--
function jsCheck() 
		{
		if (jsTrim(document.form1.QSYear.value) != "" || jsTrim(document.form1.QSMonth.value) != "" || jsTrim(document.form1.QSDay.value) != "") if (ChkDate('QSYear',document.form1.QSYear.value,document.form1.QSMonth.value,document.form1.QSDay.value,'起始時間') == false) return false;
		if (jsTrim(document.form1.QEYear.value) != "" || jsTrim(document.form1.QEMonth.value) != "" || jsTrim(document.form1.QEDay.value) != "") if (ChkDate('QEYear',document.form1.QEYear.value,document.form1.QEMonth.value,document.form1.QEDay.value,'結束時間') == false) return false;
		if (jsTrim(document.form1.QSYear.value) != "" && jsTrim(document.form1.QSMonth.value) != "" && jsTrim(document.form1.QSDay.value) != "" && jsTrim(document.form1.QEYear.value) != "" && jsTrim(document.form1.QEMonth.value) != "" && jsTrim(document.form1.QEDay.value) != "") if (CompareDate('QSYear',document.form1.QSYear.value,document.form1.QSMonth.value,document.form1.QSDay.value,document.form1.QEYear.value,document.form1.QEMonth.value,document.form1.QEDay.value,'起始時間','結束時間') == false) return false;
		}
function PerformanceExport() 
		{
		document.form_exp.QSYear.value = document.form1.QSYear.value;
		document.form_exp.QSMonth.value = document.form1.QSMonth.value;
		document.form_exp.QSDay.value = document.form1.QSDay.value;
		document.form_exp.QEYear.value = document.form1.QEYear.value;
		document.form_exp.QEMonth.value = document.form1.QEMonth.value;
		document.form_exp.QEDay.value = document.form1.QEDay.value;
		document.form_exp.QPE.value = document.form1.QPE.value;
		document.form_exp.KeyWord.value = document.form1.KeyWord.value;
		document.form_exp.QPStatus.value = document.form1.QPStatus.value;
		document.form_exp.QAcR.value = '<?php echo $QAcR;?>';
		document.form_exp.submit();
		}
function ProjectExport() 
		{
		document.form_exp2.QSYear.value = document.form1.QSYear.value;
		document.form_exp2.QSMonth.value = document.form1.QSMonth.value;
		document.form_exp2.QSDay.value = document.form1.QSDay.value;
		document.form_exp2.QEYear.value = document.form1.QEYear.value;
		document.form_exp2.QEMonth.value = document.form1.QEMonth.value;
		document.form_exp2.QEDay.value = document.form1.QEDay.value;
		document.form_exp2.QPE.value = document.form1.QPE.value;
		document.form_exp2.KeyWord.value = document.form1.KeyWord.value;
		document.form_exp2.QPStatus.value = document.form1.QPStatus.value;
		document.form_exp2.QAcR.value = '<?php echo $QAcR;?>';
		document.form_exp2.submit();
		}
//-->
</script>
</head>

<body>
<?php include "top.php";?>
<table width="100%" border="0" cellspacing="0" cellpadding="5">
	<tr>
    <td width="160" height="600" align="left" valign="top">
			<?php include "menu.php";?>
    </td>
    <td valign="top">
    	<table width="100%" border="0" cellpadding="0" cellspacing="0">
    		<tr>
    			<td>
			    	<table width="750" border="0" cellpadding="0" cellspacing="0">
			    		<tr height="30">
			    			<td class="c2"> 業務 績效查核報表管理</td>
			    		</tr>
			    	</table>
						<?php
						$QSDate = $_POST['QSDate'];
						if (trim($QSDate) == "") $QSDate = $_GET['QSDate'];
						$QEDate = $_POST['QEDate'];
						if (trim($QEDate) == "") $QEDate = $_GET['QEDate'];
						if (trim($QSDate) == "") {
								$QSYear = $_POST['QSYear'];
								$QSMonth = $_POST['QSMonth'];
								$QSDay = $_POST['QSDay'];
								if (trim($QSYear) != "" || trim($QSMonth) != "" || trim($QSDay) != "") if (checkdate($QSMonth,$QSDay ,$QSYear)) $QSDate = $QSYear."-".$QSMonth."-".$QSDay;
								}
						if (trim($QEDate) == "") {
								$QEYear = $_POST['QEYear'];
								$QEMonth = $_POST['QEMonth'];
								$QEDay = $_POST['QEDay'];
								if (trim($QEYear) != "" || trim($QEMonth) != "" || trim($QEDay) != "") if (checkdate($QEMonth,$QEDay ,$QEYear)) $QEDate = $QEYear."-".$QEMonth."-".$QEDay;
								}
			    	$QPE = $_POST['QPE'];
			    	if (trim($QPE) == "") $QPE = $_GET['QPE'];

			    	$KeyWord = $_POST['KeyWord'];
			    	if (trim($KeyWord) == "") $KeyWord = $_GET['KeyWord'];
			    	$QPStatus = $_POST['QPStatus'];
			    	if (trim($QPStatus) == "") $QPStatus = $_GET['QPStatus'];
						if (trim($KeyWord) != "") {
								$SQL_ProjectCertificate="select PID from ProjectCertificate where Deltag='N' and PCNo like '%".$KeyWord."%' group by PID order by PID;";
								echo $SQL_ProjectCertificate;
								$result_ProjectCertificate=mysqli_query($link,$SQL_ProjectCertificate) or die ("無法執行查詢");
								$SqlPID = "";
								while(list($PC_PID)=mysqli_fetch_row($result_ProjectCertificate)){
										if (trim($SqlPID) == "") $SqlPID = $PC_PID;
										else $SqlPID = $SqlPID.",".$PC_PID;
										}
								mysqli_free_result($result_ProjectCertificate);

								$SQL_ProjectAccounting="select PID from ProjectAccounting where Deltag='N' and (PAItem like '%".$KeyWord."%' or Invoice like '%".$KeyWord."%' or PANote like '%".$KeyWord."%') group by PID order by PID;";
								$result_ProjectAccounting=mysqli_query($link,$SQL_ProjectAccounting) or die ("無法執行查詢");
								$SqlPID = "";
								while(list($PA_PID)=mysqli_fetch_row($result_ProjectAccounting)){
										if (trim($SqlPID) == "") $SqlPID = $PA_PID;
										else $SqlPID = $SqlPID.",".$PA_PID;
										}
								mysqli_free_result($result_ProjectAccounting);
								}
						if (trim($SqlPID) != "") $SqlPID = " PID in (".$SqlPID.")";
			    	if (trim($KeyWord) != "") {
			    			if (trim($SqlPID) == "") $SqlTxt = $SqlTxt." and (PUID like '%".$KeyWord."%' or CName like '%".$KeyWord."%' or CTel like '%".$KeyWord."%' or CFax like '%".$KeyWord."%' or Contact like '%".$KeyWord."%' or CMobile like '%".$KeyWord."%' or CEMail like '%".$KeyWord."%' or CAddress like '%".$KeyWord."%' or PName like '%".$KeyWord."%' or ModelName like '%".$KeyWord."%' or SeriesModel like '%".$KeyWord."%' or PE like '%".$KeyWord."%' or PNote like '%".$KeyWord."%')";
			    			else $SqlTxt = $SqlTxt." and (PUID like '%".$KeyWord."%' or CName like '%".$KeyWord."%' or CTel like '%".$KeyWord."%' or CFax like '%".$KeyWord."%' or Contact like '%".$KeyWord."%' or CMobile like '%".$KeyWord."%' or CEMail like '%".$KeyWord."%' or CAddress like '%".$KeyWord."%' or PName like '%".$KeyWord."%' or ModelName like '%".$KeyWord."%' or SeriesModel like '%".$KeyWord."%' or PE like '%".$KeyWord."%' or PNote like '%".$KeyWord."%' or ApplyItem like '%".$KeyWord."%' or ".$SqlPID.")";
			    			}

						if (trim($QAcR) != "") {
								$SQL_QAcR="SELECT DISTINCT a.PID FROM Project a, ProjectAccounting b WHERE a.PID = b.PID AND a.Deltag = 'N' AND b.Deltag = 'N' AND a.InvoiceDate is not null AND b.PAStatus = 'W' ORDER BY a.PID";
								$result_QAcR=mysqli_query($link,$SQL_QAcR) or die ("無法執行查詢");
								$Sql_PID = "";
								while(list($PQ_PID)=mysqli_fetch_row($result_QAcR)){
										if (trim($Sql_PID) == "") $Sql_PID = $PQ_PID;
										else $Sql_PID = $Sql_PID.",".$PQ_PID;
										}
								mysqli_free_result($result_QAcR);
								}

						if (trim($QSDate) != "" && trim($QEDate) != "") $SqlTxt = $SqlTxt." and (AddDate >= '".$QSDate." 00:00:00') and (AddDate <= '".$QEDate." 23:59:59') ";
						else if (trim($QSDate) != "" && trim($QEDate) == "") $SqlTxt = $SqlTxt." and (AddDate >= '".$QSDate." 00:00:00') ";
						else if (trim($QSDate) == "" && trim($QEDate) != "") $SqlTxt = $SqlTxt." and (AddDate <= '".$QEDate." 23:59:59') ";

						if (trim($Sql_PID) != "") $SqlTxt = $SqlTxt . " and PID in (".$Sql_PID.")";
			    	//if (trim($KeyWord) != "") $SqlTxt = " and (PUID like '%".$KeyWord."%' or CName like '%".$KeyWord."%' or CTel like '%".$KeyWord."%' or CFax like '%".$KeyWord."%' or Contact like '%".$KeyWord."%' or CMobile like '%".$KeyWord."%' or CEMail like '%".$KeyWord."%' or CAddress like '%".$KeyWord."%' or PName like '%".$KeyWord."%' or ModelName like '%".$KeyWord."%' or SeriesModel like '%".$KeyWord."%' or PE like '%".$KeyWord."%')";
			    	if (trim($QPE) != "") $SqlTxt = $SqlTxt." and PE='".$QPE."' ";
			    	if (trim($QPStatus) != "") $SqlTxt = $SqlTxt." and PStatus='".$QPStatus."' ";
						$page = $_GET['page'];
						if (trim($page) == "") $page = 1;
						$page_rows=15;  //每頁筆數
						$php_Self = "ProjectPerformance.php";  //分頁web檔名

						$button_css = "h4";
						$limit_txt =" limit ".(($page-1) * $page_rows).",".$page_rows;
						$url_str = "&QSDate=".$QSDate."&QEDate=".$QEDate."&QPE=".$QPE."&QPStatus=".$QPStatus."&QAcR=".$QAcR."&KeyWord=".urlencode($KeyWord);
						$Sql_str="select PID,PUID,CID,CName,CTel,CFax,Contact,CMobile,CEMail,CAddress,PStatus,PName,ModelName,SeriesModel,PE,Quote,ApplyItem,Canon,SNote,PlanDate,CloseDate,PNote,QuoteDate,ReturnDate from Project where Deltag='N' ".$SqlTxt." order by PStatus asc,PID desc;";
						$SQL_Project="select PID,PUID,CID,CName,CTel,CFax,Contact,CMobile,CEMail,CAddress,PStatus,PName,ModelName,SeriesModel,PE,(select MName from Manager where MUID=Project.PE and DelTag='N') PEName,(select MEName from Manager where MUID=Project.PE and DelTag='N') PEEName,Quote,ApplyItem,Canon,SNote,PlanDate,CloseDate,PNote,QuoteDate,ReturnDate from Project where Deltag='N' ".$SqlTxt." order by PStatus asc,PID desc ".$limit_txt.";";
						$result_Project=mysqli_query($link,$SQL_Project) or die ("無法執行查詢");
						?>
			    	<table width="750" border="0" cellpadding="0" cellspacing="0">
			    		<form name="form1" action="ProjectPerformance.php" method="post" onSubmit="return jsCheck();">
			        <tr onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td class="h3">案件日期：
			            <input name="QSYear" type="text" size="4" value="<?php echo $QSYear;?>" />年
			            <input name="QSMonth" type="text" size="2" value="<?php echo $QSMonth;?>" />月
			            <input name="QSDay" type="text" size="2" value="<?php echo $QSDay;?>" />日
			            <img src="../images/icon.gif" width="16" height="18" style="cursor: hand" onclick="javascript:displayDatePicker('QSYear','QSMonth','QSDay');"/>～
			            <input name="QEYear" type="text" size="4" value="<?php echo $QEYear;?>" />年
			            <input name="QEMonth" type="text" size="2" value="<?php echo $QEMonth;?>" />月
			            <input name="QEDay" type="text" size="2" value="<?php echo $QEDay;?>" />日
			            <img src="../images/icon.gif" width="16" height="18" style="cursor: hand" onclick="javascript:displayDatePicker('QEYear','QEMonth','QEDay');"/>
			    				 狀態：
			    				<select name="QPStatus">
			    					<option value="">不限</option>
			    					<option value="A"<?php if (trim($QPStatus) == "A") echo " selected";?>>新開案</option>
			    					<option value="B"<?php if (trim($QPStatus) == "B") echo " selected";?>>報價中</option>
			    					<option value="C"<?php if (trim($QPStatus) == "C") echo " selected";?>>案件處理中</option>
			    					<option value="D"<?php if (trim($QPStatus) == "D") echo " selected";?>>審查中</option>
			    					<option value="E"<?php if (trim($QPStatus) == "E") echo " selected";?>>補件中</option>
			    					<option value="F"<?php if (trim($QPStatus) == "F") echo " selected";?>>待印證</option>
			    					<option value="G"<?php if (trim($QPStatus) == "G") echo " selected";?>>案件取消</option>
			    					<option value="H"<?php if (trim($QPStatus) == "H") echo " selected";?>>已結案</option>
			    				</select>
			          </td>
			        </tr>
			    		<tr>
			    			<td align="left" class="h3">
			    				案件業務：
				    			<?php
									$SQL_Manager="select MUID,MName,MEName from Manager where Deltag='N' and ISBusiness = 'Y' and IsLeft='N';";
									$result_Manager=mysqli_query($link,$SQL_Manager) or die ("無法執行查詢");
				    			?>
			    				<select name="QPE">
			    					<option value="">不限</option>
			          		<?php while(list($MUID,$MName,$MEName)=mysqli_fetch_row($result_Manager)){?>
			          		<option value="<?php echo $MUID;?>"<?php if (trim($MUID) == trim($QPE)) echo " selected";?>><?php echo $MEName.$MName;?></option>
			          		<?php }?>
			    				</select>
					        <?php
					        mysqli_free_result($result_Manager);
					        ?>
			    				 關鍵字：<input type="text" name="KeyWord" size="10" value="<?php echo $KeyWord;?>"> 
								  <input type="submit" name="search" class="input_bot" value="查詢"> <input type="button" name="button" class="input_bot" value="全部列出" onclick="javascript:location.href='ProjectPerformance.php';"> 
			    			  <input type="button" name="report" class="input_bot" value="報表輸出" onclick="javascript:PerformanceExport();"> 
			    			  <input type="button" name="report" class="input_bot" value="時間統計報表" onclick="javascript:ProjectExport();">
			    			</td>
			    		</tr>
			    		</form>
			    	</table>
			    	<table width="750" border="0" cellpadding="5" cellspacing="2" class="s2">
			        <tr align="center">
			          <td width="80" align="center" background="../images/table_bg.gif" class="t21">案件編號</td>
			          <td width="250" background="../images/table_bg.gif" class="t21">產品名稱</td>
			          <td width="250" background="../images/table_bg.gif" class="t21">客戶名稱</td>
			          <td width="100" background="../images/table_bg.gif" class="t21">狀態<br>案件業務</td>
			          <td width="60" background="../images/table_bg.gif" class="t21">詳 細</td>
			        </tr>
		          <?php
		          $tmp = 1;
		          while(list($PID,$PUID,$CID,$CName,$CTel,$CFax,$Contact,$CMobile,$CEMail,$CAddress,$PStatus,$PName,$ModelName,$SeriesModel,$PE,$PEName,$PEEName,$Quote,$ApplyItem,$Canon,$SNote,$PlanDate,$CloseDate,$PNote,$QuoteDate,$ReturnDate)=mysqli_fetch_row($result_Project)){
		        	if (trim($ModelName) == "") $ModelName = "NA";
		        	?>
		        	<tr<?php if ($tmp%2 == 0) echo " bgcolor=\"#F6F6F6\"";?>>
			          <td align="center" class="h3"><?php echo $PUID;?></td>
			          <td class="h3"><?php echo $PName;?></td>
			          <td class="h3"><?php echo $CName;?></td>
			          <td align="center" class="h3">
			          	<?php
			          	if (trim($PStatus) == "A") echo "新開案";
			          	else if (trim($PStatus) == "B") echo "報價中";
			          	else if (trim($PStatus) == "C") echo "案件處理中";
			          	else if (trim($PStatus) == "D") echo "審查中";
			          	else if (trim($PStatus) == "E") echo "補件中";
			          	else if (trim($PStatus) == "F") echo "待印證";
			          	else if (trim($PStatus) == "G") echo "案件取消";
			          	else if (trim($PStatus) == "H") echo "已結案";
			          	echo "<br>".$PEEName.$PEName;
			          	?>
			          </td>
			          <td align="center"><input type="button" name="edit" value="詳 細" class="input_bot" onclick="javascript:location.href='ProjectDetail.php?PID=<?php echo $PID;?>&page=<?php echo $page;?><?php echo $url_str;?>';"></td>
			        </tr>
			        <?php
            			$tmp++;
			      			}
            	mysqli_free_result($result_Project);
			        ?>
			      </table>
			      <table width="750" border="0" cellpadding="5" cellspacing="2" class="s2">
			        <tr align="center">
			          <td bgcolor="#E8F0C2" class="h4"><?php Page_show($Sql_str,$page_rows,$php_Self,$link,$page,$url_str,$button_css);?></td>
			        </tr>
			      </table>
    			</td>
    		</tr>
    	</table>
    </td>
	</tr>
</table>
<form name="form_exp" action="ProjectPerformanceExport.php" method="post" target="_PerformanceExport">
	<input type="hidden" name="QSYear">
	<input type="hidden" name="QSMonth">
	<input type="hidden" name="QSDay">
	<input type="hidden" name="QEYear">
	<input type="hidden" name="QEMonth">
	<input type="hidden" name="QEDay">
	<input type="hidden" name="QPE">
	<input type="hidden" name="KeyWord">
	<input type="hidden" name="QPStatus">
	<input type="hidden" name="QAcR">
</form>
<form name="form_exp2" action="ProjectExport.php" method="post" target="_ProjectExport">
	<input type="hidden" name="QSYear">
	<input type="hidden" name="QSMonth">
	<input type="hidden" name="QSDay">
	<input type="hidden" name="QEYear">
	<input type="hidden" name="QEMonth">
	<input type="hidden" name="QEDay">
	<input type="hidden" name="QPE">
	<input type="hidden" name="KeyWord">
	<input type="hidden" name="QPStatus">
	<input type="hidden" name="QAcR">
</form>
<?php include "down.php";?>
</body>
</html>
<?php
mysqli_close($link);
?>