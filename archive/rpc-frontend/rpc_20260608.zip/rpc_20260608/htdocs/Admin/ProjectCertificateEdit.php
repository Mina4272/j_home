﻿<?php	
include "CheckPermission.php";
include "CheckProject.php";
include "../global.php";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $PageAdminTitle;?></title>
<link href="../type.css" rel="stylesheet" type="text/css" />
<style type="text/css">
<!--
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
}
-->
</style>
<link href="../script/DatePicker.css" rel="stylesheet" type="text/css" />
<Script LANGUAGE="Javascript" SRC="../script/DatePicker.js"></Script>
<Script type="text/javascript" language="javascript" src="../script/CheckForm.js"></Script>
<script type="text/JavaScript">
<!--
function jsCheck() 
		{
		if (ChkImp('PCNo',document.form1.PCNo.value,'証書編號') == false) return false;
		if (ChkImp('PCName',document.form1.PCName.value,'証書名稱') == false) return false;
		if (document.form1.PCType.value == "D") if (ChkImp('PCTypeName',document.form1.PCTypeName.value,'其他種類名稱') == false) return false;
		//if (ChkImp('PCFile',document.form1.PCFile.value,'証書檔案') == false) return false;
		if (jsTrim(document.form1.PCSYear.value) != "" || jsTrim(document.form1.PCSMonth.value) != "" || jsTrim(document.form1.PCSDay.value) != "") if (ChkDate('PCSYear',document.form1.PCSYear.value,document.form1.PCSMonth.value,document.form1.PCSDay.value,'証書有效起始日期') == false) return false;
		if (jsTrim(document.form1.PCEYear.value) != "" || jsTrim(document.form1.PCEMonth.value) != "" || jsTrim(document.form1.PCEDay.value) != "") if (ChkDate('PCEYear',document.form1.PCEYear.value,document.form1.PCEMonth.value,document.form1.PCEDay.value,'証書有效結束日期') == false) return false;
		//if (jsTrim(document.form1.PCSYear.value) != "" || jsTrim(document.form1.PCSMonth.value) != "" || jsTrim(document.form1.PCSDay.value) != "" || jsTrim(document.form1.PCEYear.value) != "" || jsTrim(document.form1.PCEMonth.value) != "" || jsTrim(document.form1.PCEDay.value) != "") {
		//		if (jsTrim(document.form1.PCSYear.value) == "" || jsTrim(document.form1.PCSMonth.value) == "" || jsTrim(document.form1.PCSDay.value) == "" || jsTrim(document.form1.PCEYear.value) == "" || jsTrim(document.form1.PCEMonth.value) == "" || jsTrim(document.form1.PCEDay.value) == "") {
		//				alert("請輸入完整的有效日期！");
		//				return false;
		//				}
		//		}
		if (jsTrim(document.form1.PCSYear.value) != "" && jsTrim(document.form1.PCSMonth.value) != "" && jsTrim(document.form1.PCSDay.value) != "" && jsTrim(document.form1.PCEYear.value) != "" && jsTrim(document.form1.PCEMonth.value) != "" && jsTrim(document.form1.PCEDay.value) != "") if (CompareDate('PCSYear',document.form1.PCSYear.value,document.form1.PCSMonth.value,document.form1.PCSDay.value,document.form1.PCEYear.value,document.form1.PCEMonth.value,document.form1.PCEDay.value,'啟始日期','結束日期') == false) return false;
		}
//-->
</script>
</head>
<body>
<?php
$PCID = $_GET['PCID'];
$PID = $_GET['PID'];
if (trim($PID) == "" || trim($PCID) == "")
		{
		mysqli_close($link);
		?>
		<script type="text/JavaScript">
			<!--
			alert ("查無資料，請冾網站管理人員！");
			self.close();
			//-->
		</script>
		<?php
		exit;
		}
$SQL_ProjectCertificate="select PCNo,PCName,PCType,PCTypeName,PCFile,PCSDate,date_format(PCSDate,'%Y'),date_format(PCSDate,'%m'),date_format(PCSDate,'%d'),PCEDate,date_format(PCEDate,'%Y'),date_format(PCEDate,'%m'),date_format(PCEDate,'%d'),PCNote,ExpireDate,date_add( ExpireDate, INTERVAL -3 MONTH ) EpDate,date_format(ExpireDate,'%Y'),date_format(ExpireDate,'%m'),DateDiff(ExpireDate,PCEDate) ExpireNum,RemindNote,(select MName from Manager where MUID=ProjectCertificate.Reminder) RMName,(select MEName from Manager where MUID=ProjectCertificate.Reminder) RMEName,RemindDate,AddUser,AddDate,ProcUser,ProcDate from ProjectCertificate where Deltag='N' and PID = '".$PID."' and PCID = '".$PCID."';";
$result_ProjectCertificate=mysqli_query($link,$SQL_ProjectCertificate) or die ("無法執行查詢");
if (mysqli_num_rows($result_ProjectCertificate) == 0)
		{
		mysqli_free_result($result_ProjectCertificate);
		mysqli_close($link);
		?>
		<SCRIPT language=javascript>
		<!--
		alert ("查無資料，請冾網站管理人員！"); 
		self.close();
		//-->
		</SCRIPT>
		<?php 	
		exit;
		}
list($PCNo,$PCName,$PCType,$PCTypeName,$PCFile,$PCSDate,$PCSYear,$PCSMonth,$PCSDay,$PCEDate,$PCEYear,$PCEMonth,$PCEDay,$PCNote,$ExpireDate,$EpDate,$ExpireYear,$ExpireMonth,$ExpireNum,$RemindNote,$RMName,$RMEName,$RemindDate,$AddUser,$AddDate,$ProcUser,$ProcDate)=mysqli_fetch_row($result_ProjectCertificate);
mysqli_free_result($result_ProjectCertificate);
?>
<table width="100%" border="0" cellpadding="0" cellspacing="0">
	<tr>
		<td>
    	<table width="100%" border="0" cellpadding="0" cellspacing="0">
    		<tr height="30">
					<td width="15" background="../images/table_bg.gif"></td>
    			<td class="c3" background="../images/table_bg.gif"><b>修改案件証書資料</b></td>
    		</tr>
    	</table>
    	<table width="100%" border="0" cellpadding="0" cellspacing="0">
        <form name="form1" method="post" action="ProjectCertificateEditDB.php" enctype="multipart/form-data" onSubmit="return jsCheck();">
        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
					<td width="15"></td>
          <td width="160" class="c3" align="right">証書編號：</td>
          <td class="c3">
          	<input id="PCNo" name="PCNo" type="text" size="20" value="<?php echo $PCNo;?>" />
          </td>
        </tr>
        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
					<td width="15"></td>
          <td class="c3" align="right">証書名稱：</td>
          <td class="c3">
          	<input id="PCName" name="PCName" type="text" size="20" value="<?php echo $PCName;?>" />
          </td>
        </tr>
        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
					<td width="15"></td>
          <td class="c3" align="right">証書種類：</td>
          <td class="c3">
          	<select id="PCType" name="PCType">
          		<option value="A"<?php if (trim($PCType) == "A") echo " selected";?>>環保標章</option>
          		<option value="B"<?php if (trim($PCType) == "B") echo " selected";?>>BSMI證書</option>
          		<option value="C"<?php if (trim($PCType) == "C") echo " selected";?>>消防證書</option>
          		<option value="D"<?php if (trim($PCType) == "D") echo " selected";?>>其他</option>
          	</select> 其他種類名稱：<input type="text" name="PCTypeName" size="10" value="<?php echo $PCTypeName;?>">
          </td>
        </tr>
        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
					<td width="15"></td>
          <td class="c3" align="right">証書檔案：</td>
          <td class="c3">
          	<input id="PCFile" name="PCFile" type="file" size="60" />
          	<input type="button" name="edit" value="下 載" class="input_bot" onclick="javascript:location.href='getfile.php?FolderName=Admin\\PCFile&FileName=<?php echo $PCFile;?>';">
          </td>
        </tr>
        <?php
        if (trim($PCSYear) == "0000") $PCSYear = "";
        if (trim($PCSMonth) == "00") $PCSMonth = "";
        if (trim($PCSDay) == "00") $PCSDay = "";
        if (trim($PCEYear) == "0000") $PCEYear = "";
        if (trim($PCEMonth) == "00") $PCEMonth = "";
        if (trim($PCEDay) == "00") $PCEDay = "";
        if (trim($ExpireNum) <= 0 || is_numeric($ExpireNum) == false) $ExpireMonth="";
        else {
        		$ExpireMonth = round($ExpireNum/30);
        		if (strlen($ExpireMonth) < 2) $ExpireMonth="0".$ExpireMonth;
        		}
        ?>
        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
					<td width="15"></td>
          <td class="c3" align="right">有效日期：</td>
          <td class="h3">
            <input id="PCSYear" name="PCSYear" type="text" size="4" value="<?php echo $PCSYear;?>" />年
            <input id="PCSMonth" name="PCSMonth" type="text" size="2" value="<?php echo $PCSMonth;?>" />月
            <input id="PCSDay" name="PCSDay" type="text" size="2" value="<?php echo $PCSDay;?>" />日
            <img src="../images/icon.gif" width="16" height="18" style="cursor: hand" onclick="javascript:displayDatePicker('PCSYear','PCSMonth','PCSDay');"/>～
            <input id="PCEYear" name="PCEYear" type="text" size="4" value="<?php echo $PCEYear;?>" />年
            <input id="PCEMonth" name="PCEMonth" type="text" size="2" value="<?php echo $PCEMonth;?>" />月
            <input id="PCEDay" name="PCEDay" type="text" size="2" value="<?php echo $PCEDay;?>" />日
            <img src="../images/icon.gif" width="16" height="18" style="cursor: hand" onclick="javascript:displayDatePicker('PCEYear','PCEMonth','PCEDay');"/>
          </td>
        </tr>
        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
					<td width="15"></td>
          <td class="c3" align="right">備註：</td>
          <td class="h3">
            <input id="PCNote" name="PCNote" type="text" size="40" value="<?php echo $PCNote;?>" />
          </td>
        </tr>
        <?php if (trim($RemindNote) != "") {?>
        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
					<td width="15"></td>
          <td class="c3" align="right">取消提醒原因：</td>
          <td class="h3">
            <?php
            echo $RemindNote."( 記錄人員：".$RMEName.$RMName." ".$RemindDate.")";
            ?>
          </td>
        </tr>
        <?php }?>
        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
					<td width="15"></td>
          <td class="c3" align="right">延長證書提醒時間：</td>
          <td class="h3">
            <select id="ExpireMonth" name="ExpireMonth">
            	<option value=""></option>
            	<option value="01"<?php if (trim($ExpireMonth) == "01") echo " selected";?>>01</option>
            	<option value="02"<?php if (trim($ExpireMonth) == "02") echo " selected";?>>02</option>
            	<option value="03"<?php if (trim($ExpireMonth) == "03") echo " selected";?>>03</option>
            	<option value="04"<?php if (trim($ExpireMonth) == "04") echo " selected";?>>04</option>
            	<option value="05"<?php if (trim($ExpireMonth) == "05") echo " selected";?>>05</option>
            	<option value="06"<?php if (trim($ExpireMonth) == "06") echo " selected";?>>06</option>
            	<option value="07"<?php if (trim($ExpireMonth) == "07") echo " selected";?>>07</option>
            	<option value="08"<?php if (trim($ExpireMonth) == "08") echo " selected";?>>08</option>
            	<option value="09"<?php if (trim($ExpireMonth) == "09") echo " selected";?>>09</option>
            	<option value="10"<?php if (trim($ExpireMonth) == "10") echo " selected";?>>10</option>
            	<option value="11"<?php if (trim($ExpireMonth) == "11") echo " selected";?>>11</option>
            	<option value="12"<?php if (trim($ExpireMonth) == "12") echo " selected";?>>12</option>
            </select> 月 ( <font color=red>設定提醒時間：<b><?php echo $EpDate;?></b></font> )
          </td>
        </tr>
        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
					<td width="15"></td>
          <td align="right" class="c3">新增人員：</td>
          <td class="h3"><?php echo $AddUser;?>　<?php echo $AddDate;?></td>
        </tr>
        <?php if (trim($ProcUser) != "") {?>
        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
					<td width="15"></td>
          <td align="right" class="c3">最後更新：</td>
          <td class="h3"><?php echo $ProcUser;?>　<?php echo $ProcDate;?>
          	<input type="button" name="edit" value="歷史記錄" class="input_bot" onclick="javascript:window.open ('ProjectCertificateHistory.php?PID=<?php echo $PID;?>&PCID=<?php echo $PCID;?>','ProjectCertificateHistory','height=500,width=950,top=200,left=200,scrollbars=yes,status=yes');">
          </td>
        </tr>
        <?php }?>
        <tr height="40" align="center">
					<td width="15"></td>
          <td colspan="2" class="h3">
          	<input type="submit" name="submit" class="input_bot" value="送 出">
          	<input name="PCID" type="hidden" id="PCID" value="<?php echo $PCID;?>" />
          	<input name="PID" type="hidden" id="PID" value="<?php echo $PID;?>" />
          </td>
        </tr>
	      </form>
      </table>
		</td>
	</tr>
</table>
</body>
</html>
<?php
mysqli_close($link);
?>