﻿<?php
include "CheckPermission.php";
include "../global.php";
require_once("../include/chinese_party.class.php");
require("class.phpmailer.php");
include "include/function.php";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $PageAdminTitle;?></title>
</head>
<body>
<?php
$MVFile = "MVFile".rand_string(12, 'ABCDEFGHIJKLMNPQRSTUVWXYZ23456789abcdefghijklmnopqrstuvwxyz').".".strtolower(substr($_FILES['MVFile']['name'],strrpos($_FILES['MVFile']['name'],".")+1,strlen($_FILES['MVFile']['name'])+1));
@copy($_FILES['MVFile']['tmp_name'],$_SERVER["DOCUMENT_ROOT"]."\\Admin\\MVFile\\".$MVFile);
$MVID = $_POST['MVID'];
$page = $_POST['page'];
$QMVSDate = $_POST['QMVSDate'];
$QMVEDate = $_POST['QMVEDate'];
$QMVType = $_POST['QMVType'];
$QMUID = $_POST['QMUID'];
$KeyWord = $_POST['KeyWord'];
$QAgent = $_POST['QAgent'];
$QMVCheck = $_POST['QMVCheck'];

$MVType = $_POST['MVType'];
$MVSYear = $_POST['MVSYear'];
$MVSMonth = $_POST['MVSMonth'];
$MVSDay = $_POST['MVSDay'];
if (trim($MVSYear) != "" || trim($MVSMonth) != "" || trim($MVSDay) != "") if (checkdate($MVSMonth,$MVSDay ,$MVSYear)) $MVSDate = $MVSYear."-".$MVSMonth."-".$MVSDay;
$MVSHouse = $_POST['MVSHouse'];
$MVSMin = $_POST['MVSMin'];

$MVEYear = $_POST['MVEYear'];
$MVEMonth = $_POST['MVEMonth'];
$MVEDay = $_POST['MVEDay'];
if (trim($MVEYear) != "" || trim($MVEMonth) != "" || trim($MVEDay) != "") if (checkdate($MVEMonth,$MVEDay ,$MVEYear)) $MVEDate = $MVEYear."-".$MVEMonth."-".$MVEDay;
$MVEHouse = $_POST['MVEHouse'];
$MVEMin = $_POST['MVEMin'];

$Hourage = $_POST['Hourage'];
$Agent = $_POST['Agent'];
$MVNote = $_POST['MVNote'];
if (trim($MVSDate) != "") $MVSDate=$MVSDate." ".$MVSHouse.":".$MVSMin.":00";
else $MVSDate="";
if (trim($MVEDate) != "") $MVEDate=$MVEDate." ".$MVEHouse.":".$MVEMin.":00";
else $MVEDate="";
$MVSend = $_POST['MVSend'];

if (trim($MVID) == "" || trim($MVType) == "" || trim($MVSDate) == "" || trim($MVEDate) == "" || trim($Hourage) == "" || trim($Agent) == "" || trim($MVSend) == "")
		{
		mysqli_close($link);
		?>
		<script type="text/JavaScript">
			<!--
			alert ("您輸入的資料不足，請重新輸入！");
			history.go(-1);
			//-->
		</script>
		<?php
		exit;
		}
$SQL_ManagerVac="select MUID,MVCheck,MVSend from ManagerVac where Deltag='N' and MVID=".$MVID.";";
$result_ManagerVac=mysqli_query($link,$SQL_ManagerVac) or die ("無法執行查詢");
if (mysqli_num_rows($result_ManagerVac) == 0)
		{
		mysqli_free_result($result_Manager);
		mysqli_close($link);
		?>
		<SCRIPT language=javascript>
		<!--
		alert ("查無資料，請冾網站管理人員！"); 
		history.go(-1);
		//-->
		</SCRIPT>
		<?php 	
		exit;
		}
list($MUID,$MVCheck,$MVSended)=mysqli_fetch_row($result_ManagerVac);
mysqli_free_result($result_ManagerVac);

if (trim($MVCheck) != "W")
		{
		mysqli_close($link);
		?>
		<script type="text/JavaScript">
			<!--
			alert ("此請假單已簽核，不得修改！");
			history.go(-1);
			//-->
		</script>
		<?php
		exit;
		}
if (trim($MVSended) == "Y")
		{
		mysqli_close($link);
		?>
		<script type="text/JavaScript">
			<!--
			alert ("此請假單已送審，不得修改！");
			history.go(-1);
			//-->
		</script>
		<?php
		exit;
		}
if (trim($MUID) != trim($_SESSION["reg_MUID"]))
		{
		mysqli_close($link);
		?>
		<script type="text/JavaScript">
			<!--
			alert ("此請假單非本人，不得修改！");
			history.go(-1);
			//-->
		</script>
		<?php
		exit;
		}

$sql="SELECT * FROM ManagerVac WHERE Deltag = 'N' and MUID = '".$_SESSION["reg_MUID"]."' and MVCheck in ('W','Y') and ('".$MVSDate."' BETWEEN MVSDate and MVEDate or '".$MVEDate."' BETWEEN MVSDate and MVEDate) and MVID <> " . $MVID;
$result=mysqli_query($link,$sql) or die ("無法執行查詢");
if (mysqli_num_rows($result) > 0)
		{
		mysqli_free_result($result);
		mysqli_close($link);
		?>
		<SCRIPT language=javascript>
		<!--
		alert ("您申請的日期：<?php echo $MVSDate . "~" . $MVEDate?> 已申請過了，請勿重覆申請！"); 
		history.go(-1);
		//-->
		</SCRIPT>
		<?php 	
		exit;
		}
mysqli_free_result($result);

$now_time = date("Y-m-d H:i:s",mktime());
$sql_insert = "INSERT INTO ManagerVacHistory(MVID,MUID,MVType,MVSDate,MVEDate,Hourage,Agent,MVNote,MVSend,MVCheck,MVCNote,MVCheckID,MVCheckDate,MVCheckIP,AddUser,AddDate,AddIP,Deltag,ProcUser,ProcDate,ProcIP,UpdateUser,UpdateDate,UpdateIP) SELECT MVID,MUID,MVType,MVSDate,MVEDate,Hourage,Agent,MVNote,MVSend,MVCheck,MVCNote,MVCheckID,MVCheckDate,MVCheckIP,AddUser,AddDate,AddIP,Deltag,ProcUser,ProcDate,ProcIP,'".$_SESSION["reg_MUID"]."','".$now_time."','".$_SERVER["REMOTE_ADDR"]."' from ManagerVac where Deltag='N' and MVID=".$MVID.";";
$result_insert=mysqli_query($link,$sql_insert) or die ("無法執行新增");
$sql_update = "update ManagerVac set MVType = '".$MVType."',MVFile = '".$MVFile."',MVSDate = '".$MVSDate."',MVEDate = '".$MVEDate."',Hourage = '".$Hourage."',Agent = '".$Agent."',MVNote = '".$MVNote."',MVSend = '".$MVSend."',ProcUser = '".$_SESSION["reg_MUID"]."',ProcDate = '".$now_time."',ProcIP = '".$_SERVER["REMOTE_ADDR"]."' where Deltag='N' and MVID=".$MVID.";";
$result_update=mysqli_query($link,$sql_update) or die ("無法執行修改");

if (trim($MVSend) == "Y") {
		if (trim($MVType) == "A") $MVType="事假";
		else if (trim($MVType) == "B") $MVType="病假";
		else if (trim($MVType) == "C") $MVType="公假";
		else if (trim($MVType) == "D") $MVType="喪假";
		else if (trim($MVType) == "E") $MVType="婚假";
		else if (trim($MVType) == "F") $MVType="產假";
		else if (trim($MVType) == "G") $MVType="特休";
		else if (trim($MVType) == "H") $MVType="其他";
		$SQL_Manager="select MName from Manager where MUID='".$MUID."'and Deltag='N';";
		$result_Manager=mysqli_query($link,$SQL_Manager) or die ("無法執行查詢");
		list($MName)=mysqli_fetch_row($result_Manager);
		mysqli_free_result($result_Manager);
    
		$SQL_Manager="select MName from Manager where MUID='".$Agent."'and Deltag='N';";
		$result_Manager=mysqli_query($link,$SQL_Manager) or die ("無法執行查詢");
		list($AMName)=mysqli_fetch_row($result_Manager);
		mysqli_free_result($result_Manager);
		
		$EMAILFN = "MVac.htm";
		$subject="請假申請通知 ！！";
		$fp=fopen($EMAILFN,"r");
		$content="";
		while($line=fgets($fp,512)){
			$content.=$line;
			}
		fclose($fp);
		
		$content = str_replace("{MName}",$MName.$MUID,$content);
		$content = str_replace("{MVType}",$MVType,$content);
		$content = str_replace("{MVDate}",$MVSDate." ~ ".$MVEDate,$content);
		$content = str_replace("{Hourage}",$Hourage,$content);
		$content = str_replace("{Agent}",$AMName,$content);
		$content = str_replace("{MVNote}",$MVNote,$content);
		
		//$cconv = new chinese_party();
		//$content = $cconv->u82tchi($content);
		//$subject = $cconv->u82tchi($subject);
    
		$SQL_Manager="SELECT EMail FROM Manager WHERE MPer LIKE '%J%' AND Deltag = 'N';";
		$result_Manager=mysqli_query($link,$SQL_Manager) or die ("無法執行查詢");
    while(list($EMail)=mysqli_fetch_row($result_Manager)){
				$mail = new PHPMailer();
				$mail->IsSMTP();
				$mail->SMTPAuth = true; //設定SMTP需要驗證
				$mail->SMTPSecure = "ssl"; // Gmail的SMTP主機需要使用SSL連線
				$mail->Host = "smtp.gmail.com"; //Gamil的SMTP主機
				$mail->Port = 465; //Gamil的SMTP主機的埠號(Gmail為465)。
				$mail->CharSet = "utf-8"; //郵件編碼
				$mail->Username = "Benson@rpclab.com"; //Gamil帳號
				$mail->Password = "76197619"; //Gmail密碼
				$mail->From     = "Benson@rpclab.com";
				$mail->FromName = $subject;
				$mail->WordWrap = 50;
				$mail->IsHTML(true);                               // send as HTML
				$mail->CharSet = "big5";
				$mail->Subject  = $subject;
				$mail->Body     =  $content;
				$mail->AddAddress($EMail,"");
				$mail->AddReplyTo("Benson@rpclab.com");
				if(!$mail->Send())
						{
				    //echo "There has been a mail error sending to " . $SendEMail . "<br>";
				    //echo "Mailer Error: " . $mail->ErrorInfo . "<br>";
				  	}
				else
						{
						//echo $SendEMail . " sending !!<br>";
						}
						
				$mail->ClearAddresses();
				$mail->ClearReplyTos();
				$mail->SmtpClose();
				}
  	mysqli_free_result($result_Manager);
		}
mysqli_close($link);
?>
<script type="text/JavaScript">
	<!--
	alert ("修改成功！");
	location.href='MVacList.php?page=<?php echo $page;?>&QMVSDate=<?php echo $QMVSDate;?>&QMVEDate=<?php echo $QMVEDate;?>&QMVType=<?php echo $QMVType;?>&QMUID=<?php echo $QMUID;?>&QAgent=<?php echo $QAgent;?>&QMVCheck=<?php echo $QMVCheck;?>&KeyWord=<?php echo urlencode($KeyWord);?>';
	//-->
</script>

</body>
</html>
