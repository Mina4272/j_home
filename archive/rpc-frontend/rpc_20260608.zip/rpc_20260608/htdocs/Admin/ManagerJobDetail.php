﻿<?php
include "CheckPermission.php";
include "../global.php";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $PageAdminTitle;?></title>
<link href="../type.css" rel="stylesheet" type="text/css" />
<style type="text/css">
<!--
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
}
-->
</style>
</head>
<body>
<?php include "top.php";?>
<?php
$MJID = empty($_GET['MJID'])?"":$_GET['MJID'];
$page = empty($_GET['page'])?"":$_GET['page'];
if (trim($MJID) == "")
		{
		mysqli_close($link);
		?>
		<script type="text/JavaScript">
			<!--
			alert ("查無資料，請冾網站管理人員！");
			history.go(-1);
			//-->
		</script>
		<?php
		exit;
		}

$SQL_ManagerJob="select a.MID, a.MJID, a.MJPeriod, a.MJTitle, a.MJDescription, a.MJDeputyID, a.MJNote, b.MName as MJDeputy from ManagerJob as a, Manager as b where a.MJDeputyID=b.MID and a.MJID='".$MJID."';";
$result_Manager=mysqli_query($link,$SQL_ManagerJob) or die ("沒有例行工作項目!");
						
if (mysqli_num_rows($result_Manager) == 0)
		{
		mysqli_free_result($result_Manager);
		mysqli_close($link);
		?>
		<SCRIPT language=javascript>
		<!--
		alert ("查無資料，請冾網站管理人員@！"); 
		history.go(-1);
		//-->
		</SCRIPT>
		<?php 	
		exit;
		}

list($MID,$MJID,$MJPeriod,$MJTitle,$MJDescription,$MJDeputyID,$MJNote, $MJDeputy)=mysqli_fetch_row($result_Manager);
mysqli_free_result($result_Manager);

$SQL_Manager="select MUID,MName from Manager where MID='".$MID."';";
$result_Manager=mysqli_query($link,$SQL_Manager) or die ("沒有例行工作項目!");
list($MUID,$MName)=mysqli_fetch_row($result_Manager);
mysqli_free_result($result_Manager);

?>
<table width="100%" border="0" cellspacing="0" cellpadding="5">
	<tr>
    <td width="160" height="600" align="left" valign="top">
			<?php include "menu.php";?>
    </td>
    <td valign="top">
    	<table width="100%" border="0" cellpadding="0" cellspacing="0">
    		<tr>
    			<td>
			    	<table width="750" border="0" cellpadding="0" cellspacing="0">
			    		<tr height="30">
			    			<td class="c2"><b>員工例行工作詳細資訊</b></td>
							
						<?php if ((trim(strstr($_SESSION["reg_MPer"],'G')) != "") || (strtolower($_SESSION["reg_MUID"]) == strtolower($MUID))){?>
							<td align="center"><input type="button" name="edit" value="修改" class="input_bot" onclick="javascript:location.href='ManagerJobEdit.php?MJID=<?php echo $MJID;?>&page=<?php echo $page;?>';"></td>
							<!--td align="center"><input type="button" name="edit" value="刪除" class="input_bot" onclick="javascript:if (confirm('您是否確定要刪除此工作項目？')) location.href='ManagerJobDelDB.php?MJID=<?php echo $MJID;?>&page=<?php echo $page;?>';"></td-->
						<?php }?>
						<?php if ((trim(strstr($_SESSION["reg_MPer"],'G')) != "")){?>
		  					<!--td align="center"><input type="button" name="edit" value="修改" class="input_bot" onclick="javascript:location.href='ManagerJobEdit.php?MJID=<?php echo $MJID;?>&page=<?php echo $page;?>';"></td-->
							<td align="center"><input type="button" name="edit" value="刪除" class="input_bot" onclick="javascript:if (confirm('您是否確定要刪除此工作項目？')) location.href='ManagerJobDelDB.php?MJID=<?php echo $MJID;?>&page=<?php echo $page;?>';"></td>
						<?php }?>
						
			    		</tr>
			    	</table>
			    	<table width="750" border="0" cellpadding="0" cellspacing="0">
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td width="160" align="right" class="c3">工作人員：</td>
			          <td class="h3"><?php echo $MName;?>
			          	<input type="hidden" name="MID" value="<?php echo $MID;?>">
			          	<input type="hidden" name="page" value="<?php echo $page;?>">
			          </td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">工作週期：</td>
			          
				<?php 
					if ($MJPeriod == 'D') echo "<td align='left' class='h3'>每天</td>";
					if ($MJPeriod == 'W') echo "<td align='left' class='h3'>每周</td>";
					if ($MJPeriod == 'M') echo "<td align='left' class='h3'>每月</td>";
					if ($MJPeriod == 'Y') echo "<td align='left' class='h3'>每年</td>";
					if ($MJPeriod == 'U') echo "<td align='left' class='h3'>不定期</td>";
		
				?>
				  
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">工作名稱：</td>
			          <td class="h3"><?php echo $MJTitle;?></td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">工作描述：</td>
			          <td class="h3"><?php echo $MJDescription;?></td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">代理人：</td>
			          <td class="h3"><?php echo $MJDeputy;?></td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">備註：</td>
			          <td class="h3"><?php echo $MJNote;?></td>
			        </tr>
			        <tr height="40" align="center">
			          <td colspan="2" class="h3"><input type="button" name="button" class="input_bot" value="回列表" onclick="javascript:location.href='ManagerJob.php?MID=<?php echo $MID;?>&page=<?php echo $page;?>';"></td>
			        </tr>
			      </table>
    			</td>
    		</tr>
    	</table>
    </td>
	</tr>
</table>
<?php include "down.php";?>
</body>
</html>
<?php
mysqli_close($link);
?>