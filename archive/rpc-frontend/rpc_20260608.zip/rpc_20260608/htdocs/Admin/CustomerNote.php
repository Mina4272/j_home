﻿<?php
include "CheckPermission.php";
include "CheckProject.php";
include "../global.php";
include "include/page_function.php";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $PageAdminTitle;?></title>
<link href="../type.css" rel="stylesheet" type="text/css" />
<style type="text/css">
<!--
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
}
-->
</style></head>

<body>
<?php
$SqlTxt = "";
$CID = empty($_GET['CID'])?"":$_GET['CID'];
$page = empty($_GET['page'])?"":$_GET['page'];
if (trim($page) == "") $page = 1;
$page_rows=10;  //每頁筆數
$php_Self = "CustomerNote.php";  //分頁web檔名

$button_css = "h4";
$limit_txt =" limit ".(($page-1) * $page_rows).",".$page_rows;
$url_str = "&CID=".$CID;
$Sql_str="select CNID,CContent,AddUser,AddDate,ProcUser,ProcDate from CustomerNote where Deltag='N' and CID = '".$CID."' ".$SqlTxt." order by CNID desc;";
$SQL_CustomerNote="select CNID,CContent,AddUser,AddDate,ProcUser,ProcDate from CustomerNote where Deltag='N' and CID = '".$CID."' ".$SqlTxt." order by CNID desc ".$limit_txt.";";
$result_CustomerNote=mysqli_query($link,$SQL_CustomerNote) or die ("無法執行查詢");
?>
<table width="100%" border="0" cellpadding="5" cellspacing="2" class="s2">
  <tr>
    <td background="../images/table_bg.gif" class="t21">
    	<input type="button" name="add" value="新 增" class="input_bot" onclick="javascript:window.open ('CustomerNoteAdd.php?CID=<?php echo $CID;?>','CustomerNote','height=300,width=550,top=200,left=200,scrollbars=yes,status=yes');">
    	　　　　　　　　　　　　　客戶備註
    </td>
    <td width="140" align="center" background="../images/table_bg.gif" class="t21">記錄人員</td>
    <td width="45" align="center" background="../images/table_bg.gif" class="t21">修 改</td>
    <td width="45" align="center" background="../images/table_bg.gif" class="t21">刪 除</td>
  </tr>
  <?php
  $tmp = 1;
  while(list($CNID,$CContent,$AddUser,$AddDate,$ProcUser,$ProcDate)=mysqli_fetch_row($result_CustomerNote)){
	?>
	<tr<?php if ($tmp%2 == 0) echo " bgcolor=\"#F6F6F6\"";?>>
    <td class="h3"><?php echo $CContent;?></td>
    <td class="h3" align="center">
    	<?php
    	if (trim($ProcUser) == "") echo $AddUser."<br>".$AddDate;
    	else echo $ProcUser."<br>".$ProcDate;
    	?>	
    </td>
    <td align="center"><input type="button" name="edit" value="修 改" class="input_bot" onclick="javascript:window.open ('CustomerNoteEdit.php?CID=<?php echo $CID;?>&CNID=<?php echo $CNID;?>','SelCustomer','height=340,width=550,top=200,left=200,scrollbars=yes,status=yes');"></td>
    <td align="center"><input type="button" name="edit" value="刪 除" class="input_bot" onclick="javascript:if (confirm('您是否確定要刪除？')) location.href='CustomerNoteDelDB.php?CID=<?php echo $CID;?>&CNID=<?php echo $CNID;?>&page=<?php echo $page;?>';"></td>
  </tr>
  <?php
			$tmp++;
			}
	mysqli_free_result($result_CustomerNote);
  ?>
</table>
<table width="100%" border="0" cellpadding="5" cellspacing="2" class="s2">
  <tr align="center">
    <td bgcolor="#E8F0C2" class="h4"><?php Page_show($Sql_str,$page_rows,$php_Self,$link,$page,$url_str,$button_css);?></td>
  </tr>
</table>
</body>
</html>
<?php
mysqli_close($link);
?>