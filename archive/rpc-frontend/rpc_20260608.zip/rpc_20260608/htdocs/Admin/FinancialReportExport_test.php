<?php
include "CheckPermission.php";
include "CheckAccountingReport.php";
include "../global.php";

$SQL_Project="SELECT a.CID, a.CName, b.PAMode, ifnull( sum( b.Charges ) , 0 ) Charges
							FROM Project a, ProjectAccounting b
							WHERE a.PID = b.PID
							AND a.Deltag = 'N'
							AND b.Deltag = 'N'
							AND (
							b.PAStatus = 'W'
							OR b.PAStatus = 'S'
							)
							AND date_format( a.AddDate, '%Y-%m-%d' )
							BETWEEN '2010-06-01'
							AND '2010-07-31'
							GROUP BY a.CID, a.CName, b.PAMode";
$result_Project=mysql_query($SQL_Project,$link) or die ("無法執行查詢");
$PaccArr=array();
while(list($CID,$CName,$PAMode,$Charges)=mysql_fetch_row($result_Project)){
		$PaccArr[$CID]['CName']=$CName;
		$PaccArr[$CID]['Charges'."_".$PAMode]=$Charges;
		}
mysql_free_result($result_Project);
//print_r($PaccArr);

//for ($tmp=0;$tmp<=$count($PaccArr)-1;$tmp++){
		//echo 
		//}

foreach ($PaccArr as $key=>$val) {
		echo "key=$key<br>";
		echo "CName=".$PaccArr[$key]['CName']."<br>";
		echo "Charges_I=".$PaccArr[$key]['Charges_I']."<br>";
		echo "Charges_O=".$PaccArr[$key]['Charges_O']."<br>";		}

?>