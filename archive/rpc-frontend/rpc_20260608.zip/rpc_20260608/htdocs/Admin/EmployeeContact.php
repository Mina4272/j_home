﻿<?php
include "CheckPermission.php";
include "CheckCustomer.php";
include "../global.php";
include "include/page_function.php";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $PageAdminTitle;?></title>
<link href="../type.css" rel="stylesheet" type="text/css" />
<style type="text/css">
<!--
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
}
-->
</style></head>

<body>
<?php
$SqlTxt="";
$TID = empty($_GET['TID'])?"":$_GET['TID'];
$page = empty($_GET['page'])?"":$_GET['page'];
if (trim($page) == "") $page = 1;
$page_rows=10;  //每頁筆數
$php_Self = "EmployeeContact.php";  //分頁web檔名

$button_css = "h4";
$limit_txt =" limit ".(($page-1) * $page_rows).",".$page_rows;
$url_str = "&TID=".$TID;
$Sql_str="select m.MName,m.MEName,te.Grade,te.CheckGrade,te.TEFile from Trainingexam te inner join manager m on te.mid = m.mid and m.deltag='N' where te.deltag='N' and te.TID='".$TID."' ".$SqlTxt." order by te.teid ";
$SQL="select m.MID,m.MName,m.MEName,te.Grade,te.CheckGrade,te.TEFile  from Trainingexam te inner join manager m on te.mid = m.mid and m.deltag='N' where te.deltag='N' and te.TID='".$TID."' ".$SqlTxt." order by te.teid ".$limit_txt.";";
$result=mysqli_query($link,$SQL) or die ("無法執行查詢");
?>
<table width="100%" border="0" cellpadding="5" cellspacing="2" class="s2">
  <tr>
    <td width="10%" align="center" background="../images/table_bg.gif" class="t21">姓名<input type="button" name="ADD" value="新 增" class="input_bot" onclick="javascript:window.open ('EmployeeContactAdd.php?TID=<?php echo $TID;?>','EmployeeContactEdit','height=280,width=550,top=200,left=200,scrollbars=yes,status=yes');"></td>
    <td width="15%" align="center" background="../images/table_bg.gif" class="t21">成績</td>
    <td width="30%" align="center" background="../images/table_bg.gif" class="t21">合格/不合格</td>
    <td width="20%" align="center" background="../images/table_bg.gif" class="t21">考核紀錄</td>
    <td width="5%" align="center" background="../images/table_bg.gif" class="t21">修 改</td>
    <!--td width="5%" align="center" background="../images/table_bg.gif" class="t21">刪 除</td-->
  </tr>
  <?php
  $tmp = 1;
  while(list($MID,$MName,$MEName,$Grade,$CheckGrade,$TEFile)=mysqli_fetch_row($result)){
	?>
	<tr<?php if ($tmp%2 == 0) echo " bgcolor=\"#F6F6F6\"";?>>
    <td class="h3" align="center"><?php echo $MName.$MEName;?></td>
  <td class="h3" align="center"><?php if($Grade == "0"){ echo "N/A";}else{ echo $Grade;}?></td>
    <td class="h3" align="center"><?php if($CheckGrade =="Y"){echo "合格";}else{ echo "不合格";}?></td>
    <td class="h3" align="center">
	<?php if (trim($TEFile) != "") {?>
	   	<input type="button" name="edit" value="下 載" class="input_bot" onclick="javascript:location.href='getfile.php?FolderName=Admin\\TEFile&FileName=<?php echo $TEFile;?>';">
	<?php }?>
	</td>
    <td align="center"><input type="button" name="edit" value="修 改" class="input_bot" onclick="javascript:window.open ('EmployeeContactEdit.php?TID=<?php echo $TID;?>&MID=<?php echo $MID;?>','EmployeeContactEdit','height=280,width=550,top=200,left=200,scrollbars=yes,status=yes');"></td>
    <!--td align="center"><input type="button" name="edit" value="刪 除" class="input_bot" onclick="javascript:if (confirm('您是否確定要刪除？')) location.href='EmployeeContactDelDB.php?TID=<?php echo $TID;?>&page=<?php echo $page;?>';"></td-->
  </tr>
  <?php
			$tmp++;
			}
	mysqli_free_result($result);
  ?>
</table>
<table width="100%" border="0" cellpadding="5" cellspacing="2" class="s2">
  <tr align="center">
    <td bgcolor="#E8F0C2" class="h4"><?php Page_show($Sql_str,$page_rows,$php_Self,$link,$page,$url_str,$button_css);?></td>
  </tr>
</table>
</body>
</html>
<?php
mysqli_close($link);
?>