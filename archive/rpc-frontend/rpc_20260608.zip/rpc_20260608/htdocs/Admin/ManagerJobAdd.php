﻿<?php	
include "CheckPermission.php";
//include "CheckManager.php";
include "../global.php";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $PageAdminTitle;?></title>
<link href="../type.css" rel="stylesheet" type="text/css" />
<style type="text/css">
<!--
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
}
-->
</style>
<link href="../script/DatePicker.css" rel="stylesheet" type="text/css" />
<Script LANGUAGE="Javascript" SRC="../script/DatePicker.js"></Script>
<Script type="text/javascript" language="javascript" src="../script/CheckForm.js"></Script>
<script type="text/JavaScript">
<!--
function jsCheck() 
		{
		if (ChkImp('MJTitle',document.form1.MUID.value,'工作名稱') == false) return false;
		}

function CheckMPer(MPerValue)
		{
		if (MPerValue == "D") {
				if (document.form1.MPer[5].checked==true) {
						if (document.form1.MPer[6].checked==true) document.form1.MPer[6].checked=false;
						if (document.form1.MPer[7].checked==true) document.form1.MPer[7].checked=false;
						}
				}
		else if (MPerValue == "I") {
				if (document.form1.MPer[6].checked==true) if (document.form1.MPer[5].checked==true) document.form1.MPer[5].checked=false;
				}
		else if (MPerValue == "L") {
				if (document.form1.MPer[7].checked==true) if (document.form1.MPer[5].checked==true) document.form1.MPer[5].checked=false;
				}
		}
//-->
</script>
</head>
<body>
<?php include "top.php";?>

<table width="100%" border="0" cellspacing="0" cellpadding="5">
	<tr>
    <td width="160" height="600" align="left" valign="top">
			<?php include "menu.php";?>
    </td>
    <td valign="top">
    	<table width="100%" border="0" cellpadding="0" cellspacing="0">
    		<tr>
    			<td>
			    	<table width="750" border="0" cellpadding="0" cellspacing="0">
			    		<tr height="30">
			    			<td class="c2"><b>新增例行工作</b></td>
			    		</tr>
			    	</table>
	
				<?php 						
					$MID = $_GET['MID'];
					//echo $MID;
					//$MName = $_GET['MName'];
					$SQL_Manager="select MUID,MName from Manager where MID='".$MID."';";
					$result_Manager=mysqli_query($link,$SQL_Manager) or die ("沒有人!");
					list($MUID,$MName)=mysqli_fetch_row($result_Manager);
					mysqli_free_result($result_Manager);

					//echo $MID."-".$MName;
				?>					

			    	<table width="750" border="0" cellpadding="0" cellspacing="0">
			        <form name="form1" method="post" action="ManagerJobAddDB.php?MID=<?php echo $MID;?>" onSubmit="return jsCheck();">
				<tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">工作人員：</td>
			          <td class="h3"><?php echo $MName ?></td>
					  <td><input type="hidden" name="MID" id="MID" value="<?php echo $_GET['MID'];?>"></td>
			        </tr>
				<tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">工作週期：</td>
			          <td class="h3">
			          	<select id="MJPeriod" name="MJPeriod">
			          		<option value="D">每日</option>
			          		<option value="W">每週</option>
			          		<option value="M">每月</option>
			          		<option value="Y">每年</option>
			          		<option value="U">不定期</option>
			          	</select>
			          </td>
			        </tr><tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">工作名稱：</td>
			          <td class="h3"><input type="text" id="MJTitle" name="MJTitle" size="30"></td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">工作描述：</td>
			          <td class="h3"><input type="text" id="MJDescription" name="MJDescription" size="100"></td>
			        </tr>
				<tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">代理人：</td>
			          <td class="h3">
			          	<select id="MJDeputyID" name="MJDeputyID">

<?php 

$SQL_select="select MID, MUID, MName from Manager where IsLeft = 'N' and DelTag = 'N';";
$result_Manager=mysqli_query($link,$SQL_select) or die ("無法執行查詢");

while(list($MID,$MUID,$MName)=mysqli_fetch_row($result_Manager)){

	echo "<option value='".$MID."'>".$MName."</option>";
}

mysqli_free_result($result_Manager);

?>
			          	</select>
			          </td>
			        </tr>

			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">工作備註：</td>
			          <td class="h3"><input type="text" id="MJNote" name="MJNote" size="100"></td>
			        </tr>
			        
			        <tr height="40" align="center">
					   <td colspan="2" class="h3"><input type="submit" name="submit" class="input_bot" value="送 出"></td>
			        </tr>
				      </form>
			      </table>
    			</td>
    		</tr>
    	</table>
    </td>
	</tr>
</table>
<?php include "down.php";?>
</body>
</html>
<?php
mysqli_close($link);
?>