﻿<?php	
include "CheckPermission.php";
include "CheckCustomer.php";
include "../global.php";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $PageAdminTitle;?></title>
<link href="../type.css" rel="stylesheet" type="text/css" />
<style type="text/css">
<!--
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
}
-->
</style>
<link href="../script/DatePicker.css" rel="stylesheet" type="text/css" />
<Script LANGUAGE="Javascript" SRC="../script/DatePicker.js"></Script>
<Script type="text/javascript" language="javascript" src="../script/CheckForm.js"></Script>
</head>
<body>
<?php
$TID = $_GET['TID'];
$MID = $_GET['MID'];
if (trim($TID) == "" || trim($MID) == "")
		{
		mysqli_close($link);
		?>
		<script type="text/JavaScript">
			<!--
			alert ("查無資料，請冾網站管理人員！");
			self.close();
			//-->
		</script>
		<?php
		exit;
		}

$SQL="select m.MID,m.MName,m.MEName,te.Grade,te.CheckGrade,te.TEFile  from Trainingexam te inner join manager m on te.mid = m.mid and m.deltag='N' where te.deltag='N' and te.TID='".$TID."' and te.MID='".$MID."'";
$result=mysqli_query($link,$SQL) or die ("無法執行查詢");
if (mysqli_num_rows($result) == 0)
		{
		mysqli_free_result($result);
		mysqli_close($link);
		?>
		<SCRIPT language=javascript>
		<!--
		alert ("查無資料，請冾網站管理人員！"); 
		self.close();
		//-->
		</SCRIPT>
		<?php 	
		exit;
		}
list($MID,$MName,$MEName,$Grade,$CheckGrade,$TEFile)=mysqli_fetch_row($result);
mysqli_free_result($result);
?>
<table width="100%" border="0" cellpadding="0" cellspacing="0">
	<tr>
		<td>
    	<table width="100%" border="0" cellpadding="0" cellspacing="0">
    		<tr height="30">
					<td width="15" background="../images/table_bg.gif"></td>
    			<td class="c3" background="../images/table_bg.gif"><b>修改成績</b></td>
    		</tr>
    	</table>
    	<table width="100%" border="0" cellpadding="0" cellspacing="0">
        <form name="form1" method="post" action="EmployeeContactEditDB.php" enctype="multipart/form-data">
        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
					<td width="15"></td>
          <td width="80" class="c3" align="right">姓名：</td>
          <td class="c3"><?php echo $MName.$MEName;?></td>
        </tr>
        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
					<td width="15"></td>
          <td class="c3" align="right">成績：</td>
          <td class="c3"><input name="Grade" type="text" size="20" value="<?php echo $Grade;?>" /></td>
        </tr>
        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
					<td width="15"></td>
          <td class="c3" align="right">合格/不合格：</td>
          <td class="c3">
			<input type="radio" name="CheckGrade" value="Y" <?php if ($CheckGrade == "Y") echo " checked";?>>合格<br>
			<input type="radio" name="CheckGrade" value="N" <?php if ($CheckGrade == "N") echo " checked";?>>不合格<br>
		  </td>
        </tr>
		<tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
					<td width="15"></td>
          <td class="c3" align="center">考核紀錄：</td>
		  <td class="h3"><input name="TEFile" type="file" size="60"/></td>
        </tr>
        <tr height="40" align="center">
					<td width="15"></td>
          <td colspan="2" class="h3">
          	<input type="submit" name="submit" class="input_bot" value="送 出">
          	<input name="TID" type="hidden" id="TID" value="<?php echo $TID;?>" />
          	<input name="MID" type="hidden" id="MID" value="<?php echo $MID;?>" />
          </td>
        </tr>
	      </form>
      </table>
		</td>
	</tr>
</table>
</body>
</html>
<?php
mysqli_close($link);
?>