﻿<?php
include "CheckPermission.php";
//include "CheckManager.php";
include "../global.php";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $PageAdminTitle;?></title>
</head>
<body>
<?php
$MJID = $_GET['MJID'];
$page = $_GET['page'];

if (trim($MJID) == "")
		{
		mysqli_close($link);
		?>
		<script type="text/JavaScript">
			<!--
			alert ("您輸入的資料不足，請重新輸入！");
			history.go(-1);
			//-->
		</script>
		<?php
		exit;
		}

$now_time = date("Y-m-d H:i:s",mktime());
$SQL_select="select MID from ManagerJob where DelTag = 'N' and MJID = '".$MJID."';";
$result_select=mysqli_query($link,$SQL_select) or die ("無法執行查詢");
list($MID)=mysqli_fetch_row($result_select);

if (mysqli_num_rows($result_select) == 0)
		{
		mysqli_free_result($result_select);
		mysqli_close($link);
		?>
		<script type="text/JavaScript">
			<!--
			alert ("查無資料，請冾網站管理人員！");
			history.go(-1);
			//-->
		</script>
		<?php
		exit;
		}
mysqli_free_result($result_select);


//$sql_insert = "INSERT INTO ManagerHistory(MID,MUID,MPassword,MName,MEName,EmployeeNo,MPID,Salary,Allowance,CLabor,CHealth,ELabor,EHealth,CRetirement,Departments,Title,Ext,EMail,MIntro,MPer,ISEngineer,ISBusiness,RDate,BirthDay,Address,RAddress,Tel,Mobile,BCode,BAccount,IsLeft,LeftDate,MLoginTime,AddUser,AddDate,AddIP,Deltag,ProcUser,ProcDate,ProcIP,UpdateUser,UpdateDate,UpdateIP) SELECT MID,MUID,MPassword,MName,MEName,EmployeeNo,MPID,Salary,Allowance,CLabor,CHealth,ELabor,EHealth,CRetirement,Departments,Title,Ext,EMail,MIntro,MPer,ISEngineer,ISBusiness,RDate,BirthDay,Address,RAddress,Tel,Mobile,BCode,BAccount,IsLeft,LeftDate,MLoginTime,AddUser,AddDate,AddIP,Deltag,ProcUser,ProcDate,ProcIP,'".$_SESSION["reg_MUID"]."','".$now_time."','".$_SERVER["REMOTE_ADDR"]."' FROM Manager where DelTag = 'N' and MID = '".$MID."';";
//$result_insert=mysqli_query($link,$sql_insert) or die ("無法執行新增");
$sql_update = "update ManagerJob set DelTag = 'Y',ProcUser = '".$_SESSION["reg_MUID"]."',ProcDate = '".$now_time."',ProcIP = '".$_SERVER["REMOTE_ADDR"]."' where DelTag = 'N' and MJID = '".$MJID."';";
$result_update=mysqli_query($link,$sql_update) or die ("無法執行修改");

mysqli_close($link);
?>
<script type="text/JavaScript">
	<!--
	alert ("刪除成功！");
	location.href='ManagerJob.php?MID=<?php echo $MID;?>&page=<?php echo $page;?>';
	//-->
</script>

</body>
</html>
