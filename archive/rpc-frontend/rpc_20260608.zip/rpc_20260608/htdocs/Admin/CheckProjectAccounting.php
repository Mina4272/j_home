<?php
//echo "reg_MPer=".$_SESSION["reg_MPer"]."<br>";
if (trim(strstr($_SESSION["reg_MPer"],'D')) == "" || trim(strstr($_SESSION["reg_MPer"],'I')) == "" || trim(strstr($_SESSION["reg_MPer"],'L')) == "") {}
else exit;
?>