﻿<?php	
include "CheckPermission.php";
include "../global.php";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $PageAdminTitle;?></title>
<link href="../type.css" rel="stylesheet" type="text/css" />
<style type="text/css">
<!--
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
}
-->
</style>
<Script type="text/javascript" language="javascript" src="../script/rpc.js"></Script>
<Script type="text/javascript" language="javascript" src="../script/CheckForm.js"></Script>
</head>
<body>
<?php
$PAHID = $_GET['PAHID'];
$PID = $_GET['PID'];
$PAID = $_GET['PAID'];
$page = $_GET['page'];
if (trim($PID) == "" || trim($PAID) == "" || trim($PAHID) == "")
		{
		mysqli_close($link);
		?>
		<script type="text/JavaScript">
			<!--
			alert ("查無資料，請冾網站管理人員！");
			history.go(-1);
			//-->
		</script>
		<?php
		exit;
		}
$SQL_Project="select PName from Project where Deltag='N' and PID = '".$PID."';";
$result_Project=mysqli_query($link,$SQL_Project) or die ("無法執行查詢");
if (mysqli_num_rows($result_Project) == 0)
		{
		mysqli_free_result($result_Project);
		mysqli_close($link);
		?>
		<SCRIPT language=javascript>
		<!--
		alert ("查無資料，請冾網站管理人員！"); 
		history.go(-1);
		//-->
		</SCRIPT>
		<?php 	
		exit;
		}
list($PName)=mysqli_fetch_row($result_Project);
mysqli_free_result($result_Project);

$SQL_ProjectAccounting="select PAHID,PANo,PAMode,PAItem,Charges,Rate,ChargesOther,PATax,PAStatus,PAPDate,PADate,PARecord,PARecordDate,PARecordIP,CID,CName,CTel,CFax,CAddress,PANote,AddUser,AddDate,ProcUser,ProcDate from ProjectAccountingHistory where Deltag='N' and PAHID = '".$PAHID."';";
$result_ProjectAccounting=mysqli_query($link,$SQL_ProjectAccounting) or die ("無法執行查詢");
if (mysqli_num_rows($result_ProjectAccounting) == 0)
		{
		mysqli_free_result($result_ProjectAccounting);
		mysqli_close($link);
		?>
		<SCRIPT language=javascript>
		<!--
		alert ("查無資料，請冾網站管理人員！"); 
		history.go(-1);
		//-->
		</SCRIPT>
		<?php 	
		exit;
		}
list($PAHID,$PANo,$PAMode,$PAItem,$Charges,$Rate,$ChargesOther,$PATax,$PAStatus,$PAPDate,$PADate,$PARecord,$PARecordDate,$PARecordIP,$CID,$CName,$CTel,$CFax,$CAddress,$PANote,$AddUser,$AddDate,$ProcUser,$ProcDate)=mysqli_fetch_row($result_ProjectAccounting);
mysqli_free_result($result_ProjectAccounting);

?>
    	<table width="100%" border="0" cellpadding="0" cellspacing="0">
    		<tr>
    			<td>
			    	<table width="750" border="0" cellpadding="0" cellspacing="0">
			    		<tr height="30">
			    			<td class="c2" background="../images/table_bg.gif"><?php echo $PName;?> 帳務管理歷史資料</td>
			    		</tr>
			    	</table>
			    	<table width="750" border="0" cellpadding="0" cellspacing="0">
			        <form name="form1" method="post" action="ProjectAccountingEditDB.php" onSubmit="return jsCheck();">
			        <tr height="35" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td width="120" align="right" class="c3">類 型：</td>
			          <td class="h3">
			          	<?php
			          	if (trim($PAMode) == "I") echo "收入";
			          	else if (trim($PAMode) == "O") echo "支出";
			          	?>
			          </td>
			        </tr>
			        <tr height="35" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">對帳編號：</td>
			          <td class="h3"><?php echo $PANo;?>
			          </td>
			        </tr>
			        <tr height="35" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">項 目：</td>
			          <td class="h3"><?php echo $PAItem;?>
			          </td>
			        </tr>
			        <tr height="35" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">費 用：</td>
			          <td class="h3">
			          	<table width="100%" border="0" cellpadding="0" cellspacing="0">
			          		<tr class="c3">
			          			<td width="90" align="right">新台幣：</td>
			          			<td width="100"><?php echo $Charges;?></td>
			          			<td width="80" align="right">匯率：</td>
			          			<td width="100"><?php echo $Rate;?></td>
			          			<td width="80" align="right"><div id="ChargesOtherText" style="display:<?php if (trim($Rate) == "0") echo "none";?>"><?php if (trim($PAMode) == "I") echo $IFlorin; else if (trim($PAMode) == "O") echo $OFlorin;?>：</div></td>
			          			<td width="300"><div id="ChargesOtherValue" style="display:<?php if (trim($Rate) == "0") echo "none";?>"><?php echo $ChargesOther;?></div></td>
			          		</tr>
			          	</table>
			          </td>
			        </tr>
			        <tr height="35" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">是否含稅：</td>
			          <td class="h3">
			          	<?php
			          	if (trim($PATax) == "Y") echo "是";
			          	else if (trim($PATax) == "N") echo "否";
			          	?>
			          </td>
			        </tr>
			        <?php if (trim($PAPDate) == "0000-00-00") $PAPDate="";?>
			        <tr height="35" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">預計結清日期：</td>
			          <td class="h3">
			          	<?php echo $PAPDate;?>
			          </td>
			        </tr>
			        <tr height="35" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">狀 況：</td>
			          <td class="h3">
			          	<?php
			          	if (trim($PAStatus) == "W") {
			          			if (trim($PAMode) == "I") echo "待收"; else if (trim($PAMode) == "O") echo "未付";
			          			}
			          	else if (trim($PAStatus) == "S") echo "<font color=blue>結清</font> ".$PADate;
			          	else if (trim($PAStatus) == "C") echo "<font color=red>取消</font>";
									?>
			          </td>
			        </tr>
			        <tr id="CheckCustomer" style="display:<?php if (trim($PAMode) == "I") echo "none";?>" height="35" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">供應商：</td>
			          <td class="h3">
						    	<table width="100%" border="0" cellpadding="0" cellspacing="0">
						        <form name="form1" method="post" action="CustomerSurveyExport.php" onSubmit="return jsCheck();" target="_CustomerSurvey">
						        <tr height="30">
						          <td width="80" align="right" class="c3">客戶名稱：</td>
						          <td class="h3">
						          	<table width="100%" border="0" cellpadding="0" cellspacing="0">
						          		<tr>
						          			<td><div id="CNamePreview" style="display:"><?php echo $CName;?></div></td>
						          			<td>
									          	<input type="hidden" name="CID" value="<?php echo $CID;?>">
									          	<input type="hidden" name="CName" value="<?php echo $CName;?>">
						          			</td>
						          		</tr>
						          	</table>
						          	
						          </td>
						        </tr>
						        <tr height="30">
						          <td align="right" class="c3">客戶電話：</td>
						          <td class="h3">
						          	<table width="100%" border="0" cellpadding="0" cellspacing="0">
						          		<tr>
						          			<td width="150">
						          				<div id="CTelPreview" style="display:"><?php echo $CTel;?></div>
									          	<input type="hidden" name="CTel" value="<?php echo $CTel;?>">
						          			</td>
						          			<td width="60" align="right" class="c3">傳真：</td>
						          			<td>
						          				<div id="CFaxPreview" style="display:"><?php echo $CFax;?></div>
						          				<input type="hidden" name="CFax" value="<?php echo $CFax;?>">
						          				<input type="hidden" name="Contact" size="20">
						          				<input type="hidden" name="CMobile" size="20">
						          				<input type="hidden" name="CEMail" size="60">
						          			</td>
						          		</tr>
						          	</table>
						          </td>
						        </tr>
						        <tr height="30">
						          <td align="right" class="c3">客戶地址：</td>
						          <td class="h3">
						          	<div id="CAddressPreview" style="display:"><?php echo $CAddress;?></div>
						          	<input type="hidden" name="CAddress" value="<?php echo $CAddress;?>">
						          </td>
						        </tr>
						      </table>
			          </td>
			        </tr>
			        <tr height="35" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">備 註：</td>
			          <td class="h3"><?php echo $PANote;?>
			          	<input type="hidden" name="PID" value="<?php echo $PID;?>">
			          	<input type="hidden" name="PAID" value="<?php echo $PAID;?>">
			          	<input type="hidden" name="spage" value="<?php echo $spage;?>">
			          	<input type="hidden" name="KeyWord" value="<?php echo $KeyWord;?>">
			          	<input type="hidden" name="QPStatus" value="<?php echo $QPStatus;?>">
			          </td>
			        </tr>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">新增人員：</td>
			          <td class="h3"><?php echo $AddUser;?>　<?php echo $AddDate;?></td>
			        </tr>
			        <?php if (trim($ProcUser) != "") {?>
			        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
			          <td align="right" class="c3">最後更新：</td>
			          <td class="h3"><?php echo $ProcUser;?>　<?php echo $ProcDate;?> 
			          </td>
			        </tr>
			        <?php }?>
			        <tr height="40" align="center">
			          <td colspan="2" class="h3"><input type="button" name="button" class="input_bot" value="回列表" onclick="javascript:location.href='ProjectAccountingHistory.php?PID=<?php echo $PID;?>&PAID=<?php echo $PAID;?>&page=<?php echo $page;?>';"></td>
			        </tr>
				      </form>
			      </table>
    			</td>
    		</tr>
    	</table>
</body>
</html>
<?php
mysqli_close($link);
?>