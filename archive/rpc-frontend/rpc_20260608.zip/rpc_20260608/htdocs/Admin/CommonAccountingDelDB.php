﻿<?php
include "CheckPermission.php";
include "CheckCommonAccounting.php";
include "../global.php";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $PageAdminTitle;?></title>
</head>
<body>
<?php
$CAID = $_GET['CAID'];
$QCAType = $_GET['QCAType'];
$QSCADate = $_GET['QSCADate'];
$QECADate = $_GET['QECADate'];
$KeyWord = $_GET['KeyWord'];

if (trim($CAID) == "")
		{
		mysqli_close($link);
		?>
		<script type="text/JavaScript">
			<!--
			alert ("您輸入的資料不足，請重新輸入！");
			history.go(-1);
			//-->
		</script>
		<?php
		exit;
		}
$SQL_CommonAccounting="select CAStatus from CommonAccounting where Deltag='N' and CAID = '".$CAID."';";
$result_CommonAccounting=mysqli_query($link,$SQL_CommonAccounting) or die ("無法執行查詢");
if (mysqli_num_rows($result_CommonAccounting) == 0)
		{
		mysqli_free_result($result_CommonAccounting);
		mysqli_close($link);
		?>
		<SCRIPT language=javascript>
		<!--
		alert ("查無資料，請冾網站管理人員！"); 
		history.go(-1);
		//-->
		</SCRIPT>
		<?php 	
		exit;
		}
list($CheckStatus)=mysqli_fetch_row($result_CommonAccounting);
mysqli_free_result($result_CommonAccounting);

if (trim($_SESSION["reg_MUID"]) == "Benson" || trim($_SESSION["reg_MUID"]) == "amanda" || trim($_SESSION["reg_MUID"]) == "jacky") {}
else {
		if (trim($CheckStatus) == "S") {
				mysqli_close($link);
				?>
				<SCRIPT language=javascript>
				<!--
				alert ("此項目不可刪除！"); 
				history.go(-1);
				//-->
				</SCRIPT>
				<?php 	
				exit;
				}
		}
$now_time = date("Y-m-d H:i:s",mktime());
if (trim($PayDate) == "") $PayDate = "0000-00-00";
if (trim($InvoiceDate) == "") $InvoiceDate = "0000-00-00";

$sql_insert = "INSERT INTO CommonAccountingHistory(CAID,CAUID,CADate,CAItem,CAType,Amount,InvoiceDate,Invoice,CAStatus,PayDate,CARecord,CARecordDate,CARecordIP,CANote,AddUser,AddDate,AddIP,Deltag,ProcUser,ProcDate,ProcIP,UpdateUser,UpdateDate,UpdateIP) SELECT CAID,CAUID,CADate,CAItem,CAType,Amount,InvoiceDate,Invoice,CAStatus,PayDate,CARecord,CARecordDate,CARecordIP,CANote,AddUser,AddDate,AddIP,Deltag,ProcUser,ProcDate,ProcIP,'".$_SESSION["reg_MUID"]."','".$now_time."','".$_SERVER["REMOTE_ADDR"]."' FROM CommonAccounting where Deltag='N' and CAID = '".$CAID."';";
$result_insert=mysqli_query($link,$sql_insert) or die ("無法執行新增");
$sql_update = "update CommonAccounting set Deltag='Y',ProcUser = '".$_SESSION["reg_MUID"]."',ProcDate = '".$now_time."',ProcIP = '".$_SERVER["REMOTE_ADDR"]."' where Deltag='N' and CAID = '".$CAID."';";
$result_update=mysqli_query($link,$sql_update) or die ("無法執行修改");

mysqli_close($link);
?>
<script type="text/JavaScript">
	<!--
	alert ("刪除成功！");
	location.href='CommonAccounting.php?QCAType=<?php echo $QCAType;?>&QSCADate=<?php echo $QSCADate;?>&QECADate=<?php echo $QECADate;?>&KeyWord=<?php echo urlencode($KeyWord);?>';
	//-->
</script>

</body>
</html>
