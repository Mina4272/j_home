<?php
include "CheckPermission.php";
include "../global.php";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $PageAdminTitle;?></title>
<link href="../type.css" rel="stylesheet" type="text/css" />

</head>

<body>
<table width="520" border="0" align="center" cellpadding="2" cellspacing="0">
  <tr>
    <td align="center"><span class="c2"><b>工作移轉清單</b></span>
    </td>
  </tr>
  <tr>
    <td align="left">
			<?php
			//$SQL_Manager="SELECT a.MJID, a.MJPeriod, a.MJTitle, a.MJDescription, a.MJDeputyID, a.MJNote, b.MName as MJDeputy from managerjob a inner join manager b on a.MJDeputyID = b.MID left join managerjobchange c on a.MJID = c.MJID where a.MID='".$_SESSION["reg_MID"]."' and a.Deltag='N' and c.ReceiveStatus='N' order by a.MJID";
			$SQL_Manager="SELECT a.MJID, a.MJPeriod, a.MJTitle, a.MJDescription, a.MJDeputyID, a.MJNote from managerjob a where a.ReceiveMID='".$_SESSION["reg_MID"]."' and a.Deltag='N'";
			//echo $SQL_Manager;
			$result_Manager=mysqli_query($link,$SQL_Manager) or die ("無法執行查詢");
			?>
    	<table width="100%" border="0" cellpadding="2" cellspacing="2" class="s2">
        <tr align="center">
			<td></td>
          <td width="100" background="../images/table_bg.gif" class="t21">工作週期</td>
          <td background="../images/table_bg.gif" class="t21">工作名稱</td>
          <td background="../images/table_bg.gif" class="t21">工作內容</td>
        </tr>
        <?php
        $tmp = 1;
        while(list($MJID,$MJPeriod,$MJTitle,$MJDescription)=mysqli_fetch_row($result_Manager)){
      	?>
    	  <form action="ManagerJobCheckDB.php" method="post">
	    <tr<?php if ($tmp%2 == 0) echo " bgcolor=\"#F6F6F6\"";?>>
          <td align="center" class="h3"><input type="hidden" name ="MJID[]" value="<?php echo $MJID;?>"/></td>
		  <?php
					if ($MJPeriod == 'D') echo "<td align='center' class='h3'> 每天</td>";
					if ($MJPeriod == 'W') echo "<td align='center' class='h3'>每周</td>";
					if ($MJPeriod == 'M') echo "<td align='center' class='h3'>每月</td>";
					if ($MJPeriod == 'Y') echo "<td align='center' class='h3'>每年</td>";
					if ($MJPeriod == 'U') echo "<td align='center' class='h3'>不定期</td>";
		
		  ?>
          <td align="center" class="h3"><?php echo $MJTitle;?></td>
          <td align="center" class="h3"><?php echo $MJDescription;?></td>
        </tr>
        <?php
      			$tmp++;
      			}
      	mysqli_free_result($result_Manager);
        ?>
		<tr height="40" align="center">
			<td align="center" class="h3"></td>
			<td align="center" class="h3"></td>
			<td align="center" class="h3"></td>
			<td colspan="2" class="h3"><input type="submit" name="submit" class="input_bot" value="接受"></td>
		</tr>
    	</form>
      </table>
    </td>
  </tr>
</table>
</body>
</html>
<?php
mysqli_close($link);
?>