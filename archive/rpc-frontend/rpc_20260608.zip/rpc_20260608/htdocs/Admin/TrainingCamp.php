<?php
include "CheckPermission.php";
include "../global.php";
include "include/page_function.php";
include "include/utf8.php";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $PageAdminTitle;?></title>
<link href="../type.css" rel="stylesheet" type="text/css" />
<script type="text/JavaScript">
<!--
function TrainingExport() 
		{
		document.form_exp.MID.value = document.form1.QMUID.value;
		document.form_exp.submit();
		}
//-->
</script>
<style type="text/css">
<!--
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
}
-->
</style></head>

<body>
<?php include "top.php";?>
<table width="100%" border="0" cellspacing="0" cellpadding="5">
	<tr>
    <td width="160" height="600" align="left" valign="top">
			<?php include "menu.php";?>
    </td>
		<?php
		$SqlTxt="";
		$page = empty($_GET['page'])?"":$_GET['page'];
		if (trim($page) == "") $page = 1;
		$page_rows=15;  //每頁筆數
		$php_Self = "TrainingCamp.php";  //分頁web檔名

		$button_css = "h4";
		$limit_txt =" limit ".(($page-1) * $page_rows).",".$page_rows;
		$url_str = "";
		?>
    <td valign="top">
    	<table width="100%" border="0" cellpadding="0" cellspacing="0">
    		<tr>
    			<td>
			    	<table width="750" border="0" cellpadding="0" cellspacing="0">
			    		<tr height="30">
							<td align="right" class="h3"><?php if (trim(strstr($_SESSION["reg_MPer"],'N')) != ""){?><input type="button" name="add" value="新 增" class="input_bot" onclick="javascript:location.href='TrainingCampAdd.php';"><?php }?></td>
			    		</tr>
			    	</table>
						<?php
						$Sql_str="select TCID,TCTTitle from TrainingCamp where Deltag='N' ".$SqlTxt." order by TCID desc;";
						$SQL_Training="select TCID,TCTTitle from TrainingCamp  where Deltag='N' ".$SqlTxt." order by TCID desc ".$limit_txt.";";
						//echo $SQL_Training;
						$result_Training=mysqli_query($link,$SQL_Training) or die ("無法執行查詢");
						?>
			    	<table width="750" border="0" cellpadding="5" cellspacing="2" class="s2">
			        <tr align="center">
			          <td width="450" align="center" background="../images/table_bg.gif" class="t21">課程主要名稱</td>
			          <?php if (trim(strstr($_SESSION["reg_MPer"],'H')) != ""){?>
			          <td width="50" background="../images/table_bg.gif" class="t21">修 改</td>
			          <td width="50" background="../images/table_bg.gif" class="t21">刪 除</td>
			          <?php }?>
			        </tr>
		          <?php
		          $tmp = 1;
		          while(list($TCID,$TCTTitle)=mysqli_fetch_row($result_Training)){
		        	?>
		        	<tr<?php if ($tmp%2 == 0) echo " bgcolor=\"#F6F6F6\"";?>>
			          <td class="h3"><?php echo $TCTTitle;?></td>
			          <?php if (trim(strstr($_SESSION["reg_MPer"],'N')) != ""){?>
			          <td align="center"><input type="button" name="edit" value="修 改" class="input_bot" onclick="javascript:location.href='TrainingCampEdit.php?TCID=<?php echo $TCID;?>&page=<?php echo $page;?><?php echo $url_str;?>';"></td>
			          <td align="center"><input type="button" name="edit" value="刪 除" class="input_bot" onclick="javascript:if (confirm('您是否確定要刪除？')) location.href='TrainingCampDelDB.php?TCID=<?php echo $TCID;?>&page=<?php echo $page;?><?php echo $url_str;?>';"></td>
			          <?php }?>
			        </tr>
			        <?php
            			$tmp++;
			      			}
            	mysqli_free_result($result_Training);
			        ?>
			      </table>
			      <table width="750" border="0" cellpadding="5" cellspacing="2" class="s2">
			        <tr align="center">
			          <td bgcolor="#E8F0C2" class="h4"><?php Page_show($Sql_str,$page_rows,$php_Self,$link,$page,$url_str,$button_css);?></td>
			        </tr>
			      </table>
    			</td>
    		</tr>
    	</table>
    </td>
	</tr>
</table>
<form name="form_exp" action="TrainingExport.php" method="post" target="_TrainingExport">
	<input type="hidden" name="MID">
</form>
<?php include "down.php";?>
</body>
</html>
<?php
mysqli_close($link);
?>