﻿<?php	
include "CheckPermission.php";
include "CheckPartLibrary.php";
include "../global.php";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $PageAdminTitle;?></title>
<link href="../type.css" rel="stylesheet" type="text/css" />
<style type="text/css">
<!--
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
}
-->
</style>
<link href="../script/DatePicker.css" rel="stylesheet" type="text/css" />
<Script LANGUAGE="Javascript" SRC="../script/DatePicker.js"></Script>
<Script type="text/javascript" language="javascript" src="../script/CheckForm.js"></Script>
<script type="text/JavaScript">
<!--
function jsCheck() 
		{
		if (ChkImp('PLCName',document.form1.PLCName.value,'類別名稱') == false) return false;
		}
//-->
</script>
</head>
<body>
<?php
$PLCID = $_GET['PLCID'];
$page = $_GET['page'];
if (trim($PLCID) == "")
		{
		mysqli_close($link);
		?>
		<script type="text/JavaScript">
			<!--
			alert ("查無資料，請冾網站管理人員！");
			history.go(-1);
			//-->
		</script>
		<?php
		exit;
		}
$SQL_PartLibraryClass="select PLCName,AddUser,AddDate,ProcUser,ProcDate from PartLibraryClass where Deltag='N' and PLCID = '".$PLCID."';";
$result_PartLibraryClass=mysqli_query($link,$SQL_PartLibraryClass) or die ("無法執行查詢");
if (mysqli_num_rows($result_PartLibraryClass) == 0)
		{
		mysqli_free_result($result_PartLibraryClass);
		mysqli_close($link);
		?>
		<SCRIPT language=javascript>
		<!--
		alert ("查無資料，請冾網站管理人員！"); 
		history.go(-1);
		//-->
		</SCRIPT>
		<?php 	
		exit;
		}
list($PLCName,$AddUser,$AddDate,$ProcUser,$ProcDate)=mysqli_fetch_row($result_PartLibraryClass);
mysqli_free_result($result_PartLibraryClass);
?>
<table width="100%" border="0" cellpadding="0" cellspacing="0">
	<tr>
		<td>
    	<table width="100%" border="0" cellpadding="0" cellspacing="0">
    		<tr height="30">
					<td width="15" background="../images/table_bg.gif"></td>
    			<td class="c3" background="../images/table_bg.gif"><b>修改零組件/檔案類別</b></td>
    		</tr>
    	</table>
    	<table width="100%" border="0" cellpadding="0" cellspacing="0">
        <form name="form1" method="post" action="PartLibraryClassEditDB.php" onSubmit="return jsCheck();">
        <tr height="40" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
					<td width="15"></td>
          <td class="c3" align="center">類別名稱：<input name="PLCName" type="text" id="PLCName" value="<?php echo $PLCName;?>" /></td>
        </tr>
        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
					<td width="15"></td>
          <td class="c3" align="center">新增人員：<span class="h3"><?php echo $AddUser;?>　<?php echo $AddDate;?></span></td>
        </tr>
        <?php if (trim($ProcUser) != "") {?>
        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
					<td width="15"></td>
          <td class="c3" align="center">最後更新：<span class="h3"><?php echo $ProcUser;?>　<?php echo $ProcDate;?></span></td>
        </tr>
        <?php }?>
        <tr height="50" align="center" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
					<td width="15"></td>
          <td class="h3"><input type="submit" name="submit" class="input_bot" value="送 出">
          	<input name="PLCID" type="hidden" id="PLCID" value="<?php echo $PLCID;?>" />	
          	<input name="page" type="hidden" id="page" value="<?php echo $page;?>" />	
          </td>
        </tr>
	      </form>
      </table>
		</td>
	</tr>
</table>
</body>
</html>
<?php
mysqli_close($link);
?>