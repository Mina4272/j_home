﻿<?php
include "CheckPermission.php";
include "CheckCustomer.php";
include "../global.php";
include "include/page_function.php";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $PageAdminTitle;?></title>
<link href="../type.css" rel="stylesheet" type="text/css" />
<style type="text/css">
<!--
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
}
-->
</style></head>

<body>
<?php
$CID = $_GET['CID'];
$CCID = $_GET['CCID'];
if (trim($CID) == "" || trim($CCID) == "")
		{
		mysqli_close($link);
		?>
		<script type="text/JavaScript">
			<!--
			alert ("查無資料，請冾網站管理人員！");
			history.go(-1);
			//-->
		</script>
		<?php
		exit;
		}
$SQL_CustomerContact="select Contact,CMobile,CEMail,AddUser,AddDate,ProcUser,ProcDate from CustomerContact where Deltag='N' and CID = '".$CID."' and CCID = '".$CCID."';";
$result_CustomerContact=mysqli_query($link,$SQL_CustomerContact) or die ("無法執行查詢");
if (mysqli_num_rows($result_CustomerContact) == 0)
		{
		mysqli_free_result($result_CustomerContact);
		mysqli_close($link);
		?>
		<SCRIPT language=javascript>
		<!--
		alert ("查無資料，請冾網站管理人員！"); 
		self.close();
		//-->
		</SCRIPT>
		<?php 	
		exit;
		}
mysqli_free_result($result_CustomerContact);
?>
<table width="100%" border="0" cellpadding="0" cellspacing="0">
	<tr>
		<td>
			<?php
			$page = empty($_GET['page'])?"":$_GET['page'];
			if (trim($page) == "") $page = 1;
			$page_rows=15;  //每頁筆數
			$php_Self = "CustomerContactHistory.php";  //分頁web檔名

			$button_css = "h4";
			$limit_txt =" limit ".(($page-1) * $page_rows).",".$page_rows;
			$url_str = "&CID=".$CID."&CCID=".$CCID;
			$Sql_str="select CCID,Contact,CMobile,CEMail,AddUser,AddDate,ProcUser,ProcDate from CustomerContactHistory where Deltag='N' and CID = '".$CID."' order by CCHID desc;";
			$SQL_CustomerContact="select CCID,Contact,CMobile,CEMail,CDep,CNote,AddUser,AddDate,ProcUser,ProcDate from CustomerContactHistory where Deltag='N' and CID = '".$CID."' order by CCHID desc ".$limit_txt.";";
			$result_CustomerContact=mysqli_query($link,$SQL_CustomerContact) or die ("無法執行查詢");
			?>
    	<table width="100%" border="0" cellpadding="5" cellspacing="2" class="s2">
        <tr align="center">
          <td width="10%" align="center" background="../images/table_bg.gif" class="t21">聯絡人</td>
			    <td width="10%" align="center" background="../images/table_bg.gif" class="t21">部 門</td>
          <td width="15%" background="../images/table_bg.gif" class="t21">電話</td>
          <td width="30%" background="../images/table_bg.gif" class="t21">E-Mail</td>
			    <td width="20%" align="center" background="../images/table_bg.gif" class="t21">聯絡事項</td>
          <td width="15%" background="../images/table_bg.gif" class="t21">最後更新</td>
        </tr>
        <?php
        $tmp = 1;
        while(list($CCID,$Contact,$CMobile,$CEMail,$CDep,$CNote,$AddUser,$AddDate,$ProcUser,$ProcDate)=mysqli_fetch_row($result_CustomerContact)){
      	?>
      	<tr<?php if ($tmp%2 == 0) echo " bgcolor=\"#F6F6F6\"";?>>
          <td align="center" class="h3"><?php echo $Contact;?></td>
          <td align="center" class="h3"><?php echo $CDep;?></td>
          <td align="center" class="h3"><?php echo $CMobile;?></td>
          <td align="center" class="h3"><?php echo $CEMail;?></td>
          <td align="center" class="h3"><?php echo $CNote;?></td>
          <td align="center" class="h3">
          	<?php
          	if (trim($ProcUser) == "") echo $AddUser."<br>".$AddDate;
          	else echo $ProcUser."<br>".$ProcDate;
          	?>
          </td>
        </tr>
        <?php
      			$tmp++;
      			}
      	mysqli_free_result($result_CustomerContact);
        ?>
      </table>
      <table width="100%" border="0" cellpadding="5" cellspacing="2" class="s2">
        <tr align="center">
          <td bgcolor="#E8F0C2" class="h4"><?php Page_show($Sql_str,$page_rows,$php_Self,$link,$page,$url_str,$button_css);?></td>
        </tr>
      </table>
		</td>
	</tr>
</table>
</body>
</html>
<?php
mysqli_close($link);
?>