﻿<?php
include "CheckPermission.php";
include "CheckTraining.php";
include "../global.php";
include "include/function.php";
require_once("../include/chinese_party.class.php");
require("class.phpmailer.php");
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $PageAdminTitle;?></title>
<link href="../type.css" rel="stylesheet" type="text/css" />
</head>

<body>
<?php
//echo "TFile=".$HTTP_POST_FILES['TFile']['name']."<br>";
//echo "TFile=".$HTTP_POST_FILES['TFile']['tmp_name']."<br>";
//exit;
$TYear = $_POST['TYear'];
$TMonth = $_POST['TMonth'];
$TDay = $_POST['TDay'];
if (trim($TYear) != "" || trim($TMonth) != "" || trim($TDay) != "") if (checkdate($TMonth,$TDay ,$TYear)) $TDate = $TYear."-".$TMonth."-".$TDay;
$TTitle = $_POST['TTitle'];
$Lecturer = $_POST['Lecturer'];
$TContent = $_POST['TContent'];
$TContent = str_replace("\r\n","<br>",$TContent);

$now_time = date("Y-m-d H:i:s",mktime());
if(trim($_FILES['TFile']['tmp_name']) != "")
		{
		if($_FILES['TFile']['size'] > 20971520)
				{
				?>
				<script type="text/JavaScript">
					<!--
					alert ("您上傳的檔案 Size 超過 20 M，請重新上傳！");
					history.go(-1);
					//-->
				</script>
				<?php
				exit();
				}
		$TFile = "TFile_".date("ymdHis",mktime()).rand_string(5, 'ABCDEFGHIJKLMNPQRSTUVWXYZ23456789abcdefghijklmnopqrstuvwxyz').".".strtolower(substr($_FILES['TFile']['name'],strrpos($_FILES['TFile']['name'],".")+1,strlen($_FILES['TFile']['name'])+1));
		@copy($_FILES['TFile']['tmp_name'],$_SERVER["DOCUMENT_ROOT"]."\\Admin\\TFile\\".$TFile);
		}
if (trim($TDate) == "" || trim($TTitle) == "" || trim($Lecturer) == "")
		{
		mysqli_close($link);
		?>
		<script type="text/JavaScript">
			<!--
			alert ("您輸入的資料不足，請重新輸入！");
			self.close();
			//-->
		</script>
		<?php
		exit;
		}

$sql_insert = "insert into Training (TDate,TTitle,Lecturer,TFile,TContent,AddUser,AddDate,AddIP) values ('".$TDate."','".$TTitle."','".$Lecturer."','".$TFile."','".$TContent."','".$_SESSION["reg_MUID"]."','".$now_time."','".$_SERVER["REMOTE_ADDR"]."');";
$result_insert=mysqli_query($link,$sql_insert) or die ("無法執行新增");

$EMAILFN = "Training.htm";
$subject="教育訓練資訊通知 ！！";
$fp=fopen($EMAILFN,"r");
$content="";
while($line=fgets($fp,512)){
	$content.=$line;
	}
fclose($fp);

$content = str_replace("{TDate}",$TDate,$content);
$content = str_replace("{TTitle}",$TTitle,$content);
$content = str_replace("{Lecturer}",$Lecturer,$content);
$content = str_replace("{TContent}",$TContent,$content);

//$cconv =& new chinese_party();
$cconv = new chinese_party();
$content = $cconv->u82tchi($content);
$subject = $cconv->u82tchi($subject);

$SQL_Manager="SELECT EMail FROM Manager WHERE Deltag = 'N';";
//$SQL_Manager="SELECT EMail FROM Manager WHERE Deltag = 'N' and MUID='jacky';";
$result_Manager=mysqli_query($link,$SQL_Manager) or die ("無法執行查詢");
while(list($EMail)=mysqli_fetch_row($result_Manager)){
		$mail = new PHPMailer();
		$mail->IsSMTP();
		$mail->Host     = "127.0.0.1";
		$mail->SMTPAuth = true;
		$mail->From     = "Benson@rpclab.com";
		$mail->FromName = $subject;
		$mail->WordWrap = 50;
		$mail->IsHTML(true);                               // send as HTML
		$mail->CharSet = "big5";
		$mail->Subject  = $subject;
		$mail->Body     =  $content;
		$mail->AddAddress($EMail,"");
		$mail->AddReplyTo("Benson@rpclab.com");
		if(!$mail->Send())
				{
		    //echo "There has been a mail error sending to " . $SendEMail . "<br>";
		    //echo "Mailer Error: " . $mail->ErrorInfo . "<br>";
		  	}
		else
				{
				//echo $SendEMail . " sending !!<br>";
				}
				
		$mail->ClearAddresses();
		$mail->ClearReplyTos();
		$mail->SmtpClose();
		}
mysqli_free_result($result_Manager);

mysqli_close($link);
?>
<script type="text/JavaScript">
	<!--
	alert ("教育訓練訊息新增完成！");
	location.href='TrainingList.php';
	//-->
</script>

</body>
</html>
