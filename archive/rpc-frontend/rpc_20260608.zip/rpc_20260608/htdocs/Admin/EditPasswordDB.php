﻿<?php
include "CheckPermission.php";
include "../global.php";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $PageAdminTitle;?></title>
</head>
<body>
<?php
$MPassword = $_POST['MPassword'];

if (trim($MPassword) == "")
		{
		mysqli_close($link);
		?>
		<script type="text/JavaScript">
			<!--
			alert ("您輸入的資料不足，請重新輸入！");
			history.go(-1);
			//-->
		</script>
		<?php
		exit;
		}

$now_time = date("Y-m-d H:i:s",mktime());
$SQL_select="select MUID from Manager where Deltag='N' and MUID = '".$_SESSION["reg_MUID"]."';";
$result_select=mysqli_query($link,$SQL_select) or die ("無法執行查詢");

if (mysqli_num_rows($result_select) == 0)
		{
		mysqli_free_result($result_select);
		mysqli_close($link);
		?>
		<script type="text/JavaScript">
			<!--
			alert ("查無資料，請冾網站管理人員！");
			history.go(-1);
			//-->
		</script>
		<?php
		exit;
		}
mysqli_free_result($result_select);

$sql_insert = "INSERT INTO ManagerHistory(MID,MUID,MPassword,MName,MEName,EmployeeNo,MPID,Salary,Allowance,CLabor,CHealth,ELabor,EHealth,CRetirement,Departments,Ext,EMail,MIntro,MPer,ISEngineer,ISBusiness,RDate,BirthDay,Address,RAddress,Tel,Mobile,BCode,BAccount,MLoginTime,AddUser,AddDate,AddIP,Deltag,ProcUser,ProcDate,ProcIP,UpdateUser,UpdateDate,UpdateIP) SELECT MID,MUID,MPassword,MName,MEName,EmployeeNo,MPID,Salary,Allowance,CLabor,CHealth,ELabor,EHealth,CRetirement,Departments,Ext,EMail,MIntro,MPer,ISEngineer,ISBusiness,RDate,BirthDay,Address,RAddress,Tel,Mobile,BCode,BAccount,MLoginTime,AddUser,AddDate,AddIP,Deltag,ProcUser,ProcDate,ProcIP,'".$_SESSION["reg_MUID"]."','".$now_time."','".$_SERVER["REMOTE_ADDR"]."' FROM Manager where Deltag='N' and MUID = '".$_SESSION["reg_MUID"]."';";
$result_insert=mysqli_query($link,$sql_insert) or die ("無法執行新增");
$sql_update = "update Manager set MPassword = '".$MPassword."',ProcUser = '".$_SESSION["reg_MUID"]."',ProcDate = '".$now_time."',ProcIP = '".$_SERVER["REMOTE_ADDR"]."' where Deltag='N' and MUID = '".$_SESSION["reg_MUID"]."';";
$result_update=mysqli_query($link,$sql_update) or die ("無法執行修改");

mysqli_close($link);
?>
<script type="text/JavaScript">
	<!--
	alert ("密碼修改成功！");
	location.href='EditPassword.php';
	//-->
</script>

</body>
</html>
