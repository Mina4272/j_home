﻿<?php
include "CheckPermission.php";
include "CheckMVac.php";
include "../global.php";
require_once 'PHPExcel.php';

$SqlPID="";
$SqlTxt="";
$SqlTxt2="";
$QSDate="";
$QEDate="";

$QSYear = empty($_POST['QSYear'])?"":$_POST['QSYear'];
$QSMonth = empty($_POST['QSMonth'])?"":$_POST['QSMonth'];
$QSDay = empty($_POST['QSDay'])?"":$_POST['QSDay'];
if (trim($QSYear) != "" || trim($QSMonth) != "" || trim($QSDay) != "") if (checkdate($QSMonth,$QSDay ,$QSYear)) $QSDate = $QSYear."-".$QSMonth."-".$QSDay;
$QEYear = empty($_POST['QEYear'])?"":$_POST['QEYear'];
$QEMonth = empty($_POST['QEMonth'])?"":$_POST['QEMonth'];
$QEDay = empty($_POST['QEDay'])?"":$_POST['QEDay'];
if (trim($QEYear) != "" || trim($QEMonth) != "" || trim($QEDay) != "") if (checkdate($QEMonth,$QEDay ,$QEYear)) $QEDate = $QEYear."-".$QEMonth."-".$QEDay;

$KeyWord = empty($_POST['KeyWord'])?"":$_POST['KeyWord'];
if (trim($KeyWord) == "") $KeyWord = empty($_GET['KeyWord'])?"":$_GET['KeyWord'];
$QPStatus = empty($_POST['QPStatus'])?"":$_POST['QPStatus'];
if (trim($QPStatus) == "") $QPStatus = empty($_GET['QPStatus'])?"":$_GET['QPStatus'];
$QPE = empty($_POST['QPE'])?"":$_POST['QPE'];
if (trim($QPE) == "") $QPE = empty($_GET['QPE'])?"":$_GET['QPE'];
$QBMUID = empty($_POST['QBMUID'])?"":$_POST['QBMUID'];
if (trim($QBMUID) == "") $QBMUID = empty($_GET['QBMUID'])?"":$_GET['QBMUID'];
$ISINo = empty($_POST['ISINo'])?"":$_POST['ISINo'];
if (trim($ISINo) == "") $ISINo = empty($_GET['ISINo'])?"":$_GET['ISINo'];
$ISAdd = empty($_POST['ISAdd'])?"":$_POST['ISAdd'];
if (trim($ISAdd) == "") $ISAdd = empty($_GET['ISAdd'])?"":$_GET['ISAdd'];
$QAcR = empty($_POST['QAcR'])?"":$_POST['QAcR'];



if (trim($KeyWord) != "") {
		$SQL_ProjectCertificate="select PID from ProjectCertificate where Deltag='N' and PCNo like '%".$KeyWord."%' group by PID order by PID;";
		$result_ProjectCertificate=mysqli_query($link,$SQL_ProjectCertificate) or die ("無法執行查詢");
	
		while(list($PC_PID)=mysqli_fetch_row($result_ProjectCertificate)){
				//if (trim($SqlPID) == "") $SqlPID = "PID='".$PC_PID."'";
				//else $SqlPID = $SqlPID." or PID='".$PC_PID."'";
				if (trim($SqlPID) == "") $SqlPID = $PC_PID;
				else $SqlPID = $SqlPID.",".$PC_PID;
				}
		mysqli_free_result($result_ProjectCertificate);
		}
if (trim($SqlPID) != "") $SqlPID = " PID in (".$SqlPID.")";
if (trim($KeyWord) != "") {
		if (trim($SqlPID) == "") $SqlTxt = $SqlTxt." and (PUID like '%".$KeyWord."%' or CName like '%".$KeyWord."%' or CTel like '%".$KeyWord."%' or CFax like '%".$KeyWord."%' or Contact like '%".$KeyWord."%' or CMobile like '%".$KeyWord."%' or CEMail like '%".$KeyWord."%' or CAddress like '%".$KeyWord."%' or PName like '%".$KeyWord."%' or ModelName like '%".$KeyWord."%' or SeriesModel like '%".$KeyWord."%' or PE like '%".$KeyWord."%' or PNote like '%".$KeyWord."%' or ApplyItem like '%".$KeyWord."%')";
		else $SqlTxt = $SqlTxt." and (PUID like '%".$KeyWord."%' or CName like '%".$KeyWord."%' or CTel like '%".$KeyWord."%' or CFax like '%".$KeyWord."%' or Contact like '%".$KeyWord."%' or CMobile like '%".$KeyWord."%' or CEMail like '%".$KeyWord."%' or CAddress like '%".$KeyWord."%' or PName like '%".$KeyWord."%' or ModelName like '%".$KeyWord."%' or SeriesModel like '%".$KeyWord."%' or PE like '%".$KeyWord."%' or PNote like '%".$KeyWord."%' or ApplyItem like '%".$KeyWord."%' or ".$SqlPID.")";
		
		}
if (trim($QPStatus) != "") $SqlTxt = $SqlTxt." and PStatus='".$QPStatus."' ";
if (trim($QPE) != "") $SqlTxt = $SqlTxt." and PE='".$QPE."' ";
if (trim($QBMUID) != "") $SqlTxt = $SqlTxt." and ifnull(BMUID,'vivi')='".$QBMUID."' ";
if (trim($ISINo) != "") {
		if (trim($ISINo) == "Y") $SqlTxt = $SqlTxt." and INo <> '' ";
		else $SqlTxt = $SqlTxt." and INo = '' ";
		}
if (trim($ISAdd) != "") {
		if (trim($ISAdd) == "Y") $SqlTxt2 = " WHERE a.PCount > 0";
		else $SqlTxt2 = " WHERE a.PCount = 0";
		}

if (trim($QSDate) != "" && trim($QEDate) != "") $SqlTxt = $SqlTxt." and (AddDate >= '".$QSDate." 00:00:00') and (AddDate <= '".$QEDate." 23:59:59') ";
else if (trim($QSDate) != "" && trim($QEDate) == "") $SqlTxt = $SqlTxt." and (AddDate >= '".$QSDate." 00:00:00') ";
else if (trim($QSDate) == "" && trim($QEDate) != "") $SqlTxt = $SqlTxt." and (AddDate <= '".$QEDate." 23:59:59') ";

$SQL_Project="select a.* from (select PID,PUID,CID,CName,CTel,CFax,Contact,CMobile,CEMail,CAddress,PStatus,PName,ModelName,SeriesModel,PE,(select MName from Manager where Deltag='N' and MUID = Project.PE) PEName,(select MEName from Manager where Deltag='N' and MUID = Project.PE) PEEName,Quote,ApplyItem,Canon,SNote,StartDate,PlanDate,replace(CloseDate,'0000-00-00',''),ifnull(DATEDIFF(CloseDate,StartDate),0) ProcDate,PNote,QuoteDate,ReturnDate,(select count(PAAID) PCount from ProjectAccountingAdd where PAACheck='N' and PID=Project.PID) PCount from Project where Deltag='N' ".$SqlTxt.") as a ".$SqlTxt2." order by a.PStatus asc,a.PID desc;";
//echo $SQL_Project;
$result_Project=mysqli_query($link,$SQL_Project) or die ("無法執行查詢");


$objPHPExcel = new PHPExcel();
$objPHPExcel->setActiveSheetIndex(0);

$objPHPExcel->getActiveSheet()->setCellValue('A1',"案件編號");
$objPHPExcel->getActiveSheet()->setCellValue('B1',"案件工程師");
$objPHPExcel->getActiveSheet()->setCellValue('C1',"客戶名稱");
$objPHPExcel->getActiveSheet()->setCellValue('D1',"產品名稱");
$objPHPExcel->getActiveSheet()->setCellValue('E1',"型號");
$objPHPExcel->getActiveSheet()->setCellValue('F1',"系列型式");
$objPHPExcel->getActiveSheet()->setCellValue('G1',"申請項目");
$objPHPExcel->getActiveSheet()->setCellValue('H1',"案件開始日期");
$objPHPExcel->getActiveSheet()->setCellValue('I1',"結案日期");
$objPHPExcel->getActiveSheet()->setCellValue('J1',"案件處理時間(天)");
$objPHPExcel->getActiveSheet()->setCellValue('K1',"案件狀態");
$objPHPExcel->getActiveSheet()->getStyle("A1")->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("B1")->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("C1")->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("D1")->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("E1")->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("F1")->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("G1")->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("H1")->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("I1")->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("J1")->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$objPHPExcel->getActiveSheet()->getStyle("K1")->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
$Ecount=2;

while(list($PID,$PUID,$CID,$CName,$CTel,$CFax,$Contact,$CMobile,$CEMail,$CAddress,$PStatus,$PName,$ModelName,$SeriesModel,$PE,$PEName,$PEEName,$Quote,$ApplyItem,$Canon,$SNote,$StartDate,$PlanDate,$CloseDate,$ProcDate,$PNote,$QuoteDate,$ReturnDate)=mysqli_fetch_row($result_Project)){
  	if (trim($PStatus) == "A") $PStatus = "新開案";
  	else if (trim($PStatus) == "B") $PStatus = "報價中";
  	else if (trim($PStatus) == "C") $PStatus = "案件處理中";
  	else if (trim($PStatus) == "D") $PStatus = "審查中";
  	else if (trim($PStatus) == "E") $PStatus = "補件中";
  	else if (trim($PStatus) == "F") $PStatus = "待印證";
  	else if (trim($PStatus) == "G") $PStatus = "案件取消";
  	else if (trim($PStatus) == "H") $PStatus = "已結案";
	
	$objPHPExcel->getActiveSheet()->setCellValue('A'.$Ecount,$PUID);
	$objPHPExcel->getActiveSheet()->setCellValue('B'.$Ecount,$PEEName.$PEName);
	$objPHPExcel->getActiveSheet()->setCellValue('C'.$Ecount,$CName);
	$objPHPExcel->getActiveSheet()->setCellValue('D'.$Ecount,$PName);
	$objPHPExcel->getActiveSheet()->setCellValue('E'.$Ecount,$ModelName);
	$objPHPExcel->getActiveSheet()->setCellValue('F'.$Ecount,$SeriesModel);
	$objPHPExcel->getActiveSheet()->setCellValue('G'.$Ecount,$ApplyItem);
	$objPHPExcel->getActiveSheet()->setCellValue('H'.$Ecount,$StartDate);
	$objPHPExcel->getActiveSheet()->setCellValue('I'.$Ecount,$CloseDate);
	$objPHPExcel->getActiveSheet()->setCellValue('J'.$Ecount,$ProcDate);
	$objPHPExcel->getActiveSheet()->setCellValue('K'.$Ecount,$PStatus);
	$objPHPExcel->getActiveSheet()->getStyle('A'.$Ecount)->getFont()->setSize(12);
	$objPHPExcel->getActiveSheet()->getStyle('B'.$Ecount)->getFont()->setSize(12);
	$objPHPExcel->getActiveSheet()->getStyle('C'.$Ecount)->getFont()->setSize(12);
	$objPHPExcel->getActiveSheet()->getStyle('D'.$Ecount)->getFont()->setSize(12);
	$objPHPExcel->getActiveSheet()->getStyle('E'.$Ecount)->getFont()->setSize(12);
	$objPHPExcel->getActiveSheet()->getStyle('F'.$Ecount)->getFont()->setSize(12);
	$objPHPExcel->getActiveSheet()->getStyle('G'.$Ecount)->getFont()->setSize(12);
	$objPHPExcel->getActiveSheet()->getStyle('H'.$Ecount)->getFont()->setSize(12);
	$objPHPExcel->getActiveSheet()->getStyle('I'.$Ecount)->getFont()->setSize(12);
	$objPHPExcel->getActiveSheet()->getStyle('J'.$Ecount)->getFont()->setSize(12);
	$objPHPExcel->getActiveSheet()->getStyle('K'.$Ecount)->getFont()->setSize(12);
	$Ecount++;
}
mysqli_free_result($result_Project);
mysqli_close($link);

$objPHPExcel->getActiveSheet()->setTitle('Project');

ob_end_clean();

header('Content-Type: application/vnd.ms-excel');
header('Content-Disposition: attachment;filename="Project.xls"');
header('Cache-Control: max-age=0');
$objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel5');
$objWriter->save('php://output');
exit;


?>

	


