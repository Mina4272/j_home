﻿<?php
include "CheckPermission.php";
include "CheckProject.php";
include "../global.php";
require_once("../include/chinese_party.class.php");
require("class.phpmailer.php");
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $PageAdminTitle;?></title>
</head>
<body>
<?php


if(isset($_POST['code'])) {

	if($_POST['code'] == $_SESSION['code']){
	
	$_SESSION['code']+=1;
	
$PUID = $_POST['PUID'];
$CID = $_POST['CID'];
$CName = $_POST['CName'];
$CTel = $_POST['CTel'];
$CFax = $_POST['CFax'];
$CAddress = $_POST['CAddress'];
$Contact = $_POST['Contact'];
$CMobile = $_POST['CMobile'];
$CEMail = $_POST['CEMail'];
$PName = $_POST['PName'];
$ModelName = $_POST['ModelName'];
$SeriesModel = $_POST['SeriesModel'];
$PE = $_POST['PE'];
$test = $_POST['test'];
$ApplyItem = $_POST['ApplyItem'];
$Agent = $_POST['Agent'];
$Canon = $_POST['Canon'];
$StartYear = $_POST['StartYear'];
$StartMonth = $_POST['StartMonth'];
$StartDay = $_POST['StartDay'];
if (trim($StartYear) != "" || trim($StartMonth) != "" || trim($StartDay) != "") if (checkdate($StartMonth,$StartDay ,$StartYear)) $StartDate = $StartYear."-".$StartMonth."-".$StartDay;
$PlanYear = $_POST['PlanYear'];
$PlanMonth = $_POST['PlanMonth'];
$PlanDay = $_POST['PlanDay'];
if (trim($PlanYear) != "" || trim($PlanMonth) != "" || trim($PlanDay) != "") if (checkdate($PlanMonth,$PlanDay ,$PlanYear)) $PlanDate = $PlanYear."-".$PlanMonth."-".$PlanDay;
$SNote = $_POST['SNote'];
$PNote = $_POST['PNote'];
$PNote1 = $_POST['PNote1'];

$CCCCode = $_POST['CCCCode'];
$EMC = $_POST['EMC'];
$POther = $_POST['POther'];
$PAYear = $_POST['PAYear'];
$PAMonth = $_POST['PAMonth'];
$PADay = $_POST['PADay'];
if (trim($PAYear) != "" || trim($PAMonth) != "" || trim($PADay) != "") if (checkdate($PAMonth,$PADay ,$PAYear)) $PADate = $PAYear."-".$PAMonth."-".$PADay;

$PNoteYear = $_POST['PNoteYear'];
$PNoteMonth = $_POST['PNoteMonth'];
$PNoteDay = $_POST['PNoteDay'];
if (trim($PNoteYear) != "" || trim($PNoteMonth) != "" || trim($PNoteDay) != "") if (checkdate($PNoteMonth,$PNoteDay ,$PNoteYear)) $PNoteDate = $PNoteYear."-".$PNoteMonth."-".$PNoteDay;

if (trim($CID) == "" || trim($PName) == "")
		{
		mysqli_close($link);
		?>
		<script type="text/JavaScript">
			<!--
			alert ("您輸入的資料不足，請重新輸入！");
			history.go(-1);
			//-->
		</script>
		<?php
		exit;
		}
if (trim($PUID) != "") {
		$SQL_Project="select PUID from Project where Deltag='N' and PUID = '".$PUID."';";
		$result_Project=mysqli_query($link,$SQL_Project) or die ("無法執行查詢");
		if (mysqli_num_rows($result_Project) != 0)
				{
				mysqli_free_result($result_Project);
				mysqli_close($link);
				?>
				<SCRIPT language=javascript>
				<!--
				alert ("您輸入的合約編號重覆，請重新輸入！"); 
				history.go(-1);
				//-->
				</SCRIPT>
				<?php 	
				exit;
				}
		mysqli_free_result($result_Project);
		}
else {
		$PCDate = date("ymd");
		//echo "PCDate=$PCDate<br>";
		$now_time = date("Y-m-d H:i:s",mktime());
		$SQL_select="select PCount from ProjectCount where PCDate = '".$PCDate."';";
		$result_select=mysqli_query($link,$SQL_select) or die ("無法執行查詢");
		if (mysqli_num_rows($result_select) == 0)
				{
				$sql_insert = "insert into ProjectCount (PCDate,PCount) values ('".$PCDate."','2');";
				$result_insert=mysqli_query($link,$sql_insert) or die ("無法執行新增");
				$PCount = "1";
				}
		else
				{
				$sql_update = "update ProjectCount set PCount = PCount + 1 where PCDate = '".$PCDate."';";
				$result_update=mysqli_query($link,$sql_update) or die ("無法執行新增");
				list($PCount)=mysqli_fetch_row($result_select);
				}
		mysqli_free_result($result_select);
		
		//echo "PCount=$PCount<br>";
		if (strlen($PCount) < 2)
			{
			for ($i=1;$i=2-strlen($PCount);$i++)
				{
				$PCount = "0" . $PCount;
				}
			}
		$PUID = "B".$PCDate.$PCount;
		}

if (trim($StartDate)=="") $StartDate = "NULL";
else $StartDate = "'$StartDate'";
if (trim($PlanDate)=="") $PlanDate = "NULL";
else $PlanDate = "'$PlanDate'";
if (trim($PADate)=="") $PADate = "NULL";
else $PADate = "'$PADate'";
if (trim($PNoteDate)=="") $PNoteDate = "NULL";
else $PNoteDate = "'$PNoteDate'";

$now_time = date("Y-m-d H:i:s",mktime());
$sql_insert = "insert into Project (PUID,CID,CName,CTel,CFax,CAddress,Contact,CMobile,CEMail,PStatus,PName,ModelName,SeriesModel,PE,test,Quote,ApplyItem,Agent,Canon,CCCCode,SNote,StartDate,PlanDate,PNote,PNoteDate,EMC,POther,PADate,PNote1,AddUser,AddDate,AddIP) values ('".$PUID."','".$CID."','".$CName."','".$CTel."','".$CFax."','".$CAddress."','".$Contact."','".$CMobile."','".$CEMail."','A','".$PName."','".$ModelName."','".$SeriesModel."','".$PE."','".$test."','".$Quote."','".$ApplyItem."','".$Agent."','".$Canon."','".$CCCCode."','".$SNote."',".$StartDate.",".$PlanDate.",'".$PNote."',".$PNoteDate.",'".$EMC."','".$POther."',".$PADate.",'".$PNote1."','".$_SESSION["reg_MUID"]."','".$now_time."','".$_SERVER["REMOTE_ADDR"]."');";
$result_insert=mysqli_query($link,$sql_insert) or die ("無法執行新增");

$SQL_Manager="select MName from Manager where Deltag='N' and ISEngineer = 'Y' and MUID='".$PE."';";
$result_Manager=mysqli_query($link,$SQL_Manager) or die ("無法執行查詢");
list($MName)=mysqli_fetch_row($result_Manager);
mysqli_free_result($result_Manager);

$EMAILFN = "notify.htm";
$subject="全威驗證案件新增通知 ！！";
$fp=fopen($EMAILFN,"r");
$content="";
while($line=fgets($fp,512)){
	$content.=$line;
	}
fclose($fp);

$content = str_replace("{PUID}",$PUID,$content);
$content = str_replace("{PName}",$PName,$content);
$content = str_replace("{ModelName}",$ModelName,$content);
$content = str_replace("{CName}",$CName,$content);
$content = str_replace("{PE}",$MName,$content);

//$cconv = new chinese_party();
//$content = $cconv->u82tchi($content);
//$subject = $cconv->u82tchi($subject);

$mail = new PHPMailer();
$mail->IsSMTP();
$mail->SMTPAuth = true;
$mail->SMTPSecure = "ssl"; // Gmail的SMTP主機需要使用SSL連線
$mail->Host = "smtp.gmail.com"; //Gamil的SMTP主機
$mail->Port = 465; //Gamil的SMTP主機的埠號(Gmail為465)。
$mail->CharSet = "utf-8"; //郵件編碼
$mail->Username = "Benson@rpclab.com"; //Gamil帳號
$mail->Password = "76197619"; //Gmail密碼
$mail->From     = "Benson@rpclab.com";
$mail->FromName = $subject;
$mail->WordWrap = 50;
$mail->IsHTML(true);                               // send as HTML
$mail->Subject  = $subject;
$mail->Body     =  $content;
$mail->AddAddress("Benson@rpclab.com","");
$mail->AddReplyTo("Benson@rpclab.com");
if(!$mail->Send())
		{
    //echo "There has been a mail error sending to " . $SendEMail . "<br>";
    //echo "Mailer Error: " . $mail->ErrorInfo . "<br>";
  	}
else
		{
		//echo $SendEMail . " sending !!<br>";
		}
		
$mail->ClearAddresses();
$mail->ClearReplyTos();
$mail->SmtpClose();
mysqli_close($link);
}
}
?>
<script type="text/JavaScript">
	<!--
	alert ("新增成功！");
	location.href='ProjectList.php';
	//-->
</script>

</body>
</html>
