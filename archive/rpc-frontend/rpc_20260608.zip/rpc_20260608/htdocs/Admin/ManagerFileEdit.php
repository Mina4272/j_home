﻿<?php	
include "CheckPermission.php";
include "CheckManager.php";
include "../global.php";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $PageAdminTitle;?></title>
<link href="../type.css" rel="stylesheet" type="text/css" />
<style type="text/css">
<!--
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
}
-->
</style>
<link href="../script/DatePicker.css" rel="stylesheet" type="text/css" />
<Script LANGUAGE="Javascript" SRC="../script/DatePicker.js"></Script>
<Script type="text/javascript" language="javascript" src="../script/CheckForm.js"></Script>
<script type="text/JavaScript">
<!--
function jsCheck() 
		{
		if (ChkImp('MTitle',document.form1.MTitle.value,'檔案名稱') == false) return false;
		}
//-->
</script>
</head>
<body>
<?php
$MFID = $_GET['MFID'];
$MID = $_GET['MID'];
if (trim($MID) == "" || trim($MFID) == "")
		{
		mysqli_close($link);
		?>
		<script type="text/JavaScript">
			<!--
			alert ("查無資料，請冾網站管理人員！");
			self.close();
			//-->
		</script>
		<?php
		exit;
		}
$SQL_ManagerFile="select MTitle,MFile,AddUser,AddDate,ProcUser,ProcDate from ManagerFile where Deltag='N' and MID = '".$MID."' and MFID = '".$MFID."';";
$result_ManagerFile=mysqli_query($link,$SQL_ManagerFile) or die ("無法執行查詢");
if (mysqli_num_rows($result_ManagerFile) == 0)
		{
		mysqli_free_result($result_ManagerFile);
		mysqli_close($link);
		?>
		<SCRIPT language=javascript>
		<!--
		alert ("查無資料，請冾網站管理人員！"); 
		self.close();
		//-->
		</SCRIPT>
		<?php 	
		exit;
		}
list($MTitle,$MFile,$AddUser,$AddDate,$ProcUser,$ProcDate)=mysqli_fetch_row($result_ManagerFile);
mysqli_free_result($result_ManagerFile);
?>
<table width="100%" border="0" cellpadding="0" cellspacing="0">
	<tr>
		<td>
    	<table width="100%" border="0" cellpadding="0" cellspacing="0">
    		<tr height="30">
					<td width="15" background="../images/table_bg.gif"></td>
    			<td class="c3" background="../images/table_bg.gif"><b>修改員工檔案資料</b></td>
    		</tr>
    	</table>
    	<table width="100%" border="0" cellpadding="0" cellspacing="0">
        <form name="form1" method="post" action="ManagerFileEditDB.php" enctype="multipart/form-data" onSubmit="return jsCheck();">
        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
					<td width="15"></td>
          <td width="160" class="c3" align="right">檔案名稱：</td>
          <td class="c3">
          	<input id="MTitle" name="MTitle" type="text" size="20" value="<?php echo $MTitle;?>" />
          </td>
        </tr>
         <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
					<td width="15"></td>
          <td class="c3" align="right">証書檔案：</td>
          <td class="c3">
          	<input id="MFile" name="MFile" type="file" size="60" />
          	<input type="button" name="edit" value="下 載" class="input_bot" onclick="javascript:location.href='getfile.php?FolderName=Admin\\MFile&FileName=<?php echo $MFile;?>';">
          </td>
        </tr>
        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
					<td width="15"></td>
          <td align="right" class="c3">新增人員：</td>
          <td class="h3"><?php echo $AddUser;?>　<?php echo $AddDate;?></td>
        </tr>
        <?php if (trim($ProcUser) != "") {?>
        <tr height="30" onmouseout="style.backgroundColor='#ffffff';" onmouseover="style.backgroundColor='#F0F0F0';">
					<td width="15"></td>
          <td align="right" class="c3">最後更新：</td>
          <td class="h3"><?php echo $ProcUser;?>　<?php echo $ProcDate;?>
          	<input type="button" name="edit" value="歷史記錄" class="input_bot" onclick="javascript:window.open ('ManagerFileHistory.php?MID=<?php echo $MID;?>&MFID=<?php echo $MFID;?>','ManagerFileHistory','height=500,width=950,top=200,left=200,scrollbars=yes,status=yes');">
          </td>
        </tr>
        <?php }?>
        <tr height="40" align="center">
					<td width="15"></td>
          <td colspan="2" class="h3">
          	<input type="submit" name="submit" class="input_bot" value="送 出">
          	<input name="MFID" type="hidden" id="MFID" value="<?php echo $MFID;?>" />
          	<input name="MID" type="hidden" id="MID" value="<?php echo $MID;?>" />
          </td>
        </tr>
	      </form>
      </table>
		</td>
	</tr>
</table>
</body>
</html>
<?php
mysqli_close($link);
?>